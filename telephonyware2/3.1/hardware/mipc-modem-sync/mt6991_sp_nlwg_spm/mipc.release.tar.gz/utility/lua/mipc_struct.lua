require("mipc_enum")

local bytestostring = function (b, len)
    s = ""
    for i = 0, len-1 do
        s = s .. string.char(b:range(i,1):le_uint())
    end
    return s
end


mipc_unreference_struct_param = ProtoField.new("STRUCT", "mtkmipc.struct", ftypes.BYTES)
mipc_v4_full_addr_t_mtu = ProtoField.uint32   ("mtkmipc.struct.mtu", "mtu", base.DEC)
mipc_v4_full_addr_t_addr = ProtoField.new("addr", "mtkmipc.struct.addr", ftypes.BYTES)
mipc_v4_full_addr_t_mask = ProtoField.new("mask", "mtkmipc.struct.mask", ftypes.BYTES)
mipc_v6_full_addr_t_mtu = ProtoField.uint32   ("mtkmipc.struct.mtu", "mtu", base.DEC)
mipc_v6_full_addr_t_addr = ProtoField.new("addr", "mtkmipc.struct.addr", ftypes.BYTES)
mipc_v6_full_addr_t_prefix = ProtoField.uint32   ("mtkmipc.struct.prefix", "prefix", base.DEC)
mipc_addr_t_addr_len = ProtoField.uint32   ("mtkmipc.struct.addr_len", "addr_len", base.DEC)
mipc_addr_t_addr = ProtoField.new("addr", "mtkmipc.struct.addr", ftypes.BYTES)
mipc_full_addr_t_addr_len = ProtoField.uint32   ("mtkmipc.struct.addr_len", "addr_len", base.DEC)
mipc_full_addr_t_addr = ProtoField.new("addr", "mtkmipc.struct.addr", ftypes.BYTES)
mipc_full_addr_t_mtu = ProtoField.uint32   ("mtkmipc.struct.mtu", "mtu", base.DEC)
mipc_full_addr_t_mask = ProtoField.new("mask", "mtkmipc.struct.mask", ftypes.BYTES)
mipc_full_addr_t_prefix = ProtoField.uint32   ("mtkmipc.struct.prefix", "prefix", base.DEC)
mipc_apn_ia_t_apn = ProtoField.new("apn", "mtkmipc.struct.apn", ftypes.STRING)
mipc_apn_ia_t_apn_idx = ProtoField.uint32   ("mtkmipc.struct.apn_idx", "apn_idx", base.DEC)
mipc_apn_ia_t_userid = ProtoField.new("userid", "mtkmipc.struct.userid", ftypes.STRING)
mipc_apn_ia_t_password = ProtoField.new("password", "mtkmipc.struct.password", ftypes.STRING)
mipc_apn_ia_t_bearer_bitmask = ProtoField.uint32   ("mtkmipc.struct.bearer_bitmask", "bearer_bitmask", base.DEC)
mipc_apn_ia_t_pdp_type = ProtoField.uint8   ("mtkmipc.struct.pdp_type", "pdp_type", base.DEC, APN_PDP_TYPE)
mipc_apn_ia_t_roaming_type = ProtoField.uint8   ("mtkmipc.struct.roaming_type", "roaming_type", base.DEC, APN_PDP_TYPE)
mipc_apn_ia_t_auth_type = ProtoField.uint8   ("mtkmipc.struct.auth_type", "auth_type", base.DEC, APN_AUTH_TYPE)
mipc_apn_ia_t_compression = ProtoField.uint8   ("mtkmipc.struct.compression", "compression", base.DEC, APN_COMPRESSION)
mipc_apn_profile_t_id = ProtoField.uint32   ("mtkmipc.struct.id", "id", base.DEC)
mipc_apn_profile_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_apn_profile_t_reserved = ProtoField.uint8   ("mtkmipc.struct.reserved", "reserved", base.DEC)
mipc_apn_profile_t_apn = ProtoField.new("apn", "mtkmipc.struct.apn", ftypes.STRING)
mipc_apn_profile_t_apn_idx = ProtoField.uint32   ("mtkmipc.struct.apn_idx", "apn_idx", base.DEC)
mipc_apn_profile_t_userid = ProtoField.new("userid", "mtkmipc.struct.userid", ftypes.STRING)
mipc_apn_profile_t_password = ProtoField.new("password", "mtkmipc.struct.password", ftypes.STRING)
mipc_apn_profile_t_bearer_bitmask = ProtoField.uint32   ("mtkmipc.struct.bearer_bitmask", "bearer_bitmask", base.DEC)
mipc_apn_profile_t_apn_type = ProtoField.uint32   ("mtkmipc.struct.apn_type", "apn_type", base.DEC, APN_TYPE)
mipc_apn_profile_t_pdp_type = ProtoField.uint8   ("mtkmipc.struct.pdp_type", "pdp_type", base.DEC, APN_PDP_TYPE)
mipc_apn_profile_t_roaming_type = ProtoField.uint8   ("mtkmipc.struct.roaming_type", "roaming_type", base.DEC, APN_PDP_TYPE)
mipc_apn_profile_t_auth_type = ProtoField.uint8   ("mtkmipc.struct.auth_type", "auth_type", base.DEC, APN_AUTH_TYPE)
mipc_apn_profile_t_compression = ProtoField.uint8   ("mtkmipc.struct.compression", "compression", base.DEC, APN_COMPRESSION)
mipc_apn_profile_t_reserve1 = ProtoField.uint8   ("mtkmipc.struct.reserve1", "reserve1", base.DEC)
mipc_apn_profile_t_reserve2 = ProtoField.uint8   ("mtkmipc.struct.reserve2", "reserve2", base.DEC)
mipc_apn_profile_t_reserve3 = ProtoField.uint8   ("mtkmipc.struct.reserve3", "reserve3", base.DEC)
mipc_apn_profile_t_enabled = ProtoField.uint8   ("mtkmipc.struct.enabled", "enabled", base.DEC, APN_ENABLED_TYPE)
mipc_apn_profile_v2_t_id = ProtoField.uint32   ("mtkmipc.struct.id", "id", base.DEC)
mipc_apn_profile_v2_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_apn_profile_v2_t_reserved = ProtoField.uint8   ("mtkmipc.struct.reserved", "reserved", base.DEC)
mipc_apn_profile_v2_t_apn = ProtoField.new("apn", "mtkmipc.struct.apn", ftypes.STRING)
mipc_apn_profile_v2_t_apn_idx = ProtoField.uint32   ("mtkmipc.struct.apn_idx", "apn_idx", base.DEC)
mipc_apn_profile_v2_t_userid = ProtoField.new("userid", "mtkmipc.struct.userid", ftypes.STRING)
mipc_apn_profile_v2_t_password = ProtoField.new("password", "mtkmipc.struct.password", ftypes.STRING)
mipc_apn_profile_v2_t_bearer_bitmask = ProtoField.uint32   ("mtkmipc.struct.bearer_bitmask", "bearer_bitmask", base.DEC)
mipc_apn_profile_v2_t_apn_type = ProtoField.uint32   ("mtkmipc.struct.apn_type", "apn_type", base.DEC, APN_TYPE)
mipc_apn_profile_v2_t_pdp_type = ProtoField.uint8   ("mtkmipc.struct.pdp_type", "pdp_type", base.DEC, APN_PDP_TYPE)
mipc_apn_profile_v2_t_roaming_type = ProtoField.uint8   ("mtkmipc.struct.roaming_type", "roaming_type", base.DEC, APN_PDP_TYPE)
mipc_apn_profile_v2_t_auth_type = ProtoField.uint8   ("mtkmipc.struct.auth_type", "auth_type", base.DEC, APN_AUTH_TYPE)
mipc_apn_profile_v2_t_compression = ProtoField.uint8   ("mtkmipc.struct.compression", "compression", base.DEC, APN_COMPRESSION)
mipc_apn_profile_v2_t_enabled = ProtoField.uint8   ("mtkmipc.struct.enabled", "enabled", base.DEC, APN_ENABLED_TYPE)
mipc_apn_profile_v2_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_apn_profile_v2_t_max_conns = ProtoField.uint32   ("mtkmipc.struct.max_conns", "max_conns", base.DEC)
mipc_apn_profile_v2_t_max_conn_t = ProtoField.uint32   ("mtkmipc.struct.max_conn_t", "max_conn_t", base.DEC)
mipc_apn_profile_v2_t_wait_time = ProtoField.uint32   ("mtkmipc.struct.wait_time", "wait_time", base.DEC)
mipc_apn_profile_v2_t_inact_timer = ProtoField.uint32   ("mtkmipc.struct.inact_timer", "inact_timer", base.DEC)
mipc_apn_profile_v2_t_v4_mtu = ProtoField.uint32   ("mtkmipc.struct.v4_mtu", "v4_mtu", base.DEC)
mipc_apn_profile_v2_t_v6_mtu = ProtoField.uint32   ("mtkmipc.struct.v6_mtu", "v6_mtu", base.DEC)
mipc_md_apn_profile_t_id = ProtoField.uint32   ("mtkmipc.struct.id", "id", base.DEC)
mipc_md_apn_profile_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_md_apn_profile_t_act_state = ProtoField.uint8   ("mtkmipc.struct.act_state", "act_state", base.DEC)
mipc_md_apn_profile_t_apn = ProtoField.new("apn", "mtkmipc.struct.apn", ftypes.STRING)
mipc_md_apn_profile_t_apn_idx = ProtoField.uint32   ("mtkmipc.struct.apn_idx", "apn_idx", base.DEC)
mipc_md_apn_profile_t_userid = ProtoField.new("userid", "mtkmipc.struct.userid", ftypes.STRING)
mipc_md_apn_profile_t_password = ProtoField.new("password", "mtkmipc.struct.password", ftypes.STRING)
mipc_md_apn_profile_t_bearer_bitmask = ProtoField.uint32   ("mtkmipc.struct.bearer_bitmask", "bearer_bitmask", base.DEC)
mipc_md_apn_profile_t_apn_type = ProtoField.uint32   ("mtkmipc.struct.apn_type", "apn_type", base.DEC, APN_TYPE)
mipc_md_apn_profile_t_pdp_type = ProtoField.uint8   ("mtkmipc.struct.pdp_type", "pdp_type", base.DEC, APN_PDP_TYPE)
mipc_md_apn_profile_t_roaming_type = ProtoField.uint8   ("mtkmipc.struct.roaming_type", "roaming_type", base.DEC, APN_PDP_TYPE)
mipc_md_apn_profile_t_auth_type = ProtoField.uint8   ("mtkmipc.struct.auth_type", "auth_type", base.DEC, APN_AUTH_TYPE)
mipc_md_apn_profile_t_reserve = ProtoField.uint8   ("mtkmipc.struct.reserve", "reserve", base.DEC)
mipc_op12_apn_profile_legacy_t_apn = ProtoField.new("apn", "mtkmipc.struct.apn", ftypes.STRING)
mipc_op12_apn_profile_legacy_t_apnb = ProtoField.new("apnb", "mtkmipc.struct.apnb", ftypes.STRING)
mipc_op12_apn_profile_legacy_t_pdp_type = ProtoField.uint8   ("mtkmipc.struct.pdp_type", "pdp_type", base.DEC, APN_PDP_TYPE)
mipc_op12_apn_profile_legacy_t_id = ProtoField.uint8   ("mtkmipc.struct.id", "id", base.DEC)
mipc_op12_apn_profile_legacy_t_apnclass = ProtoField.uint8   ("mtkmipc.struct.apnclass", "apnclass", base.DEC, APN_AUTH_TYPE)
mipc_op12_apn_profile_legacy_t_enabled = ProtoField.uint8   ("mtkmipc.struct.enabled", "enabled", base.DEC, APN_ENABLED_TYPE)
mipc_op12_apn_profile_legacy_t_max_conn = ProtoField.uint8   ("mtkmipc.struct.max_conn", "max_conn", base.DEC)
mipc_op12_apn_profile_legacy_t_max_conn_t = ProtoField.uint8   ("mtkmipc.struct.max_conn_t", "max_conn_t", base.DEC)
mipc_op12_apn_profile_legacy_t_wait_time = ProtoField.uint32   ("mtkmipc.struct.wait_time", "wait_time", base.DEC)
mipc_op12_apn_profile_legacy_t_act_state = ProtoField.uint8   ("mtkmipc.struct.act_state", "act_state", base.DEC)
mipc_op12_apn_profile_legacy_t_reserve1 = ProtoField.uint8   ("mtkmipc.struct.reserve1", "reserve1", base.DEC)
mipc_op12_apn_profile_legacy_t_reserve2 = ProtoField.uint8   ("mtkmipc.struct.reserve2", "reserve2", base.DEC)
mipc_op12_apn_profile_legacy_t_reserve3 = ProtoField.uint8   ("mtkmipc.struct.reserve3", "reserve3", base.DEC)
mipc_op12_apn_profile_t_apn = ProtoField.new("apn", "mtkmipc.struct.apn", ftypes.STRING)
mipc_op12_apn_profile_t_apn_bear = ProtoField.new("apn_bear", "mtkmipc.struct.apn_bear", ftypes.STRING)
mipc_op12_apn_profile_t_pdp_type = ProtoField.uint8   ("mtkmipc.struct.pdp_type", "pdp_type", base.DEC, APN_PDP_TYPE)
mipc_op12_apn_profile_t_act_state = ProtoField.uint8   ("mtkmipc.struct.act_state", "act_state", base.DEC)
mipc_op12_apn_profile_t_id = ProtoField.uint32   ("mtkmipc.struct.id", "id", base.DEC)
mipc_op12_apn_profile_t_apn_class = ProtoField.uint32   ("mtkmipc.struct.apn_class", "apn_class", base.DEC, APN_AUTH_TYPE)
mipc_op12_apn_profile_t_enabled = ProtoField.uint32   ("mtkmipc.struct.enabled", "enabled", base.DEC, APN_ENABLED_TYPE)
mipc_op12_apn_profile_t_max_conn = ProtoField.uint32   ("mtkmipc.struct.max_conn", "max_conn", base.DEC)
mipc_op12_apn_profile_t_max_conn_t = ProtoField.uint32   ("mtkmipc.struct.max_conn_t", "max_conn_t", base.DEC)
mipc_op12_apn_profile_t_wait_time = ProtoField.uint32   ("mtkmipc.struct.wait_time", "wait_time", base.DEC)
mipc_data_nitz_info_t_year = ProtoField.uint32   ("mtkmipc.struct.year", "year", base.DEC)
mipc_data_nitz_info_t_month = ProtoField.uint32   ("mtkmipc.struct.month", "month", base.DEC)
mipc_data_nitz_info_t_day = ProtoField.uint32   ("mtkmipc.struct.day", "day", base.DEC)
mipc_data_nitz_info_t_hour = ProtoField.uint32   ("mtkmipc.struct.hour", "hour", base.DEC)
mipc_data_nitz_info_t_minute = ProtoField.uint32   ("mtkmipc.struct.minute", "minute", base.DEC)
mipc_data_nitz_info_t_second = ProtoField.uint32   ("mtkmipc.struct.second", "second", base.DEC)
mipc_data_v4_addr_t_addr = ProtoField.new("addr", "mtkmipc.struct.addr", ftypes.BYTES)
mipc_data_v6_addr_t_addr = ProtoField.new("addr", "mtkmipc.struct.addr", ftypes.BYTES)
mipc_data_pco_ie_t_ie = ProtoField.new("ie", "mtkmipc.struct.ie", ftypes.STRING)
mipc_data_pco_ie_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_data_pco_ie_t_content = ProtoField.new("content", "mtkmipc.struct.content", ftypes.STRING)
mipc_data_ran_result_t_ran = ProtoField.uint8   ("mtkmipc.struct.ran", "ran", base.DEC, RAN)
mipc_data_ran_result_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_data_ran_result_t_deact_cause = ProtoField.uint32   ("mtkmipc.struct.deact_cause", "deact_cause", base.DEC, RESULT)
mipc_data_ran_result_t_modify_cause = ProtoField.uint32   ("mtkmipc.struct.modify_cause", "modify_cause", base.DEC, RESULT)
mipc_tmgi_struct_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_tmgi_struct_t_service_id = ProtoField.new("service_id", "mtkmipc.struct.service_id", ftypes.BYTES)
mipc_mbs_session_info_t_op = ProtoField.uint16   ("mtkmipc.struct.op", "op", base.DEC, MBS_OP)
mipc_mbs_session_info_t_sesson_id_type = ProtoField.uint16   ("mtkmipc.struct.sesson_id_type", "sesson_id_type", base.DEC, MBS_SESSION_ID_TYPE)
mipc_mbs_session_info_t_src_ip_addr = ProtoField.new("src_ip_addr", "mtkmipc.struct.src_ip_addr", ftypes.BYTES)
mipc_mbs_session_info_t_dest_ip_addr = ProtoField.new("dest_ip_addr", "mtkmipc.struct.dest_ip_addr", ftypes.BYTES)
mipc_mbs_session_update_ind_t_psi = ProtoField.uint16   ("mtkmipc.struct.psi", "psi", base.DEC)
mipc_mbs_session_update_ind_t_ip_addr_present = ProtoField.uint16   ("mtkmipc.struct.ip_addr_present", "ip_addr_present", base.DEC)
mipc_mbs_session_update_ind_t_src_ip_addr = ProtoField.new("src_ip_addr", "mtkmipc.struct.src_ip_addr", ftypes.BYTES)
mipc_mbs_session_update_ind_t_dest_ip_addr = ProtoField.new("dest_ip_addr", "mtkmipc.struct.dest_ip_addr", ftypes.BYTES)
mipc_mbs_session_update_ind_t_mbs_decision = ProtoField.uint16   ("mtkmipc.struct.mbs_decision", "mbs_decision", base.DEC, MBS_DECISION)
mipc_mbs_session_update_ind_t_reject_cause = ProtoField.uint16   ("mtkmipc.struct.reject_cause", "reject_cause", base.DEC, MBS_REJECT_CAUSE)
mipc_mbs_session_update_ind_t_mbs_sec_container_raw_present = ProtoField.uint16   ("mtkmipc.struct.mbs_sec_container_raw_present", "mbs_sec_container_raw_present", base.DEC)
mipc_mbs_session_update_ind_t_mbs_sec_container_raw = ProtoField.new("mbs_sec_container_raw", "mtkmipc.struct.mbs_sec_container_raw", ftypes.BYTES)
mipc_mbs_session_update_ind_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_cell_global_id_struct_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_cell_global_id_struct_t_cell_id = ProtoField.new("cell_id", "mtkmipc.struct.cell_id", ftypes.BYTES)
mipc_tac_struct_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_tac_struct_t_ta_code = ProtoField.new("ta_code", "mtkmipc.struct.ta_code", ftypes.BYTES)
mipc_data_packet_filter_t_len = ProtoField.uint8   ("mtkmipc.struct.len", "len", base.DEC)
mipc_data_packet_filter_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_data_packet_filter_t_pattern = ProtoField.new("pattern", "mtkmipc.struct.pattern", ftypes.BYTES)
mipc_data_packet_filter_t_mask = ProtoField.new("mask", "mtkmipc.struct.mask", ftypes.BYTES)
mipc_data_secondary_pdp_context_present_info_t_cid_present = ProtoField.uint8   ("mtkmipc.struct.cid_present", "cid_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_present_info_t_p_cid_present = ProtoField.uint8   ("mtkmipc.struct.p_cid_present", "p_cid_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_present_info_t_bearer_id_present = ProtoField.uint8   ("mtkmipc.struct.bearer_id_present", "bearer_id_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_present_info_t_im_cn_signalling_flag_present = ProtoField.uint8   ("mtkmipc.struct.im_cn_signalling_flag_present", "IM_CN_Signalling_Flag_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_present_info_t_wlan_offload_present = ProtoField.uint8   ("mtkmipc.struct.wlan_offload_present", "WLAN_Offload_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_present_info_t_pdu_session_id_present = ProtoField.uint8   ("mtkmipc.struct.pdu_session_id_present", "PDU_session_id_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_present_info_t_qfi_present = ProtoField.uint8   ("mtkmipc.struct.qfi_present", "QFI_present", base.DEC, BOOLEAN)
mipc_data_secondary_pdp_context_info_t_cid = ProtoField.uint8   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_secondary_pdp_context_info_t_p_cid = ProtoField.uint8   ("mtkmipc.struct.p_cid", "p_cid", base.DEC)
mipc_data_secondary_pdp_context_info_t_bearer_id = ProtoField.uint8   ("mtkmipc.struct.bearer_id", "bearer_id", base.DEC)
mipc_data_secondary_pdp_context_info_t_im_cn_signalling_flag = ProtoField.uint8   ("mtkmipc.struct.im_cn_signalling_flag", "IM_CN_Signalling_Flag", base.DEC)
mipc_data_secondary_pdp_context_info_t_wlan_offload = ProtoField.uint8   ("mtkmipc.struct.wlan_offload", "WLAN_Offload", base.DEC)
mipc_data_secondary_pdp_context_info_t_pdu_session_id = ProtoField.uint8   ("mtkmipc.struct.pdu_session_id", "PDU_session_id", base.DEC)
mipc_data_secondary_pdp_context_info_t_qfi = ProtoField.uint16   ("mtkmipc.struct.qfi", "QFI", base.DEC)
mipc_mipi_device_t_instance_id = ProtoField.uint8   ("mtkmipc.struct.instance_id", "instance_id", base.DEC)
mipc_mipi_device_t_trans_port = ProtoField.uint8   ("mtkmipc.struct.trans_port", "trans_port", base.DEC)
mipc_mipi_device_t_mipi_port = ProtoField.uint8   ("mtkmipc.struct.mipi_port", "mipi_port", base.DEC)
mipc_mipi_device_t_usid = ProtoField.uint8   ("mtkmipc.struct.usid", "usid", base.DEC)
mipc_mipi_device_t_mid = ProtoField.uint16   ("mtkmipc.struct.mid", "mid", base.DEC)
mipc_mipi_device_t_pid = ProtoField.uint16   ("mtkmipc.struct.pid", "pid", base.DEC)
mipc_mipi_device_t_hw_mid = ProtoField.uint16   ("mtkmipc.struct.hw_mid", "hw_mid", base.DEC)
mipc_mipi_device_t_hw_pid = ProtoField.uint16   ("mtkmipc.struct.hw_pid", "hw_pid", base.DEC)
mipc_data_qos_info_t_cid = ProtoField.uint16   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_qos_info_t_qci = ProtoField.uint16   ("mtkmipc.struct.qci", "QCI", base.DEC)
mipc_data_qos_info_t_dl_gbr = ProtoField.uint32   ("mtkmipc.struct.dl_gbr", "DL_GBR", base.DEC)
mipc_data_qos_info_t_ul_gbr = ProtoField.uint32   ("mtkmipc.struct.ul_gbr", "UL_GBR", base.DEC)
mipc_data_qos_info_t_dl_mbr = ProtoField.uint32   ("mtkmipc.struct.dl_mbr", "DL_MBR", base.DEC)
mipc_data_qos_info_t_ul_mbr = ProtoField.uint32   ("mtkmipc.struct.ul_mbr", "UL_MBR", base.DEC)
mipc_data_qos_info_t_dl_ambr = ProtoField.uint32   ("mtkmipc.struct.dl_ambr", "DL_AMBR", base.DEC)
mipc_data_qos_info_t_ul_ambr = ProtoField.uint32   ("mtkmipc.struct.ul_ambr", "UL_AMBR", base.DEC)
mipc_data_5gqos_info_t_cid = ProtoField.uint16   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_5gqos_info_t_vqi = ProtoField.uint16   ("mtkmipc.struct.vqi", "VQI", base.DEC)
mipc_data_5gqos_info_t_dl_gfbr = ProtoField.uint64   ("mtkmipc.struct.dl_gfbr", "DL_GFBR", base.DEC)
mipc_data_5gqos_info_t_ul_gfbr = ProtoField.uint64   ("mtkmipc.struct.ul_gfbr", "UL_GFBR", base.DEC)
mipc_data_5gqos_info_t_dl_mfbr = ProtoField.uint64   ("mtkmipc.struct.dl_mfbr", "DL_MFBR", base.DEC)
mipc_data_5gqos_info_t_ul_mfbr = ProtoField.uint64   ("mtkmipc.struct.ul_mfbr", "UL_MFBR", base.DEC)
mipc_data_5gqos_info_t_dl_sambr = ProtoField.uint64   ("mtkmipc.struct.dl_sambr", "DL_SAMBR", base.DEC)
mipc_data_5gqos_info_t_ul_sambr = ProtoField.uint64   ("mtkmipc.struct.ul_sambr", "UL_SAMBR", base.DEC)
mipc_data_5gqos_info_t_averaging_window = ProtoField.uint32   ("mtkmipc.struct.averaging_window", "Averaging_window", base.DEC)
mipc_data_tft_info_t_cid = ProtoField.uint8   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_tft_info_t_packet_filter_identifier = ProtoField.uint8   ("mtkmipc.struct.packet_filter_identifier", "packet_filter_identifier", base.DEC)
mipc_data_tft_info_t_evaluation_precedence_index = ProtoField.uint8   ("mtkmipc.struct.evaluation_precedence_index", "evaluation_precedence_index", base.DEC)
mipc_data_tft_info_t_remote_v4_addr_present = ProtoField.uint8   ("mtkmipc.struct.remote_v4_addr_present", "remote_v4_addr_present", base.DEC)
mipc_data_tft_info_t_remote_v6_addr_present = ProtoField.uint8   ("mtkmipc.struct.remote_v6_addr_present", "remote_v6_addr_present", base.DEC)
mipc_data_tft_info_t_protocol_number_next_header = ProtoField.uint8   ("mtkmipc.struct.protocol_number_next_header", "protocol_number_next_header", base.DEC)
mipc_data_tft_info_t_tos_traffic_class = ProtoField.uint8   ("mtkmipc.struct.tos_traffic_class", "tos_traffic_class", base.DEC)
mipc_data_tft_info_t_tos_mask = ProtoField.uint8   ("mtkmipc.struct.tos_mask", "tos_mask", base.DEC)
mipc_data_tft_info_t_direction = ProtoField.uint8   ("mtkmipc.struct.direction", "direction", base.DEC)
mipc_data_tft_info_t_nw_packet_filter_identifier = ProtoField.uint8   ("mtkmipc.struct.nw_packet_filter_identifier", "NW_packet_filter_identifier", base.DEC)
mipc_data_tft_info_t_local_v4_addr_present = ProtoField.uint8   ("mtkmipc.struct.local_v4_addr_present", "local_v4_addr_present", base.DEC)
mipc_data_tft_info_t_local_v6_addr_present = ProtoField.uint8   ("mtkmipc.struct.local_v6_addr_present", "local_v6_addr_present", base.DEC)
mipc_data_tft_info_t_remote_v4_addr = ProtoField.uint8   ("mtkmipc.struct.remote_v4_addr", "remote_v4_addr", base.DEC)
mipc_data_tft_info_t_remote_v4_subnet_mask = ProtoField.uint8   ("mtkmipc.struct.remote_v4_subnet_mask", "remote_v4_subnet_mask", base.DEC)
mipc_data_tft_info_t_remote_v6_addr = ProtoField.uint8   ("mtkmipc.struct.remote_v6_addr", "remote_v6_addr", base.DEC)
mipc_data_tft_info_t_remote_v6_subnet_mask = ProtoField.uint8   ("mtkmipc.struct.remote_v6_subnet_mask", "remote_v6_subnet_mask", base.DEC)
mipc_data_tft_info_t_local_port_low = ProtoField.uint16   ("mtkmipc.struct.local_port_low", "local_port_low", base.DEC)
mipc_data_tft_info_t_local_port_high = ProtoField.uint16   ("mtkmipc.struct.local_port_high", "local_port_high", base.DEC)
mipc_data_tft_info_t_remote_port_low = ProtoField.uint16   ("mtkmipc.struct.remote_port_low", "remote_port_low", base.DEC)
mipc_data_tft_info_t_remote_port_high = ProtoField.uint16   ("mtkmipc.struct.remote_port_high", "remote_port_high", base.DEC)
mipc_data_tft_info_t_ipsec_spi = ProtoField.uint32   ("mtkmipc.struct.ipsec_spi", "ipsec_spi", base.DEC)
mipc_data_tft_info_t_flow_label = ProtoField.uint32   ("mtkmipc.struct.flow_label", "flow_label", base.DEC)
mipc_data_tft_info_t_local_v4_addr = ProtoField.uint8   ("mtkmipc.struct.local_v4_addr", "local_v4_addr", base.DEC)
mipc_data_tft_info_t_local_v4_subnet_mask = ProtoField.uint8   ("mtkmipc.struct.local_v4_subnet_mask", "local_v4_subnet_mask", base.DEC)
mipc_data_tft_info_t_local_v6_addr = ProtoField.uint8   ("mtkmipc.struct.local_v6_addr", "local_v6_addr", base.DEC)
mipc_data_tft_info_t_local_v6_subnet_mask = ProtoField.uint8   ("mtkmipc.struct.local_v6_subnet_mask", "local_v6_subnet_mask", base.DEC)
mipc_data_tft_info_t_qri = ProtoField.uint32   ("mtkmipc.struct.qri", "QRI", base.DEC)
mipc_data_tft_info_t_dest_mac_addr_present = ProtoField.uint16   ("mtkmipc.struct.dest_mac_addr_present", "dest_MAC_addr_present", base.DEC)
mipc_data_tft_info_t_src_mac_addr_present = ProtoField.uint16   ("mtkmipc.struct.src_mac_addr_present", "src_MAC_addr_present", base.DEC)
mipc_data_tft_info_t_dest_mac_addr = ProtoField.uint8   ("mtkmipc.struct.dest_mac_addr", "dest_MAC_addr", base.DEC)
mipc_data_tft_info_t_src_mac_addr = ProtoField.uint8   ("mtkmipc.struct.src_mac_addr", "src_MAC_addr", base.DEC)
mipc_data_tft_info_t_c_tag_vid = ProtoField.uint16   ("mtkmipc.struct.c_tag_vid", "C_TAG_VID", base.DEC)
mipc_data_tft_info_t_s_tag_vid = ProtoField.uint16   ("mtkmipc.struct.s_tag_vid", "S_TAG_VID", base.DEC)
mipc_data_tft_info_t_c_tag_pcp_dei = ProtoField.uint8   ("mtkmipc.struct.c_tag_pcp_dei", "C_TAG_PCP_DEI", base.DEC)
mipc_data_tft_info_t_s_tag_pcp_dei = ProtoField.uint8   ("mtkmipc.struct.s_tag_pcp_dei", "S_TAG_PCP_DEI", base.DEC)
mipc_data_tft_info_t_ethertype = ProtoField.uint16   ("mtkmipc.struct.ethertype", "ethertype", base.DEC)
mipc_data_tft_info_t_packet_filter_identifier_present = ProtoField.uint8   ("mtkmipc.struct.packet_filter_identifier_present", "packet_filter_identifier_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_evaluation_precedence_index_present = ProtoField.uint8   ("mtkmipc.struct.evaluation_precedence_index_present", "evaluation_precedence_index_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_protocol_number_next_header_present = ProtoField.uint8   ("mtkmipc.struct.protocol_number_next_header_present", "protocol_number_next_header_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_ipsec_spi_present = ProtoField.uint8   ("mtkmipc.struct.ipsec_spi_present", "ipsec_spi_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_tos_traffic_class_and_mask_present = ProtoField.uint8   ("mtkmipc.struct.tos_traffic_class_and_mask_present", "tos_traffic_class_and_mask_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_flow_label_present = ProtoField.uint8   ("mtkmipc.struct.flow_label_present", "flow_label_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_direction_present = ProtoField.uint8   ("mtkmipc.struct.direction_present", "direction_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_nw_packet_filter_identifier_present = ProtoField.uint8   ("mtkmipc.struct.nw_packet_filter_identifier_present", "NW_packet_filter_Identifier_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_qri_present = ProtoField.uint8   ("mtkmipc.struct.qri_present", "QRI_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_c_tag_vid_present = ProtoField.uint8   ("mtkmipc.struct.c_tag_vid_present", "C_TAG_VID_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_s_tag_vid_present = ProtoField.uint8   ("mtkmipc.struct.s_tag_vid_present", "S_TAG_VID_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_c_tag_pcp_dei_present = ProtoField.uint8   ("mtkmipc.struct.c_tag_pcp_dei_present", "C_TAG_PCP_DEI_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_s_tag_pcp_dei_present = ProtoField.uint8   ("mtkmipc.struct.s_tag_pcp_dei_present", "S_TAG_PCP_DEI_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_ethertype_present = ProtoField.uint8   ("mtkmipc.struct.ethertype_present", "ethertype_present", base.DEC, BOOLEAN)
mipc_data_tft_info_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_data_tft_info_v1_t_cid = ProtoField.uint8   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_tft_info_v1_t_packet_filter_identifier_present = ProtoField.uint8   ("mtkmipc.struct.packet_filter_identifier_present", "packet_filter_identifier_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_packet_filter_identifier = ProtoField.uint8   ("mtkmipc.struct.packet_filter_identifier", "packet_filter_identifier", base.DEC)
mipc_data_tft_info_v1_t_evaluation_precedence_index_present = ProtoField.uint8   ("mtkmipc.struct.evaluation_precedence_index_present", "evaluation_precedence_index_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_evaluation_precedence_index = ProtoField.uint8   ("mtkmipc.struct.evaluation_precedence_index", "evaluation_precedence_index", base.DEC)
mipc_data_tft_info_v1_t_remote_v4_addr_present = ProtoField.uint8   ("mtkmipc.struct.remote_v4_addr_present", "remote_v4_addr_present", base.DEC)
mipc_data_tft_info_v1_t_remote_v4_addr = ProtoField.uint8   ("mtkmipc.struct.remote_v4_addr", "remote_v4_addr", base.DEC)
mipc_data_tft_info_v1_t_remote_v4_subnet_mask = ProtoField.uint8   ("mtkmipc.struct.remote_v4_subnet_mask", "remote_v4_subnet_mask", base.DEC)
mipc_data_tft_info_v1_t_remote_v6_addr_present = ProtoField.uint8   ("mtkmipc.struct.remote_v6_addr_present", "remote_v6_addr_present", base.DEC)
mipc_data_tft_info_v1_t_remote_v6_addr = ProtoField.uint8   ("mtkmipc.struct.remote_v6_addr", "remote_v6_addr", base.DEC)
mipc_data_tft_info_v1_t_remote_v6_prefix = ProtoField.uint8   ("mtkmipc.struct.remote_v6_prefix", "remote_v6_prefix", base.DEC)
mipc_data_tft_info_v1_t_protocol_number_next_header_present = ProtoField.uint8   ("mtkmipc.struct.protocol_number_next_header_present", "protocol_number_next_header_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_protocol_number_next_header = ProtoField.uint8   ("mtkmipc.struct.protocol_number_next_header", "protocol_number_next_header", base.DEC)
mipc_data_tft_info_v1_t_padding1 = ProtoField.uint8   ("mtkmipc.struct.padding1", "padding1", base.DEC)
mipc_data_tft_info_v1_t_local_port_low = ProtoField.uint16   ("mtkmipc.struct.local_port_low", "local_port_low", base.DEC)
mipc_data_tft_info_v1_t_local_port_high = ProtoField.uint16   ("mtkmipc.struct.local_port_high", "local_port_high", base.DEC)
mipc_data_tft_info_v1_t_remote_port_low = ProtoField.uint16   ("mtkmipc.struct.remote_port_low", "remote_port_low", base.DEC)
mipc_data_tft_info_v1_t_remote_port_high = ProtoField.uint16   ("mtkmipc.struct.remote_port_high", "remote_port_high", base.DEC)
mipc_data_tft_info_v1_t_ipsec_spi_present = ProtoField.uint8   ("mtkmipc.struct.ipsec_spi_present", "ipsec_spi_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_padding2 = ProtoField.uint8   ("mtkmipc.struct.padding2", "padding2", base.DEC)
mipc_data_tft_info_v1_t_ipsec_spi = ProtoField.uint32   ("mtkmipc.struct.ipsec_spi", "ipsec_spi", base.DEC)
mipc_data_tft_info_v1_t_tos_traffic_class_and_mask_present = ProtoField.uint8   ("mtkmipc.struct.tos_traffic_class_and_mask_present", "tos_traffic_class_and_mask_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_tos_traffic_class = ProtoField.uint8   ("mtkmipc.struct.tos_traffic_class", "tos_traffic_class", base.DEC)
mipc_data_tft_info_v1_t_tos_mask = ProtoField.uint8   ("mtkmipc.struct.tos_mask", "tos_mask", base.DEC)
mipc_data_tft_info_v1_t_flow_label_present = ProtoField.uint8   ("mtkmipc.struct.flow_label_present", "flow_label_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_flow_label = ProtoField.uint32   ("mtkmipc.struct.flow_label", "flow_label", base.DEC)
mipc_data_tft_info_v1_t_direction_present = ProtoField.uint8   ("mtkmipc.struct.direction_present", "direction_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_direction = ProtoField.uint8   ("mtkmipc.struct.direction", "direction", base.DEC)
mipc_data_tft_info_v1_t_nw_packet_filter_identifier_present = ProtoField.uint8   ("mtkmipc.struct.nw_packet_filter_identifier_present", "NW_packet_filter_Identifier_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_nw_packet_filter_identifier = ProtoField.uint8   ("mtkmipc.struct.nw_packet_filter_identifier", "NW_packet_filter_identifier", base.DEC)
mipc_data_tft_info_v1_t_local_v4_addr_present = ProtoField.uint8   ("mtkmipc.struct.local_v4_addr_present", "local_v4_addr_present", base.DEC)
mipc_data_tft_info_v1_t_local_v4_addr = ProtoField.uint8   ("mtkmipc.struct.local_v4_addr", "local_v4_addr", base.DEC)
mipc_data_tft_info_v1_t_local_v4_subnet_mask = ProtoField.uint8   ("mtkmipc.struct.local_v4_subnet_mask", "local_v4_subnet_mask", base.DEC)
mipc_data_tft_info_v1_t_local_v6_addr_present = ProtoField.uint8   ("mtkmipc.struct.local_v6_addr_present", "local_v6_addr_present", base.DEC)
mipc_data_tft_info_v1_t_local_v6_addr = ProtoField.uint8   ("mtkmipc.struct.local_v6_addr", "local_v6_addr", base.DEC)
mipc_data_tft_info_v1_t_local_v6_prefix = ProtoField.uint8   ("mtkmipc.struct.local_v6_prefix", "local_v6_prefix", base.DEC)
mipc_data_tft_info_v1_t_qri_present = ProtoField.uint8   ("mtkmipc.struct.qri_present", "QRI_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_padding3 = ProtoField.uint8   ("mtkmipc.struct.padding3", "padding3", base.DEC)
mipc_data_tft_info_v1_t_qri = ProtoField.uint32   ("mtkmipc.struct.qri", "QRI", base.DEC)
mipc_data_tft_info_v1_t_dest_mac_addr_present = ProtoField.uint16   ("mtkmipc.struct.dest_mac_addr_present", "dest_MAC_addr_present", base.DEC)
mipc_data_tft_info_v1_t_dest_mac_addr = ProtoField.uint8   ("mtkmipc.struct.dest_mac_addr", "dest_MAC_addr", base.DEC)
mipc_data_tft_info_v1_t_src_mac_addr_present = ProtoField.uint16   ("mtkmipc.struct.src_mac_addr_present", "src_MAC_addr_present", base.DEC)
mipc_data_tft_info_v1_t_src_mac_addr = ProtoField.uint8   ("mtkmipc.struct.src_mac_addr", "src_MAC_addr", base.DEC)
mipc_data_tft_info_v1_t_c_tag_vid_present = ProtoField.uint8   ("mtkmipc.struct.c_tag_vid_present", "C_TAG_VID_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_padding4 = ProtoField.uint8   ("mtkmipc.struct.padding4", "padding4", base.DEC)
mipc_data_tft_info_v1_t_c_tag_vid = ProtoField.uint16   ("mtkmipc.struct.c_tag_vid", "C_TAG_VID", base.DEC)
mipc_data_tft_info_v1_t_s_tag_vid_present = ProtoField.uint8   ("mtkmipc.struct.s_tag_vid_present", "S_TAG_VID_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_padding5 = ProtoField.uint8   ("mtkmipc.struct.padding5", "padding5", base.DEC)
mipc_data_tft_info_v1_t_s_tag_vid = ProtoField.uint16   ("mtkmipc.struct.s_tag_vid", "S_TAG_VID", base.DEC)
mipc_data_tft_info_v1_t_c_tag_pcp_dei_present = ProtoField.uint8   ("mtkmipc.struct.c_tag_pcp_dei_present", "C_TAG_PCP_DEI_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_c_tag_pcp_dei = ProtoField.uint8   ("mtkmipc.struct.c_tag_pcp_dei", "C_TAG_PCP_DEI", base.DEC)
mipc_data_tft_info_v1_t_s_tag_pcp_dei_present = ProtoField.uint8   ("mtkmipc.struct.s_tag_pcp_dei_present", "S_TAG_PCP_DEI_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_s_tag_pcp_dei = ProtoField.uint8   ("mtkmipc.struct.s_tag_pcp_dei", "S_TAG_PCP_DEI", base.DEC)
mipc_data_tft_info_v1_t_ethertype_present = ProtoField.uint8   ("mtkmipc.struct.ethertype_present", "ethertype_present", base.DEC, BOOLEAN)
mipc_data_tft_info_v1_t_padding6 = ProtoField.uint8   ("mtkmipc.struct.padding6", "padding6", base.DEC)
mipc_data_tft_info_v1_t_ethertype = ProtoField.uint16   ("mtkmipc.struct.ethertype", "ethertype", base.DEC)
mipc_data_start_keepalive_request_t_type = ProtoField.uint32   ("mtkmipc.struct.type", "type", base.DEC, DATA_KEEPALIVE_TYPE)
mipc_data_start_keepalive_request_t_sourceport = ProtoField.uint32   ("mtkmipc.struct.sourceport", "sourcePort", base.DEC)
mipc_data_start_keepalive_request_t_destinationport = ProtoField.uint32   ("mtkmipc.struct.destinationport", "destinationPort", base.DEC)
mipc_data_start_keepalive_request_t_maxkeepaliveintervalmillis = ProtoField.uint32   ("mtkmipc.struct.maxkeepaliveintervalmillis", "maxKeepaliveIntervalMillis", base.DEC)
mipc_data_start_keepalive_request_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_start_keepalive_request_t_sourceaddress = ProtoField.new("sourceAddress", "mtkmipc.struct.sourceaddress", ftypes.STRING)
mipc_data_start_keepalive_request_t_destinationaddress = ProtoField.new("destinationAddress", "mtkmipc.struct.destinationaddress", ftypes.STRING)
mipc_s_nssai_struct_t_sst_present = ProtoField.uint8   ("mtkmipc.struct.sst_present", "sst_present", base.DEC, BOOLEAN)
mipc_s_nssai_struct_t_sst = ProtoField.uint8   ("mtkmipc.struct.sst", "sst", base.DEC)
mipc_s_nssai_struct_t_sd_present = ProtoField.uint8   ("mtkmipc.struct.sd_present", "sd_present", base.DEC, BOOLEAN)
mipc_s_nssai_struct_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_s_nssai_struct_t_sd = ProtoField.uint32   ("mtkmipc.struct.sd", "sd", base.DEC)
mipc_s_nssai_struct_t_mapped_sst_present = ProtoField.uint8   ("mtkmipc.struct.mapped_sst_present", "mapped_sst_present", base.DEC, BOOLEAN)
mipc_s_nssai_struct_t_mapped_sst = ProtoField.uint8   ("mtkmipc.struct.mapped_sst", "mapped_sst", base.DEC)
mipc_s_nssai_struct_t_mapped_sd_present = ProtoField.uint8   ("mtkmipc.struct.mapped_sd_present", "mapped_sd_present", base.DEC, BOOLEAN)
mipc_s_nssai_struct_t_padding2 = ProtoField.uint8   ("mtkmipc.struct.padding2", "padding2", base.DEC)
mipc_s_nssai_struct_t_mapped_sd = ProtoField.uint32   ("mtkmipc.struct.mapped_sd", "mapped_sd", base.DEC)
mipc_ursp_route_sel_desc_struct_t_p_val = ProtoField.uint8   ("mtkmipc.struct.p_val", "p_val", base.DEC)
mipc_ursp_route_sel_desc_struct_t_ssc_mode = ProtoField.uint8   ("mtkmipc.struct.ssc_mode", "ssc_mode", base.DEC, SSC_MODE_ENUM)
mipc_ursp_route_sel_desc_struct_t_dnn_len = ProtoField.uint8   ("mtkmipc.struct.dnn_len", "dnn_len", base.DEC)
mipc_ursp_route_sel_desc_struct_t_s_nssai_present = ProtoField.uint8   ("mtkmipc.struct.s_nssai_present", "s_nssai_present", base.DEC, BOOLEAN)
mipc_ursp_route_sel_desc_struct_t_dnn = ProtoField.new("dnn", "mtkmipc.struct.dnn", ftypes.STRING)
mipc_ursp_route_sel_desc_struct_t_pdu_session_type = ProtoField.uint8   ("mtkmipc.struct.pdu_session_type", "pdu_session_type", base.DEC)
mipc_ursp_route_sel_desc_struct_t_pref_access_type = ProtoField.uint8   ("mtkmipc.struct.pref_access_type", "pref_access_type", base.DEC)
mipc_ursp_route_sel_desc_struct_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_is_match_all = ProtoField.uint8   ("mtkmipc.struct.is_match_all", "is_match_all", base.DEC)
mipc_ursp_traffic_desc_struct_t_dnn_len = ProtoField.uint8   ("mtkmipc.struct.dnn_len", "dnn_len", base.DEC)
mipc_ursp_traffic_desc_struct_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_dnn = ProtoField.new("dnn", "mtkmipc.struct.dnn", ftypes.STRING)
mipc_ursp_traffic_desc_struct_t_os_id = ProtoField.new("os_id", "mtkmipc.struct.os_id", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_app_id_len = ProtoField.uint8   ("mtkmipc.struct.app_id_len", "app_id_len", base.DEC)
mipc_ursp_traffic_desc_struct_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_app_id = ProtoField.new("app_id", "mtkmipc.struct.app_id", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_reserved3 = ProtoField.uint8   ("mtkmipc.struct.reserved3", "reserved3", base.DEC)
mipc_ursp_traffic_desc_struct_t_ipv4_addr = ProtoField.new("ipv4_addr", "mtkmipc.struct.ipv4_addr", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_ipv4_mask = ProtoField.new("ipv4_mask", "mtkmipc.struct.ipv4_mask", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_ipv6_addr = ProtoField.new("ipv6_addr", "mtkmipc.struct.ipv6_addr", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_ipv6_prefix_len = ProtoField.uint8   ("mtkmipc.struct.ipv6_prefix_len", "ipv6_prefix_len", base.DEC)
mipc_ursp_traffic_desc_struct_t_reserved4 = ProtoField.new("reserved4", "mtkmipc.struct.reserved4", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_port_num = ProtoField.uint16   ("mtkmipc.struct.port_num", "port_num", base.DEC)
mipc_ursp_traffic_desc_struct_t_min_port_num = ProtoField.uint16   ("mtkmipc.struct.min_port_num", "min_port_num", base.DEC)
mipc_ursp_traffic_desc_struct_t_max_port_num = ProtoField.uint16   ("mtkmipc.struct.max_port_num", "max_port_num", base.DEC)
mipc_ursp_traffic_desc_struct_t_prot_id_next_hdr = ProtoField.uint8   ("mtkmipc.struct.prot_id_next_hdr", "prot_id_next_hdr", base.DEC)
mipc_ursp_traffic_desc_struct_t_dst_fqdn_len = ProtoField.uint8   ("mtkmipc.struct.dst_fqdn_len", "dst_fqdn_len", base.DEC)
mipc_ursp_traffic_desc_struct_t_dst_fqdn = ProtoField.new("dst_fqdn", "mtkmipc.struct.dst_fqdn", ftypes.BYTES)
mipc_ursp_traffic_desc_struct_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_ursp_ue_local_conf_struct_t_ssc_mode = ProtoField.uint8   ("mtkmipc.struct.ssc_mode", "ssc_mode", base.DEC, SSC_MODE_ENUM)
mipc_ursp_ue_local_conf_struct_t_dnn_len = ProtoField.uint8   ("mtkmipc.struct.dnn_len", "dnn_len", base.DEC)
mipc_ursp_ue_local_conf_struct_t_reserved = ProtoField.uint8   ("mtkmipc.struct.reserved", "reserved", base.DEC)
mipc_ursp_ue_local_conf_struct_t_s_nssai_present = ProtoField.uint8   ("mtkmipc.struct.s_nssai_present", "s_nssai_present", base.DEC, BOOLEAN)
mipc_ursp_ue_local_conf_struct_t_dnn = ProtoField.new("dnn", "mtkmipc.struct.dnn", ftypes.STRING)
mipc_ursp_ue_local_conf_struct_t_pdu_session_type = ProtoField.uint8   ("mtkmipc.struct.pdu_session_type", "pdu_session_type", base.DEC)
mipc_ursp_ue_local_conf_struct_t_pref_access_type = ProtoField.uint8   ("mtkmipc.struct.pref_access_type", "pref_access_type", base.DEC)
mipc_ursp_ue_local_conf_struct_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_ursp_get_route_supp_profile_ind_struct_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_ursp_get_route_supp_profile_ind_struct_t_supp_profile_type = ProtoField.uint32   ("mtkmipc.struct.supp_profile_type", "supp_profile_type", base.DEC, URSP_ROUTE_SUPP_PROFILE_TYPE_ENUM)
mipc_ursp_get_route_supp_profile_ind_struct_t_is_match_all_disallowed = ProtoField.uint8   ("mtkmipc.struct.is_match_all_disallowed", "is_match_all_disallowed", base.DEC)
mipc_ursp_get_route_supp_profile_ind_struct_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_ursp_rule_struct_t_p_val = ProtoField.uint8   ("mtkmipc.struct.p_val", "p_val", base.DEC)
mipc_ursp_rule_struct_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_ursp_rule_struct_t_num_of_rsd = ProtoField.uint8   ("mtkmipc.struct.num_of_rsd", "num_of_rsd", base.DEC)
mipc_ursp_rule_struct_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_ursp_ue_policy_plmn_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_plmn_specific_s_nssai_struct_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.BYTES)
mipc_plmn_specific_s_nssai_struct_t_sst_present = ProtoField.uint8   ("mtkmipc.struct.sst_present", "sst_present", base.DEC, BOOLEAN)
mipc_plmn_specific_s_nssai_struct_t_sst = ProtoField.uint8   ("mtkmipc.struct.sst", "sst", base.DEC)
mipc_plmn_specific_s_nssai_struct_t_sd_present = ProtoField.uint8   ("mtkmipc.struct.sd_present", "sd_present", base.DEC, BOOLEAN)
mipc_plmn_specific_s_nssai_struct_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_plmn_specific_s_nssai_struct_t_sd = ProtoField.uint32   ("mtkmipc.struct.sd", "sd", base.DEC)
mipc_plmn_specific_s_nssai_struct_t_mapped_sst_present = ProtoField.uint8   ("mtkmipc.struct.mapped_sst_present", "mapped_sst_present", base.DEC, BOOLEAN)
mipc_plmn_specific_s_nssai_struct_t_mapped_sst = ProtoField.uint8   ("mtkmipc.struct.mapped_sst", "mapped_sst", base.DEC)
mipc_plmn_specific_s_nssai_struct_t_mapped_sd_present = ProtoField.uint8   ("mtkmipc.struct.mapped_sd_present", "mapped_sd_present", base.DEC, BOOLEAN)
mipc_plmn_specific_s_nssai_struct_t_padding2 = ProtoField.uint8   ("mtkmipc.struct.padding2", "padding2", base.DEC)
mipc_plmn_specific_s_nssai_struct_t_mapped_sd = ProtoField.uint32   ("mtkmipc.struct.mapped_sd", "mapped_sd", base.DEC)
mipc_rejected_s_nssai_struct_t_cause_value = ProtoField.uint8   ("mtkmipc.struct.cause_value", "cause_value", base.DEC)
mipc_rejected_s_nssai_struct_t_sst_present = ProtoField.uint8   ("mtkmipc.struct.sst_present", "sst_present", base.DEC, BOOLEAN)
mipc_rejected_s_nssai_struct_t_sst = ProtoField.uint8   ("mtkmipc.struct.sst", "sst", base.DEC)
mipc_rejected_s_nssai_struct_t_sd_present = ProtoField.uint8   ("mtkmipc.struct.sd_present", "sd_present", base.DEC, BOOLEAN)
mipc_rejected_s_nssai_struct_t_sd = ProtoField.uint32   ("mtkmipc.struct.sd", "sd", base.DEC)
mipc_lte_cc_meas_info_t_lte_cc_type = ProtoField.new("lte_cc_type", "mtkmipc.struct.lte_cc_type", ftypes.STRING)
mipc_lte_cc_meas_info_t_path_loss = ProtoField.uint16   ("mtkmipc.struct.path_loss", "path_loss", base.DEC)
mipc_lte_cc_meas_info_t_rank_indicator = ProtoField.uint16   ("mtkmipc.struct.rank_indicator", "rank_indicator", base.DEC)
mipc_lte_cc_meas_info_t_serv_rsrp = ProtoField.int32   ("mtkmipc.struct.serv_rsrp", "serv_rsrp", base.DEC)
mipc_lte_cc_meas_info_t_serv_rsrq = ProtoField.int32   ("mtkmipc.struct.serv_rsrq", "serv_rsrq", base.DEC)
mipc_lte_cc_meas_info_t_serv_snr = ProtoField.int32   ("mtkmipc.struct.serv_snr", "serv_snr", base.DEC)
mipc_lte_cc_meas_info_t_serv_rssi = ProtoField.int32   ("mtkmipc.struct.serv_rssi", "serv_rssi", base.DEC)
mipc_lte_cc_meas_info_v1_t_lte_cc_type = ProtoField.new("lte_cc_type", "mtkmipc.struct.lte_cc_type", ftypes.STRING)
mipc_lte_cc_meas_info_v1_t_cell_index = ProtoField.uint16   ("mtkmipc.struct.cell_index", "cell_index", base.DEC)
mipc_lte_cc_meas_info_v1_t_path_loss = ProtoField.uint16   ("mtkmipc.struct.path_loss", "path_loss", base.DEC)
mipc_lte_cc_meas_info_v1_t_rank_indicator = ProtoField.uint16   ("mtkmipc.struct.rank_indicator", "rank_indicator", base.DEC)
mipc_lte_cc_meas_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_lte_cc_meas_info_v1_t_serv_rsrp = ProtoField.int32   ("mtkmipc.struct.serv_rsrp", "serv_rsrp", base.DEC)
mipc_lte_cc_meas_info_v1_t_serv_rsrq = ProtoField.int32   ("mtkmipc.struct.serv_rsrq", "serv_rsrq", base.DEC)
mipc_lte_cc_meas_info_v1_t_serv_snr = ProtoField.int32   ("mtkmipc.struct.serv_snr", "serv_snr", base.DEC)
mipc_lte_cc_meas_info_v1_t_serv_rssi = ProtoField.int32   ("mtkmipc.struct.serv_rssi", "serv_rssi", base.DEC)
mipc_lte_cc_meas_info_v1_t_measbw_rssi = ProtoField.int32   ("mtkmipc.struct.measbw_rssi", "measbw_rssi", base.DEC)
mipc_nr_cc_meas_info_t_nr_cc_type = ProtoField.new("nr_cc_type", "mtkmipc.struct.nr_cc_type", ftypes.STRING)
mipc_nr_cc_meas_info_t_path_loss = ProtoField.uint16   ("mtkmipc.struct.path_loss", "path_loss", base.DEC)
mipc_nr_cc_meas_info_t_rank_indicator = ProtoField.uint16   ("mtkmipc.struct.rank_indicator", "rank_indicator", base.DEC)
mipc_nr_cc_meas_info_t_brsrp = ProtoField.int32   ("mtkmipc.struct.brsrp", "brsrp", base.DEC)
mipc_nr_cc_meas_info_t_serv_rsrp = ProtoField.int32   ("mtkmipc.struct.serv_rsrp", "serv_rsrp", base.DEC)
mipc_nr_cc_meas_info_t_serv_rsrq = ProtoField.int32   ("mtkmipc.struct.serv_rsrq", "serv_rsrq", base.DEC)
mipc_nr_cc_meas_info_t_ssb_best_beam_id = ProtoField.uint32   ("mtkmipc.struct.ssb_best_beam_id", "ssb_best_beam_id", base.DEC)
mipc_nr_cc_meas_info_t_ssb_snr_avg = ProtoField.int32   ("mtkmipc.struct.ssb_snr_avg", "ssb_snr_avg", base.DEC)
mipc_nr_cc_meas_info_t_ssb_rsrp_avg = ProtoField.int32   ("mtkmipc.struct.ssb_rsrp_avg", "ssb_rsrp_avg", base.DEC)
mipc_nr_cc_meas_info_t_trs_snr_avg = ProtoField.int32   ("mtkmipc.struct.trs_snr_avg", "trs_snr_avg", base.DEC)
mipc_nr_cc_meas_info_t_trs_rsrp_avg = ProtoField.int32   ("mtkmipc.struct.trs_rsrp_avg", "trs_rsrp_avg", base.DEC)
mipc_nr_cc_meas_info_t_serv_snr = ProtoField.int32   ("mtkmipc.struct.serv_snr", "serv_snr", base.DEC)
mipc_nr_cc_meas_info_t_serv_rssi = ProtoField.int32   ("mtkmipc.struct.serv_rssi", "serv_rssi", base.DEC)
mipc_nr_cc_meas_info_v1_t_nr_cc_type = ProtoField.new("nr_cc_type", "mtkmipc.struct.nr_cc_type", ftypes.STRING)
mipc_nr_cc_meas_info_v1_t_cell_index = ProtoField.uint16   ("mtkmipc.struct.cell_index", "cell_index", base.DEC)
mipc_nr_cc_meas_info_v1_t_path_loss = ProtoField.uint16   ("mtkmipc.struct.path_loss", "path_loss", base.DEC)
mipc_nr_cc_meas_info_v1_t_rank_indicator = ProtoField.uint16   ("mtkmipc.struct.rank_indicator", "rank_indicator", base.DEC)
mipc_nr_cc_meas_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nr_cc_meas_info_v1_t_brsrp = ProtoField.int32   ("mtkmipc.struct.brsrp", "brsrp", base.DEC)
mipc_nr_cc_meas_info_v1_t_serv_rsrp = ProtoField.int32   ("mtkmipc.struct.serv_rsrp", "serv_rsrp", base.DEC)
mipc_nr_cc_meas_info_v1_t_serv_rsrq = ProtoField.int32   ("mtkmipc.struct.serv_rsrq", "serv_rsrq", base.DEC)
mipc_nr_cc_meas_info_v1_t_ssb_best_beam_id = ProtoField.uint32   ("mtkmipc.struct.ssb_best_beam_id", "ssb_best_beam_id", base.DEC)
mipc_nr_cc_meas_info_v1_t_ssb_snr_avg = ProtoField.int32   ("mtkmipc.struct.ssb_snr_avg", "ssb_snr_avg", base.DEC)
mipc_nr_cc_meas_info_v1_t_ssb_rsrp_avg = ProtoField.int32   ("mtkmipc.struct.ssb_rsrp_avg", "ssb_rsrp_avg", base.DEC)
mipc_nr_cc_meas_info_v1_t_trs_snr_avg = ProtoField.int32   ("mtkmipc.struct.trs_snr_avg", "trs_snr_avg", base.DEC)
mipc_nr_cc_meas_info_v1_t_trs_rsrp_avg = ProtoField.int32   ("mtkmipc.struct.trs_rsrp_avg", "trs_rsrp_avg", base.DEC)
mipc_nr_cc_meas_info_v1_t_serv_snr = ProtoField.int32   ("mtkmipc.struct.serv_snr", "serv_snr", base.DEC)
mipc_nr_cc_meas_info_v1_t_serv_rssi = ProtoField.int32   ("mtkmipc.struct.serv_rssi", "serv_rssi", base.DEC)
mipc_nr_cc_meas_info_v1_t_bwp_rssi = ProtoField.int32   ("mtkmipc.struct.bwp_rssi", "bwp_rssi", base.DEC)
mipc_wcdma_current_cell_info_t_band = ProtoField.uint32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_wcdma_current_cell_info_t_pci = ProtoField.uint32   ("mtkmipc.struct.pci", "pci", base.DEC)
mipc_wcdma_current_cell_info_t_uarfcn = ProtoField.uint32   ("mtkmipc.struct.uarfcn", "uarfcn", base.DEC)
mipc_wcdma_current_cell_info_t_dl_bandwidth = ProtoField.uint16   ("mtkmipc.struct.dl_bandwidth", "dl_bandwidth", base.DEC)
mipc_wcdma_current_cell_info_t_ul_bandwidth = ProtoField.uint16   ("mtkmipc.struct.ul_bandwidth", "ul_bandwidth", base.DEC)
mipc_current_cell_info_t_scc_state = ProtoField.uint8   ("mtkmipc.struct.scc_state", "scc_state", base.DEC)
mipc_current_cell_info_t_scc_ul_configured = ProtoField.uint8   ("mtkmipc.struct.scc_ul_configured", "scc_ul_configured", base.DEC)
mipc_current_cell_info_t_cc_band = ProtoField.uint16   ("mtkmipc.struct.cc_band", "cc_band", base.DEC)
mipc_current_cell_info_t_cc_pci = ProtoField.uint32   ("mtkmipc.struct.cc_pci", "cc_pci", base.DEC)
mipc_current_cell_info_t_cc_arfcn = ProtoField.uint32   ("mtkmipc.struct.cc_arfcn", "cc_arfcn", base.DEC)
mipc_current_cell_info_t_cc_dl_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_dl_bandwidth", "cc_dl_bandwidth", base.DEC)
mipc_current_cell_info_t_cc_ul_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_ul_bandwidth", "cc_ul_bandwidth", base.DEC)
mipc_current_cell_info_t_cc_dl_bandwidth_str = ProtoField.new("cc_dl_bandwidth_str", "mtkmipc.struct.cc_dl_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_t_cc_ul_bandwidth_str = ProtoField.new("cc_ul_bandwidth_str", "mtkmipc.struct.cc_ul_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_t_cc_dl_mimo = ProtoField.uint8   ("mtkmipc.struct.cc_dl_mimo", "cc_dl_mimo", base.DEC)
mipc_current_cell_info_t_cc_ul_mimo = ProtoField.uint8   ("mtkmipc.struct.cc_ul_mimo", "cc_ul_mimo", base.DEC)
mipc_current_cell_info_t_cc_dl_modulation = ProtoField.uint8   ("mtkmipc.struct.cc_dl_modulation", "cc_dl_modulation", base.DEC)
mipc_current_cell_info_t_cc_ul_modulation = ProtoField.uint8   ("mtkmipc.struct.cc_ul_modulation", "cc_ul_modulation", base.DEC)
mipc_current_cell_info_t_cc_dl_rb = ProtoField.uint8   ("mtkmipc.struct.cc_dl_rb", "cc_dl_rb", base.DEC)
mipc_current_cell_info_t_cc_ul_rb = ProtoField.uint8   ("mtkmipc.struct.cc_ul_rb", "cc_ul_rb", base.DEC)
mipc_current_cell_info_t_cc_dl_mcs = ProtoField.uint8   ("mtkmipc.struct.cc_dl_mcs", "cc_dl_mcs", base.DEC)
mipc_current_cell_info_t_cc_ul_mcs = ProtoField.uint8   ("mtkmipc.struct.cc_ul_mcs", "cc_ul_mcs", base.DEC)
mipc_current_cell_info_t_cc_pucch_tx_pwr = ProtoField.int32   ("mtkmipc.struct.cc_pucch_tx_pwr", "cc_pucch_tx_pwr", base.DEC)
mipc_current_cell_info_t_cc_pusch_tx_pwr = ProtoField.int32   ("mtkmipc.struct.cc_pusch_tx_pwr", "cc_pusch_tx_pwr", base.DEC)
mipc_current_cell_info_t_cc_lte_dl_tm = ProtoField.uint16   ("mtkmipc.struct.cc_lte_dl_tm", "cc_lte_dl_tm", base.DEC)
mipc_current_cell_info_t_cc_lte_ul_tm = ProtoField.uint16   ("mtkmipc.struct.cc_lte_ul_tm", "cc_lte_ul_tm", base.DEC)
mipc_current_cell_info_t_cc_dl_tput = ProtoField.uint32   ("mtkmipc.struct.cc_dl_tput", "cc_dl_tput", base.DEC)
mipc_current_cell_info_t_cc_ul_tput = ProtoField.uint32   ("mtkmipc.struct.cc_ul_tput", "cc_ul_tput", base.DEC)
mipc_current_cell_info_t_cc_dl_bwp_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_dl_bwp_bandwidth", "cc_dl_bwp_bandwidth", base.DEC)
mipc_current_cell_info_t_cc_ul_bwp_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_ul_bwp_bandwidth", "cc_ul_bwp_bandwidth", base.DEC)
mipc_current_cell_info_t_cc_dl_bwp_bandwidth_str = ProtoField.new("cc_dl_bwp_bandwidth_str", "mtkmipc.struct.cc_dl_bwp_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_t_cc_ul_bwp_bandwidth_str = ProtoField.new("cc_ul_bwp_bandwidth_str", "mtkmipc.struct.cc_ul_bwp_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_t_cc_dl_spectral_efficiency = ProtoField.uint32   ("mtkmipc.struct.cc_dl_spectral_efficiency", "cc_dl_spectral_efficiency", base.DEC)
mipc_current_cell_info_t_cc_ul_spectral_efficiency = ProtoField.uint32   ("mtkmipc.struct.cc_ul_spectral_efficiency", "cc_ul_spectral_efficiency", base.DEC)
mipc_current_cell_info_v1_t_scc_state = ProtoField.uint8   ("mtkmipc.struct.scc_state", "scc_state", base.DEC)
mipc_current_cell_info_v1_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_current_cell_info_v1_t_cell_index = ProtoField.uint16   ("mtkmipc.struct.cell_index", "cell_index", base.DEC)
mipc_current_cell_info_v1_t_scc_ul_configured = ProtoField.uint8   ("mtkmipc.struct.scc_ul_configured", "scc_ul_configured", base.DEC)
mipc_current_cell_info_v1_t_padding1 = ProtoField.uint8   ("mtkmipc.struct.padding1", "padding1", base.DEC)
mipc_current_cell_info_v1_t_cc_band = ProtoField.uint16   ("mtkmipc.struct.cc_band", "cc_band", base.DEC)
mipc_current_cell_info_v1_t_cc_pci = ProtoField.uint32   ("mtkmipc.struct.cc_pci", "cc_pci", base.DEC)
mipc_current_cell_info_v1_t_cc_arfcn = ProtoField.uint32   ("mtkmipc.struct.cc_arfcn", "cc_arfcn", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_dl_bandwidth", "cc_dl_bandwidth", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_ul_bandwidth", "cc_ul_bandwidth", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_bandwidth_str = ProtoField.new("cc_dl_bandwidth_str", "mtkmipc.struct.cc_dl_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_v1_t_cc_ul_bandwidth_str = ProtoField.new("cc_ul_bandwidth_str", "mtkmipc.struct.cc_ul_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_v1_t_cc_dl_mimo = ProtoField.uint8   ("mtkmipc.struct.cc_dl_mimo", "cc_dl_mimo", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_mimo = ProtoField.uint8   ("mtkmipc.struct.cc_ul_mimo", "cc_ul_mimo", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_modulation = ProtoField.uint8   ("mtkmipc.struct.cc_dl_modulation", "cc_dl_modulation", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_modulation = ProtoField.uint8   ("mtkmipc.struct.cc_ul_modulation", "cc_ul_modulation", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_rb = ProtoField.uint8   ("mtkmipc.struct.cc_dl_rb", "cc_dl_rb", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_rb = ProtoField.uint8   ("mtkmipc.struct.cc_ul_rb", "cc_ul_rb", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_mcs = ProtoField.uint8   ("mtkmipc.struct.cc_dl_mcs", "cc_dl_mcs", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_mcs = ProtoField.uint8   ("mtkmipc.struct.cc_ul_mcs", "cc_ul_mcs", base.DEC)
mipc_current_cell_info_v1_t_cc_pucch_tx_pwr = ProtoField.int32   ("mtkmipc.struct.cc_pucch_tx_pwr", "cc_pucch_tx_pwr", base.DEC)
mipc_current_cell_info_v1_t_cc_pusch_tx_pwr = ProtoField.int32   ("mtkmipc.struct.cc_pusch_tx_pwr", "cc_pusch_tx_pwr", base.DEC)
mipc_current_cell_info_v1_t_cc_lte_dl_tm = ProtoField.uint16   ("mtkmipc.struct.cc_lte_dl_tm", "cc_lte_dl_tm", base.DEC)
mipc_current_cell_info_v1_t_cc_lte_ul_tm = ProtoField.uint16   ("mtkmipc.struct.cc_lte_ul_tm", "cc_lte_ul_tm", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_tput = ProtoField.uint32   ("mtkmipc.struct.cc_dl_tput", "cc_dl_tput", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_tput = ProtoField.uint32   ("mtkmipc.struct.cc_ul_tput", "cc_ul_tput", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_bwp_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_dl_bwp_bandwidth", "cc_dl_bwp_bandwidth", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_bwp_bandwidth = ProtoField.uint16   ("mtkmipc.struct.cc_ul_bwp_bandwidth", "cc_ul_bwp_bandwidth", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_bwp_bandwidth_str = ProtoField.new("cc_dl_bwp_bandwidth_str", "mtkmipc.struct.cc_dl_bwp_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_v1_t_cc_ul_bwp_bandwidth_str = ProtoField.new("cc_ul_bwp_bandwidth_str", "mtkmipc.struct.cc_ul_bwp_bandwidth_str", ftypes.STRING)
mipc_current_cell_info_v1_t_cc_dl_spectral_efficiency = ProtoField.uint32   ("mtkmipc.struct.cc_dl_spectral_efficiency", "cc_dl_spectral_efficiency", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_spectral_efficiency = ProtoField.uint32   ("mtkmipc.struct.cc_ul_spectral_efficiency", "cc_ul_spectral_efficiency", base.DEC)
mipc_current_cell_info_v1_t_cc_dl_bwp_central_freq = ProtoField.uint32   ("mtkmipc.struct.cc_dl_bwp_central_freq", "cc_dl_bwp_central_freq", base.DEC)
mipc_current_cell_info_v1_t_cc_ul_bwp_central_freq = ProtoField.uint32   ("mtkmipc.struct.cc_ul_bwp_central_freq", "cc_ul_bwp_central_freq", base.DEC)
mipc_current_cell_info_v1_t_cc_lte_target_pwr = ProtoField.int32   ("mtkmipc.struct.cc_lte_target_pwr", "cc_lte_target_pwr", base.DEC)
mipc_current_cell_info_v1_t_cc_lte_meas_bandwidth = ProtoField.uint32   ("mtkmipc.struct.cc_lte_meas_bandwidth", "cc_lte_meas_bandwidth", base.DEC)
mipc_current_cell_info_v1_t_central_arfcn = ProtoField.uint32   ("mtkmipc.struct.central_arfcn", "central_arfcn", base.DEC)
mipc_nw_provider_t_index = ProtoField.uint32   ("mtkmipc.struct.index", "index", base.DEC)
mipc_nw_provider_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_provider_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_nw_provider_t_network_name = ProtoField.new("network_name", "mtkmipc.struct.network_name", ftypes.STRING)
mipc_nw_provider_t_network_short_name = ProtoField.new("network_short_name", "mtkmipc.struct.network_short_name", ftypes.STRING)
mipc_nw_provider_t_act = ProtoField.uint32   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_provider_t_act_supported = ProtoField.uint32   ("mtkmipc.struct.act_supported", "act_supported", base.DEC)
mipc_nw_provider_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_provider_t_rssi = ProtoField.uint8   ("mtkmipc.struct.rssi", "rssi", base.DEC)
mipc_nw_provider_t_error_rate = ProtoField.uint8   ("mtkmipc.struct.error_rate", "error_rate", base.DEC)
mipc_nw_provider_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_nitz_info_t_year = ProtoField.uint32   ("mtkmipc.struct.year", "year", base.DEC)
mipc_nw_nitz_info_t_month = ProtoField.uint32   ("mtkmipc.struct.month", "month", base.DEC)
mipc_nw_nitz_info_t_day = ProtoField.uint32   ("mtkmipc.struct.day", "day", base.DEC)
mipc_nw_nitz_info_t_hour = ProtoField.uint32   ("mtkmipc.struct.hour", "hour", base.DEC)
mipc_nw_nitz_info_t_minute = ProtoField.uint32   ("mtkmipc.struct.minute", "minute", base.DEC)
mipc_nw_nitz_info_t_second = ProtoField.uint32   ("mtkmipc.struct.second", "second", base.DEC)
mipc_nw_nitz_info_t_time_zone_offset_minutes = ProtoField.int32   ("mtkmipc.struct.time_zone_offset_minutes", "time_zone_offset_minutes", base.DEC)
mipc_nw_nitz_info_t_daylight_saving_offset_minutes = ProtoField.int32   ("mtkmipc.struct.daylight_saving_offset_minutes", "daylight_saving_offset_minutes", base.DEC)
mipc_nw_anbr_info_t_anbrq_config = ProtoField.uint8   ("mtkmipc.struct.anbrq_config", "anbrq_config", base.DEC)
mipc_nw_anbr_info_t_ebi = ProtoField.uint8   ("mtkmipc.struct.ebi", "ebi", base.DEC)
mipc_nw_anbr_info_t_is_ul = ProtoField.uint8   ("mtkmipc.struct.is_ul", "is_ul", base.DEC)
mipc_nw_anbr_info_t_beare_id = ProtoField.uint8   ("mtkmipc.struct.beare_id", "beare_id", base.DEC)
mipc_nw_anbr_info_t_bitrate = ProtoField.uint16   ("mtkmipc.struct.bitrate", "bitrate", base.DEC)
mipc_nw_anbr_info_t_pdu_session_id = ProtoField.uint8   ("mtkmipc.struct.pdu_session_id", "pdu_session_id", base.DEC)
mipc_nw_anbr_info_t_ext_param = ProtoField.uint8   ("mtkmipc.struct.ext_param", "ext_param", base.DEC)
mipc_nw_irat_info_t_irat_status = ProtoField.uint8   ("mtkmipc.struct.irat_status", "irat_status", base.DEC)
mipc_nw_irat_info_t_is_successful = ProtoField.uint8   ("mtkmipc.struct.is_successful", "is_successful", base.DEC)
mipc_nw_reg_state_t_ps_state = ProtoField.uint8   ("mtkmipc.struct.ps_state", "ps_state", base.DEC)
mipc_nw_reg_state_t_cs_state = ProtoField.uint8   ("mtkmipc.struct.cs_state", "cs_state", base.DEC)
mipc_nw_reg_state_t_plmn = ProtoField.new("plmn", "mtkmipc.struct.plmn", ftypes.STRING)
mipc_nw_reg_state_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_reg_state_t_cs_plmn = ProtoField.new("cs_plmn", "mtkmipc.struct.cs_plmn", ftypes.STRING)
mipc_nw_reg_state_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_reg_state_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_reg_state_t_cs_lac = ProtoField.uint32   ("mtkmipc.struct.cs_lac", "cs_lac", base.DEC)
mipc_nw_reg_state_t_ci = ProtoField.uint32   ("mtkmipc.struct.ci", "ci", base.DEC)
mipc_nw_reg_state_t_cs_ci = ProtoField.uint32   ("mtkmipc.struct.cs_ci", "cs_ci", base.DEC)
mipc_nw_reg_state_t_is_roaming = ProtoField.uint8   ("mtkmipc.struct.is_roaming", "is_roaming", base.DEC)
mipc_nw_reg_state_t_cs_is_roaming = ProtoField.uint8   ("mtkmipc.struct.cs_is_roaming", "cs_is_roaming", base.DEC)
mipc_nw_reg_state_t_padding3 = ProtoField.new("padding3", "mtkmipc.struct.padding3", ftypes.BYTES)
mipc_nw_reg_state_v1_t_ps_state = ProtoField.uint8   ("mtkmipc.struct.ps_state", "ps_state", base.DEC)
mipc_nw_reg_state_v1_t_cs_state = ProtoField.uint8   ("mtkmipc.struct.cs_state", "cs_state", base.DEC)
mipc_nw_reg_state_v1_t_plmn = ProtoField.new("plmn", "mtkmipc.struct.plmn", ftypes.STRING)
mipc_nw_reg_state_v1_t_cs_plmn = ProtoField.new("cs_plmn", "mtkmipc.struct.cs_plmn", ftypes.STRING)
mipc_nw_reg_state_v1_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_reg_state_v1_t_cs_lac = ProtoField.uint32   ("mtkmipc.struct.cs_lac", "cs_lac", base.DEC)
mipc_nw_reg_state_v1_t_ci = ProtoField.uint32   ("mtkmipc.struct.ci", "ci", base.DEC)
mipc_nw_reg_state_v1_t_cs_ci = ProtoField.uint32   ("mtkmipc.struct.cs_ci", "cs_ci", base.DEC)
mipc_nw_reg_state_v1_t_is_roaming = ProtoField.uint8   ("mtkmipc.struct.is_roaming", "is_roaming", base.DEC)
mipc_nw_reg_state_v1_t_cs_is_roaming = ProtoField.uint8   ("mtkmipc.struct.cs_is_roaming", "cs_is_roaming", base.DEC)
mipc_nw_reg_state_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_reg_info_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_reg_info_t_plmn = ProtoField.new("plmn", "mtkmipc.struct.plmn", ftypes.STRING)
mipc_nw_reg_info_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_reg_info_t_ci = ProtoField.uint32   ("mtkmipc.struct.ci", "ci", base.DEC)
mipc_nw_location_info_t_location_area_code = ProtoField.uint32   ("mtkmipc.struct.location_area_code", "location_area_code", base.DEC)
mipc_nw_location_info_t_tracking_area_code = ProtoField.uint32   ("mtkmipc.struct.tracking_area_code", "tracking_area_code", base.DEC)
mipc_nw_location_info_t_cell_id = ProtoField.uint32   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_gsm_cell_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_gsm_cell_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_gsm_cell_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_gsm_cell_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_gsm_cell_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_gsm_cell_t_arfcn = ProtoField.uint32   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_gsm_cell_t_base_station_id = ProtoField.uint32   ("mtkmipc.struct.base_station_id", "base_station_id", base.DEC)
mipc_nw_gsm_cell_t_rx_level = ProtoField.uint32   ("mtkmipc.struct.rx_level", "rx_level", base.DEC)
mipc_nw_gsm_cell_t_biterrorrate = ProtoField.uint32   ("mtkmipc.struct.biterrorrate", "bitErrorRate", base.DEC)
mipc_nw_gsm_cell_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_gsm_cell_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_gsm_cell_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_umts_cell_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_umts_cell_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_umts_cell_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_umts_cell_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_umts_cell_t_uarfcn = ProtoField.uint32   ("mtkmipc.struct.uarfcn", "uarfcn", base.DEC)
mipc_nw_umts_cell_t_psc = ProtoField.uint32   ("mtkmipc.struct.psc", "psc", base.DEC)
mipc_nw_umts_cell_t_rscp = ProtoField.int32   ("mtkmipc.struct.rscp", "rscp", base.DEC)
mipc_nw_umts_cell_t_ecno = ProtoField.int32   ("mtkmipc.struct.ecno", "ecno", base.DEC)
mipc_nw_umts_cell_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_umts_cell_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_umts_cell_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_lte_cell_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_lte_cell_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_lte_cell_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_lte_cell_t_earfcn = ProtoField.uint32   ("mtkmipc.struct.earfcn", "earfcn", base.DEC)
mipc_nw_lte_cell_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_nw_lte_cell_t_tac = ProtoField.uint32   ("mtkmipc.struct.tac", "tac", base.DEC)
mipc_nw_lte_cell_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_lte_cell_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_lte_cell_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_lte_cell_t_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrp_in_qdbm", "rsrp_in_qdbm", base.DEC)
mipc_nw_lte_cell_t_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrq_in_qdbm", "rsrq_in_qdbm", base.DEC)
mipc_nw_lte_cell_t_rssnr = ProtoField.int32   ("mtkmipc.struct.rssnr", "rssnr", base.DEC)
mipc_nw_lte_cell_t_cqi = ProtoField.uint32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_lte_cell_t_dl_freq_band = ProtoField.uint32   ("mtkmipc.struct.dl_freq_band", "dl_freq_band", base.DEC)
mipc_nw_lte_cell_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_lte_cell_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_lte_cell_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_lte_cell_v1_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_lte_cell_v1_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_lte_cell_v1_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_lte_cell_v1_t_earfcn = ProtoField.uint32   ("mtkmipc.struct.earfcn", "earfcn", base.DEC)
mipc_nw_lte_cell_v1_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_nw_lte_cell_v1_t_tac = ProtoField.uint32   ("mtkmipc.struct.tac", "tac", base.DEC)
mipc_nw_lte_cell_v1_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_lte_cell_v1_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_lte_cell_v1_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_lte_cell_v1_t_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrp_in_qdbm", "rsrp_in_qdbm", base.DEC)
mipc_nw_lte_cell_v1_t_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrq_in_qdbm", "rsrq_in_qdbm", base.DEC)
mipc_nw_lte_cell_v1_t_rssnr = ProtoField.int32   ("mtkmipc.struct.rssnr", "rssnr", base.DEC)
mipc_nw_lte_cell_v1_t_cqi = ProtoField.uint32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_lte_cell_v1_t_dl_freq_band = ProtoField.uint32   ("mtkmipc.struct.dl_freq_band", "dl_freq_band", base.DEC)
mipc_nw_lte_cell_v1_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_lte_cell_v1_t_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.cqi_table_index", "cqi_table_index", base.DEC)
mipc_nw_lte_cell_v1_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_lte_cell_v1_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_lte_cell_v2_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_lte_cell_v2_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_lte_cell_v2_t_cid = ProtoField.uint32   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_lte_cell_v2_t_earfcn = ProtoField.uint32   ("mtkmipc.struct.earfcn", "earfcn", base.DEC)
mipc_nw_lte_cell_v2_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_nw_lte_cell_v2_t_tac = ProtoField.uint32   ("mtkmipc.struct.tac", "tac", base.DEC)
mipc_nw_lte_cell_v2_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_lte_cell_v2_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_lte_cell_v2_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_lte_cell_v2_t_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrp_in_qdbm", "rsrp_in_qdbm", base.DEC)
mipc_nw_lte_cell_v2_t_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrq_in_qdbm", "rsrq_in_qdbm", base.DEC)
mipc_nw_lte_cell_v2_t_rssnr = ProtoField.int32   ("mtkmipc.struct.rssnr", "rssnr", base.DEC)
mipc_nw_lte_cell_v2_t_cqi = ProtoField.uint32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_lte_cell_v2_t_dl_freq_band = ProtoField.uint32   ("mtkmipc.struct.dl_freq_band", "dl_freq_band", base.DEC)
mipc_nw_lte_cell_v2_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_lte_cell_v2_t_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.cqi_table_index", "cqi_table_index", base.DEC)
mipc_nw_lte_cell_v2_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_lte_cell_v2_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_lte_cell_v2_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_nr_cell_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_nr_cell_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_nr_cell_t_cid = ProtoField.uint64   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_nr_cell_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_nw_nr_cell_t_nr_arfcn = ProtoField.uint32   ("mtkmipc.struct.nr_arfcn", "nr_arfcn", base.DEC)
mipc_nw_nr_cell_t_tac = ProtoField.uint32   ("mtkmipc.struct.tac", "tac", base.DEC)
mipc_nw_nr_cell_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_nr_cell_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_nr_cell_t_sinr = ProtoField.int32   ("mtkmipc.struct.sinr", "sinr", base.DEC)
mipc_nw_nr_cell_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_nr_cell_t_csirsrp = ProtoField.uint32   ("mtkmipc.struct.csirsrp", "csirsrp", base.DEC)
mipc_nw_nr_cell_t_csirsrq = ProtoField.uint32   ("mtkmipc.struct.csirsrq", "csirsrq", base.DEC)
mipc_nw_nr_cell_t_csisinr = ProtoField.uint32   ("mtkmipc.struct.csisinr", "csisinr", base.DEC)
mipc_nw_nr_cell_t_dl_freq_band = ProtoField.uint32   ("mtkmipc.struct.dl_freq_band", "dl_freq_band", base.DEC)
mipc_nw_nr_cell_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_nr_cell_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_nr_cell_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_nr_cell_v1_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_nr_cell_v1_t_cid = ProtoField.uint64   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_nr_cell_v1_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_nw_nr_cell_v1_t_nr_arfcn = ProtoField.uint32   ("mtkmipc.struct.nr_arfcn", "nr_arfcn", base.DEC)
mipc_nw_nr_cell_v1_t_tac = ProtoField.uint32   ("mtkmipc.struct.tac", "tac", base.DEC)
mipc_nw_nr_cell_v1_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_nr_cell_v1_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_nr_cell_v1_t_sinr = ProtoField.int32   ("mtkmipc.struct.sinr", "sinr", base.DEC)
mipc_nw_nr_cell_v1_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_nr_cell_v1_t_csirsrp = ProtoField.uint32   ("mtkmipc.struct.csirsrp", "csirsrp", base.DEC)
mipc_nw_nr_cell_v1_t_csirsrq = ProtoField.uint32   ("mtkmipc.struct.csirsrq", "csirsrq", base.DEC)
mipc_nw_nr_cell_v1_t_csisinr = ProtoField.uint32   ("mtkmipc.struct.csisinr", "csisinr", base.DEC)
mipc_nw_nr_cell_v1_t_dl_freq_band = ProtoField.uint32   ("mtkmipc.struct.dl_freq_band", "dl_freq_band", base.DEC)
mipc_nw_nr_cell_v1_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_nr_cell_v1_t_csi_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_table_index", "csi_cqi_table_index", base.DEC)
mipc_nw_nr_cell_v1_t_csi_cqi_report_num = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_num", "csi_cqi_report_num", base.DEC)
mipc_nw_nr_cell_v1_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_nr_cell_v1_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_nr_cell_v1_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_nr_cell_v1_t_csi_cqi_report_list = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_list", "csi_cqi_report_list", base.DEC)
mipc_nw_cdma_cell_t_networkid = ProtoField.uint32   ("mtkmipc.struct.networkid", "networkId", base.DEC)
mipc_nw_cdma_cell_t_systemid = ProtoField.uint32   ("mtkmipc.struct.systemid", "systemId", base.DEC)
mipc_nw_cdma_cell_t_basestationid = ProtoField.uint32   ("mtkmipc.struct.basestationid", "basestationId", base.DEC)
mipc_nw_cdma_cell_t_longitude = ProtoField.uint32   ("mtkmipc.struct.longitude", "longitude", base.DEC)
mipc_nw_cdma_cell_t_latitude = ProtoField.uint32   ("mtkmipc.struct.latitude", "latitude", base.DEC)
mipc_nw_cdma_cell_t_dbm_cdma = ProtoField.uint32   ("mtkmipc.struct.dbm_cdma", "dbm_cdma", base.DEC)
mipc_nw_cdma_cell_t_ecio_cdma = ProtoField.uint32   ("mtkmipc.struct.ecio_cdma", "ecio_cdma", base.DEC)
mipc_nw_cdma_cell_t_dbm_evdo = ProtoField.uint32   ("mtkmipc.struct.dbm_evdo", "dbm_evdo", base.DEC)
mipc_nw_cdma_cell_t_ecio_evdo = ProtoField.uint32   ("mtkmipc.struct.ecio_evdo", "ecio_evdo", base.DEC)
mipc_nw_cdma_cell_t_snr_evdo = ProtoField.uint32   ("mtkmipc.struct.snr_evdo", "snr_evdo", base.DEC)
mipc_nw_cdma_cell_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_cdma_cell_t_registered = ProtoField.uint8   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_cdma_cell_v1_t_networkid = ProtoField.uint32   ("mtkmipc.struct.networkid", "networkId", base.DEC)
mipc_nw_cdma_cell_v1_t_systemid = ProtoField.uint32   ("mtkmipc.struct.systemid", "systemId", base.DEC)
mipc_nw_cdma_cell_v1_t_basestationid = ProtoField.uint32   ("mtkmipc.struct.basestationid", "basestationId", base.DEC)
mipc_nw_cdma_cell_v1_t_longitude = ProtoField.uint32   ("mtkmipc.struct.longitude", "longitude", base.DEC)
mipc_nw_cdma_cell_v1_t_latitude = ProtoField.uint32   ("mtkmipc.struct.latitude", "latitude", base.DEC)
mipc_nw_cdma_cell_v1_t_dbm_cdma = ProtoField.uint32   ("mtkmipc.struct.dbm_cdma", "dbm_cdma", base.DEC)
mipc_nw_cdma_cell_v1_t_ecio_cdma = ProtoField.uint32   ("mtkmipc.struct.ecio_cdma", "ecio_cdma", base.DEC)
mipc_nw_cdma_cell_v1_t_dbm_evdo = ProtoField.uint32   ("mtkmipc.struct.dbm_evdo", "dbm_evdo", base.DEC)
mipc_nw_cdma_cell_v1_t_ecio_evdo = ProtoField.uint32   ("mtkmipc.struct.ecio_evdo", "ecio_evdo", base.DEC)
mipc_nw_cdma_cell_v1_t_snr_evdo = ProtoField.uint32   ("mtkmipc.struct.snr_evdo", "snr_evdo", base.DEC)
mipc_nw_cdma_cell_v1_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_cdma_cell_v1_t_registered = ProtoField.uint8   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_cdma_cell_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_tdscdma_cell_t_tbd = ProtoField.int32   ("mtkmipc.struct.tbd", "TBD", base.DEC)
mipc_nw_reg_change_info_t_stat = ProtoField.uint8   ("mtkmipc.struct.stat", "stat", base.DEC)
mipc_nw_reg_change_info_t_lac_tac = ProtoField.uint32   ("mtkmipc.struct.lac_tac", "lac_tac", base.DEC)
mipc_nw_reg_change_info_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_reg_change_info_t_eact = ProtoField.uint16   ("mtkmipc.struct.eact", "eact", base.DEC)
mipc_nw_reg_change_info_t_rac = ProtoField.uint8   ("mtkmipc.struct.rac", "rac", base.DEC)
mipc_nw_reg_change_info_t_nw_existence = ProtoField.uint8   ("mtkmipc.struct.nw_existence", "nw_existence", base.DEC)
mipc_nw_reg_change_info_t_roam_indicator = ProtoField.uint8   ("mtkmipc.struct.roam_indicator", "roam_indicator", base.DEC)
mipc_nw_reg_change_info_t_cause_type = ProtoField.uint8   ("mtkmipc.struct.cause_type", "cause_type", base.DEC)
mipc_nw_reg_change_info_t_reject_cause = ProtoField.uint16   ("mtkmipc.struct.reject_cause", "reject_cause", base.DEC)
mipc_nw_reg_change_info_t_dcnr_restricted = ProtoField.uint8   ("mtkmipc.struct.dcnr_restricted", "dcnr_restricted", base.DEC)
mipc_nw_reg_change_info_t_endc_sib_status = ProtoField.uint8   ("mtkmipc.struct.endc_sib_status", "endc_sib_status", base.DEC)
mipc_nw_reg_change_info_t_endc_available = ProtoField.uint8   ("mtkmipc.struct.endc_available", "endc_available", base.DEC)
mipc_nw_cs_reg_info_t_stat = ProtoField.uint8   ("mtkmipc.struct.stat", "stat", base.DEC)
mipc_nw_cs_reg_info_t_rat = ProtoField.uint16   ("mtkmipc.struct.rat", "rat", base.DEC)
mipc_nw_cs_reg_info_t_css = ProtoField.uint8   ("mtkmipc.struct.css", "css", base.DEC)
mipc_nw_cs_reg_info_t_roaming_ind = ProtoField.uint8   ("mtkmipc.struct.roaming_ind", "roaming_ind", base.DEC)
mipc_nw_cs_reg_info_t_is_in_prl = ProtoField.int8   ("mtkmipc.struct.is_in_prl", "is_in_prl", base.DEC)
mipc_nw_cs_reg_info_t_def_roaming_ind = ProtoField.int16   ("mtkmipc.struct.def_roaming_ind", "def_roaming_ind", base.DEC)
mipc_nw_cs_reg_info_t_reason_for_denial = ProtoField.uint16   ("mtkmipc.struct.reason_for_denial", "reason_for_denial", base.DEC)
mipc_nw_cs_reg_info_v1_t_stat = ProtoField.uint8   ("mtkmipc.struct.stat", "stat", base.DEC)
mipc_nw_cs_reg_info_v1_t_padding1 = ProtoField.uint8   ("mtkmipc.struct.padding1", "padding1", base.DEC)
mipc_nw_cs_reg_info_v1_t_rat = ProtoField.uint16   ("mtkmipc.struct.rat", "rat", base.DEC)
mipc_nw_cs_reg_info_v1_t_css = ProtoField.uint8   ("mtkmipc.struct.css", "css", base.DEC)
mipc_nw_cs_reg_info_v1_t_roaming_ind = ProtoField.uint8   ("mtkmipc.struct.roaming_ind", "roaming_ind", base.DEC)
mipc_nw_cs_reg_info_v1_t_is_in_prl = ProtoField.int8   ("mtkmipc.struct.is_in_prl", "is_in_prl", base.DEC)
mipc_nw_cs_reg_info_v1_t_padding2 = ProtoField.uint8   ("mtkmipc.struct.padding2", "padding2", base.DEC)
mipc_nw_cs_reg_info_v1_t_def_roaming_ind = ProtoField.int16   ("mtkmipc.struct.def_roaming_ind", "def_roaming_ind", base.DEC)
mipc_nw_cs_reg_info_v1_t_reason_for_denial = ProtoField.uint16   ("mtkmipc.struct.reason_for_denial", "reason_for_denial", base.DEC)
mipc_nw_ps_reg_info_t_stat = ProtoField.uint8   ("mtkmipc.struct.stat", "stat", base.DEC, NW_REGISTER_STATE)
mipc_nw_ps_reg_info_t_rat = ProtoField.uint16   ("mtkmipc.struct.rat", "rat", base.DEC, NW_DATA_SPEED)
mipc_nw_ps_reg_info_t_reason_for_denial = ProtoField.uint16   ("mtkmipc.struct.reason_for_denial", "reason_for_denial", base.DEC)
mipc_nw_ps_reg_info_t_max_data_calls = ProtoField.uint16   ("mtkmipc.struct.max_data_calls", "max_data_calls", base.DEC)
mipc_nw_ps_reg_info_t_is_vops_supported = ProtoField.int32   ("mtkmipc.struct.is_vops_supported", "is_vops_supported", base.DEC)
mipc_nw_ps_reg_info_t_is_emc_bearer_supported = ProtoField.int32   ("mtkmipc.struct.is_emc_bearer_supported", "is_emc_bearer_supported", base.DEC)
mipc_nw_ps_reg_info_t_is_endc_available = ProtoField.uint8   ("mtkmipc.struct.is_endc_available", "is_endc_available", base.DEC)
mipc_nw_ps_reg_info_t_is_dcnr_restricted = ProtoField.uint8   ("mtkmipc.struct.is_dcnr_restricted", "is_dcnr_restricted", base.DEC)
mipc_nw_ps_reg_info_t_is_nr_available = ProtoField.uint8   ("mtkmipc.struct.is_nr_available", "is_nr_available", base.DEC)
mipc_nw_ps_reg_info_t_roaming_ind = ProtoField.uint8   ("mtkmipc.struct.roaming_ind", "roaming_ind", base.DEC)
mipc_nw_ps_reg_info_t_is_in_prl = ProtoField.int8   ("mtkmipc.struct.is_in_prl", "is_in_prl", base.DEC)
mipc_nw_ps_reg_info_t_def_roaming_ind = ProtoField.int16   ("mtkmipc.struct.def_roaming_ind", "def_roaming_ind", base.DEC)
mipc_nw_ps_reg_info_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_ps_reg_info_t_cache_endc_connect = ProtoField.uint8   ("mtkmipc.struct.cache_endc_connect", "cache_endc_connect", base.DEC)
mipc_nw_ps_reg_info_t_lac_tac = ProtoField.uint32   ("mtkmipc.struct.lac_tac", "lac_tac", base.DEC)
mipc_nw_channel_lock_info_t_opt = ProtoField.uint8   ("mtkmipc.struct.opt", "opt", base.DEC, NW_CH_LOCK)
mipc_nw_channel_lock_info_t_act = ProtoField.uint8   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_channel_lock_info_t_band_info = ProtoField.uint32   ("mtkmipc.struct.band_info", "band_info", base.DEC)
mipc_nw_channel_lock_info_t_channel_num = ProtoField.uint8   ("mtkmipc.struct.channel_num", "channel_num", base.DEC)
mipc_nw_channel_lock_info_t_arfcn_list = ProtoField.uint32   ("mtkmipc.struct.arfcn_list", "arfcn_list", base.DEC)
mipc_nw_channel_lock_info_t_cell_id = ProtoField.uint32   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_channel_lock_info_t_lock_mode = ProtoField.uint8   ("mtkmipc.struct.lock_mode", "lock_mode", base.DEC, NW_CH_LOCK_MODE)
mipc_nw_channel_lock_info_v1_t_opt = ProtoField.uint32   ("mtkmipc.struct.opt", "opt", base.DEC, NW_CH_LOCK)
mipc_nw_channel_lock_info_v1_t_act = ProtoField.uint32   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_channel_lock_info_v1_t_band_info = ProtoField.uint32   ("mtkmipc.struct.band_info", "band_info", base.DEC)
mipc_nw_channel_lock_info_v1_t_channel_num = ProtoField.uint32   ("mtkmipc.struct.channel_num", "channel_num", base.DEC)
mipc_nw_channel_lock_info_v1_t_arfcn_list = ProtoField.uint32   ("mtkmipc.struct.arfcn_list", "arfcn_list", base.DEC)
mipc_nw_channel_lock_info_v1_t_cell_id = ProtoField.uint32   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_channel_lock_info_v1_t_lock_mode = ProtoField.uint32   ("mtkmipc.struct.lock_mode", "lock_mode", base.DEC, NW_CH_LOCK_MODE)
mipc_nw_gsm_signal_strength_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_gsm_signal_strength_t_bit_error_rate = ProtoField.int32   ("mtkmipc.struct.bit_error_rate", "bit_error_rate", base.DEC)
mipc_nw_gsm_signal_strength_t_timing_advance = ProtoField.int32   ("mtkmipc.struct.timing_advance", "timing_advance", base.DEC)
mipc_nw_umts_signal_strength_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_umts_signal_strength_t_bit_error_rate = ProtoField.int32   ("mtkmipc.struct.bit_error_rate", "bit_error_rate", base.DEC)
mipc_nw_umts_signal_strength_t_rscp = ProtoField.int32   ("mtkmipc.struct.rscp", "rscp", base.DEC)
mipc_nw_umts_signal_strength_t_ecno = ProtoField.int32   ("mtkmipc.struct.ecno", "ecno", base.DEC)
mipc_nw_lte_signal_strength_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_lte_signal_strength_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_lte_signal_strength_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_lte_signal_strength_t_rssnr = ProtoField.int32   ("mtkmipc.struct.rssnr", "rssnr", base.DEC)
mipc_nw_lte_signal_strength_t_cqi = ProtoField.int32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_lte_signal_strength_t_timing_advance = ProtoField.int32   ("mtkmipc.struct.timing_advance", "timing_advance", base.DEC)
mipc_nw_lte_signal_strength_v1_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_lte_signal_strength_v1_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_lte_signal_strength_v1_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_lte_signal_strength_v1_t_rssnr = ProtoField.int32   ("mtkmipc.struct.rssnr", "rssnr", base.DEC)
mipc_nw_lte_signal_strength_v1_t_cqi = ProtoField.int32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_lte_signal_strength_v1_t_timing_advance = ProtoField.int32   ("mtkmipc.struct.timing_advance", "timing_advance", base.DEC)
mipc_nw_lte_signal_strength_v1_t_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.cqi_table_index", "cqi_table_index", base.DEC)
mipc_nw_lte_signal_strength_v2_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_lte_signal_strength_v2_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_lte_signal_strength_v2_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_lte_signal_strength_v2_t_rssnr = ProtoField.int32   ("mtkmipc.struct.rssnr", "rssnr", base.DEC)
mipc_nw_lte_signal_strength_v2_t_cqi = ProtoField.int32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_lte_signal_strength_v2_t_timing_advance = ProtoField.int32   ("mtkmipc.struct.timing_advance", "timing_advance", base.DEC)
mipc_nw_lte_signal_strength_v2_t_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.cqi_table_index", "cqi_table_index", base.DEC)
mipc_nw_lte_signal_strength_v2_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_nr_signal_strength_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_nr_signal_strength_t_ss_rsrp = ProtoField.int32   ("mtkmipc.struct.ss_rsrp", "ss_rsrp", base.DEC)
mipc_nw_nr_signal_strength_t_ss_rsrq = ProtoField.int32   ("mtkmipc.struct.ss_rsrq", "ss_rsrq", base.DEC)
mipc_nw_nr_signal_strength_t_ss_sinr = ProtoField.int32   ("mtkmipc.struct.ss_sinr", "ss_sinr", base.DEC)
mipc_nw_nr_signal_strength_t_csi_rsrp = ProtoField.int32   ("mtkmipc.struct.csi_rsrp", "csi_rsrp", base.DEC)
mipc_nw_nr_signal_strength_t_csi_rsrq = ProtoField.int32   ("mtkmipc.struct.csi_rsrq", "csi_rsrq", base.DEC)
mipc_nw_nr_signal_strength_t_csi_sinr = ProtoField.int32   ("mtkmipc.struct.csi_sinr", "csi_sinr", base.DEC)
mipc_nw_nr_signal_strength_v1_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_nr_signal_strength_v1_t_ss_rsrp = ProtoField.int32   ("mtkmipc.struct.ss_rsrp", "ss_rsrp", base.DEC)
mipc_nw_nr_signal_strength_v1_t_ss_rsrq = ProtoField.int32   ("mtkmipc.struct.ss_rsrq", "ss_rsrq", base.DEC)
mipc_nw_nr_signal_strength_v1_t_ss_sinr = ProtoField.int32   ("mtkmipc.struct.ss_sinr", "ss_sinr", base.DEC)
mipc_nw_nr_signal_strength_v1_t_csi_rsrp = ProtoField.int32   ("mtkmipc.struct.csi_rsrp", "csi_rsrp", base.DEC)
mipc_nw_nr_signal_strength_v1_t_csi_rsrq = ProtoField.int32   ("mtkmipc.struct.csi_rsrq", "csi_rsrq", base.DEC)
mipc_nw_nr_signal_strength_v1_t_csi_sinr = ProtoField.int32   ("mtkmipc.struct.csi_sinr", "csi_sinr", base.DEC)
mipc_nw_nr_signal_strength_v1_t_csi_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_table_index", "csi_cqi_table_index", base.DEC)
mipc_nw_nr_signal_strength_v1_t_csi_cqi_report_num = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_num", "csi_cqi_report_num", base.DEC)
mipc_nw_nr_signal_strength_v1_t_csi_cqi_report_list = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_list", "csi_cqi_report_list", base.DEC)
mipc_nw_nr_signal_strength_v3_t_signal_strength = ProtoField.int32   ("mtkmipc.struct.signal_strength", "signal_strength", base.DEC)
mipc_nw_nr_signal_strength_v3_t_ss_rsrp = ProtoField.int32   ("mtkmipc.struct.ss_rsrp", "ss_rsrp", base.DEC)
mipc_nw_nr_signal_strength_v3_t_ss_rsrq = ProtoField.int32   ("mtkmipc.struct.ss_rsrq", "ss_rsrq", base.DEC)
mipc_nw_nr_signal_strength_v3_t_ss_sinr = ProtoField.int32   ("mtkmipc.struct.ss_sinr", "ss_sinr", base.DEC)
mipc_nw_nr_signal_strength_v3_t_csi_rsrp = ProtoField.int32   ("mtkmipc.struct.csi_rsrp", "csi_rsrp", base.DEC)
mipc_nw_nr_signal_strength_v3_t_csi_rsrq = ProtoField.int32   ("mtkmipc.struct.csi_rsrq", "csi_rsrq", base.DEC)
mipc_nw_nr_signal_strength_v3_t_csi_sinr = ProtoField.int32   ("mtkmipc.struct.csi_sinr", "csi_sinr", base.DEC)
mipc_nw_nr_signal_strength_v3_t_csi_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_table_index", "csi_cqi_table_index", base.DEC)
mipc_nw_nr_signal_strength_v3_t_csi_cqi_report_num = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_num", "csi_cqi_report_num", base.DEC)
mipc_nw_nr_signal_strength_v3_t_csi_cqi_report_list = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_list", "csi_cqi_report_list", base.DEC)
mipc_nw_nr_signal_strength_v3_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_nr_signal_strength_v3_t_timing_advance = ProtoField.int32   ("mtkmipc.struct.timing_advance", "timing_advance", base.DEC)
mipc_nw_cdma_signal_strength_t_dbm = ProtoField.int32   ("mtkmipc.struct.dbm", "dbm", base.DEC)
mipc_nw_cdma_signal_strength_t_ecio = ProtoField.int32   ("mtkmipc.struct.ecio", "ecio", base.DEC)
mipc_nw_cdma_signal_strength_t_snr = ProtoField.int32   ("mtkmipc.struct.snr", "snr", base.DEC)
mipc_nw_cscon_status_t_mode = ProtoField.uint8   ("mtkmipc.struct.mode", "mode", base.DEC, NW_CSCON_MODE)
mipc_nw_cscon_status_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC, NW_CSCON_STATE)
mipc_nw_cscon_status_t_access = ProtoField.uint8   ("mtkmipc.struct.access", "access", base.DEC, NW_CSCON_ACCESS)
mipc_nw_cscon_status_t_core_network = ProtoField.uint8   ("mtkmipc.struct.core_network", "core_network", base.DEC, NW_CSCON_CORE_NETWORK)
mipc_nw_pol_info_t_start_index = ProtoField.uint32   ("mtkmipc.struct.start_index", "start_index", base.DEC)
mipc_nw_pol_info_t_end_index = ProtoField.uint32   ("mtkmipc.struct.end_index", "end_index", base.DEC)
mipc_nw_pol_info_t_format_first = ProtoField.uint8   ("mtkmipc.struct.format_first", "format_first", base.DEC)
mipc_nw_pol_info_t_format_last = ProtoField.uint8   ("mtkmipc.struct.format_last", "format_last", base.DEC)
mipc_nw_pol_info_v1_t_start_index = ProtoField.uint32   ("mtkmipc.struct.start_index", "start_index", base.DEC)
mipc_nw_pol_info_v1_t_end_index = ProtoField.uint32   ("mtkmipc.struct.end_index", "end_index", base.DEC)
mipc_nw_pol_info_v1_t_format_first = ProtoField.uint8   ("mtkmipc.struct.format_first", "format_first", base.DEC)
mipc_nw_pol_info_v1_t_format_last = ProtoField.uint8   ("mtkmipc.struct.format_last", "format_last", base.DEC)
mipc_nw_pol_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_ps_cs_reg_roaming_info_t_m_voice_reg_state = ProtoField.uint8   ("mtkmipc.struct.m_voice_reg_state", "m_voice_reg_state", base.DEC, NW_PS_CS_REG_STATE)
mipc_nw_ps_cs_reg_roaming_info_t_m_data_reg_state = ProtoField.uint8   ("mtkmipc.struct.m_data_reg_state", "m_data_reg_state", base.DEC, NW_PS_CS_REG_STATE)
mipc_nw_ps_cs_reg_roaming_info_t_m_voice_roaming_type = ProtoField.uint8   ("mtkmipc.struct.m_voice_roaming_type", "m_voice_roaming_type", base.DEC, NW_PS_CS_ROAMING_TYPE)
mipc_nw_ps_cs_reg_roaming_info_t_m_data_roaming_type = ProtoField.uint8   ("mtkmipc.struct.m_data_roaming_type", "m_data_roaming_type", base.DEC, NW_PS_CS_ROAMING_TYPE)
mipc_nw_ps_cs_reg_roaming_info_t_m_ril_voice_reg_state = ProtoField.uint8   ("mtkmipc.struct.m_ril_voice_reg_state", "m_ril_voice_reg_state", base.DEC, NW_RIL_PS_CS_REG_STATE)
mipc_nw_ps_cs_reg_roaming_info_t_m_ril_data_reg_state = ProtoField.uint8   ("mtkmipc.struct.m_ril_data_reg_state", "m_ril_data_reg_state", base.DEC, NW_RIL_PS_CS_REG_STATE)
mipc_nw_cellmeasurement_info_t_rat = ProtoField.uint8   ("mtkmipc.struct.rat", "rat", base.DEC)
mipc_nw_cellmeasurement_info_t_arfcn = ProtoField.uint32   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_cellmeasurement_info_t_pci = ProtoField.uint32   ("mtkmipc.struct.pci", "pci", base.DEC)
mipc_nw_cellmeasurement_info_t_rsrp = ProtoField.uint32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_cellmeasurement_info_t_rsrq = ProtoField.uint32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_cellmeasurement_info_t_snr = ProtoField.uint32   ("mtkmipc.struct.snr", "snr", base.DEC)
mipc_nw_cellmeasurement_info_t_cid = ProtoField.uint64   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_cell_band_bandwidth_t_cell_band = ProtoField.uint16   ("mtkmipc.struct.cell_band", "cell_band", base.DEC)
mipc_nw_cell_band_bandwidth_t_cell_bandwidth = ProtoField.uint32   ("mtkmipc.struct.cell_bandwidth", "cell_bandwidth", base.DEC)
mipc_nw_cell_band_bandwidth_v1_t_cell_band = ProtoField.uint16   ("mtkmipc.struct.cell_band", "cell_band", base.DEC)
mipc_nw_cell_band_bandwidth_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_cell_band_bandwidth_v1_t_cell_bandwidth = ProtoField.uint32   ("mtkmipc.struct.cell_bandwidth", "cell_bandwidth", base.DEC)
mipc_nw_lte_nr_ca_info_t_cell_index = ProtoField.uint32   ("mtkmipc.struct.cell_index", "cell_index", base.DEC)
mipc_nw_lte_nr_ca_info_t_cell_state = ProtoField.uint8   ("mtkmipc.struct.cell_state", "cell_state", base.DEC)
mipc_nw_lte_nr_ca_info_t_cc_cw0_cqi = ProtoField.uint8   ("mtkmipc.struct.cc_cw0_cqi", "cc_cw0_cqi", base.DEC)
mipc_nw_lte_nr_ca_info_t_cc_cw1_cqi = ProtoField.uint8   ("mtkmipc.struct.cc_cw1_cqi", "cc_cw1_cqi", base.DEC)
mipc_nw_lte_nr_ca_info_t_cell_bandwidth = ProtoField.uint8   ("mtkmipc.struct.cell_bandwidth", "cell_bandwidth", base.DEC)
mipc_nw_lte_nr_ca_info_t_cell_band = ProtoField.uint16   ("mtkmipc.struct.cell_band", "cell_band", base.DEC)
mipc_nw_lte_nr_ca_info_t_cc_pci = ProtoField.uint16   ("mtkmipc.struct.cc_pci", "cc_pci", base.DEC)
mipc_nw_lte_nr_ca_info_t_cc_arfcn = ProtoField.uint32   ("mtkmipc.struct.cc_arfcn", "cc_arfcn", base.DEC)
mipc_nw_lte_nr_ca_info_t_cell_bandwidth_str = ProtoField.new("cell_bandwidth_str", "mtkmipc.struct.cell_bandwidth_str", ftypes.STRING)
mipc_nw_umts_cell_frequency_info_t_ul_arfcn = ProtoField.uint32   ("mtkmipc.struct.ul_arfcn", "ul_arfcn", base.DEC)
mipc_nw_umts_cell_frequency_info_t_dl_arfcn = ProtoField.uint32   ("mtkmipc.struct.dl_arfcn", "dl_arfcn", base.DEC)
mipc_nw_umts_cell_frequency_info_t_band = ProtoField.uint32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_cell_plmn_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_cell_plmn_t_plmn_name = ProtoField.new("plmn_name", "mtkmipc.struct.plmn_name", ftypes.STRING)
mipc_nw_raw_signal_info_t_sig1 = ProtoField.int32   ("mtkmipc.struct.sig1", "sig1", base.DEC)
mipc_nw_raw_signal_info_t_sig2 = ProtoField.int32   ("mtkmipc.struct.sig2", "sig2", base.DEC)
mipc_nw_raw_signal_info_t_rssi_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rssi_in_qdbm", "rssi_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_rscp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rscp_in_qdbm", "rscp_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_ecn0_in_qdbm = ProtoField.int32   ("mtkmipc.struct.ecn0_in_qdbm", "ecn0_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrq_in_qdbm", "rsrq_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrp_in_qdbm", "rsrp_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_eact = ProtoField.int32   ("mtkmipc.struct.eact", "eact", base.DEC)
mipc_nw_raw_signal_info_t_sig3 = ProtoField.int32   ("mtkmipc.struct.sig3", "sig3", base.DEC)
mipc_nw_raw_signal_info_t_serv_band = ProtoField.int32   ("mtkmipc.struct.serv_band", "serv_band", base.DEC)
mipc_nw_raw_signal_info_t_second_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.second_rsrq_in_qdbm", "second_rsrq_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_second_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.second_rsrp_in_qdbm", "second_rsrp_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_t_second_sig3 = ProtoField.int32   ("mtkmipc.struct.second_sig3", "second_sig3", base.DEC)
mipc_nw_raw_signal_info_t_signal_type = ProtoField.uint8   ("mtkmipc.struct.signal_type", "signal_type", base.DEC, NW_SIGNAL_TYPE)
mipc_nw_raw_signal_info_v1_t_sig1 = ProtoField.int32   ("mtkmipc.struct.sig1", "sig1", base.DEC)
mipc_nw_raw_signal_info_v1_t_sig2 = ProtoField.int32   ("mtkmipc.struct.sig2", "sig2", base.DEC)
mipc_nw_raw_signal_info_v1_t_rssi_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rssi_in_qdbm", "rssi_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_rscp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rscp_in_qdbm", "rscp_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_ecn0_in_qdbm = ProtoField.int32   ("mtkmipc.struct.ecn0_in_qdbm", "ecn0_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrq_in_qdbm", "rsrq_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.rsrp_in_qdbm", "rsrp_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_eact = ProtoField.int32   ("mtkmipc.struct.eact", "eact", base.DEC)
mipc_nw_raw_signal_info_v1_t_sig3 = ProtoField.int32   ("mtkmipc.struct.sig3", "sig3", base.DEC)
mipc_nw_raw_signal_info_v1_t_serv_band = ProtoField.int32   ("mtkmipc.struct.serv_band", "serv_band", base.DEC)
mipc_nw_raw_signal_info_v1_t_second_rsrq_in_qdbm = ProtoField.int32   ("mtkmipc.struct.second_rsrq_in_qdbm", "second_rsrq_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_second_rsrp_in_qdbm = ProtoField.int32   ("mtkmipc.struct.second_rsrp_in_qdbm", "second_rsrp_in_qdbm", base.DEC)
mipc_nw_raw_signal_info_v1_t_second_sig3 = ProtoField.int32   ("mtkmipc.struct.second_sig3", "second_sig3", base.DEC)
mipc_nw_raw_signal_info_v1_t_signal_type = ProtoField.uint8   ("mtkmipc.struct.signal_type", "signal_type", base.DEC, NW_SIGNAL_TYPE)
mipc_nw_raw_signal_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_physical_channel_info_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC, NW_DATA_SPEED)
mipc_physical_channel_info_t_status = ProtoField.uint8   ("mtkmipc.struct.status", "status", base.DEC, NW_CELL_CONNECTION_STATE)
mipc_physical_channel_info_t_cell_bandwidth_downlink = ProtoField.int32   ("mtkmipc.struct.cell_bandwidth_downlink", "cell_bandwidth_downlink", base.DEC)
mipc_physical_channel_info_t_channel_number = ProtoField.int32   ("mtkmipc.struct.channel_number", "channel_number", base.DEC)
mipc_physical_channel_info_t_num_cids = ProtoField.int32   ("mtkmipc.struct.num_cids", "num_cids", base.DEC)
mipc_physical_channel_info_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_physical_channel_info_v1_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC, NW_DATA_SPEED)
mipc_physical_channel_info_v1_t_status = ProtoField.uint8   ("mtkmipc.struct.status", "status", base.DEC, NW_CELL_CONNECTION_STATE)
mipc_physical_channel_info_v1_t_cell_bandwidth_downlink = ProtoField.int32   ("mtkmipc.struct.cell_bandwidth_downlink", "cell_bandwidth_downlink", base.DEC)
mipc_physical_channel_info_v1_t_cell_bandwidth_uplink = ProtoField.int32   ("mtkmipc.struct.cell_bandwidth_uplink", "cell_bandwidth_uplink", base.DEC)
mipc_physical_channel_info_v1_t_downlink_channel_number = ProtoField.int32   ("mtkmipc.struct.downlink_channel_number", "downlink_channel_number", base.DEC)
mipc_physical_channel_info_v1_t_uplink_channel_number = ProtoField.int32   ("mtkmipc.struct.uplink_channel_number", "uplink_channel_number", base.DEC)
mipc_physical_channel_info_v1_t_num_cids = ProtoField.int32   ("mtkmipc.struct.num_cids", "num_cids", base.DEC)
mipc_physical_channel_info_v1_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_physical_channel_info_v1_t_band = ProtoField.uint32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_physical_channel_info_v1_t_frequency_range = ProtoField.uint32   ("mtkmipc.struct.frequency_range", "frequency_range", base.DEC)
mipc_physical_channel_info_v2_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC, NW_DATA_SPEED)
mipc_physical_channel_info_v2_t_status = ProtoField.uint8   ("mtkmipc.struct.status", "status", base.DEC, NW_CELL_CONNECTION_STATE)
mipc_physical_channel_info_v2_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_physical_channel_info_v2_t_cell_bandwidth_downlink = ProtoField.int32   ("mtkmipc.struct.cell_bandwidth_downlink", "cell_bandwidth_downlink", base.DEC)
mipc_physical_channel_info_v2_t_cell_bandwidth_uplink = ProtoField.int32   ("mtkmipc.struct.cell_bandwidth_uplink", "cell_bandwidth_uplink", base.DEC)
mipc_physical_channel_info_v2_t_downlink_channel_number = ProtoField.int32   ("mtkmipc.struct.downlink_channel_number", "downlink_channel_number", base.DEC)
mipc_physical_channel_info_v2_t_uplink_channel_number = ProtoField.int32   ("mtkmipc.struct.uplink_channel_number", "uplink_channel_number", base.DEC)
mipc_physical_channel_info_v2_t_num_cids = ProtoField.int32   ("mtkmipc.struct.num_cids", "num_cids", base.DEC)
mipc_physical_channel_info_v2_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_physical_channel_info_v2_t_band = ProtoField.uint32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_physical_channel_info_v2_t_frequency_range = ProtoField.uint32   ("mtkmipc.struct.frequency_range", "frequency_range", base.DEC)
mipc_nw_name_pair_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_name_pair_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_band_power_pair_t_band = ProtoField.uint32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_nw_band_power_pair_t_power = ProtoField.uint32   ("mtkmipc.struct.power", "power", base.DEC)
mipc_nw_suggested_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC, NW_PROVIDER_STATE)
mipc_nw_suggested_t_network_long_name = ProtoField.new("network_long_name", "mtkmipc.struct.network_long_name", ftypes.STRING)
mipc_nw_suggested_t_network_short_name = ProtoField.new("network_short_name", "mtkmipc.struct.network_short_name", ftypes.STRING)
mipc_nw_suggested_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_suggested_t_lac = ProtoField.new("lac", "mtkmipc.struct.lac", ftypes.STRING)
mipc_nw_suggested_t_act = ProtoField.uint32   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_suggested_v1_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC, NW_PROVIDER_STATE)
mipc_nw_suggested_v1_t_network_long_name = ProtoField.new("network_long_name", "mtkmipc.struct.network_long_name", ftypes.STRING)
mipc_nw_suggested_v1_t_network_short_name = ProtoField.new("network_short_name", "mtkmipc.struct.network_short_name", ftypes.STRING)
mipc_nw_suggested_v1_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_suggested_v1_t_lac = ProtoField.new("lac", "mtkmipc.struct.lac", ftypes.STRING)
mipc_nw_suggested_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_suggested_v1_t_act = ProtoField.uint32   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_arfcn_t_arfcn = ProtoField.uint32   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_femtocell_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_femtocell_info_t_oper_long_name = ProtoField.new("oper_long_name", "mtkmipc.struct.oper_long_name", ftypes.STRING)
mipc_nw_femtocell_info_t_oper_short_name = ProtoField.new("oper_short_name", "mtkmipc.struct.oper_short_name", ftypes.STRING)
mipc_nw_femtocell_info_t_act = ProtoField.uint8   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_femtocell_info_t_num_csg = ProtoField.uint8   ("mtkmipc.struct.num_csg", "num_csg", base.DEC)
mipc_nw_femtocell_info_t_csg_id = ProtoField.uint32   ("mtkmipc.struct.csg_id", "csg_id", base.DEC)
mipc_nw_femtocell_info_t_csg_type = ProtoField.uint8   ("mtkmipc.struct.csg_type", "csg_type", base.DEC)
mipc_nw_femtocell_info_t_hnb_name = ProtoField.new("hnb_name", "mtkmipc.struct.hnb_name", ftypes.STRING)
mipc_nw_femtocell_info_t_sig = ProtoField.new("sig", "mtkmipc.struct.sig", ftypes.STRING)
mipc_nw_femtocell_info_v1_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_femtocell_info_v1_t_oper_long_name = ProtoField.new("oper_long_name", "mtkmipc.struct.oper_long_name", ftypes.STRING)
mipc_nw_femtocell_info_v1_t_oper_short_name = ProtoField.new("oper_short_name", "mtkmipc.struct.oper_short_name", ftypes.STRING)
mipc_nw_femtocell_info_v1_t_act = ProtoField.uint8   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_femtocell_info_v1_t_num_csg = ProtoField.uint8   ("mtkmipc.struct.num_csg", "num_csg", base.DEC)
mipc_nw_femtocell_info_v1_t_padding1 = ProtoField.new("padding1", "mtkmipc.struct.padding1", ftypes.BYTES)
mipc_nw_femtocell_info_v1_t_csg_id = ProtoField.uint32   ("mtkmipc.struct.csg_id", "csg_id", base.DEC)
mipc_nw_femtocell_info_v1_t_csg_type = ProtoField.uint8   ("mtkmipc.struct.csg_type", "csg_type", base.DEC)
mipc_nw_femtocell_info_v1_t_hnb_name = ProtoField.new("hnb_name", "mtkmipc.struct.hnb_name", ftypes.STRING)
mipc_nw_femtocell_info_v1_t_sig = ProtoField.new("sig", "mtkmipc.struct.sig", ftypes.STRING)
mipc_nw_femtocell_info_v1_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_pseudocell_info_t_type = ProtoField.uint8   ("mtkmipc.struct.type", "type", base.DEC)
mipc_nw_pseudocell_info_t_plmn = ProtoField.new("plmn", "mtkmipc.struct.plmn", ftypes.STRING)
mipc_nw_pseudocell_info_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_pseudocell_info_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_pseudocell_info_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_pseudocell_info_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_pseudocell_info_t_arfcn = ProtoField.uint16   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_pseudocell_info_t_bsic = ProtoField.uint8   ("mtkmipc.struct.bsic", "bsic", base.DEC)
mipc_nw_pseudocell_info_t_si3_raw_data = ProtoField.new("si3_raw_data", "mtkmipc.struct.si3_raw_data", ftypes.STRING)
mipc_nw_barring_info_t_service_type = ProtoField.uint16   ("mtkmipc.struct.service_type", "service_type", base.DEC)
mipc_nw_barring_info_t_barring_type = ProtoField.uint8   ("mtkmipc.struct.barring_type", "barring_type", base.DEC)
mipc_nw_barring_info_t_factor = ProtoField.uint8   ("mtkmipc.struct.factor", "factor", base.DEC)
mipc_nw_barring_info_t_time_seconds = ProtoField.uint16   ("mtkmipc.struct.time_seconds", "time_seconds", base.DEC)
mipc_nw_barring_info_t_is_barred = ProtoField.uint8   ("mtkmipc.struct.is_barred", "is_barred", base.DEC)
mipc_nw_barring_info_v1_t_service_type = ProtoField.uint16   ("mtkmipc.struct.service_type", "service_type", base.DEC)
mipc_nw_barring_info_v1_t_barring_type = ProtoField.uint8   ("mtkmipc.struct.barring_type", "barring_type", base.DEC)
mipc_nw_barring_info_v1_t_factor = ProtoField.uint8   ("mtkmipc.struct.factor", "factor", base.DEC)
mipc_nw_barring_info_v1_t_time_seconds = ProtoField.uint16   ("mtkmipc.struct.time_seconds", "time_seconds", base.DEC)
mipc_nw_barring_info_v1_t_is_barred = ProtoField.uint8   ("mtkmipc.struct.is_barred", "is_barred", base.DEC)
mipc_nw_barring_info_v1_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_nw_threshold_array_t_num_of_threshold = ProtoField.uint8   ("mtkmipc.struct.num_of_threshold", "num_of_threshold", base.DEC)
mipc_nw_threshold_array_t_threshold_dbm = ProtoField.int32   ("mtkmipc.struct.threshold_dbm", "threshold_dbm", base.DEC)
mipc_nw_threshold_array_v1_t_num_of_threshold = ProtoField.uint8   ("mtkmipc.struct.num_of_threshold", "num_of_threshold", base.DEC)
mipc_nw_threshold_array_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_threshold_array_v1_t_threshold_dbm = ProtoField.int32   ("mtkmipc.struct.threshold_dbm", "threshold_dbm", base.DEC)
mipc_nw_extend_provider_t_index = ProtoField.uint32   ("mtkmipc.struct.index", "index", base.DEC)
mipc_nw_extend_provider_t_stat = ProtoField.uint32   ("mtkmipc.struct.stat", "stat", base.DEC, NW_PROVIDER_STATE)
mipc_nw_extend_provider_t_oper_long_name = ProtoField.new("oper_long_name", "mtkmipc.struct.oper_long_name", ftypes.STRING)
mipc_nw_extend_provider_t_oper_short_name = ProtoField.new("oper_short_name", "mtkmipc.struct.oper_short_name", ftypes.STRING)
mipc_nw_extend_provider_t_oper_numeric_name = ProtoField.new("oper_numeric_name", "mtkmipc.struct.oper_numeric_name", ftypes.STRING)
mipc_nw_extend_provider_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_nw_extend_provider_t_lac = ProtoField.new("lac", "mtkmipc.struct.lac", ftypes.STRING)
mipc_nw_extend_provider_t_act = ProtoField.uint32   ("mtkmipc.struct.act", "act", base.DEC)
mipc_nw_extend_provider_t_csq_rssi = ProtoField.uint32   ("mtkmipc.struct.csq_rssi", "csq_rssi", base.DEC)
mipc_nw_extend_provider_t_register_state = ProtoField.uint32   ("mtkmipc.struct.register_state", "register_state", base.DEC)
mipc_nw_extend_provider_t_timestamp_type = ProtoField.uint32   ("mtkmipc.struct.timestamp_type", "timestamp_type", base.DEC)
mipc_nw_extend_provider_t_timestamp = ProtoField.int32   ("mtkmipc.struct.timestamp", "timestamp", base.DEC)
mipc_nw_extend_provider_t_connection_stat = ProtoField.uint32   ("mtkmipc.struct.connection_stat", "connection_stat", base.DEC)
mipc_nw_extend_provider_t_cell_id = ProtoField.new("cell_id", "mtkmipc.struct.cell_id", ftypes.STRING)
mipc_nw_extend_provider_t_freq = ProtoField.uint32   ("mtkmipc.struct.freq", "freq", base.DEC)
mipc_nw_extend_provider_t_bsic_psc_cpid_pci = ProtoField.int32   ("mtkmipc.struct.bsic_psc_cpid_pci", "bsic_psc_cpid_pci", base.DEC)
mipc_nw_extend_provider_t_sig2 = ProtoField.int32   ("mtkmipc.struct.sig2", "sig2", base.DEC)
mipc_nw_extend_provider_t_sig3 = ProtoField.int32   ("mtkmipc.struct.sig3", "sig3", base.DEC)
mipc_nw_extend_provider_t_sig4 = ProtoField.int32   ("mtkmipc.struct.sig4", "sig4", base.DEC)
mipc_nw_extend_provider_t_sig5 = ProtoField.int32   ("mtkmipc.struct.sig5", "sig5", base.DEC)
mipc_nw_extend_provider_t_bit_error_rat = ProtoField.uint32   ("mtkmipc.struct.bit_error_rat", "bit_error_rat", base.DEC)
mipc_nw_extend_provider_t_timing_advance = ProtoField.uint32   ("mtkmipc.struct.timing_advance", "timing_advance", base.DEC)
mipc_nw_extend_provider_t_cqi = ProtoField.uint32   ("mtkmipc.struct.cqi", "cqi", base.DEC)
mipc_nw_ecainfo_t_ca_info = ProtoField.uint32   ("mtkmipc.struct.ca_info", "ca_info", base.DEC)
mipc_nw_ecainfo_t_pcell_bw = ProtoField.uint32   ("mtkmipc.struct.pcell_bw", "pcell_bw", base.DEC)
mipc_nw_ecainfo_t_scell_bw1 = ProtoField.uint32   ("mtkmipc.struct.scell_bw1", "scell_bw1", base.DEC)
mipc_nw_ecainfo_t_scell_bw2 = ProtoField.uint32   ("mtkmipc.struct.scell_bw2", "scell_bw2", base.DEC)
mipc_nw_ecainfo_t_scell_bw3 = ProtoField.uint32   ("mtkmipc.struct.scell_bw3", "scell_bw3", base.DEC)
mipc_nw_ecainfo_t_scell_bw4 = ProtoField.uint32   ("mtkmipc.struct.scell_bw4", "scell_bw4", base.DEC)
mipc_1xrtt_cell_info_t_sid = ProtoField.int32   ("mtkmipc.struct.sid", "sid", base.DEC)
mipc_1xrtt_cell_info_t_nid = ProtoField.int32   ("mtkmipc.struct.nid", "nid", base.DEC)
mipc_1xrtt_cell_info_t_bsid = ProtoField.int32   ("mtkmipc.struct.bsid", "bsid", base.DEC)
mipc_band_combo_info_t_band_combo = ProtoField.new("band_combo", "mtkmipc.struct.band_combo", ftypes.STRING)
mipc_nw_ca_band_t_ca_band_class = ProtoField.uint32   ("mtkmipc.struct.ca_band_class", "ca_band_class", base.DEC)
mipc_nw_tuw_info_t_tuw_id = ProtoField.uint8   ("mtkmipc.struct.tuw_id", "tuw_id", base.DEC, NW_TUW_ID)
mipc_nw_tuw_info_t_tuw_length = ProtoField.uint32   ("mtkmipc.struct.tuw_length", "tuw_length", base.DEC)
mipc_nw_tuw_info_v1_t_tuw_id = ProtoField.uint8   ("mtkmipc.struct.tuw_id", "tuw_id", base.DEC, NW_TUW_ID)
mipc_nw_tuw_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_tuw_info_v1_t_tuw_length = ProtoField.uint32   ("mtkmipc.struct.tuw_length", "tuw_length", base.DEC)
mipc_nr_ca_band_t_band = ProtoField.int32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_lte_bound_info_t_sbp_id = ProtoField.uint32   ("mtkmipc.struct.sbp_id", "sbp_id", base.DEC)
mipc_lte_bound_info_t_event_type = ProtoField.uint32   ("mtkmipc.struct.event_type", "event_type", base.DEC, LTE_EVENT_TYPE)
mipc_lte_bound_info_t_threshold = ProtoField.uint32   ("mtkmipc.struct.threshold", "threshold", base.DEC)
mipc_lte_bound_info_t_signal_quality_type = ProtoField.uint32   ("mtkmipc.struct.signal_quality_type", "signal_quality_type", base.DEC, SIGNAL_QUALITY_TYPE)
mipc_lte_bound_info_t_upper_bound = ProtoField.int32   ("mtkmipc.struct.upper_bound", "upper_bound", base.DEC)
mipc_lte_bound_info_t_lower_bound = ProtoField.int32   ("mtkmipc.struct.lower_bound", "lower_bound", base.DEC)
mipc_nw_allowed_mcc_list_t_allowed_mcc_number = ProtoField.uint32   ("mtkmipc.struct.allowed_mcc_number", "allowed_mcc_number", base.DEC)
mipc_nw_allowed_mcc_list_t_allowed_mcc = ProtoField.uint16   ("mtkmipc.struct.allowed_mcc", "allowed_mcc", base.DEC)
mipc_nw_record_info_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC, NW_SCAN_RAT)
mipc_nw_record_info_t_num_band = ProtoField.uint32   ("mtkmipc.struct.num_band", "num_band", base.DEC)
mipc_nw_record_info_t_band = ProtoField.uint32   ("mtkmipc.struct.band", "band", base.DEC)
mipc_nw_record_info_t_num_channel = ProtoField.uint32   ("mtkmipc.struct.num_channel", "num_channel", base.DEC)
mipc_nw_record_info_t_channel = ProtoField.uint32   ("mtkmipc.struct.channel", "channel", base.DEC)
mipc_nw_plmn_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_scan_info_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC, NW_SCAN_RAT)
mipc_nw_scan_info_t_xarfcn = ProtoField.int32   ("mtkmipc.struct.xarfcn", "xarfcn", base.DEC)
mipc_nw_scan_info_t_pcid = ProtoField.int32   ("mtkmipc.struct.pcid", "pcid", base.DEC)
mipc_nw_scan_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_scan_info_t_cell_id = ProtoField.new("cell_id", "mtkmipc.struct.cell_id", ftypes.STRING)
mipc_nw_scan_info_t_lac_or_tac = ProtoField.new("lac_or_tac", "mtkmipc.struct.lac_or_tac", ftypes.STRING)
mipc_nw_scan_info_t_plmn_status = ProtoField.int32   ("mtkmipc.struct.plmn_status", "plmn_status", base.DEC)
mipc_nw_scan_info_t_registered = ProtoField.int32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_scan_info_t_srv_cell_status = ProtoField.int32   ("mtkmipc.struct.srv_cell_status", "srv_cell_status", base.DEC)
mipc_nw_scan_info_t_sig1 = ProtoField.int32   ("mtkmipc.struct.sig1", "sig1", base.DEC)
mipc_nw_scan_info_t_sig2 = ProtoField.int32   ("mtkmipc.struct.sig2", "sig2", base.DEC)
mipc_nw_scan_info_t_sig3 = ProtoField.int32   ("mtkmipc.struct.sig3", "sig3", base.DEC)
mipc_nw_scan_info_t_sig4 = ProtoField.int32   ("mtkmipc.struct.sig4", "sig4", base.DEC)
mipc_nw_scan_info_t_sig5 = ProtoField.int32   ("mtkmipc.struct.sig5", "sig5", base.DEC)
mipc_nw_scan_info_v1_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC, NW_SCAN_RAT)
mipc_nw_scan_info_v1_t_xarfcn = ProtoField.int32   ("mtkmipc.struct.xarfcn", "xarfcn", base.DEC)
mipc_nw_scan_info_v1_t_pcid = ProtoField.int32   ("mtkmipc.struct.pcid", "pcid", base.DEC)
mipc_nw_scan_info_v1_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_nw_scan_info_v1_t_cell_id = ProtoField.new("cell_id", "mtkmipc.struct.cell_id", ftypes.STRING)
mipc_nw_scan_info_v1_t_lac_or_tac = ProtoField.new("lac_or_tac", "mtkmipc.struct.lac_or_tac", ftypes.STRING)
mipc_nw_scan_info_v1_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_nw_scan_info_v1_t_plmn_status = ProtoField.int32   ("mtkmipc.struct.plmn_status", "plmn_status", base.DEC)
mipc_nw_scan_info_v1_t_registered = ProtoField.int32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_scan_info_v1_t_srv_cell_status = ProtoField.int32   ("mtkmipc.struct.srv_cell_status", "srv_cell_status", base.DEC)
mipc_nw_scan_info_v1_t_sig1 = ProtoField.int32   ("mtkmipc.struct.sig1", "sig1", base.DEC)
mipc_nw_scan_info_v1_t_sig2 = ProtoField.int32   ("mtkmipc.struct.sig2", "sig2", base.DEC)
mipc_nw_scan_info_v1_t_sig3 = ProtoField.int32   ("mtkmipc.struct.sig3", "sig3", base.DEC)
mipc_nw_scan_info_v1_t_sig4 = ProtoField.int32   ("mtkmipc.struct.sig4", "sig4", base.DEC)
mipc_nw_scan_info_v1_t_sig5 = ProtoField.int32   ("mtkmipc.struct.sig5", "sig5", base.DEC)
mipc_os_id_info_t_os_id = ProtoField.new("os_id", "mtkmipc.struct.os_id", ftypes.BYTES)
mipc_nw_congestion_info_v1_t_mode = ProtoField.uint32   ("mtkmipc.struct.mode", "mode", base.DEC)
mipc_nw_congestion_info_v1_t_op = ProtoField.uint32   ("mtkmipc.struct.op", "op", base.DEC)
mipc_nw_congestion_info_v1_t_serv_type = ProtoField.uint32   ("mtkmipc.struct.serv_type", "serv_type", base.DEC)
mipc_nw_congestion_info_v1_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC)
mipc_nw_congestion_info_v1_t_det_time = ProtoField.uint32   ("mtkmipc.struct.det_time", "det_time", base.DEC)
mipc_nw_congestion_info_v1_t_duration = ProtoField.uint32   ("mtkmipc.struct.duration", "duration", base.DEC)
mipc_nw_congestion_info_v1_t_bar_duration = ProtoField.uint32   ("mtkmipc.struct.bar_duration", "bar_duration", base.DEC)
mipc_nw_congestion_info_v1_t_cond_grant_bytes = ProtoField.uint32   ("mtkmipc.struct.cond_grant_bytes", "cond_grant_bytes", base.DEC)
mipc_nw_congestion_info_v1_t_cond_bsr = ProtoField.uint32   ("mtkmipc.struct.cond_bsr", "cond_bsr", base.DEC)
mipc_nw_congestion_info_v1_t_cond_pdcp_discard_rate = ProtoField.uint32   ("mtkmipc.struct.cond_pdcp_discard_rate", "cond_pdcp_discard_rate", base.DEC)
mipc_nw_congestion_info_v1_t_cond_phr = ProtoField.int32   ("mtkmipc.struct.cond_phr", "cond_phr", base.DEC)
mipc_nw_congestion_info_v1_t_cond_s_rsrp = ProtoField.int32   ("mtkmipc.struct.cond_s_rsrp", "cond_s_rsrp", base.DEC)
mipc_nw_congestion_info_v1_t_cond_s_sinr = ProtoField.int32   ("mtkmipc.struct.cond_s_sinr", "cond_s_sinr", base.DEC)
mipc_nw_congestion_info_v1_t_cond_n_rsrp = ProtoField.int32   ("mtkmipc.struct.cond_n_rsrp", "cond_n_rsrp", base.DEC)
mipc_nw_congestion_info_v1_t_cond_n_sinr = ProtoField.int32   ("mtkmipc.struct.cond_n_sinr", "cond_n_sinr", base.DEC)
mipc_nw_congestion_info_v1_t_cond_ul_bler = ProtoField.uint32   ("mtkmipc.struct.cond_ul_bler", "cond_ul_bler", base.DEC)
mipc_nw_congestion_info_v1_t_cond_dl_bler = ProtoField.uint32   ("mtkmipc.struct.cond_dl_bler", "cond_dl_bler", base.DEC)
mipc_nw_congestion_info_v1_t_cond_ul_tput = ProtoField.uint32   ("mtkmipc.struct.cond_ul_tput", "cond_ul_tput", base.DEC)
mipc_nw_congestion_info_v1_t_cond_dl_tput = ProtoField.uint32   ("mtkmipc.struct.cond_dl_tput", "cond_dl_tput", base.DEC)
mipc_nw_congestion_info_v1_t_cond_ul_alloc_rate = ProtoField.uint32   ("mtkmipc.struct.cond_ul_alloc_rate", "cond_ul_alloc_rate", base.DEC)
mipc_nw_congestion_info_v1_t_cond_dl_alloc_rate = ProtoField.uint32   ("mtkmipc.struct.cond_dl_alloc_rate", "cond_dl_alloc_rate", base.DEC)
mipc_nw_congestion_info_v1_t_cond_ul_pending_data = ProtoField.uint32   ("mtkmipc.struct.cond_ul_pending_data", "cond_ul_pending_data", base.DEC)
mipc_nw_handover_rat_info_t_para_number = ProtoField.uint8   ("mtkmipc.struct.para_number", "para_number", base.DEC)
mipc_nw_handover_rat_info_t_rat = ProtoField.uint8   ("mtkmipc.struct.rat", "rat", base.DEC, NW_HANDOVER_RAT_TYPE)
mipc_nw_handover_rat_info_t_mcc = ProtoField.uint16   ("mtkmipc.struct.mcc", "mcc", base.DEC)
mipc_nw_handover_rat_info_t_mnc = ProtoField.uint16   ("mtkmipc.struct.mnc", "mnc", base.DEC)
mipc_nw_handover_rat_info_t_mnc_digit_num = ProtoField.uint8   ("mtkmipc.struct.mnc_digit_num", "mnc_digit_num", base.DEC)
mipc_nw_handover_rat_info_t_padding1 = ProtoField.new("padding1", "mtkmipc.struct.padding1", ftypes.BYTES)
mipc_nw_handover_rat_info_t_area_code = ProtoField.uint32   ("mtkmipc.struct.area_code", "area_code", base.DEC)
mipc_nw_handover_rat_info_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_handover_rat_info_t_band = ProtoField.uint16   ("mtkmipc.struct.band", "band", base.DEC)
mipc_nw_handover_rat_info_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_handover_rat_info_t_arfcn = ProtoField.uint32   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_sim_msisdn_t_msisdn = ProtoField.new("msisdn", "mtkmipc.struct.msisdn", ftypes.BYTES)
mipc_sim_pin_desc_t_pin_mode = ProtoField.uint8   ("mtkmipc.struct.pin_mode", "pin_mode", base.DEC)
mipc_sim_pin_desc_t_pin_format = ProtoField.uint8   ("mtkmipc.struct.pin_format", "pin_format", base.DEC)
mipc_sim_pin_desc_t_pin_len_min = ProtoField.uint8   ("mtkmipc.struct.pin_len_min", "pin_len_min", base.DEC)
mipc_sim_pin_desc_t_pin_len_max = ProtoField.uint8   ("mtkmipc.struct.pin_len_max", "pin_len_max", base.DEC)
mipc_sim_app_info_t_app_type = ProtoField.uint8   ("mtkmipc.struct.app_type", "app_type", base.DEC)
mipc_sim_app_info_t_app_id_len = ProtoField.uint8   ("mtkmipc.struct.app_id_len", "app_id_len", base.DEC)
mipc_sim_app_info_t_sim_app_id = ProtoField.new("sim_app_id", "mtkmipc.struct.sim_app_id", ftypes.BYTES)
mipc_sim_app_info_t_name_len = ProtoField.uint8   ("mtkmipc.struct.name_len", "name_len", base.DEC)
mipc_sim_app_info_t_name = ProtoField.new("name", "mtkmipc.struct.name", ftypes.BYTES)
mipc_sim_app_info_t_num_of_pins = ProtoField.uint8   ("mtkmipc.struct.num_of_pins", "num_of_pins", base.DEC)
mipc_sim_app_info_t_pin_ref = ProtoField.new("pin_ref", "mtkmipc.struct.pin_ref", ftypes.BYTES)
mipc_sim_slots_info_t_card_state = ProtoField.new("card_state", "mtkmipc.struct.card_state", ftypes.STRING)
mipc_sim_slots_info_t_slots_state = ProtoField.uint8   ("mtkmipc.struct.slots_state", "slots_state", base.DEC)
mipc_sim_slots_info_t_logical_idx = ProtoField.uint8   ("mtkmipc.struct.logical_idx", "logical_idx", base.DEC)
mipc_sim_slots_info_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_sim_slots_info_t_atr = ProtoField.new("atr", "mtkmipc.struct.atr", ftypes.STRING)
mipc_sim_slots_info_t_eid = ProtoField.new("eid", "mtkmipc.struct.eid", ftypes.STRING)
mipc_sim_slots_info_t_iccid = ProtoField.new("iccid", "mtkmipc.struct.iccid", ftypes.STRING)
mipc_eid_byte_struct_t_is_valid = ProtoField.uint8   ("mtkmipc.struct.is_valid", "is_valid", base.DEC, BOOLEAN)
mipc_eid_byte_struct_t_eid = ProtoField.new("eid", "mtkmipc.struct.eid", ftypes.BYTES)
mipc_port_info_t_iccid = ProtoField.new("iccid", "mtkmipc.struct.iccid", ftypes.STRING)
mipc_port_info_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.STRING)
mipc_port_info_t_lsi = ProtoField.uint8   ("mtkmipc.struct.lsi", "lsi", base.DEC)
mipc_port_info_t_port_active = ProtoField.uint8   ("mtkmipc.struct.port_active", "port_active", base.DEC, BOOLEAN)
mipc_port_info_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.STRING)
mipc_app_status_desc_t_app_type = ProtoField.uint8   ("mtkmipc.struct.app_type", "app_type", base.DEC, SIM_APP_TYPE)
mipc_app_status_desc_t_app_state = ProtoField.uint8   ("mtkmipc.struct.app_state", "app_state", base.DEC, SIM_APP_STATE)
mipc_app_status_desc_t_pin_status = ProtoField.uint8   ("mtkmipc.struct.pin_status", "pin_status", base.DEC, SIM_PIN_STATE)
mipc_app_status_desc_t_sub_status = ProtoField.uint8   ("mtkmipc.struct.sub_status", "sub_status", base.DEC, SIM_APP_SUB_STATUS)
mipc_app_status_desc_t_pin1_replaced = ProtoField.uint8   ("mtkmipc.struct.pin1_replaced", "pin1_replaced", base.DEC)
mipc_app_status_desc_t_pin1_state = ProtoField.uint8   ("mtkmipc.struct.pin1_state", "pin1_state", base.DEC, PIN_STATE)
mipc_app_status_desc_t_pin2_state = ProtoField.uint8   ("mtkmipc.struct.pin2_state", "pin2_state", base.DEC, PIN_STATE)
mipc_app_status_desc_t_reserved1 = ProtoField.uint8   ("mtkmipc.struct.reserved1", "reserved1", base.DEC)
mipc_app_status_desc_t_aid = ProtoField.new("aid", "mtkmipc.struct.aid", ftypes.STRING)
mipc_app_status_desc_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_app_status_desc_t_app_label = ProtoField.new("app_label", "mtkmipc.struct.app_label", ftypes.STRING)
mipc_app_status_desc_t_reserved3 = ProtoField.new("reserved3", "mtkmipc.struct.reserved3", ftypes.BYTES)
mipc_file_list_t_path = ProtoField.new("path", "mtkmipc.struct.path", ftypes.STRING)
mipc_file_list_t_data = ProtoField.new("data", "mtkmipc.struct.data", ftypes.STRING)
mipc_sid_nid_list_t_sid = ProtoField.new("sid", "mtkmipc.struct.sid", ftypes.STRING)
mipc_sid_nid_list_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_sid_nid_list_t_nid = ProtoField.new("nid", "mtkmipc.struct.nid", ftypes.STRING)
mipc_sim_carrier_struct_t_mcc = ProtoField.new("mcc", "mtkmipc.struct.mcc", ftypes.STRING)
mipc_sim_carrier_struct_t_mnc = ProtoField.new("mnc", "mtkmipc.struct.mnc", ftypes.STRING)
mipc_sim_carrier_struct_t_match_cat = ProtoField.uint8   ("mtkmipc.struct.match_cat", "match_cat", base.DEC)
mipc_sim_carrier_struct_t_match_data = ProtoField.new("match_data", "mtkmipc.struct.match_data", ftypes.STRING)
mipc_sms_pdu_t_message_index = ProtoField.uint16   ("mtkmipc.struct.message_index", "message_index", base.DEC)
mipc_sms_pdu_t_pdu_len = ProtoField.uint8   ("mtkmipc.struct.pdu_len", "pdu_len", base.DEC)
mipc_sms_pdu_t_status = ProtoField.uint8   ("mtkmipc.struct.status", "status", base.DEC, SMS_STATUS)
mipc_sms_pdu_t_sms_class = ProtoField.uint8   ("mtkmipc.struct.sms_class", "sms_class", base.DEC, SMS_CLASS)
mipc_sms_pdu_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_sms_pdu_t_pdu = ProtoField.new("pdu", "mtkmipc.struct.pdu", ftypes.BYTES)
mipc_ss_call_forward_t_call_forward_status = ProtoField.uint8   ("mtkmipc.struct.call_forward_status", "call_forward_status", base.DEC, SS_ACTIVE_STATUS)
mipc_ss_call_forward_t_dial_number = ProtoField.new("dial_number", "mtkmipc.struct.dial_number", ftypes.STRING)
mipc_ss_call_forward_t_service_class = ProtoField.uint16   ("mtkmipc.struct.service_class", "service_class", base.DEC, SS_SERVICE_CLASS)
mipc_ss_call_forward_t_type_of_address = ProtoField.uint16   ("mtkmipc.struct.type_of_address", "type_of_address", base.DEC)
mipc_ss_call_forward_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_ss_call_forward_t_timer = ProtoField.uint8   ("mtkmipc.struct.timer", "timer", base.DEC)
mipc_ss_call_forward_t_reason = ProtoField.uint8   ("mtkmipc.struct.reason", "reason", base.DEC, SS_CALL_FORWARD_REASON)
mipc_ss_call_forward_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_ss_call_forward_t_time_slot_begin = ProtoField.new("time_slot_begin", "mtkmipc.struct.time_slot_begin", ftypes.STRING)
mipc_ss_call_forward_t_time_slot_end = ProtoField.new("time_slot_end", "mtkmipc.struct.time_slot_end", ftypes.STRING)
mipc_ss_call_waiting_t_call_waiting_status = ProtoField.uint8   ("mtkmipc.struct.call_waiting_status", "call_waiting_status", base.DEC, SS_ACTIVE_STATUS)
mipc_ss_call_waiting_t_padding = ProtoField.uint8   ("mtkmipc.struct.padding", "padding", base.DEC)
mipc_ss_call_waiting_t_service_class = ProtoField.uint16   ("mtkmipc.struct.service_class", "service_class", base.DEC, SS_SERVICE_CLASS)
mipc_ss_cb_dialnumber_t_number_status = ProtoField.uint8   ("mtkmipc.struct.number_status", "number_status", base.DEC, SS_ACTIVE_STATUS)
mipc_ss_cb_dialnumber_t_dial_number = ProtoField.new("dial_number", "mtkmipc.struct.dial_number", ftypes.STRING)
mipc_sys_mapping_t_ps_id = ProtoField.uint32   ("mtkmipc.struct.ps_id", "ps_id", base.DEC)
mipc_sys_lte_band_t_lte_band_class = ProtoField.uint32   ("mtkmipc.struct.lte_band_class", "lte_band_class", base.DEC)
mipc_sys_nr_band_t_nr_band_class = ProtoField.uint32   ("mtkmipc.struct.nr_band_class", "nr_band_class", base.DEC)
mipc_sys_thermal_sensor_config_t_enable = ProtoField.uint32   ("mtkmipc.struct.enable", "enable", base.DEC)
mipc_sys_thermal_sensor_config_t_sensor_id = ProtoField.uint32   ("mtkmipc.struct.sensor_id", "sensor_id", base.DEC)
mipc_sys_thermal_sensor_config_t_alarm_id = ProtoField.uint32   ("mtkmipc.struct.alarm_id", "alarm_id", base.DEC)
mipc_sys_thermal_sensor_config_t_threshold = ProtoField.int32   ("mtkmipc.struct.threshold", "threshold", base.DEC)
mipc_sys_thermal_sensor_config_t_hysteresis = ProtoField.uint32   ("mtkmipc.struct.hysteresis", "hysteresis", base.DEC)
mipc_sys_thermal_sensor_config_t_interval = ProtoField.uint32   ("mtkmipc.struct.interval", "interval", base.DEC)
mipc_sys_thermal_sensor_config_t_alarm_type = ProtoField.uint32   ("mtkmipc.struct.alarm_type", "alarm_type", base.DEC)
mipc_sys_thermal_sensor_config_e_t_enable = ProtoField.uint32   ("mtkmipc.struct.enable", "enable", base.DEC)
mipc_sys_thermal_sensor_config_e_t_sensor_id = ProtoField.uint32   ("mtkmipc.struct.sensor_id", "sensor_id", base.DEC)
mipc_sys_thermal_sensor_config_e_t_alarm_id = ProtoField.uint32   ("mtkmipc.struct.alarm_id", "alarm_id", base.DEC)
mipc_sys_thermal_sensor_config_e_t_threshold = ProtoField.int32   ("mtkmipc.struct.threshold", "threshold", base.DEC)
mipc_sys_thermal_sensor_config_e_t_hysteresis = ProtoField.uint32   ("mtkmipc.struct.hysteresis", "hysteresis", base.DEC)
mipc_sys_thermal_sensor_config_e_t_interval = ProtoField.uint32   ("mtkmipc.struct.interval", "interval", base.DEC)
mipc_sys_thermal_sensor_config_e_t_alarm_type = ProtoField.uint32   ("mtkmipc.struct.alarm_type", "alarm_type", base.DEC)
mipc_sys_thermal_actuator_state_info_t_actuator_id = ProtoField.uint32   ("mtkmipc.struct.actuator_id", "actuator_id", base.DEC)
mipc_sys_thermal_actuator_state_info_t_num_throttling_state = ProtoField.uint32   ("mtkmipc.struct.num_throttling_state", "num_throttling_state", base.DEC)
mipc_sys_thermal_actuator_state_info_t_current_throttling_state = ProtoField.uint32   ("mtkmipc.struct.current_throttling_state", "current_throttling_state", base.DEC)
mipc_sys_thermal_actuator_state_info_t_actuator_name = ProtoField.new("actuator_name", "mtkmipc.struct.actuator_name", ftypes.STRING)
mipc_sys_thermal_sensor_info_t_sensor_id = ProtoField.uint32   ("mtkmipc.struct.sensor_id", "sensor_id", base.DEC)
mipc_sys_thermal_sensor_info_t_temperature = ProtoField.int32   ("mtkmipc.struct.temperature", "temperature", base.DEC)
mipc_sys_thermal_sensor_info_e_t_sensor_id = ProtoField.uint32   ("mtkmipc.struct.sensor_id", "sensor_id", base.DEC)
mipc_sys_thermal_sensor_info_e_t_temperature = ProtoField.int32   ("mtkmipc.struct.temperature", "temperature", base.DEC)
mipc_sys_thermal_trip_map_t_val_trip_map = ProtoField.uint32   ("mtkmipc.struct.val_trip_map", "val_trip_map", base.DEC)
mipc_sys_thermal_trip_map_t_threshold_value = ProtoField.int32   ("mtkmipc.struct.threshold_value", "threshold_value", base.DEC)
mipc_sys_thermal_trip_map_t_hysteresis_value = ProtoField.uint32   ("mtkmipc.struct.hysteresis_value", "hysteresis_value", base.DEC)
mipc_sys_thermal_trip_map_t_sampling_period = ProtoField.uint32   ("mtkmipc.struct.sampling_period", "sampling_period", base.DEC)
mipc_sys_thermal_trip_map_t_sensor_alarm_type = ProtoField.uint32   ("mtkmipc.struct.sensor_alarm_type", "sensor_alarm_type", base.DEC)
mipc_sys_thermal_trip_map_t_throttle_level = ProtoField.uint32   ("mtkmipc.struct.throttle_level", "throttle_level", base.DEC)
mipc_sys_thermal_trip_change_t_sensor_id = ProtoField.uint32   ("mtkmipc.struct.sensor_id", "sensor_id", base.DEC)
mipc_sys_thermal_trip_change_t_before_trip_temp = ProtoField.int32   ("mtkmipc.struct.before_trip_temp", "before_trip_temp", base.DEC)
mipc_sys_thermal_trip_change_t_after_trip_temp = ProtoField.int32   ("mtkmipc.struct.after_trip_temp", "after_trip_temp", base.DEC)
mipc_sys_thermal_trip_change_t_save_cfg_to_nv = ProtoField.uint32   ("mtkmipc.struct.save_cfg_to_nv", "save_cfg_to_nv", base.DEC)
mipc_sys_mia_metrics_t_type = ProtoField.uint32   ("mtkmipc.struct.type", "type", base.DEC)
mipc_sys_mia_metrics_t_latency = ProtoField.uint32   ("mtkmipc.struct.latency", "latency", base.DEC)
mipc_sys_mia_metrics_t_ul_tput = ProtoField.uint32   ("mtkmipc.struct.ul_tput", "ul_tput", base.DEC)
mipc_sys_mia_metrics_t_dl_tput = ProtoField.uint32   ("mtkmipc.struct.dl_tput", "dl_tput", base.DEC)
mipc_call_detail_info_t_number_present = ProtoField.uint8   ("mtkmipc.struct.number_present", "number_present", base.DEC, CALL_CLI_VALIDITY)
mipc_call_detail_info_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_call_detail_info_t_number = ProtoField.new("number", "mtkmipc.struct.number", ftypes.STRING)
mipc_call_detail_info_t_name_present = ProtoField.uint8   ("mtkmipc.struct.name_present", "name_present", base.DEC, CALL_CNI_VALIDITY)
mipc_call_detail_info_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_call_detail_info_t_name = ProtoField.new("name", "mtkmipc.struct.name", ftypes.STRING)
mipc_call_detail_info_t_display_name = ProtoField.new("display_name", "mtkmipc.struct.display_name", ftypes.STRING)
mipc_call_detail_info_t_verstat = ProtoField.new("verstat", "mtkmipc.struct.verstat", ftypes.STRING)
mipc_call_detail_info_t_privacy = ProtoField.new("privacy", "mtkmipc.struct.privacy", ftypes.STRING)
mipc_call_video_cap_t_local_video_cap_present = ProtoField.uint8   ("mtkmipc.struct.local_video_cap_present", "local_video_cap_present", base.DEC, BOOLEAN)
mipc_call_video_cap_t_local_video_cap = ProtoField.uint8   ("mtkmipc.struct.local_video_cap", "local_video_cap", base.DEC)
mipc_call_video_cap_t_remote_video_cap_present = ProtoField.uint8   ("mtkmipc.struct.remote_video_cap_present", "remote_video_cap_present", base.DEC, BOOLEAN)
mipc_call_video_cap_t_remote_video_cap = ProtoField.uint8   ("mtkmipc.struct.remote_video_cap", "remote_video_cap", base.DEC)
mipc_ecc_info_t_is_fake_ecc = ProtoField.uint8   ("mtkmipc.struct.is_fake_ecc", "is_fake_ecc", base.DEC, BOOLEAN)
mipc_ecc_info_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_ecc_info_t_category = ProtoField.uint16   ("mtkmipc.struct.category", "category", base.DEC)
mipc_ecc_info_t_type = ProtoField.uint16   ("mtkmipc.struct.type", "type", base.DEC, ECC_INFO_TYPE)
mipc_ecc_info_t_number = ProtoField.new("number", "mtkmipc.struct.number", ftypes.STRING)
mipc_ecc_info_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_ecc_info_v1_t_is_fake_ecc = ProtoField.uint8   ("mtkmipc.struct.is_fake_ecc", "is_fake_ecc", base.DEC, BOOLEAN)
mipc_ecc_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_ecc_info_v1_t_category = ProtoField.uint16   ("mtkmipc.struct.category", "category", base.DEC)
mipc_ecc_info_v1_t_type = ProtoField.uint16   ("mtkmipc.struct.type", "type", base.DEC, ECC_INFO_TYPE)
mipc_ecc_info_v1_t_number = ProtoField.new("number", "mtkmipc.struct.number", ftypes.STRING)
mipc_ecc_info_v1_t_sub_service = ProtoField.new("sub_service", "mtkmipc.struct.sub_service", ftypes.STRING)
mipc_nw_srxlev_info_t_srxlev_in_qdb = ProtoField.uint16   ("mtkmipc.struct.srxlev_in_qdb", "srxlev_in_qdb", base.DEC)
mipc_nw_srxlev_info_t_squal_in_qdb = ProtoField.uint16   ("mtkmipc.struct.squal_in_qdb", "squal_in_qdb", base.DEC)
mipc_phb_name_str_t_name_str = ProtoField.new("name_str", "mtkmipc.struct.name_str", ftypes.STRING)
mipc_phb_name_str_t_encode_method = ProtoField.uint32   ("mtkmipc.struct.encode_method", "encode_method", base.DEC, PHB_ENCODE_METHOD)
mipc_phb_email_str_t_name_str = ProtoField.new("name_str", "mtkmipc.struct.name_str", ftypes.STRING)
mipc_phb_email_str_t_encode_method = ProtoField.uint32   ("mtkmipc.struct.encode_method", "encode_method", base.DEC, PHB_ENCODE_METHOD)
mipc_phb_anr_entry_t_type = ProtoField.uint32   ("mtkmipc.struct.type", "type", base.DEC)
mipc_phb_anr_entry_t_index = ProtoField.uint32   ("mtkmipc.struct.index", "index", base.DEC)
mipc_phb_anr_entry_t_ton = ProtoField.uint32   ("mtkmipc.struct.ton", "ton", base.DEC)
mipc_phb_anr_entry_t_number = ProtoField.new("number", "mtkmipc.struct.number", ftypes.STRING)
mipc_phb_entry_t_index = ProtoField.uint32   ("mtkmipc.struct.index", "index", base.DEC)
mipc_phb_entry_t_ton = ProtoField.uint32   ("mtkmipc.struct.ton", "ton", base.DEC)
mipc_phb_entry_t_number = ProtoField.new("number", "mtkmipc.struct.number", ftypes.STRING)
mipc_phb_entry_t_alphaid = ProtoField.new("alphaID", "mtkmipc.struct.alphaid", ftypes.STRING)
mipc_phb_entry_t_adnumber = ProtoField.new("adnumber", "mtkmipc.struct.adnumber", ftypes.STRING)
mipc_phb_entry_t_adtype = ProtoField.uint32   ("mtkmipc.struct.adtype", "adtype", base.DEC)
mipc_phb_entry_t_email = ProtoField.new("email", "mtkmipc.struct.email", ftypes.STRING)
mipc_phb_entry_t_encode_method = ProtoField.uint32   ("mtkmipc.struct.encode_method", "encode_method", base.DEC, PHB_ENCODE_METHOD)
mipc_embms_area_id_info_t_num_area_ids = ProtoField.uint8   ("mtkmipc.struct.num_area_ids", "num_area_ids", base.DEC)
mipc_embms_area_id_info_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_embms_area_id_info_t_area_id = ProtoField.uint8   ("mtkmipc.struct.area_id", "area_id", base.DEC)
mipc_embms_session_info_t_index = ProtoField.uint16   ("mtkmipc.struct.index", "index", base.DEC)
mipc_embms_session_info_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_embms_session_info_t_tmgi = ProtoField.new("tmgi", "mtkmipc.struct.tmgi", ftypes.STRING)
mipc_embms_session_info_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_embms_session_info_t_session_id = ProtoField.new("session_id", "mtkmipc.struct.session_id", ftypes.STRING)
mipc_embms_session_info_t_status = ProtoField.uint8   ("mtkmipc.struct.status", "status", base.DEC)
mipc_embms_nb_req_info_t_num_nf = ProtoField.uint8   ("mtkmipc.struct.num_nf", "num_nf", base.DEC)
mipc_embms_nb_req_info_t_index = ProtoField.uint8   ("mtkmipc.struct.index", "index", base.DEC)
mipc_embms_nb_req_info_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_embms_nb_req_info_t_nf = ProtoField.uint32   ("mtkmipc.struct.nf", "nf", base.DEC)
mipc_embms_nb_req_info_t_num_bands_nf = ProtoField.uint8   ("mtkmipc.struct.num_bands_nf", "num_bands_nf", base.DEC)
mipc_embms_nb_req_info_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_embms_nb_req_info_t_band_nf = ProtoField.uint16   ("mtkmipc.struct.band_nf", "band_nf", base.DEC)
mipc_embms_nb_req_info_t_num_sais_nf = ProtoField.uint8   ("mtkmipc.struct.num_sais_nf", "num_sais_nf", base.DEC)
mipc_embms_nb_req_info_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_embms_nb_req_info_t_sai_nf = ProtoField.uint16   ("mtkmipc.struct.sai_nf", "sai_nf", base.DEC)
mipc_embms_sai_cf_info_t_num_intra_freq = ProtoField.uint8   ("mtkmipc.struct.num_intra_freq", "num_intra_freq", base.DEC)
mipc_embms_sai_cf_info_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_embms_sai_cf_info_t_intra_freq = ProtoField.uint32   ("mtkmipc.struct.intra_freq", "intra_freq", base.DEC)
mipc_embms_sai_cf_info_t_num_sais = ProtoField.uint8   ("mtkmipc.struct.num_sais", "num_sais", base.DEC)
mipc_embms_sai_cf_info_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_embms_sai_cf_info_t_sais = ProtoField.uint16   ("mtkmipc.struct.sais", "sais", base.DEC)
mipc_embms_sai_nf_info_t_index = ProtoField.uint8   ("mtkmipc.struct.index", "index", base.DEC)
mipc_embms_sai_nf_info_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_embms_sai_nf_info_t_nf = ProtoField.uint32   ("mtkmipc.struct.nf", "nf", base.DEC)
mipc_embms_sai_nf_info_t_num_bands_nf = ProtoField.uint8   ("mtkmipc.struct.num_bands_nf", "num_bands_nf", base.DEC)
mipc_embms_sai_nf_info_t_reserved1 = ProtoField.new("reserved1", "mtkmipc.struct.reserved1", ftypes.BYTES)
mipc_embms_sai_nf_info_t_band_nf = ProtoField.uint16   ("mtkmipc.struct.band_nf", "band_nf", base.DEC)
mipc_embms_sai_nf_info_t_num_sais_nf = ProtoField.uint8   ("mtkmipc.struct.num_sais_nf", "num_sais_nf", base.DEC)
mipc_embms_sai_nf_info_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_embms_sai_nf_info_t_sai_nf = ProtoField.uint16   ("mtkmipc.struct.sai_nf", "sai_nf", base.DEC)
mipc_internal_set_filter_req_t_nccmni_net_if = ProtoField.uint8   ("mtkmipc.struct.nccmni_net_if", "nccmni_net_if", base.DEC)
mipc_internal_set_filter_req_t_reserve1 = ProtoField.uint8   ("mtkmipc.struct.reserve1", "reserve1", base.DEC)
mipc_internal_set_filter_req_t_nccmni_seq = ProtoField.uint16   ("mtkmipc.struct.nccmni_seq", "nccmni_seq", base.DEC)
mipc_internal_set_filter_req_t_valid_field = ProtoField.uint32   ("mtkmipc.struct.valid_field", "valid_field", base.DEC)
mipc_internal_set_filter_req_t_ip_type = ProtoField.uint8   ("mtkmipc.struct.ip_type", "ip_type", base.DEC)
mipc_internal_set_filter_req_t_ctrl_protocol = ProtoField.uint8   ("mtkmipc.struct.ctrl_protocol", "ctrl_protocol", base.DEC)
mipc_internal_set_filter_req_t_src_port = ProtoField.uint16   ("mtkmipc.struct.src_port", "src_port", base.DEC)
mipc_internal_set_filter_req_t_dst_port = ProtoField.uint16   ("mtkmipc.struct.dst_port", "dst_port", base.DEC)
mipc_internal_set_filter_req_t_tcp_flags = ProtoField.uint16   ("mtkmipc.struct.tcp_flags", "tcp_flags", base.DEC)
mipc_internal_set_filter_req_t_spi = ProtoField.uint32   ("mtkmipc.struct.spi", "spi", base.DEC)
mipc_internal_set_filter_req_t_src_v4_addr = ProtoField.uint8   ("mtkmipc.struct.src_v4_addr", "src_v4_addr", base.DEC)
mipc_internal_set_filter_req_t_dst_v4_addr = ProtoField.uint8   ("mtkmipc.struct.dst_v4_addr", "dst_v4_addr", base.DEC)
mipc_internal_set_filter_req_t_src_v6_addr = ProtoField.uint8   ("mtkmipc.struct.src_v6_addr", "src_v6_addr", base.DEC)
mipc_internal_set_filter_req_t_dst_v6_addr = ProtoField.uint8   ("mtkmipc.struct.dst_v6_addr", "dst_v6_addr", base.DEC)
mipc_internal_set_filter_req_t_icmpv4_type = ProtoField.uint8   ("mtkmipc.struct.icmpv4_type", "icmpv4_type", base.DEC)
mipc_internal_set_filter_req_t_icmpv6_type = ProtoField.uint8   ("mtkmipc.struct.icmpv6_type", "icmpv6_type", base.DEC)
mipc_internal_set_filter_req_t_reserve = ProtoField.uint16   ("mtkmipc.struct.reserve", "reserve", base.DEC)
mipc_internal_set_filter_req_t_features = ProtoField.uint32   ("mtkmipc.struct.features", "features", base.DEC)
mipc_internal_set_filter_cnf_t_nccmni_net_if = ProtoField.uint8   ("mtkmipc.struct.nccmni_net_if", "nccmni_net_if", base.DEC)
mipc_internal_set_filter_cnf_t_reserve1 = ProtoField.uint8   ("mtkmipc.struct.reserve1", "reserve1", base.DEC)
mipc_internal_set_filter_cnf_t_nccmni_seq = ProtoField.uint16   ("mtkmipc.struct.nccmni_seq", "nccmni_seq", base.DEC)
mipc_internal_set_filter_cnf_t_filter_id = ProtoField.int32   ("mtkmipc.struct.filter_id", "filter_id", base.DEC)
mipc_internal_reset_filter_req_t_nccmni_net_if = ProtoField.uint8   ("mtkmipc.struct.nccmni_net_if", "nccmni_net_if", base.DEC)
mipc_internal_reset_filter_req_t_reserve1 = ProtoField.uint8   ("mtkmipc.struct.reserve1", "reserve1", base.DEC)
mipc_internal_reset_filter_req_t_nccmni_seq = ProtoField.uint16   ("mtkmipc.struct.nccmni_seq", "nccmni_seq", base.DEC)
mipc_internal_reset_filter_req_t_is_deregister_all_filter = ProtoField.int32   ("mtkmipc.struct.is_deregister_all_filter", "is_deregister_all_filter", base.DEC)
mipc_internal_reset_filter_req_t_filter_id = ProtoField.int32   ("mtkmipc.struct.filter_id", "filter_id", base.DEC)
mipc_internal_reset_filter_cnf_t_nccmni_net_if = ProtoField.uint8   ("mtkmipc.struct.nccmni_net_if", "nccmni_net_if", base.DEC)
mipc_internal_reset_filter_cnf_t_reserve1 = ProtoField.uint8   ("mtkmipc.struct.reserve1", "reserve1", base.DEC)
mipc_internal_reset_filter_cnf_t_nccmni_seq = ProtoField.uint16   ("mtkmipc.struct.nccmni_seq", "nccmni_seq", base.DEC)
mipc_internal_reset_filter_cnf_t_is_success = ProtoField.int32   ("mtkmipc.struct.is_success", "is_success", base.DEC)
mipc_nw_tx_t_tx = ProtoField.uint32   ("mtkmipc.struct.tx", "tx", base.DEC)
mipc_plmn_cag_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_plmn_cag_info_t_reserved = ProtoField.uint8   ("mtkmipc.struct.reserved", "reserved", base.DEC)
mipc_plmn_cag_info_t_act = ProtoField.uint8   ("mtkmipc.struct.act", "act", base.DEC)
mipc_plmn_cag_info_t_only_via_cag = ProtoField.uint8   ("mtkmipc.struct.only_via_cag", "only_via_cag", base.DEC)
mipc_plmn_cag_info_t_cag_id_info_count = ProtoField.uint8   ("mtkmipc.struct.cag_id_info_count", "cag_id_info_count", base.DEC)
mipc_plmn_cag_info_t_padding1 = ProtoField.uint8   ("mtkmipc.struct.padding1", "padding1", base.DEC)
mipc_plmn_cag_info_t_cag_id = ProtoField.uint32   ("mtkmipc.struct.cag_id", "cag_id", base.DEC)
mipc_plmn_cag_info_t_hrnn = ProtoField.new("hrnn", "mtkmipc.struct.hrnn", ftypes.STRING)
mipc_plmn_cag_info_t_cag_status = ProtoField.uint8   ("mtkmipc.struct.cag_status", "cag_status", base.DEC)
mipc_plmn_cag_info_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_congestion_info_t_op = ProtoField.uint32   ("mtkmipc.struct.op", "op", base.DEC)
mipc_nw_congestion_info_t_serv_type = ProtoField.uint32   ("mtkmipc.struct.serv_type", "serv_type", base.DEC)
mipc_nw_congestion_info_t_rat = ProtoField.uint32   ("mtkmipc.struct.rat", "rat", base.DEC)
mipc_nw_congestion_info_t_det_time = ProtoField.uint32   ("mtkmipc.struct.det_time", "det_time", base.DEC)
mipc_nw_congestion_info_t_duration = ProtoField.uint32   ("mtkmipc.struct.duration", "duration", base.DEC)
mipc_nw_congestion_info_t_cond_grant_bytes = ProtoField.uint32   ("mtkmipc.struct.cond_grant_bytes", "cond_grant_bytes", base.DEC)
mipc_nw_congestion_info_t_cond_bsr = ProtoField.uint32   ("mtkmipc.struct.cond_bsr", "cond_bsr", base.DEC)
mipc_nw_congestion_info_t_cond_pdcp_discard_rate = ProtoField.uint32   ("mtkmipc.struct.cond_pdcp_discard_rate", "cond_pdcp_discard_rate", base.DEC)
mipc_nw_congestion_info_t_cond_phr = ProtoField.int32   ("mtkmipc.struct.cond_phr", "cond_phr", base.DEC)
mipc_nw_congestion_info_t_cond_s_rsrp = ProtoField.int32   ("mtkmipc.struct.cond_s_rsrp", "cond_s_rsrp", base.DEC)
mipc_nw_congestion_info_t_cond_s_sinr = ProtoField.int32   ("mtkmipc.struct.cond_s_sinr", "cond_s_sinr", base.DEC)
mipc_nw_congestion_info_t_cond_n_rsrp = ProtoField.int32   ("mtkmipc.struct.cond_n_rsrp", "cond_n_rsrp", base.DEC)
mipc_nw_congestion_info_t_cond_n_sinr = ProtoField.int32   ("mtkmipc.struct.cond_n_sinr", "cond_n_sinr", base.DEC)
mipc_mbms_session_status_t_is_activate = ProtoField.uint8   ("mtkmipc.struct.is_activate", "is_activate", base.DEC)
mipc_mbms_session_status_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_mbms_session_status_t_service_id = ProtoField.new("service_id", "mtkmipc.struct.service_id", ftypes.BYTES)
mipc_mbms_freq_info_t_freq = ProtoField.uint32   ("mtkmipc.struct.freq", "freq", base.DEC)
mipc_mbms_tmgi_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_mbms_tmgi_info_t_service_id = ProtoField.new("service_id", "mtkmipc.struct.service_id", ftypes.BYTES)
mipc_mbs_nrarfcn_info_t_nrarfcn = ProtoField.uint32   ("mtkmipc.struct.nrarfcn", "nrarfcn", base.DEC)
mipc_mbs_fsai_info_t_mbs_fsai = ProtoField.new("mbs_fsai", "mtkmipc.struct.mbs_fsai", ftypes.BYTES)
mipc_mbms_usd_fsai_info_t_num_of_nrarfcn = ProtoField.uint16   ("mtkmipc.struct.num_of_nrarfcn", "num_of_nrarfcn", base.DEC)
mipc_mbms_usd_fsai_info_t_num_of_fsai = ProtoField.uint16   ("mtkmipc.struct.num_of_fsai", "num_of_fsai", base.DEC)
mipc_mbms_usd_fsai_info_t_nrarfcn = ProtoField.uint32   ("mtkmipc.struct.nrarfcn", "nrarfcn", base.DEC)
mipc_mbms_tac_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_mbms_tac_info_t_ta_code = ProtoField.new("ta_code", "mtkmipc.struct.ta_code", ftypes.BYTES)
mipc_mbms_ip_address_info_t_src_ip_address = ProtoField.new("src_ip_address", "mtkmipc.struct.src_ip_address", ftypes.BYTES)
mipc_mbms_ip_address_info_t_dest_ip_address = ProtoField.new("dest_ip_address", "mtkmipc.struct.dest_ip_address", ftypes.BYTES)
mipc_mbms_cell_id_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_mbms_cell_id_info_t_cell_id = ProtoField.new("cell_id", "mtkmipc.struct.cell_id", ftypes.BYTES)
mipc_data_tsn_info_t_port_mac_present = ProtoField.uint8   ("mtkmipc.struct.port_mac_present", "port_mac_present", base.DEC, BOOLEAN)
mipc_data_tsn_info_t_port_mac = ProtoField.new("port_mac", "mtkmipc.struct.port_mac", ftypes.BYTES)
mipc_data_tsn_info_t_res_time_present = ProtoField.uint8   ("mtkmipc.struct.res_time_present", "res_time_present", base.DEC, BOOLEAN)
mipc_data_tsn_info_t_res_time = ProtoField.new("res_time", "mtkmipc.struct.res_time", ftypes.BYTES)
mipc_data_tsn_info_t_pmic_present = ProtoField.uint8   ("mtkmipc.struct.pmic_present", "pmic_present", base.DEC, BOOLEAN)
mipc_data_tsn_info_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_data_tsn_info_t_pmic_len = ProtoField.uint16   ("mtkmipc.struct.pmic_len", "pmic_len", base.DEC)
mipc_data_tsn_info_t_pmic = ProtoField.new("pmic", "mtkmipc.struct.pmic", ftypes.BYTES)
mipc_data_tsn_time_t_day = ProtoField.uint32   ("mtkmipc.struct.day", "day", base.DEC)
mipc_data_tsn_time_t_second = ProtoField.uint32   ("mtkmipc.struct.second", "second", base.DEC)
mipc_data_tsn_time_t_milli_second = ProtoField.uint32   ("mtkmipc.struct.milli_second", "milli_second", base.DEC)
mipc_data_tsn_time_t_nano_second = ProtoField.uint32   ("mtkmipc.struct.nano_second", "nano_second", base.DEC)
mipc_data_tsn_time_t_uncertainly = ProtoField.uint32   ("mtkmipc.struct.uncertainly", "uncertainly", base.DEC)
mipc_data_tsn_time_t_timeinfotype = ProtoField.uint32   ("mtkmipc.struct.timeinfotype", "timeInfoType", base.DEC)
mipc_data_tsn_time_t_referencesfn = ProtoField.uint32   ("mtkmipc.struct.referencesfn", "referenceSFN", base.DEC)
mipc_ftai_info_t_plmn_id = ProtoField.new("plmn_id", "mtkmipc.struct.plmn_id", ftypes.STRING)
mipc_ftai_info_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_ftai_info_t_tac = ProtoField.uint16   ("mtkmipc.struct.tac", "TAC", base.DEC)
mipc_sys_idc_gpio_cfg_t_gpio_0 = ProtoField.uint8   ("mtkmipc.struct.gpio_0", "gpio_0", base.DEC)
mipc_sys_idc_gpio_cfg_t_gpio_1 = ProtoField.uint8   ("mtkmipc.struct.gpio_1", "gpio_1", base.DEC)
mipc_sys_idc_gpio_cfg_t_gpio_2 = ProtoField.uint8   ("mtkmipc.struct.gpio_2", "gpio_2", base.DEC)
mipc_track_item_t_track_index = ProtoField.uint16   ("mtkmipc.struct.track_index", "track_index", base.DEC)
mipc_track_item_t_mipc_msg_id = ProtoField.uint16   ("mtkmipc.struct.mipc_msg_id", "mipc_msg_id", base.DEC)
mipc_track_item_t_pending_time = ProtoField.uint32   ("mtkmipc.struct.pending_time", "pending_time", base.DEC)
mipc_track_item_t_mipc_txid = ProtoField.uint16   ("mtkmipc.struct.mipc_txid", "mipc_txid", base.DEC)
mipc_track_item_t_mipc_id = ProtoField.uint16   ("mtkmipc.struct.mipc_id", "mipc_id", base.DEC)
mipc_wfp_filter_struct_t_filter_config = ProtoField.uint32   ("mtkmipc.struct.filter_config", "filter_config", base.DEC)
mipc_wfp_filter_struct_t_operation_config = ProtoField.uint32   ("mtkmipc.struct.operation_config", "operation_config", base.DEC)
mipc_wfp_filter_struct_t_priority = ProtoField.uint8   ("mtkmipc.struct.priority", "priority", base.DEC)
mipc_wfp_filter_struct_t_ip_ver = ProtoField.uint8   ("mtkmipc.struct.ip_ver", "ip_ver", base.DEC)
mipc_wfp_filter_struct_t_protocol = ProtoField.uint8   ("mtkmipc.struct.protocol", "protocol", base.DEC)
mipc_wfp_filter_struct_t_icmp_type = ProtoField.uint8   ("mtkmipc.struct.icmp_type", "icmp_type", base.DEC)
mipc_wfp_filter_struct_t_icmp_code = ProtoField.uint8   ("mtkmipc.struct.icmp_code", "icmp_code", base.DEC)
mipc_wfp_filter_struct_t_reserved = ProtoField.new("reserved", "mtkmipc.struct.reserved", ftypes.BYTES)
mipc_wfp_filter_struct_t_ip_src = ProtoField.uint8   ("mtkmipc.struct.ip_src", "ip_src", base.DEC)
mipc_wfp_filter_struct_t_ip_src_mask = ProtoField.uint8   ("mtkmipc.struct.ip_src_mask", "ip_src_mask", base.DEC)
mipc_wfp_filter_struct_t_reserved2 = ProtoField.new("reserved2", "mtkmipc.struct.reserved2", ftypes.BYTES)
mipc_wfp_filter_struct_t_ip_dest = ProtoField.uint8   ("mtkmipc.struct.ip_dest", "ip_dest", base.DEC)
mipc_wfp_filter_struct_t_ip_dest_mask = ProtoField.uint8   ("mtkmipc.struct.ip_dest_mask", "ip_dest_mask", base.DEC)
mipc_wfp_filter_struct_t_reserved3 = ProtoField.new("reserved3", "mtkmipc.struct.reserved3", ftypes.BYTES)
mipc_wfp_filter_struct_t_src_port = ProtoField.uint16   ("mtkmipc.struct.src_port", "src_port", base.DEC)
mipc_wfp_filter_struct_t_src_port_mask = ProtoField.uint16   ("mtkmipc.struct.src_port_mask", "src_port_mask", base.DEC)
mipc_wfp_filter_struct_t_dst_port = ProtoField.uint16   ("mtkmipc.struct.dst_port", "dst_port", base.DEC)
mipc_wfp_filter_struct_t_dst_port_mask = ProtoField.uint16   ("mtkmipc.struct.dst_port_mask", "dst_port_mask", base.DEC)
mipc_wfp_filter_struct_t_tcp_flags = ProtoField.uint16   ("mtkmipc.struct.tcp_flags", "tcp_flags", base.DEC)
mipc_wfp_filter_struct_t_tcp_flags_mask = ProtoField.uint16   ("mtkmipc.struct.tcp_flags_mask", "tcp_flags_mask", base.DEC)
mipc_wfp_filter_struct_t_tcp_flags_operation = ProtoField.uint16   ("mtkmipc.struct.tcp_flags_operation", "tcp_flags_operation", base.DEC)
mipc_wfp_filter_struct_t_reserved4 = ProtoField.new("reserved4", "mtkmipc.struct.reserved4", ftypes.BYTES)
mipc_wfp_filter_struct_t_icmp_src_ip = ProtoField.uint16   ("mtkmipc.struct.icmp_src_ip", "icmp_src_ip", base.DEC)
mipc_wfp_filter_struct_t_icmp_src_port = ProtoField.uint16   ("mtkmipc.struct.icmp_src_port", "icmp_src_port", base.DEC)
mipc_wfp_filter_struct_t_icmp_src_mask = ProtoField.uint16   ("mtkmipc.struct.icmp_src_mask", "icmp_src_mask", base.DEC)
mipc_wfp_filter_struct_t_esp_spi = ProtoField.uint32   ("mtkmipc.struct.esp_spi", "esp_spi", base.DEC)
mipc_wfp_filter_struct_t_esp_spi_mask = ProtoField.uint32   ("mtkmipc.struct.esp_spi_mask", "esp_spi_mask", base.DEC)
mipc_stk_menu_select_t_item_id = ProtoField.uint8   ("mtkmipc.struct.item_id", "item_id", base.DEC)
mipc_stk_menu_select_t_help_req = ProtoField.uint8   ("mtkmipc.struct.help_req", "help_req", base.DEC, BOOLEAN)
mipc_stk_address_t_ton_npi = ProtoField.uint8   ("mtkmipc.struct.ton_npi", "ton_npi", base.DEC)
mipc_stk_address_t_valid_dialling_number_len = ProtoField.uint8   ("mtkmipc.struct.valid_dialling_number_len", "valid_dialling_number_len", base.DEC)
mipc_stk_address_t_dialling_number = ProtoField.new("dialling_number", "mtkmipc.struct.dialling_number", ftypes.BYTES)
mipc_stk_ussdstring_t_dcs = ProtoField.uint8   ("mtkmipc.struct.dcs", "dcs", base.DEC)
mipc_stk_ussdstring_t_valid_ussd_data_len = ProtoField.uint8   ("mtkmipc.struct.valid_ussd_data_len", "valid_ussd_data_len", base.DEC)
mipc_stk_ussdstring_t_ussd_data = ProtoField.new("ussd_data", "mtkmipc.struct.ussd_data", ftypes.BYTES)
mipc_stk_call_control_param_t_call_control_param_type = ProtoField.uint8   ("mtkmipc.struct.call_control_param_type", "call_control_param_type", base.DEC, STK_CALL_CONTROL_PARA_TYPE)
mipc_stk_event_dl_mt_call_t_call_id = ProtoField.uint8   ("mtkmipc.struct.call_id", "call_id", base.DEC)
mipc_stk_event_dl_call_con_t_ismo = ProtoField.uint8   ("mtkmipc.struct.ismo", "ismo", base.DEC, BOOLEAN)
mipc_stk_event_dl_call_con_t_call_id = ProtoField.uint8   ("mtkmipc.struct.call_id", "call_id", base.DEC)
mipc_stk_event_dl_call_discon_t_transaction_id = ProtoField.uint8   ("mtkmipc.struct.transaction_id", "transaction_id", base.DEC)
mipc_stk_event_dl_call_discon_t_is_near_end = ProtoField.uint8   ("mtkmipc.struct.is_near_end", "is_near_end", base.DEC, BOOLEAN)
mipc_stk_ims_registration_status_t_valid_impu_list_len = ProtoField.uint8   ("mtkmipc.struct.valid_impu_list_len", "valid_impu_list_len", base.DEC)
mipc_stk_ims_registration_status_t_impu_list = ProtoField.new("impu_list", "mtkmipc.struct.impu_list", ftypes.BYTES)
mipc_stk_ims_registration_status_t_valid_ims_status_code_len = ProtoField.uint8   ("mtkmipc.struct.valid_ims_status_code_len", "valid_ims_status_code_len", base.DEC)
mipc_stk_ims_registration_status_t_ims_status_code = ProtoField.new("ims_status_code", "mtkmipc.struct.ims_status_code", ftypes.BYTES)
mipc_stk_sms_pp_data_dl_t_valid_sms_tpdu_len = ProtoField.uint8   ("mtkmipc.struct.valid_sms_tpdu_len", "valid_sms_tpdu_len", base.DEC)
mipc_stk_sms_pp_data_dl_t_sms_tpdu = ProtoField.new("sms_tpdu", "mtkmipc.struct.sms_tpdu", ftypes.BYTES)
mipc_stk_call_control_rsp_t_cc_result = ProtoField.uint8   ("mtkmipc.struct.cc_result", "cc_result", base.DEC, STK_CALL_CONTROL_RESULT)
mipc_stk_call_control_rsp_t_valid_capability_params1_len = ProtoField.uint8   ("mtkmipc.struct.valid_capability_params1_len", "valid_capability_params1_len", base.DEC)
mipc_stk_call_control_rsp_t_capability_params1 = ProtoField.new("capability_params1", "mtkmipc.struct.capability_params1", ftypes.BYTES)
mipc_stk_call_control_rsp_t_valid_sub_address_len = ProtoField.uint8   ("mtkmipc.struct.valid_sub_address_len", "valid_sub_address_len", base.DEC)
mipc_stk_call_control_rsp_t_sub_address = ProtoField.new("sub_address", "mtkmipc.struct.sub_address", ftypes.BYTES)
mipc_stk_call_control_rsp_t_valid_alpha_id_len = ProtoField.uint8   ("mtkmipc.struct.valid_alpha_id_len", "valid_alpha_id_len", base.DEC)
mipc_stk_call_control_rsp_t_alpha_id = ProtoField.new("alpha_id", "mtkmipc.struct.alpha_id", ftypes.BYTES)
mipc_stk_call_control_rsp_t_repeat_indicator = ProtoField.uint8   ("mtkmipc.struct.repeat_indicator", "repeat_indicator", base.DEC, STK_BC_REPEAT_INDICATOR)
mipc_stk_call_control_rsp_t_valid_capability_params2_len = ProtoField.uint8   ("mtkmipc.struct.valid_capability_params2_len", "valid_capability_params2_len", base.DEC)
mipc_stk_call_control_rsp_t_capability_params2 = ProtoField.new("capability_params2", "mtkmipc.struct.capability_params2", ftypes.BYTES)
mipc_stk_call_control_sms_rsp_t_cc_result = ProtoField.uint8   ("mtkmipc.struct.cc_result", "cc_result", base.DEC, STK_CALL_CONTROL_RESULT)
mipc_stk_call_control_sms_rsp_t_valid_alpha_id_len = ProtoField.uint8   ("mtkmipc.struct.valid_alpha_id_len", "valid_alpha_id_len", base.DEC)
mipc_stk_call_control_sms_rsp_t_alpha_id = ProtoField.new("alpha_id", "mtkmipc.struct.alpha_id", ftypes.BYTES)
mipc_srvcc_call_ctxt_struct_t_call_id = ProtoField.uint8   ("mtkmipc.struct.call_id", "call_id", base.DEC)
mipc_srvcc_call_ctxt_struct_t_call_mode = ProtoField.uint8   ("mtkmipc.struct.call_mode", "call_mode", base.DEC, EXIMS_SRVCC_CALL_MODE_ENUM)
mipc_srvcc_call_ctxt_struct_t_call_direction = ProtoField.uint8   ("mtkmipc.struct.call_direction", "call_direction", base.DEC, EXIMS_SRVCC_CALL_DIRECTION_ENUM)
mipc_srvcc_call_ctxt_struct_t_call_state = ProtoField.uint8   ("mtkmipc.struct.call_state", "call_state", base.DEC, EXIMS_SRVCC_CALL_STATE_ENUM)
mipc_srvcc_call_ctxt_struct_t_call_ecc_category = ProtoField.uint16   ("mtkmipc.struct.call_ecc_category", "call_ecc_category", base.DEC, EXIMS_SRVCC_CALL_ECC_CATEGORY_ENUM)
mipc_srvcc_call_ctxt_struct_t_num_of_conf_parts = ProtoField.uint8   ("mtkmipc.struct.num_of_conf_parts", "num_of_conf_parts", base.DEC)
mipc_srvcc_call_ctxt_struct_t_call_number = ProtoField.new("call_number", "mtkmipc.struct.call_number", ftypes.STRING)
mipc_ntn_ephemeris_state_t_position_x = ProtoField.int32   ("mtkmipc.struct.position_x", "position_x", base.DEC)
mipc_ntn_ephemeris_state_t_position_y = ProtoField.int32   ("mtkmipc.struct.position_y", "position_y", base.DEC)
mipc_ntn_ephemeris_state_t_position_z = ProtoField.int32   ("mtkmipc.struct.position_z", "position_z", base.DEC)
mipc_ntn_ephemeris_state_t_velocity_vx = ProtoField.int32   ("mtkmipc.struct.velocity_vx", "velocity_vx", base.DEC)
mipc_ntn_ephemeris_state_t_velocity_vy = ProtoField.int32   ("mtkmipc.struct.velocity_vy", "velocity_vy", base.DEC)
mipc_ntn_ephemeris_state_t_velocity_vz = ProtoField.int32   ("mtkmipc.struct.velocity_vz", "velocity_vz", base.DEC)
mipc_pcie_link_status_t_lane_num = ProtoField.uint32   ("mtkmipc.struct.lane_num", "lane_num", base.DEC)
mipc_pcie_link_status_t_rate_level = ProtoField.uint32   ("mtkmipc.struct.rate_level", "rate_level", base.DEC)
mipc_pcie_counter_register_t_l0 = ProtoField.uint32   ("mtkmipc.struct.l0", "L0", base.DEC)
mipc_pcie_counter_register_t_l0s = ProtoField.uint32   ("mtkmipc.struct.l0s", "L0s", base.DEC)
mipc_pcie_counter_register_t_l1 = ProtoField.uint32   ("mtkmipc.struct.l1", "L1", base.DEC)
mipc_pcie_counter_register_t_l11 = ProtoField.uint32   ("mtkmipc.struct.l11", "L11", base.DEC)
mipc_pcie_counter_register_t_l12 = ProtoField.uint32   ("mtkmipc.struct.l12", "L12", base.DEC)
mipc_pcie_counter_register_t_l2 = ProtoField.uint32   ("mtkmipc.struct.l2", "L2", base.DEC)
mipc_pcie_counter_register_t_rcvr = ProtoField.uint32   ("mtkmipc.struct.rcvr", "RCVR", base.DEC)
mipc_pcie_counter_register_t_others = ProtoField.uint32   ("mtkmipc.struct.others", "OTHERS", base.DEC)
mipc_nw_lte_meas_cell_t_earfcn = ProtoField.uint32   ("mtkmipc.struct.earfcn", "EARFCN", base.DEC)
mipc_nw_lte_meas_cell_t_pci = ProtoField.uint16   ("mtkmipc.struct.pci", "PCI", base.DEC)
mipc_nw_lte_meas_cell_t_rsrp = ProtoField.int16   ("mtkmipc.struct.rsrp", "RSRP", base.DEC)
mipc_nw_nr_meas_cell_t_narfcn = ProtoField.uint32   ("mtkmipc.struct.narfcn", "NARFCN", base.DEC)
mipc_nw_nr_meas_cell_t_pci = ProtoField.uint16   ("mtkmipc.struct.pci", "PCI", base.DEC)
mipc_nw_nr_meas_cell_t_rsrp = ProtoField.int16   ("mtkmipc.struct.rsrp", "RSRP", base.DEC)
mipc_sys_modem_t_modem_id = ProtoField.uint64   ("mtkmipc.struct.modem_id", "modem_id", base.DEC)
mipc_sys_modem_t_executor_number = ProtoField.uint32   ("mtkmipc.struct.executor_number", "executor_number", base.DEC)
mipc_sys_modem_t_sim_number = ProtoField.uint32   ("mtkmipc.struct.sim_number", "sim_number", base.DEC)
mipc_sys_modem_t_concurrency = ProtoField.uint32   ("mtkmipc.struct.concurrency", "concurrency", base.DEC)
mipc_sys_modem_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_sys_adpclk_freq_info_t_center_frequency = ProtoField.uint64   ("mtkmipc.struct.center_frequency", "center_frequency", base.DEC)
mipc_sys_adpclk_freq_info_t_frequency_spread = ProtoField.uint32   ("mtkmipc.struct.frequency_spread", "frequency_spread", base.DEC)
mipc_sys_adpclk_freq_info_t_noise_power = ProtoField.uint32   ("mtkmipc.struct.noise_power", "noise_power", base.DEC)
mipc_sys_adpclk_freq_info_t_relative_signal_strength = ProtoField.uint32   ("mtkmipc.struct.relative_signal_strength", "relative_signal_strength", base.DEC)
mipc_sys_adpclk_freq_info_t_connect_status = ProtoField.uint32   ("mtkmipc.struct.connect_status", "connect_status", base.DEC)
mipc_data_5gqos_info_v1_t_cid = ProtoField.uint16   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_data_5gqos_info_v1_t_vqi = ProtoField.uint16   ("mtkmipc.struct.vqi", "VQI", base.DEC)
mipc_data_5gqos_info_v1_t_averaging_window = ProtoField.uint32   ("mtkmipc.struct.averaging_window", "Averaging_window", base.DEC)
mipc_data_5gqos_info_v1_t_dl_gfbr = ProtoField.uint64   ("mtkmipc.struct.dl_gfbr", "DL_GFBR", base.DEC)
mipc_data_5gqos_info_v1_t_ul_gfbr = ProtoField.uint64   ("mtkmipc.struct.ul_gfbr", "UL_GFBR", base.DEC)
mipc_data_5gqos_info_v1_t_dl_mfbr = ProtoField.uint64   ("mtkmipc.struct.dl_mfbr", "DL_MFBR", base.DEC)
mipc_data_5gqos_info_v1_t_ul_mfbr = ProtoField.uint64   ("mtkmipc.struct.ul_mfbr", "UL_MFBR", base.DEC)
mipc_data_5gqos_info_v1_t_dl_sambr = ProtoField.uint64   ("mtkmipc.struct.dl_sambr", "DL_SAMBR", base.DEC)
mipc_data_5gqos_info_v1_t_ul_sambr = ProtoField.uint64   ("mtkmipc.struct.ul_sambr", "UL_SAMBR", base.DEC)
mipc_nw_nr_cell_v2_t_state = ProtoField.uint8   ("mtkmipc.struct.state", "state", base.DEC)
mipc_nw_nr_cell_v2_t_provider_id = ProtoField.new("provider_id", "mtkmipc.struct.provider_id", ftypes.STRING)
mipc_nw_nr_cell_v2_t_cid = ProtoField.uint64   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_nr_cell_v2_t_physical_cell_id = ProtoField.uint32   ("mtkmipc.struct.physical_cell_id", "physical_cell_id", base.DEC)
mipc_nw_nr_cell_v2_t_nr_arfcn = ProtoField.uint32   ("mtkmipc.struct.nr_arfcn", "nr_arfcn", base.DEC)
mipc_nw_nr_cell_v2_t_tac = ProtoField.uint32   ("mtkmipc.struct.tac", "tac", base.DEC)
mipc_nw_nr_cell_v2_t_rsrp = ProtoField.int32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_nr_cell_v2_t_rsrq = ProtoField.int32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_nr_cell_v2_t_sinr = ProtoField.int32   ("mtkmipc.struct.sinr", "sinr", base.DEC)
mipc_nw_nr_cell_v2_t_ta = ProtoField.uint32   ("mtkmipc.struct.ta", "ta", base.DEC)
mipc_nw_nr_cell_v2_t_csirsrp = ProtoField.uint32   ("mtkmipc.struct.csirsrp", "csirsrp", base.DEC)
mipc_nw_nr_cell_v2_t_csirsrq = ProtoField.uint32   ("mtkmipc.struct.csirsrq", "csirsrq", base.DEC)
mipc_nw_nr_cell_v2_t_csisinr = ProtoField.uint32   ("mtkmipc.struct.csisinr", "csisinr", base.DEC)
mipc_nw_nr_cell_v2_t_dl_freq_band = ProtoField.uint32   ("mtkmipc.struct.dl_freq_band", "dl_freq_band", base.DEC)
mipc_nw_nr_cell_v2_t_registered = ProtoField.uint32   ("mtkmipc.struct.registered", "registered", base.DEC)
mipc_nw_nr_cell_v2_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_nr_cell_v2_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_nr_cell_v2_t_csi_cqi_table_index = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_table_index", "csi_cqi_table_index", base.DEC)
mipc_nw_nr_cell_v2_t_csi_cqi_report_num = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_num", "csi_cqi_report_num", base.DEC)
mipc_nw_nr_cell_v2_t_csi_cqi_report_list = ProtoField.uint8   ("mtkmipc.struct.csi_cqi_report_list", "csi_cqi_report_list", base.DEC)
mipc_nw_nr_cell_v2_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_reg_change_info_v1_t_stat = ProtoField.uint8   ("mtkmipc.struct.stat", "stat", base.DEC)
mipc_nw_reg_change_info_v1_t_padding1 = ProtoField.new("padding1", "mtkmipc.struct.padding1", ftypes.BYTES)
mipc_nw_reg_change_info_v1_t_lac_tac = ProtoField.uint32   ("mtkmipc.struct.lac_tac", "lac_tac", base.DEC)
mipc_nw_reg_change_info_v1_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_reg_change_info_v1_t_eact = ProtoField.uint16   ("mtkmipc.struct.eact", "eact", base.DEC)
mipc_nw_reg_change_info_v1_t_rac = ProtoField.uint8   ("mtkmipc.struct.rac", "rac", base.DEC)
mipc_nw_reg_change_info_v1_t_nw_existence = ProtoField.uint8   ("mtkmipc.struct.nw_existence", "nw_existence", base.DEC)
mipc_nw_reg_change_info_v1_t_roam_indicator = ProtoField.uint8   ("mtkmipc.struct.roam_indicator", "roam_indicator", base.DEC)
mipc_nw_reg_change_info_v1_t_cause_type = ProtoField.uint8   ("mtkmipc.struct.cause_type", "cause_type", base.DEC)
mipc_nw_reg_change_info_v1_t_reject_cause = ProtoField.uint16   ("mtkmipc.struct.reject_cause", "reject_cause", base.DEC)
mipc_nw_reg_change_info_v1_t_dcnr_restricted = ProtoField.uint8   ("mtkmipc.struct.dcnr_restricted", "dcnr_restricted", base.DEC)
mipc_nw_reg_change_info_v1_t_endc_sib_status = ProtoField.uint8   ("mtkmipc.struct.endc_sib_status", "endc_sib_status", base.DEC)
mipc_nw_reg_change_info_v1_t_endc_available = ProtoField.uint8   ("mtkmipc.struct.endc_available", "endc_available", base.DEC)
mipc_nw_reg_change_info_v1_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_ps_reg_info_v1_t_stat = ProtoField.uint8   ("mtkmipc.struct.stat", "stat", base.DEC, NW_REGISTER_STATE)
mipc_nw_ps_reg_info_v1_t_padding1 = ProtoField.uint8   ("mtkmipc.struct.padding1", "padding1", base.DEC)
mipc_nw_ps_reg_info_v1_t_rat = ProtoField.uint16   ("mtkmipc.struct.rat", "rat", base.DEC, NW_DATA_SPEED)
mipc_nw_ps_reg_info_v1_t_reason_for_denial = ProtoField.uint16   ("mtkmipc.struct.reason_for_denial", "reason_for_denial", base.DEC)
mipc_nw_ps_reg_info_v1_t_max_data_calls = ProtoField.uint16   ("mtkmipc.struct.max_data_calls", "max_data_calls", base.DEC)
mipc_nw_ps_reg_info_v1_t_is_vops_supported = ProtoField.int32   ("mtkmipc.struct.is_vops_supported", "is_vops_supported", base.DEC)
mipc_nw_ps_reg_info_v1_t_is_emc_bearer_supported = ProtoField.int32   ("mtkmipc.struct.is_emc_bearer_supported", "is_emc_bearer_supported", base.DEC)
mipc_nw_ps_reg_info_v1_t_is_endc_available = ProtoField.uint8   ("mtkmipc.struct.is_endc_available", "is_endc_available", base.DEC)
mipc_nw_ps_reg_info_v1_t_is_dcnr_restricted = ProtoField.uint8   ("mtkmipc.struct.is_dcnr_restricted", "is_dcnr_restricted", base.DEC)
mipc_nw_ps_reg_info_v1_t_is_nr_available = ProtoField.uint8   ("mtkmipc.struct.is_nr_available", "is_nr_available", base.DEC)
mipc_nw_ps_reg_info_v1_t_roaming_ind = ProtoField.uint8   ("mtkmipc.struct.roaming_ind", "roaming_ind", base.DEC)
mipc_nw_ps_reg_info_v1_t_is_in_prl = ProtoField.int8   ("mtkmipc.struct.is_in_prl", "is_in_prl", base.DEC)
mipc_nw_ps_reg_info_v1_t_padding2 = ProtoField.uint8   ("mtkmipc.struct.padding2", "padding2", base.DEC)
mipc_nw_ps_reg_info_v1_t_def_roaming_ind = ProtoField.int16   ("mtkmipc.struct.def_roaming_ind", "def_roaming_ind", base.DEC)
mipc_nw_ps_reg_info_v1_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_ps_reg_info_v1_t_cache_endc_connect = ProtoField.uint8   ("mtkmipc.struct.cache_endc_connect", "cache_endc_connect", base.DEC)
mipc_nw_ps_reg_info_v1_t_padding3 = ProtoField.new("padding3", "mtkmipc.struct.padding3", ftypes.BYTES)
mipc_nw_ps_reg_info_v1_t_lac_tac = ProtoField.uint32   ("mtkmipc.struct.lac_tac", "lac_tac", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_rat = ProtoField.uint8   ("mtkmipc.struct.rat", "rat", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_nw_cellmeasurement_info_v1_t_arfcn = ProtoField.uint32   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_pci = ProtoField.uint32   ("mtkmipc.struct.pci", "pci", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_rsrp = ProtoField.uint32   ("mtkmipc.struct.rsrp", "rsrp", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_rsrq = ProtoField.uint32   ("mtkmipc.struct.rsrq", "rsrq", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_snr = ProtoField.uint32   ("mtkmipc.struct.snr", "snr", base.DEC)
mipc_nw_cellmeasurement_info_v1_t_cid = ProtoField.uint64   ("mtkmipc.struct.cid", "cid", base.DEC)
mipc_nw_pseudocell_info_v1_t_type = ProtoField.uint8   ("mtkmipc.struct.type", "type", base.DEC)
mipc_nw_pseudocell_info_v1_t_plmn = ProtoField.new("plmn", "mtkmipc.struct.plmn", ftypes.STRING)
mipc_nw_pseudocell_info_v1_t_long_name = ProtoField.new("long_name", "mtkmipc.struct.long_name", ftypes.STRING)
mipc_nw_pseudocell_info_v1_t_short_name = ProtoField.new("short_name", "mtkmipc.struct.short_name", ftypes.STRING)
mipc_nw_pseudocell_info_v1_t_lac = ProtoField.uint32   ("mtkmipc.struct.lac", "lac", base.DEC)
mipc_nw_pseudocell_info_v1_t_padding1 = ProtoField.new("padding1", "mtkmipc.struct.padding1", ftypes.BYTES)
mipc_nw_pseudocell_info_v1_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_pseudocell_info_v1_t_arfcn = ProtoField.uint16   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_pseudocell_info_v1_t_bsic = ProtoField.uint8   ("mtkmipc.struct.bsic", "bsic", base.DEC)
mipc_nw_pseudocell_info_v1_t_si3_raw_data = ProtoField.new("si3_raw_data", "mtkmipc.struct.si3_raw_data", ftypes.STRING)
mipc_nw_pseudocell_info_v1_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_handover_rat_info_v1_t_cell_id = ProtoField.uint64   ("mtkmipc.struct.cell_id", "cell_id", base.DEC)
mipc_nw_handover_rat_info_v1_t_para_number = ProtoField.uint8   ("mtkmipc.struct.para_number", "para_number", base.DEC)
mipc_nw_handover_rat_info_v1_t_rat = ProtoField.uint8   ("mtkmipc.struct.rat", "rat", base.DEC, NW_HANDOVER_RAT_TYPE)
mipc_nw_handover_rat_info_v1_t_mnc_digit_num = ProtoField.uint8   ("mtkmipc.struct.mnc_digit_num", "mnc_digit_num", base.DEC)
mipc_nw_handover_rat_info_v1_t_padding1 = ProtoField.new("padding1", "mtkmipc.struct.padding1", ftypes.BYTES)
mipc_nw_handover_rat_info_v1_t_mcc = ProtoField.uint16   ("mtkmipc.struct.mcc", "mcc", base.DEC)
mipc_nw_handover_rat_info_v1_t_mnc = ProtoField.uint16   ("mtkmipc.struct.mnc", "mnc", base.DEC)
mipc_nw_handover_rat_info_v1_t_band = ProtoField.uint16   ("mtkmipc.struct.band", "band", base.DEC)
mipc_nw_handover_rat_info_v1_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_nw_handover_rat_info_v1_t_area_code = ProtoField.uint32   ("mtkmipc.struct.area_code", "area_code", base.DEC)
mipc_nw_handover_rat_info_v1_t_arfcn = ProtoField.uint32   ("mtkmipc.struct.arfcn", "arfcn", base.DEC)
mipc_nw_handover_rat_info_v1_t_padding3 = ProtoField.new("padding3", "mtkmipc.struct.padding3", ftypes.BYTES)
mipc_ntn_ephemeris_orbital_t_semi_major_axis = ProtoField.uint64   ("mtkmipc.struct.semi_major_axis", "semi_major_axis", base.DEC)
mipc_ntn_ephemeris_orbital_t_eccentricity = ProtoField.uint32   ("mtkmipc.struct.eccentricity", "eccentricity", base.DEC)
mipc_ntn_ephemeris_orbital_t_periapsis = ProtoField.uint32   ("mtkmipc.struct.periapsis", "periapsis", base.DEC)
mipc_ntn_ephemeris_orbital_t_longitude = ProtoField.uint32   ("mtkmipc.struct.longitude", "longitude", base.DEC)
mipc_ntn_ephemeris_orbital_t_inclination = ProtoField.int32   ("mtkmipc.struct.inclination", "inclination", base.DEC)
mipc_ntn_ephemeris_orbital_t_anomaly = ProtoField.uint32   ("mtkmipc.struct.anomaly", "anomaly", base.DEC)
mipc_ntn_ephemeris_orbital_t_padding = ProtoField.new("padding", "mtkmipc.struct.padding", ftypes.BYTES)
mipc_ntn_sib31_info_t_ephemeris_state_vector_present = ProtoField.uint8   ("mtkmipc.struct.ephemeris_state_vector_present", "ephemeris_state_vector_present", base.DEC, BOOLEAN)
mipc_ntn_sib31_info_t_padding1 = ProtoField.new("padding1", "mtkmipc.struct.padding1", ftypes.BYTES)
mipc_ntn_sib31_info_t_ephemeris_orbital_present = ProtoField.uint8   ("mtkmipc.struct.ephemeris_orbital_present", "ephemeris_orbital_present", base.DEC, BOOLEAN)
mipc_ntn_sib31_info_t_padding2 = ProtoField.new("padding2", "mtkmipc.struct.padding2", ftypes.BYTES)
mipc_ntn_sib31_info_t_nta_common = ProtoField.uint32   ("mtkmipc.struct.nta_common", "nta_common", base.DEC)
mipc_ntn_sib31_info_t_nta_common_drift = ProtoField.int32   ("mtkmipc.struct.nta_common_drift", "nta_common_drift", base.DEC)
mipc_ntn_sib31_info_t_nta_common_drift_variation = ProtoField.uint32   ("mtkmipc.struct.nta_common_drift_variation", "nta_common_drift_variation", base.DEC)
mipc_ntn_sib31_info_t_satellite_type = ProtoField.uint8   ("mtkmipc.struct.satellite_type", "satellite_type", base.DEC, NTN_SATELLITE_TYPE)
mipc_ntn_sib31_info_t_sib31_scheduling_cycle = ProtoField.uint8   ("mtkmipc.struct.sib31_scheduling_cycle", "sib31_scheduling_cycle", base.DEC)
mipc_ntn_sib31_info_t_padding3 = ProtoField.new("padding3", "mtkmipc.struct.padding3", ftypes.BYTES)

mipc_struct_field = {
    mipc_unreference_struct_param,
    mipc_v4_full_addr_t_mtu,
    mipc_v4_full_addr_t_addr,
    mipc_v4_full_addr_t_mask,
    mipc_v6_full_addr_t_mtu,
    mipc_v6_full_addr_t_addr,
    mipc_v6_full_addr_t_prefix,
    mipc_addr_t_addr_len,
    mipc_addr_t_addr,
    mipc_full_addr_t_addr_len,
    mipc_full_addr_t_addr,
    mipc_full_addr_t_mtu,
    mipc_full_addr_t_mask,
    mipc_full_addr_t_prefix,
    mipc_apn_ia_t_apn,
    mipc_apn_ia_t_apn_idx,
    mipc_apn_ia_t_userid,
    mipc_apn_ia_t_password,
    mipc_apn_ia_t_bearer_bitmask,
    mipc_apn_ia_t_pdp_type,
    mipc_apn_ia_t_roaming_type,
    mipc_apn_ia_t_auth_type,
    mipc_apn_ia_t_compression,
    mipc_apn_profile_t_id,
    mipc_apn_profile_t_plmn_id,
    mipc_apn_profile_t_reserved,
    mipc_apn_profile_t_apn,
    mipc_apn_profile_t_apn_idx,
    mipc_apn_profile_t_userid,
    mipc_apn_profile_t_password,
    mipc_apn_profile_t_bearer_bitmask,
    mipc_apn_profile_t_apn_type,
    mipc_apn_profile_t_pdp_type,
    mipc_apn_profile_t_roaming_type,
    mipc_apn_profile_t_auth_type,
    mipc_apn_profile_t_compression,
    mipc_apn_profile_t_reserve1,
    mipc_apn_profile_t_reserve2,
    mipc_apn_profile_t_reserve3,
    mipc_apn_profile_t_enabled,
    mipc_apn_profile_v2_t_id,
    mipc_apn_profile_v2_t_plmn_id,
    mipc_apn_profile_v2_t_reserved,
    mipc_apn_profile_v2_t_apn,
    mipc_apn_profile_v2_t_apn_idx,
    mipc_apn_profile_v2_t_userid,
    mipc_apn_profile_v2_t_password,
    mipc_apn_profile_v2_t_bearer_bitmask,
    mipc_apn_profile_v2_t_apn_type,
    mipc_apn_profile_v2_t_pdp_type,
    mipc_apn_profile_v2_t_roaming_type,
    mipc_apn_profile_v2_t_auth_type,
    mipc_apn_profile_v2_t_compression,
    mipc_apn_profile_v2_t_enabled,
    mipc_apn_profile_v2_t_padding,
    mipc_apn_profile_v2_t_max_conns,
    mipc_apn_profile_v2_t_max_conn_t,
    mipc_apn_profile_v2_t_wait_time,
    mipc_apn_profile_v2_t_inact_timer,
    mipc_apn_profile_v2_t_v4_mtu,
    mipc_apn_profile_v2_t_v6_mtu,
    mipc_md_apn_profile_t_id,
    mipc_md_apn_profile_t_plmn_id,
    mipc_md_apn_profile_t_act_state,
    mipc_md_apn_profile_t_apn,
    mipc_md_apn_profile_t_apn_idx,
    mipc_md_apn_profile_t_userid,
    mipc_md_apn_profile_t_password,
    mipc_md_apn_profile_t_bearer_bitmask,
    mipc_md_apn_profile_t_apn_type,
    mipc_md_apn_profile_t_pdp_type,
    mipc_md_apn_profile_t_roaming_type,
    mipc_md_apn_profile_t_auth_type,
    mipc_md_apn_profile_t_reserve,
    mipc_op12_apn_profile_legacy_t_apn,
    mipc_op12_apn_profile_legacy_t_apnb,
    mipc_op12_apn_profile_legacy_t_pdp_type,
    mipc_op12_apn_profile_legacy_t_id,
    mipc_op12_apn_profile_legacy_t_apnclass,
    mipc_op12_apn_profile_legacy_t_enabled,
    mipc_op12_apn_profile_legacy_t_max_conn,
    mipc_op12_apn_profile_legacy_t_max_conn_t,
    mipc_op12_apn_profile_legacy_t_wait_time,
    mipc_op12_apn_profile_legacy_t_act_state,
    mipc_op12_apn_profile_legacy_t_reserve1,
    mipc_op12_apn_profile_legacy_t_reserve2,
    mipc_op12_apn_profile_legacy_t_reserve3,
    mipc_op12_apn_profile_t_apn,
    mipc_op12_apn_profile_t_apn_bear,
    mipc_op12_apn_profile_t_pdp_type,
    mipc_op12_apn_profile_t_act_state,
    mipc_op12_apn_profile_t_id,
    mipc_op12_apn_profile_t_apn_class,
    mipc_op12_apn_profile_t_enabled,
    mipc_op12_apn_profile_t_max_conn,
    mipc_op12_apn_profile_t_max_conn_t,
    mipc_op12_apn_profile_t_wait_time,
    mipc_data_nitz_info_t_year,
    mipc_data_nitz_info_t_month,
    mipc_data_nitz_info_t_day,
    mipc_data_nitz_info_t_hour,
    mipc_data_nitz_info_t_minute,
    mipc_data_nitz_info_t_second,
    mipc_data_v4_addr_t_addr,
    mipc_data_v6_addr_t_addr,
    mipc_data_pco_ie_t_ie,
    mipc_data_pco_ie_t_reserved,
    mipc_data_pco_ie_t_content,
    mipc_data_ran_result_t_ran,
    mipc_data_ran_result_t_padding,
    mipc_data_ran_result_t_deact_cause,
    mipc_data_ran_result_t_modify_cause,
    mipc_tmgi_struct_t_plmn_id,
    mipc_tmgi_struct_t_service_id,
    mipc_mbs_session_info_t_op,
    mipc_mbs_session_info_t_sesson_id_type,
    mipc_mbs_session_info_t_src_ip_addr,
    mipc_mbs_session_info_t_dest_ip_addr,
    mipc_mbs_session_update_ind_t_psi,
    mipc_mbs_session_update_ind_t_ip_addr_present,
    mipc_mbs_session_update_ind_t_src_ip_addr,
    mipc_mbs_session_update_ind_t_dest_ip_addr,
    mipc_mbs_session_update_ind_t_mbs_decision,
    mipc_mbs_session_update_ind_t_reject_cause,
    mipc_mbs_session_update_ind_t_mbs_sec_container_raw_present,
    mipc_mbs_session_update_ind_t_mbs_sec_container_raw,
    mipc_mbs_session_update_ind_t_padding,
    mipc_cell_global_id_struct_t_plmn_id,
    mipc_cell_global_id_struct_t_cell_id,
    mipc_tac_struct_t_plmn_id,
    mipc_tac_struct_t_ta_code,
    mipc_data_packet_filter_t_len,
    mipc_data_packet_filter_t_reserved,
    mipc_data_packet_filter_t_pattern,
    mipc_data_packet_filter_t_mask,
    mipc_data_secondary_pdp_context_present_info_t_cid_present,
    mipc_data_secondary_pdp_context_present_info_t_p_cid_present,
    mipc_data_secondary_pdp_context_present_info_t_bearer_id_present,
    mipc_data_secondary_pdp_context_present_info_t_im_cn_signalling_flag_present,
    mipc_data_secondary_pdp_context_present_info_t_wlan_offload_present,
    mipc_data_secondary_pdp_context_present_info_t_pdu_session_id_present,
    mipc_data_secondary_pdp_context_present_info_t_qfi_present,
    mipc_data_secondary_pdp_context_info_t_cid,
    mipc_data_secondary_pdp_context_info_t_p_cid,
    mipc_data_secondary_pdp_context_info_t_bearer_id,
    mipc_data_secondary_pdp_context_info_t_im_cn_signalling_flag,
    mipc_data_secondary_pdp_context_info_t_wlan_offload,
    mipc_data_secondary_pdp_context_info_t_pdu_session_id,
    mipc_data_secondary_pdp_context_info_t_qfi,
    mipc_mipi_device_t_instance_id,
    mipc_mipi_device_t_trans_port,
    mipc_mipi_device_t_mipi_port,
    mipc_mipi_device_t_usid,
    mipc_mipi_device_t_mid,
    mipc_mipi_device_t_pid,
    mipc_mipi_device_t_hw_mid,
    mipc_mipi_device_t_hw_pid,
    mipc_data_qos_info_t_cid,
    mipc_data_qos_info_t_qci,
    mipc_data_qos_info_t_dl_gbr,
    mipc_data_qos_info_t_ul_gbr,
    mipc_data_qos_info_t_dl_mbr,
    mipc_data_qos_info_t_ul_mbr,
    mipc_data_qos_info_t_dl_ambr,
    mipc_data_qos_info_t_ul_ambr,
    mipc_data_5gqos_info_t_cid,
    mipc_data_5gqos_info_t_vqi,
    mipc_data_5gqos_info_t_dl_gfbr,
    mipc_data_5gqos_info_t_ul_gfbr,
    mipc_data_5gqos_info_t_dl_mfbr,
    mipc_data_5gqos_info_t_ul_mfbr,
    mipc_data_5gqos_info_t_dl_sambr,
    mipc_data_5gqos_info_t_ul_sambr,
    mipc_data_5gqos_info_t_averaging_window,
    mipc_data_tft_info_t_cid,
    mipc_data_tft_info_t_packet_filter_identifier,
    mipc_data_tft_info_t_evaluation_precedence_index,
    mipc_data_tft_info_t_remote_v4_addr_present,
    mipc_data_tft_info_t_remote_v6_addr_present,
    mipc_data_tft_info_t_protocol_number_next_header,
    mipc_data_tft_info_t_tos_traffic_class,
    mipc_data_tft_info_t_tos_mask,
    mipc_data_tft_info_t_direction,
    mipc_data_tft_info_t_nw_packet_filter_identifier,
    mipc_data_tft_info_t_local_v4_addr_present,
    mipc_data_tft_info_t_local_v6_addr_present,
    mipc_data_tft_info_t_remote_v4_addr,
    mipc_data_tft_info_t_remote_v4_subnet_mask,
    mipc_data_tft_info_t_remote_v6_addr,
    mipc_data_tft_info_t_remote_v6_subnet_mask,
    mipc_data_tft_info_t_local_port_low,
    mipc_data_tft_info_t_local_port_high,
    mipc_data_tft_info_t_remote_port_low,
    mipc_data_tft_info_t_remote_port_high,
    mipc_data_tft_info_t_ipsec_spi,
    mipc_data_tft_info_t_flow_label,
    mipc_data_tft_info_t_local_v4_addr,
    mipc_data_tft_info_t_local_v4_subnet_mask,
    mipc_data_tft_info_t_local_v6_addr,
    mipc_data_tft_info_t_local_v6_subnet_mask,
    mipc_data_tft_info_t_qri,
    mipc_data_tft_info_t_dest_mac_addr_present,
    mipc_data_tft_info_t_src_mac_addr_present,
    mipc_data_tft_info_t_dest_mac_addr,
    mipc_data_tft_info_t_src_mac_addr,
    mipc_data_tft_info_t_c_tag_vid,
    mipc_data_tft_info_t_s_tag_vid,
    mipc_data_tft_info_t_c_tag_pcp_dei,
    mipc_data_tft_info_t_s_tag_pcp_dei,
    mipc_data_tft_info_t_ethertype,
    mipc_data_tft_info_t_packet_filter_identifier_present,
    mipc_data_tft_info_t_evaluation_precedence_index_present,
    mipc_data_tft_info_t_protocol_number_next_header_present,
    mipc_data_tft_info_t_ipsec_spi_present,
    mipc_data_tft_info_t_tos_traffic_class_and_mask_present,
    mipc_data_tft_info_t_flow_label_present,
    mipc_data_tft_info_t_direction_present,
    mipc_data_tft_info_t_nw_packet_filter_identifier_present,
    mipc_data_tft_info_t_qri_present,
    mipc_data_tft_info_t_c_tag_vid_present,
    mipc_data_tft_info_t_s_tag_vid_present,
    mipc_data_tft_info_t_c_tag_pcp_dei_present,
    mipc_data_tft_info_t_s_tag_pcp_dei_present,
    mipc_data_tft_info_t_ethertype_present,
    mipc_data_tft_info_t_padding,
    mipc_data_tft_info_v1_t_cid,
    mipc_data_tft_info_v1_t_packet_filter_identifier_present,
    mipc_data_tft_info_v1_t_packet_filter_identifier,
    mipc_data_tft_info_v1_t_evaluation_precedence_index_present,
    mipc_data_tft_info_v1_t_evaluation_precedence_index,
    mipc_data_tft_info_v1_t_remote_v4_addr_present,
    mipc_data_tft_info_v1_t_remote_v4_addr,
    mipc_data_tft_info_v1_t_remote_v4_subnet_mask,
    mipc_data_tft_info_v1_t_remote_v6_addr_present,
    mipc_data_tft_info_v1_t_remote_v6_addr,
    mipc_data_tft_info_v1_t_remote_v6_prefix,
    mipc_data_tft_info_v1_t_protocol_number_next_header_present,
    mipc_data_tft_info_v1_t_protocol_number_next_header,
    mipc_data_tft_info_v1_t_padding1,
    mipc_data_tft_info_v1_t_local_port_low,
    mipc_data_tft_info_v1_t_local_port_high,
    mipc_data_tft_info_v1_t_remote_port_low,
    mipc_data_tft_info_v1_t_remote_port_high,
    mipc_data_tft_info_v1_t_ipsec_spi_present,
    mipc_data_tft_info_v1_t_padding2,
    mipc_data_tft_info_v1_t_ipsec_spi,
    mipc_data_tft_info_v1_t_tos_traffic_class_and_mask_present,
    mipc_data_tft_info_v1_t_tos_traffic_class,
    mipc_data_tft_info_v1_t_tos_mask,
    mipc_data_tft_info_v1_t_flow_label_present,
    mipc_data_tft_info_v1_t_flow_label,
    mipc_data_tft_info_v1_t_direction_present,
    mipc_data_tft_info_v1_t_direction,
    mipc_data_tft_info_v1_t_nw_packet_filter_identifier_present,
    mipc_data_tft_info_v1_t_nw_packet_filter_identifier,
    mipc_data_tft_info_v1_t_local_v4_addr_present,
    mipc_data_tft_info_v1_t_local_v4_addr,
    mipc_data_tft_info_v1_t_local_v4_subnet_mask,
    mipc_data_tft_info_v1_t_local_v6_addr_present,
    mipc_data_tft_info_v1_t_local_v6_addr,
    mipc_data_tft_info_v1_t_local_v6_prefix,
    mipc_data_tft_info_v1_t_qri_present,
    mipc_data_tft_info_v1_t_padding3,
    mipc_data_tft_info_v1_t_qri,
    mipc_data_tft_info_v1_t_dest_mac_addr_present,
    mipc_data_tft_info_v1_t_dest_mac_addr,
    mipc_data_tft_info_v1_t_src_mac_addr_present,
    mipc_data_tft_info_v1_t_src_mac_addr,
    mipc_data_tft_info_v1_t_c_tag_vid_present,
    mipc_data_tft_info_v1_t_padding4,
    mipc_data_tft_info_v1_t_c_tag_vid,
    mipc_data_tft_info_v1_t_s_tag_vid_present,
    mipc_data_tft_info_v1_t_padding5,
    mipc_data_tft_info_v1_t_s_tag_vid,
    mipc_data_tft_info_v1_t_c_tag_pcp_dei_present,
    mipc_data_tft_info_v1_t_c_tag_pcp_dei,
    mipc_data_tft_info_v1_t_s_tag_pcp_dei_present,
    mipc_data_tft_info_v1_t_s_tag_pcp_dei,
    mipc_data_tft_info_v1_t_ethertype_present,
    mipc_data_tft_info_v1_t_padding6,
    mipc_data_tft_info_v1_t_ethertype,
    mipc_data_start_keepalive_request_t_type,
    mipc_data_start_keepalive_request_t_sourceport,
    mipc_data_start_keepalive_request_t_destinationport,
    mipc_data_start_keepalive_request_t_maxkeepaliveintervalmillis,
    mipc_data_start_keepalive_request_t_cid,
    mipc_data_start_keepalive_request_t_sourceaddress,
    mipc_data_start_keepalive_request_t_destinationaddress,
    mipc_s_nssai_struct_t_sst_present,
    mipc_s_nssai_struct_t_sst,
    mipc_s_nssai_struct_t_sd_present,
    mipc_s_nssai_struct_t_padding,
    mipc_s_nssai_struct_t_sd,
    mipc_s_nssai_struct_t_mapped_sst_present,
    mipc_s_nssai_struct_t_mapped_sst,
    mipc_s_nssai_struct_t_mapped_sd_present,
    mipc_s_nssai_struct_t_padding2,
    mipc_s_nssai_struct_t_mapped_sd,
    mipc_ursp_route_sel_desc_struct_t_p_val,
    mipc_ursp_route_sel_desc_struct_t_ssc_mode,
    mipc_ursp_route_sel_desc_struct_t_dnn_len,
    mipc_ursp_route_sel_desc_struct_t_s_nssai_present,
    mipc_ursp_route_sel_desc_struct_t_dnn,
    mipc_ursp_route_sel_desc_struct_t_pdu_session_type,
    mipc_ursp_route_sel_desc_struct_t_pref_access_type,
    mipc_ursp_route_sel_desc_struct_t_padding2,
    mipc_ursp_traffic_desc_struct_t_is_match_all,
    mipc_ursp_traffic_desc_struct_t_dnn_len,
    mipc_ursp_traffic_desc_struct_t_reserved1,
    mipc_ursp_traffic_desc_struct_t_dnn,
    mipc_ursp_traffic_desc_struct_t_os_id,
    mipc_ursp_traffic_desc_struct_t_app_id_len,
    mipc_ursp_traffic_desc_struct_t_reserved2,
    mipc_ursp_traffic_desc_struct_t_app_id,
    mipc_ursp_traffic_desc_struct_t_reserved3,
    mipc_ursp_traffic_desc_struct_t_ipv4_addr,
    mipc_ursp_traffic_desc_struct_t_ipv4_mask,
    mipc_ursp_traffic_desc_struct_t_ipv6_addr,
    mipc_ursp_traffic_desc_struct_t_ipv6_prefix_len,
    mipc_ursp_traffic_desc_struct_t_reserved4,
    mipc_ursp_traffic_desc_struct_t_port_num,
    mipc_ursp_traffic_desc_struct_t_min_port_num,
    mipc_ursp_traffic_desc_struct_t_max_port_num,
    mipc_ursp_traffic_desc_struct_t_prot_id_next_hdr,
    mipc_ursp_traffic_desc_struct_t_dst_fqdn_len,
    mipc_ursp_traffic_desc_struct_t_dst_fqdn,
    mipc_ursp_traffic_desc_struct_t_padding,
    mipc_ursp_ue_local_conf_struct_t_ssc_mode,
    mipc_ursp_ue_local_conf_struct_t_dnn_len,
    mipc_ursp_ue_local_conf_struct_t_reserved,
    mipc_ursp_ue_local_conf_struct_t_s_nssai_present,
    mipc_ursp_ue_local_conf_struct_t_dnn,
    mipc_ursp_ue_local_conf_struct_t_pdu_session_type,
    mipc_ursp_ue_local_conf_struct_t_pref_access_type,
    mipc_ursp_ue_local_conf_struct_t_padding,
    mipc_ursp_get_route_supp_profile_ind_struct_t_cid,
    mipc_ursp_get_route_supp_profile_ind_struct_t_supp_profile_type,
    mipc_ursp_get_route_supp_profile_ind_struct_t_is_match_all_disallowed,
    mipc_ursp_get_route_supp_profile_ind_struct_t_padding,
    mipc_ursp_rule_struct_t_p_val,
    mipc_ursp_rule_struct_t_reserved1,
    mipc_ursp_rule_struct_t_num_of_rsd,
    mipc_ursp_rule_struct_t_reserved2,
    mipc_ursp_ue_policy_plmn_t_plmn_id,
    mipc_plmn_specific_s_nssai_struct_t_plmn_id,
    mipc_plmn_specific_s_nssai_struct_t_sst_present,
    mipc_plmn_specific_s_nssai_struct_t_sst,
    mipc_plmn_specific_s_nssai_struct_t_sd_present,
    mipc_plmn_specific_s_nssai_struct_t_padding,
    mipc_plmn_specific_s_nssai_struct_t_sd,
    mipc_plmn_specific_s_nssai_struct_t_mapped_sst_present,
    mipc_plmn_specific_s_nssai_struct_t_mapped_sst,
    mipc_plmn_specific_s_nssai_struct_t_mapped_sd_present,
    mipc_plmn_specific_s_nssai_struct_t_padding2,
    mipc_plmn_specific_s_nssai_struct_t_mapped_sd,
    mipc_rejected_s_nssai_struct_t_cause_value,
    mipc_rejected_s_nssai_struct_t_sst_present,
    mipc_rejected_s_nssai_struct_t_sst,
    mipc_rejected_s_nssai_struct_t_sd_present,
    mipc_rejected_s_nssai_struct_t_sd,
    mipc_lte_cc_meas_info_t_lte_cc_type,
    mipc_lte_cc_meas_info_t_path_loss,
    mipc_lte_cc_meas_info_t_rank_indicator,
    mipc_lte_cc_meas_info_t_serv_rsrp,
    mipc_lte_cc_meas_info_t_serv_rsrq,
    mipc_lte_cc_meas_info_t_serv_snr,
    mipc_lte_cc_meas_info_t_serv_rssi,
    mipc_lte_cc_meas_info_v1_t_lte_cc_type,
    mipc_lte_cc_meas_info_v1_t_cell_index,
    mipc_lte_cc_meas_info_v1_t_path_loss,
    mipc_lte_cc_meas_info_v1_t_rank_indicator,
    mipc_lte_cc_meas_info_v1_t_padding,
    mipc_lte_cc_meas_info_v1_t_serv_rsrp,
    mipc_lte_cc_meas_info_v1_t_serv_rsrq,
    mipc_lte_cc_meas_info_v1_t_serv_snr,
    mipc_lte_cc_meas_info_v1_t_serv_rssi,
    mipc_lte_cc_meas_info_v1_t_measbw_rssi,
    mipc_nr_cc_meas_info_t_nr_cc_type,
    mipc_nr_cc_meas_info_t_path_loss,
    mipc_nr_cc_meas_info_t_rank_indicator,
    mipc_nr_cc_meas_info_t_brsrp,
    mipc_nr_cc_meas_info_t_serv_rsrp,
    mipc_nr_cc_meas_info_t_serv_rsrq,
    mipc_nr_cc_meas_info_t_ssb_best_beam_id,
    mipc_nr_cc_meas_info_t_ssb_snr_avg,
    mipc_nr_cc_meas_info_t_ssb_rsrp_avg,
    mipc_nr_cc_meas_info_t_trs_snr_avg,
    mipc_nr_cc_meas_info_t_trs_rsrp_avg,
    mipc_nr_cc_meas_info_t_serv_snr,
    mipc_nr_cc_meas_info_t_serv_rssi,
    mipc_nr_cc_meas_info_v1_t_nr_cc_type,
    mipc_nr_cc_meas_info_v1_t_cell_index,
    mipc_nr_cc_meas_info_v1_t_path_loss,
    mipc_nr_cc_meas_info_v1_t_rank_indicator,
    mipc_nr_cc_meas_info_v1_t_padding,
    mipc_nr_cc_meas_info_v1_t_brsrp,
    mipc_nr_cc_meas_info_v1_t_serv_rsrp,
    mipc_nr_cc_meas_info_v1_t_serv_rsrq,
    mipc_nr_cc_meas_info_v1_t_ssb_best_beam_id,
    mipc_nr_cc_meas_info_v1_t_ssb_snr_avg,
    mipc_nr_cc_meas_info_v1_t_ssb_rsrp_avg,
    mipc_nr_cc_meas_info_v1_t_trs_snr_avg,
    mipc_nr_cc_meas_info_v1_t_trs_rsrp_avg,
    mipc_nr_cc_meas_info_v1_t_serv_snr,
    mipc_nr_cc_meas_info_v1_t_serv_rssi,
    mipc_nr_cc_meas_info_v1_t_bwp_rssi,
    mipc_wcdma_current_cell_info_t_band,
    mipc_wcdma_current_cell_info_t_pci,
    mipc_wcdma_current_cell_info_t_uarfcn,
    mipc_wcdma_current_cell_info_t_dl_bandwidth,
    mipc_wcdma_current_cell_info_t_ul_bandwidth,
    mipc_current_cell_info_t_scc_state,
    mipc_current_cell_info_t_scc_ul_configured,
    mipc_current_cell_info_t_cc_band,
    mipc_current_cell_info_t_cc_pci,
    mipc_current_cell_info_t_cc_arfcn,
    mipc_current_cell_info_t_cc_dl_bandwidth,
    mipc_current_cell_info_t_cc_ul_bandwidth,
    mipc_current_cell_info_t_cc_dl_bandwidth_str,
    mipc_current_cell_info_t_cc_ul_bandwidth_str,
    mipc_current_cell_info_t_cc_dl_mimo,
    mipc_current_cell_info_t_cc_ul_mimo,
    mipc_current_cell_info_t_cc_dl_modulation,
    mipc_current_cell_info_t_cc_ul_modulation,
    mipc_current_cell_info_t_cc_dl_rb,
    mipc_current_cell_info_t_cc_ul_rb,
    mipc_current_cell_info_t_cc_dl_mcs,
    mipc_current_cell_info_t_cc_ul_mcs,
    mipc_current_cell_info_t_cc_pucch_tx_pwr,
    mipc_current_cell_info_t_cc_pusch_tx_pwr,
    mipc_current_cell_info_t_cc_lte_dl_tm,
    mipc_current_cell_info_t_cc_lte_ul_tm,
    mipc_current_cell_info_t_cc_dl_tput,
    mipc_current_cell_info_t_cc_ul_tput,
    mipc_current_cell_info_t_cc_dl_bwp_bandwidth,
    mipc_current_cell_info_t_cc_ul_bwp_bandwidth,
    mipc_current_cell_info_t_cc_dl_bwp_bandwidth_str,
    mipc_current_cell_info_t_cc_ul_bwp_bandwidth_str,
    mipc_current_cell_info_t_cc_dl_spectral_efficiency,
    mipc_current_cell_info_t_cc_ul_spectral_efficiency,
    mipc_current_cell_info_v1_t_scc_state,
    mipc_current_cell_info_v1_t_padding,
    mipc_current_cell_info_v1_t_cell_index,
    mipc_current_cell_info_v1_t_scc_ul_configured,
    mipc_current_cell_info_v1_t_padding1,
    mipc_current_cell_info_v1_t_cc_band,
    mipc_current_cell_info_v1_t_cc_pci,
    mipc_current_cell_info_v1_t_cc_arfcn,
    mipc_current_cell_info_v1_t_cc_dl_bandwidth,
    mipc_current_cell_info_v1_t_cc_ul_bandwidth,
    mipc_current_cell_info_v1_t_cc_dl_bandwidth_str,
    mipc_current_cell_info_v1_t_cc_ul_bandwidth_str,
    mipc_current_cell_info_v1_t_cc_dl_mimo,
    mipc_current_cell_info_v1_t_cc_ul_mimo,
    mipc_current_cell_info_v1_t_cc_dl_modulation,
    mipc_current_cell_info_v1_t_cc_ul_modulation,
    mipc_current_cell_info_v1_t_cc_dl_rb,
    mipc_current_cell_info_v1_t_cc_ul_rb,
    mipc_current_cell_info_v1_t_cc_dl_mcs,
    mipc_current_cell_info_v1_t_cc_ul_mcs,
    mipc_current_cell_info_v1_t_cc_pucch_tx_pwr,
    mipc_current_cell_info_v1_t_cc_pusch_tx_pwr,
    mipc_current_cell_info_v1_t_cc_lte_dl_tm,
    mipc_current_cell_info_v1_t_cc_lte_ul_tm,
    mipc_current_cell_info_v1_t_cc_dl_tput,
    mipc_current_cell_info_v1_t_cc_ul_tput,
    mipc_current_cell_info_v1_t_cc_dl_bwp_bandwidth,
    mipc_current_cell_info_v1_t_cc_ul_bwp_bandwidth,
    mipc_current_cell_info_v1_t_cc_dl_bwp_bandwidth_str,
    mipc_current_cell_info_v1_t_cc_ul_bwp_bandwidth_str,
    mipc_current_cell_info_v1_t_cc_dl_spectral_efficiency,
    mipc_current_cell_info_v1_t_cc_ul_spectral_efficiency,
    mipc_current_cell_info_v1_t_cc_dl_bwp_central_freq,
    mipc_current_cell_info_v1_t_cc_ul_bwp_central_freq,
    mipc_current_cell_info_v1_t_cc_lte_target_pwr,
    mipc_current_cell_info_v1_t_cc_lte_meas_bandwidth,
    mipc_current_cell_info_v1_t_central_arfcn,
    mipc_nw_provider_t_index,
    mipc_nw_provider_t_plmn_id,
    mipc_nw_provider_t_reserved,
    mipc_nw_provider_t_network_name,
    mipc_nw_provider_t_network_short_name,
    mipc_nw_provider_t_act,
    mipc_nw_provider_t_act_supported,
    mipc_nw_provider_t_state,
    mipc_nw_provider_t_rssi,
    mipc_nw_provider_t_error_rate,
    mipc_nw_provider_t_padding,
    mipc_nw_nitz_info_t_year,
    mipc_nw_nitz_info_t_month,
    mipc_nw_nitz_info_t_day,
    mipc_nw_nitz_info_t_hour,
    mipc_nw_nitz_info_t_minute,
    mipc_nw_nitz_info_t_second,
    mipc_nw_nitz_info_t_time_zone_offset_minutes,
    mipc_nw_nitz_info_t_daylight_saving_offset_minutes,
    mipc_nw_anbr_info_t_anbrq_config,
    mipc_nw_anbr_info_t_ebi,
    mipc_nw_anbr_info_t_is_ul,
    mipc_nw_anbr_info_t_beare_id,
    mipc_nw_anbr_info_t_bitrate,
    mipc_nw_anbr_info_t_pdu_session_id,
    mipc_nw_anbr_info_t_ext_param,
    mipc_nw_irat_info_t_irat_status,
    mipc_nw_irat_info_t_is_successful,
    mipc_nw_reg_state_t_ps_state,
    mipc_nw_reg_state_t_cs_state,
    mipc_nw_reg_state_t_plmn,
    mipc_nw_reg_state_t_padding,
    mipc_nw_reg_state_t_cs_plmn,
    mipc_nw_reg_state_t_padding2,
    mipc_nw_reg_state_t_lac,
    mipc_nw_reg_state_t_cs_lac,
    mipc_nw_reg_state_t_ci,
    mipc_nw_reg_state_t_cs_ci,
    mipc_nw_reg_state_t_is_roaming,
    mipc_nw_reg_state_t_cs_is_roaming,
    mipc_nw_reg_state_t_padding3,
    mipc_nw_reg_state_v1_t_ps_state,
    mipc_nw_reg_state_v1_t_cs_state,
    mipc_nw_reg_state_v1_t_plmn,
    mipc_nw_reg_state_v1_t_cs_plmn,
    mipc_nw_reg_state_v1_t_lac,
    mipc_nw_reg_state_v1_t_cs_lac,
    mipc_nw_reg_state_v1_t_ci,
    mipc_nw_reg_state_v1_t_cs_ci,
    mipc_nw_reg_state_v1_t_is_roaming,
    mipc_nw_reg_state_v1_t_cs_is_roaming,
    mipc_nw_reg_state_v1_t_padding,
    mipc_nw_reg_info_t_state,
    mipc_nw_reg_info_t_plmn,
    mipc_nw_reg_info_t_lac,
    mipc_nw_reg_info_t_ci,
    mipc_nw_location_info_t_location_area_code,
    mipc_nw_location_info_t_tracking_area_code,
    mipc_nw_location_info_t_cell_id,
    mipc_nw_gsm_cell_t_state,
    mipc_nw_gsm_cell_t_provider_id,
    mipc_nw_gsm_cell_t_lac,
    mipc_nw_gsm_cell_t_cid,
    mipc_nw_gsm_cell_t_ta,
    mipc_nw_gsm_cell_t_arfcn,
    mipc_nw_gsm_cell_t_base_station_id,
    mipc_nw_gsm_cell_t_rx_level,
    mipc_nw_gsm_cell_t_biterrorrate,
    mipc_nw_gsm_cell_t_registered,
    mipc_nw_gsm_cell_t_long_name,
    mipc_nw_gsm_cell_t_short_name,
    mipc_nw_umts_cell_t_state,
    mipc_nw_umts_cell_t_provider_id,
    mipc_nw_umts_cell_t_lac,
    mipc_nw_umts_cell_t_cid,
    mipc_nw_umts_cell_t_uarfcn,
    mipc_nw_umts_cell_t_psc,
    mipc_nw_umts_cell_t_rscp,
    mipc_nw_umts_cell_t_ecno,
    mipc_nw_umts_cell_t_registered,
    mipc_nw_umts_cell_t_long_name,
    mipc_nw_umts_cell_t_short_name,
    mipc_nw_lte_cell_t_state,
    mipc_nw_lte_cell_t_provider_id,
    mipc_nw_lte_cell_t_cid,
    mipc_nw_lte_cell_t_earfcn,
    mipc_nw_lte_cell_t_physical_cell_id,
    mipc_nw_lte_cell_t_tac,
    mipc_nw_lte_cell_t_rsrp,
    mipc_nw_lte_cell_t_rsrq,
    mipc_nw_lte_cell_t_ta,
    mipc_nw_lte_cell_t_rsrp_in_qdbm,
    mipc_nw_lte_cell_t_rsrq_in_qdbm,
    mipc_nw_lte_cell_t_rssnr,
    mipc_nw_lte_cell_t_cqi,
    mipc_nw_lte_cell_t_dl_freq_band,
    mipc_nw_lte_cell_t_registered,
    mipc_nw_lte_cell_t_long_name,
    mipc_nw_lte_cell_t_short_name,
    mipc_nw_lte_cell_v1_t_state,
    mipc_nw_lte_cell_v1_t_provider_id,
    mipc_nw_lte_cell_v1_t_cid,
    mipc_nw_lte_cell_v1_t_earfcn,
    mipc_nw_lte_cell_v1_t_physical_cell_id,
    mipc_nw_lte_cell_v1_t_tac,
    mipc_nw_lte_cell_v1_t_rsrp,
    mipc_nw_lte_cell_v1_t_rsrq,
    mipc_nw_lte_cell_v1_t_ta,
    mipc_nw_lte_cell_v1_t_rsrp_in_qdbm,
    mipc_nw_lte_cell_v1_t_rsrq_in_qdbm,
    mipc_nw_lte_cell_v1_t_rssnr,
    mipc_nw_lte_cell_v1_t_cqi,
    mipc_nw_lte_cell_v1_t_dl_freq_band,
    mipc_nw_lte_cell_v1_t_registered,
    mipc_nw_lte_cell_v1_t_cqi_table_index,
    mipc_nw_lte_cell_v1_t_long_name,
    mipc_nw_lte_cell_v1_t_short_name,
    mipc_nw_lte_cell_v2_t_state,
    mipc_nw_lte_cell_v2_t_provider_id,
    mipc_nw_lte_cell_v2_t_cid,
    mipc_nw_lte_cell_v2_t_earfcn,
    mipc_nw_lte_cell_v2_t_physical_cell_id,
    mipc_nw_lte_cell_v2_t_tac,
    mipc_nw_lte_cell_v2_t_rsrp,
    mipc_nw_lte_cell_v2_t_rsrq,
    mipc_nw_lte_cell_v2_t_ta,
    mipc_nw_lte_cell_v2_t_rsrp_in_qdbm,
    mipc_nw_lte_cell_v2_t_rsrq_in_qdbm,
    mipc_nw_lte_cell_v2_t_rssnr,
    mipc_nw_lte_cell_v2_t_cqi,
    mipc_nw_lte_cell_v2_t_dl_freq_band,
    mipc_nw_lte_cell_v2_t_registered,
    mipc_nw_lte_cell_v2_t_cqi_table_index,
    mipc_nw_lte_cell_v2_t_long_name,
    mipc_nw_lte_cell_v2_t_short_name,
    mipc_nw_lte_cell_v2_t_padding,
    mipc_nw_nr_cell_t_state,
    mipc_nw_nr_cell_t_provider_id,
    mipc_nw_nr_cell_t_cid,
    mipc_nw_nr_cell_t_physical_cell_id,
    mipc_nw_nr_cell_t_nr_arfcn,
    mipc_nw_nr_cell_t_tac,
    mipc_nw_nr_cell_t_rsrp,
    mipc_nw_nr_cell_t_rsrq,
    mipc_nw_nr_cell_t_sinr,
    mipc_nw_nr_cell_t_ta,
    mipc_nw_nr_cell_t_csirsrp,
    mipc_nw_nr_cell_t_csirsrq,
    mipc_nw_nr_cell_t_csisinr,
    mipc_nw_nr_cell_t_dl_freq_band,
    mipc_nw_nr_cell_t_registered,
    mipc_nw_nr_cell_t_long_name,
    mipc_nw_nr_cell_t_short_name,
    mipc_nw_nr_cell_v1_t_state,
    mipc_nw_nr_cell_v1_t_cid,
    mipc_nw_nr_cell_v1_t_physical_cell_id,
    mipc_nw_nr_cell_v1_t_nr_arfcn,
    mipc_nw_nr_cell_v1_t_tac,
    mipc_nw_nr_cell_v1_t_rsrp,
    mipc_nw_nr_cell_v1_t_rsrq,
    mipc_nw_nr_cell_v1_t_sinr,
    mipc_nw_nr_cell_v1_t_ta,
    mipc_nw_nr_cell_v1_t_csirsrp,
    mipc_nw_nr_cell_v1_t_csirsrq,
    mipc_nw_nr_cell_v1_t_csisinr,
    mipc_nw_nr_cell_v1_t_dl_freq_band,
    mipc_nw_nr_cell_v1_t_registered,
    mipc_nw_nr_cell_v1_t_csi_cqi_table_index,
    mipc_nw_nr_cell_v1_t_csi_cqi_report_num,
    mipc_nw_nr_cell_v1_t_provider_id,
    mipc_nw_nr_cell_v1_t_long_name,
    mipc_nw_nr_cell_v1_t_short_name,
    mipc_nw_nr_cell_v1_t_csi_cqi_report_list,
    mipc_nw_cdma_cell_t_networkid,
    mipc_nw_cdma_cell_t_systemid,
    mipc_nw_cdma_cell_t_basestationid,
    mipc_nw_cdma_cell_t_longitude,
    mipc_nw_cdma_cell_t_latitude,
    mipc_nw_cdma_cell_t_dbm_cdma,
    mipc_nw_cdma_cell_t_ecio_cdma,
    mipc_nw_cdma_cell_t_dbm_evdo,
    mipc_nw_cdma_cell_t_ecio_evdo,
    mipc_nw_cdma_cell_t_snr_evdo,
    mipc_nw_cdma_cell_t_state,
    mipc_nw_cdma_cell_t_registered,
    mipc_nw_cdma_cell_v1_t_networkid,
    mipc_nw_cdma_cell_v1_t_systemid,
    mipc_nw_cdma_cell_v1_t_basestationid,
    mipc_nw_cdma_cell_v1_t_longitude,
    mipc_nw_cdma_cell_v1_t_latitude,
    mipc_nw_cdma_cell_v1_t_dbm_cdma,
    mipc_nw_cdma_cell_v1_t_ecio_cdma,
    mipc_nw_cdma_cell_v1_t_dbm_evdo,
    mipc_nw_cdma_cell_v1_t_ecio_evdo,
    mipc_nw_cdma_cell_v1_t_snr_evdo,
    mipc_nw_cdma_cell_v1_t_state,
    mipc_nw_cdma_cell_v1_t_registered,
    mipc_nw_cdma_cell_v1_t_padding,
    mipc_nw_tdscdma_cell_t_tbd,
    mipc_nw_reg_change_info_t_stat,
    mipc_nw_reg_change_info_t_lac_tac,
    mipc_nw_reg_change_info_t_cell_id,
    mipc_nw_reg_change_info_t_eact,
    mipc_nw_reg_change_info_t_rac,
    mipc_nw_reg_change_info_t_nw_existence,
    mipc_nw_reg_change_info_t_roam_indicator,
    mipc_nw_reg_change_info_t_cause_type,
    mipc_nw_reg_change_info_t_reject_cause,
    mipc_nw_reg_change_info_t_dcnr_restricted,
    mipc_nw_reg_change_info_t_endc_sib_status,
    mipc_nw_reg_change_info_t_endc_available,
    mipc_nw_cs_reg_info_t_stat,
    mipc_nw_cs_reg_info_t_rat,
    mipc_nw_cs_reg_info_t_css,
    mipc_nw_cs_reg_info_t_roaming_ind,
    mipc_nw_cs_reg_info_t_is_in_prl,
    mipc_nw_cs_reg_info_t_def_roaming_ind,
    mipc_nw_cs_reg_info_t_reason_for_denial,
    mipc_nw_cs_reg_info_v1_t_stat,
    mipc_nw_cs_reg_info_v1_t_padding1,
    mipc_nw_cs_reg_info_v1_t_rat,
    mipc_nw_cs_reg_info_v1_t_css,
    mipc_nw_cs_reg_info_v1_t_roaming_ind,
    mipc_nw_cs_reg_info_v1_t_is_in_prl,
    mipc_nw_cs_reg_info_v1_t_padding2,
    mipc_nw_cs_reg_info_v1_t_def_roaming_ind,
    mipc_nw_cs_reg_info_v1_t_reason_for_denial,
    mipc_nw_ps_reg_info_t_stat,
    mipc_nw_ps_reg_info_t_rat,
    mipc_nw_ps_reg_info_t_reason_for_denial,
    mipc_nw_ps_reg_info_t_max_data_calls,
    mipc_nw_ps_reg_info_t_is_vops_supported,
    mipc_nw_ps_reg_info_t_is_emc_bearer_supported,
    mipc_nw_ps_reg_info_t_is_endc_available,
    mipc_nw_ps_reg_info_t_is_dcnr_restricted,
    mipc_nw_ps_reg_info_t_is_nr_available,
    mipc_nw_ps_reg_info_t_roaming_ind,
    mipc_nw_ps_reg_info_t_is_in_prl,
    mipc_nw_ps_reg_info_t_def_roaming_ind,
    mipc_nw_ps_reg_info_t_cell_id,
    mipc_nw_ps_reg_info_t_cache_endc_connect,
    mipc_nw_ps_reg_info_t_lac_tac,
    mipc_nw_channel_lock_info_t_opt,
    mipc_nw_channel_lock_info_t_act,
    mipc_nw_channel_lock_info_t_band_info,
    mipc_nw_channel_lock_info_t_channel_num,
    mipc_nw_channel_lock_info_t_arfcn_list,
    mipc_nw_channel_lock_info_t_cell_id,
    mipc_nw_channel_lock_info_t_lock_mode,
    mipc_nw_channel_lock_info_v1_t_opt,
    mipc_nw_channel_lock_info_v1_t_act,
    mipc_nw_channel_lock_info_v1_t_band_info,
    mipc_nw_channel_lock_info_v1_t_channel_num,
    mipc_nw_channel_lock_info_v1_t_arfcn_list,
    mipc_nw_channel_lock_info_v1_t_cell_id,
    mipc_nw_channel_lock_info_v1_t_lock_mode,
    mipc_nw_gsm_signal_strength_t_signal_strength,
    mipc_nw_gsm_signal_strength_t_bit_error_rate,
    mipc_nw_gsm_signal_strength_t_timing_advance,
    mipc_nw_umts_signal_strength_t_signal_strength,
    mipc_nw_umts_signal_strength_t_bit_error_rate,
    mipc_nw_umts_signal_strength_t_rscp,
    mipc_nw_umts_signal_strength_t_ecno,
    mipc_nw_lte_signal_strength_t_signal_strength,
    mipc_nw_lte_signal_strength_t_rsrp,
    mipc_nw_lte_signal_strength_t_rsrq,
    mipc_nw_lte_signal_strength_t_rssnr,
    mipc_nw_lte_signal_strength_t_cqi,
    mipc_nw_lte_signal_strength_t_timing_advance,
    mipc_nw_lte_signal_strength_v1_t_signal_strength,
    mipc_nw_lte_signal_strength_v1_t_rsrp,
    mipc_nw_lte_signal_strength_v1_t_rsrq,
    mipc_nw_lte_signal_strength_v1_t_rssnr,
    mipc_nw_lte_signal_strength_v1_t_cqi,
    mipc_nw_lte_signal_strength_v1_t_timing_advance,
    mipc_nw_lte_signal_strength_v1_t_cqi_table_index,
    mipc_nw_lte_signal_strength_v2_t_signal_strength,
    mipc_nw_lte_signal_strength_v2_t_rsrp,
    mipc_nw_lte_signal_strength_v2_t_rsrq,
    mipc_nw_lte_signal_strength_v2_t_rssnr,
    mipc_nw_lte_signal_strength_v2_t_cqi,
    mipc_nw_lte_signal_strength_v2_t_timing_advance,
    mipc_nw_lte_signal_strength_v2_t_cqi_table_index,
    mipc_nw_lte_signal_strength_v2_t_padding,
    mipc_nw_nr_signal_strength_t_signal_strength,
    mipc_nw_nr_signal_strength_t_ss_rsrp,
    mipc_nw_nr_signal_strength_t_ss_rsrq,
    mipc_nw_nr_signal_strength_t_ss_sinr,
    mipc_nw_nr_signal_strength_t_csi_rsrp,
    mipc_nw_nr_signal_strength_t_csi_rsrq,
    mipc_nw_nr_signal_strength_t_csi_sinr,
    mipc_nw_nr_signal_strength_v1_t_signal_strength,
    mipc_nw_nr_signal_strength_v1_t_ss_rsrp,
    mipc_nw_nr_signal_strength_v1_t_ss_rsrq,
    mipc_nw_nr_signal_strength_v1_t_ss_sinr,
    mipc_nw_nr_signal_strength_v1_t_csi_rsrp,
    mipc_nw_nr_signal_strength_v1_t_csi_rsrq,
    mipc_nw_nr_signal_strength_v1_t_csi_sinr,
    mipc_nw_nr_signal_strength_v1_t_csi_cqi_table_index,
    mipc_nw_nr_signal_strength_v1_t_csi_cqi_report_num,
    mipc_nw_nr_signal_strength_v1_t_csi_cqi_report_list,
    mipc_nw_nr_signal_strength_v3_t_signal_strength,
    mipc_nw_nr_signal_strength_v3_t_ss_rsrp,
    mipc_nw_nr_signal_strength_v3_t_ss_rsrq,
    mipc_nw_nr_signal_strength_v3_t_ss_sinr,
    mipc_nw_nr_signal_strength_v3_t_csi_rsrp,
    mipc_nw_nr_signal_strength_v3_t_csi_rsrq,
    mipc_nw_nr_signal_strength_v3_t_csi_sinr,
    mipc_nw_nr_signal_strength_v3_t_csi_cqi_table_index,
    mipc_nw_nr_signal_strength_v3_t_csi_cqi_report_num,
    mipc_nw_nr_signal_strength_v3_t_csi_cqi_report_list,
    mipc_nw_nr_signal_strength_v3_t_padding,
    mipc_nw_nr_signal_strength_v3_t_timing_advance,
    mipc_nw_cdma_signal_strength_t_dbm,
    mipc_nw_cdma_signal_strength_t_ecio,
    mipc_nw_cdma_signal_strength_t_snr,
    mipc_nw_cscon_status_t_mode,
    mipc_nw_cscon_status_t_state,
    mipc_nw_cscon_status_t_access,
    mipc_nw_cscon_status_t_core_network,
    mipc_nw_pol_info_t_start_index,
    mipc_nw_pol_info_t_end_index,
    mipc_nw_pol_info_t_format_first,
    mipc_nw_pol_info_t_format_last,
    mipc_nw_pol_info_v1_t_start_index,
    mipc_nw_pol_info_v1_t_end_index,
    mipc_nw_pol_info_v1_t_format_first,
    mipc_nw_pol_info_v1_t_format_last,
    mipc_nw_pol_info_v1_t_padding,
    mipc_nw_ps_cs_reg_roaming_info_t_m_voice_reg_state,
    mipc_nw_ps_cs_reg_roaming_info_t_m_data_reg_state,
    mipc_nw_ps_cs_reg_roaming_info_t_m_voice_roaming_type,
    mipc_nw_ps_cs_reg_roaming_info_t_m_data_roaming_type,
    mipc_nw_ps_cs_reg_roaming_info_t_m_ril_voice_reg_state,
    mipc_nw_ps_cs_reg_roaming_info_t_m_ril_data_reg_state,
    mipc_nw_cellmeasurement_info_t_rat,
    mipc_nw_cellmeasurement_info_t_arfcn,
    mipc_nw_cellmeasurement_info_t_pci,
    mipc_nw_cellmeasurement_info_t_rsrp,
    mipc_nw_cellmeasurement_info_t_rsrq,
    mipc_nw_cellmeasurement_info_t_snr,
    mipc_nw_cellmeasurement_info_t_cid,
    mipc_nw_cell_band_bandwidth_t_cell_band,
    mipc_nw_cell_band_bandwidth_t_cell_bandwidth,
    mipc_nw_cell_band_bandwidth_v1_t_cell_band,
    mipc_nw_cell_band_bandwidth_v1_t_padding,
    mipc_nw_cell_band_bandwidth_v1_t_cell_bandwidth,
    mipc_nw_lte_nr_ca_info_t_cell_index,
    mipc_nw_lte_nr_ca_info_t_cell_state,
    mipc_nw_lte_nr_ca_info_t_cc_cw0_cqi,
    mipc_nw_lte_nr_ca_info_t_cc_cw1_cqi,
    mipc_nw_lte_nr_ca_info_t_cell_bandwidth,
    mipc_nw_lte_nr_ca_info_t_cell_band,
    mipc_nw_lte_nr_ca_info_t_cc_pci,
    mipc_nw_lte_nr_ca_info_t_cc_arfcn,
    mipc_nw_lte_nr_ca_info_t_cell_bandwidth_str,
    mipc_nw_umts_cell_frequency_info_t_ul_arfcn,
    mipc_nw_umts_cell_frequency_info_t_dl_arfcn,
    mipc_nw_umts_cell_frequency_info_t_band,
    mipc_cell_plmn_t_plmn_id,
    mipc_cell_plmn_t_plmn_name,
    mipc_nw_raw_signal_info_t_sig1,
    mipc_nw_raw_signal_info_t_sig2,
    mipc_nw_raw_signal_info_t_rssi_in_qdbm,
    mipc_nw_raw_signal_info_t_rscp_in_qdbm,
    mipc_nw_raw_signal_info_t_ecn0_in_qdbm,
    mipc_nw_raw_signal_info_t_rsrq_in_qdbm,
    mipc_nw_raw_signal_info_t_rsrp_in_qdbm,
    mipc_nw_raw_signal_info_t_eact,
    mipc_nw_raw_signal_info_t_sig3,
    mipc_nw_raw_signal_info_t_serv_band,
    mipc_nw_raw_signal_info_t_second_rsrq_in_qdbm,
    mipc_nw_raw_signal_info_t_second_rsrp_in_qdbm,
    mipc_nw_raw_signal_info_t_second_sig3,
    mipc_nw_raw_signal_info_t_signal_type,
    mipc_nw_raw_signal_info_v1_t_sig1,
    mipc_nw_raw_signal_info_v1_t_sig2,
    mipc_nw_raw_signal_info_v1_t_rssi_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_rscp_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_ecn0_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_rsrq_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_rsrp_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_eact,
    mipc_nw_raw_signal_info_v1_t_sig3,
    mipc_nw_raw_signal_info_v1_t_serv_band,
    mipc_nw_raw_signal_info_v1_t_second_rsrq_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_second_rsrp_in_qdbm,
    mipc_nw_raw_signal_info_v1_t_second_sig3,
    mipc_nw_raw_signal_info_v1_t_signal_type,
    mipc_nw_raw_signal_info_v1_t_padding,
    mipc_physical_channel_info_t_rat,
    mipc_physical_channel_info_t_status,
    mipc_physical_channel_info_t_cell_bandwidth_downlink,
    mipc_physical_channel_info_t_channel_number,
    mipc_physical_channel_info_t_num_cids,
    mipc_physical_channel_info_t_physical_cell_id,
    mipc_physical_channel_info_v1_t_rat,
    mipc_physical_channel_info_v1_t_status,
    mipc_physical_channel_info_v1_t_cell_bandwidth_downlink,
    mipc_physical_channel_info_v1_t_cell_bandwidth_uplink,
    mipc_physical_channel_info_v1_t_downlink_channel_number,
    mipc_physical_channel_info_v1_t_uplink_channel_number,
    mipc_physical_channel_info_v1_t_num_cids,
    mipc_physical_channel_info_v1_t_physical_cell_id,
    mipc_physical_channel_info_v1_t_band,
    mipc_physical_channel_info_v1_t_frequency_range,
    mipc_physical_channel_info_v2_t_rat,
    mipc_physical_channel_info_v2_t_status,
    mipc_physical_channel_info_v2_t_padding,
    mipc_physical_channel_info_v2_t_cell_bandwidth_downlink,
    mipc_physical_channel_info_v2_t_cell_bandwidth_uplink,
    mipc_physical_channel_info_v2_t_downlink_channel_number,
    mipc_physical_channel_info_v2_t_uplink_channel_number,
    mipc_physical_channel_info_v2_t_num_cids,
    mipc_physical_channel_info_v2_t_physical_cell_id,
    mipc_physical_channel_info_v2_t_band,
    mipc_physical_channel_info_v2_t_frequency_range,
    mipc_nw_name_pair_t_short_name,
    mipc_nw_name_pair_t_long_name,
    mipc_nw_band_power_pair_t_band,
    mipc_nw_band_power_pair_t_power,
    mipc_nw_suggested_t_state,
    mipc_nw_suggested_t_network_long_name,
    mipc_nw_suggested_t_network_short_name,
    mipc_nw_suggested_t_plmn_id,
    mipc_nw_suggested_t_lac,
    mipc_nw_suggested_t_act,
    mipc_nw_suggested_v1_t_state,
    mipc_nw_suggested_v1_t_network_long_name,
    mipc_nw_suggested_v1_t_network_short_name,
    mipc_nw_suggested_v1_t_plmn_id,
    mipc_nw_suggested_v1_t_lac,
    mipc_nw_suggested_v1_t_padding,
    mipc_nw_suggested_v1_t_act,
    mipc_nw_arfcn_t_arfcn,
    mipc_nw_femtocell_info_t_plmn_id,
    mipc_nw_femtocell_info_t_oper_long_name,
    mipc_nw_femtocell_info_t_oper_short_name,
    mipc_nw_femtocell_info_t_act,
    mipc_nw_femtocell_info_t_num_csg,
    mipc_nw_femtocell_info_t_csg_id,
    mipc_nw_femtocell_info_t_csg_type,
    mipc_nw_femtocell_info_t_hnb_name,
    mipc_nw_femtocell_info_t_sig,
    mipc_nw_femtocell_info_v1_t_plmn_id,
    mipc_nw_femtocell_info_v1_t_oper_long_name,
    mipc_nw_femtocell_info_v1_t_oper_short_name,
    mipc_nw_femtocell_info_v1_t_act,
    mipc_nw_femtocell_info_v1_t_num_csg,
    mipc_nw_femtocell_info_v1_t_padding1,
    mipc_nw_femtocell_info_v1_t_csg_id,
    mipc_nw_femtocell_info_v1_t_csg_type,
    mipc_nw_femtocell_info_v1_t_hnb_name,
    mipc_nw_femtocell_info_v1_t_sig,
    mipc_nw_femtocell_info_v1_t_padding2,
    mipc_nw_pseudocell_info_t_type,
    mipc_nw_pseudocell_info_t_plmn,
    mipc_nw_pseudocell_info_t_long_name,
    mipc_nw_pseudocell_info_t_short_name,
    mipc_nw_pseudocell_info_t_lac,
    mipc_nw_pseudocell_info_t_cell_id,
    mipc_nw_pseudocell_info_t_arfcn,
    mipc_nw_pseudocell_info_t_bsic,
    mipc_nw_pseudocell_info_t_si3_raw_data,
    mipc_nw_barring_info_t_service_type,
    mipc_nw_barring_info_t_barring_type,
    mipc_nw_barring_info_t_factor,
    mipc_nw_barring_info_t_time_seconds,
    mipc_nw_barring_info_t_is_barred,
    mipc_nw_barring_info_v1_t_service_type,
    mipc_nw_barring_info_v1_t_barring_type,
    mipc_nw_barring_info_v1_t_factor,
    mipc_nw_barring_info_v1_t_time_seconds,
    mipc_nw_barring_info_v1_t_is_barred,
    mipc_nw_barring_info_v1_t_padding,
    mipc_nw_threshold_array_t_num_of_threshold,
    mipc_nw_threshold_array_t_threshold_dbm,
    mipc_nw_threshold_array_v1_t_num_of_threshold,
    mipc_nw_threshold_array_v1_t_padding,
    mipc_nw_threshold_array_v1_t_threshold_dbm,
    mipc_nw_extend_provider_t_index,
    mipc_nw_extend_provider_t_stat,
    mipc_nw_extend_provider_t_oper_long_name,
    mipc_nw_extend_provider_t_oper_short_name,
    mipc_nw_extend_provider_t_oper_numeric_name,
    mipc_nw_extend_provider_t_reserved,
    mipc_nw_extend_provider_t_lac,
    mipc_nw_extend_provider_t_act,
    mipc_nw_extend_provider_t_csq_rssi,
    mipc_nw_extend_provider_t_register_state,
    mipc_nw_extend_provider_t_timestamp_type,
    mipc_nw_extend_provider_t_timestamp,
    mipc_nw_extend_provider_t_connection_stat,
    mipc_nw_extend_provider_t_cell_id,
    mipc_nw_extend_provider_t_freq,
    mipc_nw_extend_provider_t_bsic_psc_cpid_pci,
    mipc_nw_extend_provider_t_sig2,
    mipc_nw_extend_provider_t_sig3,
    mipc_nw_extend_provider_t_sig4,
    mipc_nw_extend_provider_t_sig5,
    mipc_nw_extend_provider_t_bit_error_rat,
    mipc_nw_extend_provider_t_timing_advance,
    mipc_nw_extend_provider_t_cqi,
    mipc_nw_ecainfo_t_ca_info,
    mipc_nw_ecainfo_t_pcell_bw,
    mipc_nw_ecainfo_t_scell_bw1,
    mipc_nw_ecainfo_t_scell_bw2,
    mipc_nw_ecainfo_t_scell_bw3,
    mipc_nw_ecainfo_t_scell_bw4,
    mipc_1xrtt_cell_info_t_sid,
    mipc_1xrtt_cell_info_t_nid,
    mipc_1xrtt_cell_info_t_bsid,
    mipc_band_combo_info_t_band_combo,
    mipc_nw_ca_band_t_ca_band_class,
    mipc_nw_tuw_info_t_tuw_id,
    mipc_nw_tuw_info_t_tuw_length,
    mipc_nw_tuw_info_v1_t_tuw_id,
    mipc_nw_tuw_info_v1_t_padding,
    mipc_nw_tuw_info_v1_t_tuw_length,
    mipc_nr_ca_band_t_band,
    mipc_lte_bound_info_t_sbp_id,
    mipc_lte_bound_info_t_event_type,
    mipc_lte_bound_info_t_threshold,
    mipc_lte_bound_info_t_signal_quality_type,
    mipc_lte_bound_info_t_upper_bound,
    mipc_lte_bound_info_t_lower_bound,
    mipc_nw_allowed_mcc_list_t_allowed_mcc_number,
    mipc_nw_allowed_mcc_list_t_allowed_mcc,
    mipc_nw_record_info_t_rat,
    mipc_nw_record_info_t_num_band,
    mipc_nw_record_info_t_band,
    mipc_nw_record_info_t_num_channel,
    mipc_nw_record_info_t_channel,
    mipc_nw_plmn_info_t_plmn_id,
    mipc_nw_scan_info_t_rat,
    mipc_nw_scan_info_t_xarfcn,
    mipc_nw_scan_info_t_pcid,
    mipc_nw_scan_info_t_plmn_id,
    mipc_nw_scan_info_t_cell_id,
    mipc_nw_scan_info_t_lac_or_tac,
    mipc_nw_scan_info_t_plmn_status,
    mipc_nw_scan_info_t_registered,
    mipc_nw_scan_info_t_srv_cell_status,
    mipc_nw_scan_info_t_sig1,
    mipc_nw_scan_info_t_sig2,
    mipc_nw_scan_info_t_sig3,
    mipc_nw_scan_info_t_sig4,
    mipc_nw_scan_info_t_sig5,
    mipc_nw_scan_info_v1_t_rat,
    mipc_nw_scan_info_v1_t_xarfcn,
    mipc_nw_scan_info_v1_t_pcid,
    mipc_nw_scan_info_v1_t_plmn_id,
    mipc_nw_scan_info_v1_t_cell_id,
    mipc_nw_scan_info_v1_t_lac_or_tac,
    mipc_nw_scan_info_v1_t_padding,
    mipc_nw_scan_info_v1_t_plmn_status,
    mipc_nw_scan_info_v1_t_registered,
    mipc_nw_scan_info_v1_t_srv_cell_status,
    mipc_nw_scan_info_v1_t_sig1,
    mipc_nw_scan_info_v1_t_sig2,
    mipc_nw_scan_info_v1_t_sig3,
    mipc_nw_scan_info_v1_t_sig4,
    mipc_nw_scan_info_v1_t_sig5,
    mipc_os_id_info_t_os_id,
    mipc_nw_congestion_info_v1_t_mode,
    mipc_nw_congestion_info_v1_t_op,
    mipc_nw_congestion_info_v1_t_serv_type,
    mipc_nw_congestion_info_v1_t_rat,
    mipc_nw_congestion_info_v1_t_det_time,
    mipc_nw_congestion_info_v1_t_duration,
    mipc_nw_congestion_info_v1_t_bar_duration,
    mipc_nw_congestion_info_v1_t_cond_grant_bytes,
    mipc_nw_congestion_info_v1_t_cond_bsr,
    mipc_nw_congestion_info_v1_t_cond_pdcp_discard_rate,
    mipc_nw_congestion_info_v1_t_cond_phr,
    mipc_nw_congestion_info_v1_t_cond_s_rsrp,
    mipc_nw_congestion_info_v1_t_cond_s_sinr,
    mipc_nw_congestion_info_v1_t_cond_n_rsrp,
    mipc_nw_congestion_info_v1_t_cond_n_sinr,
    mipc_nw_congestion_info_v1_t_cond_ul_bler,
    mipc_nw_congestion_info_v1_t_cond_dl_bler,
    mipc_nw_congestion_info_v1_t_cond_ul_tput,
    mipc_nw_congestion_info_v1_t_cond_dl_tput,
    mipc_nw_congestion_info_v1_t_cond_ul_alloc_rate,
    mipc_nw_congestion_info_v1_t_cond_dl_alloc_rate,
    mipc_nw_congestion_info_v1_t_cond_ul_pending_data,
    mipc_nw_handover_rat_info_t_para_number,
    mipc_nw_handover_rat_info_t_rat,
    mipc_nw_handover_rat_info_t_mcc,
    mipc_nw_handover_rat_info_t_mnc,
    mipc_nw_handover_rat_info_t_mnc_digit_num,
    mipc_nw_handover_rat_info_t_padding1,
    mipc_nw_handover_rat_info_t_area_code,
    mipc_nw_handover_rat_info_t_cell_id,
    mipc_nw_handover_rat_info_t_band,
    mipc_nw_handover_rat_info_t_padding2,
    mipc_nw_handover_rat_info_t_arfcn,
    mipc_sim_msisdn_t_msisdn,
    mipc_sim_pin_desc_t_pin_mode,
    mipc_sim_pin_desc_t_pin_format,
    mipc_sim_pin_desc_t_pin_len_min,
    mipc_sim_pin_desc_t_pin_len_max,
    mipc_sim_app_info_t_app_type,
    mipc_sim_app_info_t_app_id_len,
    mipc_sim_app_info_t_sim_app_id,
    mipc_sim_app_info_t_name_len,
    mipc_sim_app_info_t_name,
    mipc_sim_app_info_t_num_of_pins,
    mipc_sim_app_info_t_pin_ref,
    mipc_sim_slots_info_t_card_state,
    mipc_sim_slots_info_t_slots_state,
    mipc_sim_slots_info_t_logical_idx,
    mipc_sim_slots_info_t_reserved,
    mipc_sim_slots_info_t_atr,
    mipc_sim_slots_info_t_eid,
    mipc_sim_slots_info_t_iccid,
    mipc_eid_byte_struct_t_is_valid,
    mipc_eid_byte_struct_t_eid,
    mipc_port_info_t_iccid,
    mipc_port_info_t_reserved1,
    mipc_port_info_t_lsi,
    mipc_port_info_t_port_active,
    mipc_port_info_t_reserved2,
    mipc_app_status_desc_t_app_type,
    mipc_app_status_desc_t_app_state,
    mipc_app_status_desc_t_pin_status,
    mipc_app_status_desc_t_sub_status,
    mipc_app_status_desc_t_pin1_replaced,
    mipc_app_status_desc_t_pin1_state,
    mipc_app_status_desc_t_pin2_state,
    mipc_app_status_desc_t_reserved1,
    mipc_app_status_desc_t_aid,
    mipc_app_status_desc_t_reserved2,
    mipc_app_status_desc_t_app_label,
    mipc_app_status_desc_t_reserved3,
    mipc_file_list_t_path,
    mipc_file_list_t_data,
    mipc_sid_nid_list_t_sid,
    mipc_sid_nid_list_t_reserved,
    mipc_sid_nid_list_t_nid,
    mipc_sim_carrier_struct_t_mcc,
    mipc_sim_carrier_struct_t_mnc,
    mipc_sim_carrier_struct_t_match_cat,
    mipc_sim_carrier_struct_t_match_data,
    mipc_sms_pdu_t_message_index,
    mipc_sms_pdu_t_pdu_len,
    mipc_sms_pdu_t_status,
    mipc_sms_pdu_t_sms_class,
    mipc_sms_pdu_t_reserved,
    mipc_sms_pdu_t_pdu,
    mipc_ss_call_forward_t_call_forward_status,
    mipc_ss_call_forward_t_dial_number,
    mipc_ss_call_forward_t_service_class,
    mipc_ss_call_forward_t_type_of_address,
    mipc_ss_call_forward_t_reserved1,
    mipc_ss_call_forward_t_timer,
    mipc_ss_call_forward_t_reason,
    mipc_ss_call_forward_t_reserved2,
    mipc_ss_call_forward_t_time_slot_begin,
    mipc_ss_call_forward_t_time_slot_end,
    mipc_ss_call_waiting_t_call_waiting_status,
    mipc_ss_call_waiting_t_padding,
    mipc_ss_call_waiting_t_service_class,
    mipc_ss_cb_dialnumber_t_number_status,
    mipc_ss_cb_dialnumber_t_dial_number,
    mipc_sys_mapping_t_ps_id,
    mipc_sys_lte_band_t_lte_band_class,
    mipc_sys_nr_band_t_nr_band_class,
    mipc_sys_thermal_sensor_config_t_enable,
    mipc_sys_thermal_sensor_config_t_sensor_id,
    mipc_sys_thermal_sensor_config_t_alarm_id,
    mipc_sys_thermal_sensor_config_t_threshold,
    mipc_sys_thermal_sensor_config_t_hysteresis,
    mipc_sys_thermal_sensor_config_t_interval,
    mipc_sys_thermal_sensor_config_t_alarm_type,
    mipc_sys_thermal_sensor_config_e_t_enable,
    mipc_sys_thermal_sensor_config_e_t_sensor_id,
    mipc_sys_thermal_sensor_config_e_t_alarm_id,
    mipc_sys_thermal_sensor_config_e_t_threshold,
    mipc_sys_thermal_sensor_config_e_t_hysteresis,
    mipc_sys_thermal_sensor_config_e_t_interval,
    mipc_sys_thermal_sensor_config_e_t_alarm_type,
    mipc_sys_thermal_actuator_state_info_t_actuator_id,
    mipc_sys_thermal_actuator_state_info_t_num_throttling_state,
    mipc_sys_thermal_actuator_state_info_t_current_throttling_state,
    mipc_sys_thermal_actuator_state_info_t_actuator_name,
    mipc_sys_thermal_sensor_info_t_sensor_id,
    mipc_sys_thermal_sensor_info_t_temperature,
    mipc_sys_thermal_sensor_info_e_t_sensor_id,
    mipc_sys_thermal_sensor_info_e_t_temperature,
    mipc_sys_thermal_trip_map_t_val_trip_map,
    mipc_sys_thermal_trip_map_t_threshold_value,
    mipc_sys_thermal_trip_map_t_hysteresis_value,
    mipc_sys_thermal_trip_map_t_sampling_period,
    mipc_sys_thermal_trip_map_t_sensor_alarm_type,
    mipc_sys_thermal_trip_map_t_throttle_level,
    mipc_sys_thermal_trip_change_t_sensor_id,
    mipc_sys_thermal_trip_change_t_before_trip_temp,
    mipc_sys_thermal_trip_change_t_after_trip_temp,
    mipc_sys_thermal_trip_change_t_save_cfg_to_nv,
    mipc_sys_mia_metrics_t_type,
    mipc_sys_mia_metrics_t_latency,
    mipc_sys_mia_metrics_t_ul_tput,
    mipc_sys_mia_metrics_t_dl_tput,
    mipc_call_detail_info_t_number_present,
    mipc_call_detail_info_t_reserved1,
    mipc_call_detail_info_t_number,
    mipc_call_detail_info_t_name_present,
    mipc_call_detail_info_t_reserved2,
    mipc_call_detail_info_t_name,
    mipc_call_detail_info_t_display_name,
    mipc_call_detail_info_t_verstat,
    mipc_call_detail_info_t_privacy,
    mipc_call_video_cap_t_local_video_cap_present,
    mipc_call_video_cap_t_local_video_cap,
    mipc_call_video_cap_t_remote_video_cap_present,
    mipc_call_video_cap_t_remote_video_cap,
    mipc_ecc_info_t_is_fake_ecc,
    mipc_ecc_info_t_reserved1,
    mipc_ecc_info_t_category,
    mipc_ecc_info_t_type,
    mipc_ecc_info_t_number,
    mipc_ecc_info_t_reserved2,
    mipc_ecc_info_v1_t_is_fake_ecc,
    mipc_ecc_info_v1_t_padding,
    mipc_ecc_info_v1_t_category,
    mipc_ecc_info_v1_t_type,
    mipc_ecc_info_v1_t_number,
    mipc_ecc_info_v1_t_sub_service,
    mipc_nw_srxlev_info_t_srxlev_in_qdb,
    mipc_nw_srxlev_info_t_squal_in_qdb,
    mipc_phb_name_str_t_name_str,
    mipc_phb_name_str_t_encode_method,
    mipc_phb_email_str_t_name_str,
    mipc_phb_email_str_t_encode_method,
    mipc_phb_anr_entry_t_type,
    mipc_phb_anr_entry_t_index,
    mipc_phb_anr_entry_t_ton,
    mipc_phb_anr_entry_t_number,
    mipc_phb_entry_t_index,
    mipc_phb_entry_t_ton,
    mipc_phb_entry_t_number,
    mipc_phb_entry_t_alphaid,
    mipc_phb_entry_t_adnumber,
    mipc_phb_entry_t_adtype,
    mipc_phb_entry_t_email,
    mipc_phb_entry_t_encode_method,
    mipc_embms_area_id_info_t_num_area_ids,
    mipc_embms_area_id_info_t_reserved,
    mipc_embms_area_id_info_t_area_id,
    mipc_embms_session_info_t_index,
    mipc_embms_session_info_t_reserved1,
    mipc_embms_session_info_t_tmgi,
    mipc_embms_session_info_t_reserved2,
    mipc_embms_session_info_t_session_id,
    mipc_embms_session_info_t_status,
    mipc_embms_nb_req_info_t_num_nf,
    mipc_embms_nb_req_info_t_index,
    mipc_embms_nb_req_info_t_padding,
    mipc_embms_nb_req_info_t_nf,
    mipc_embms_nb_req_info_t_num_bands_nf,
    mipc_embms_nb_req_info_t_reserved1,
    mipc_embms_nb_req_info_t_band_nf,
    mipc_embms_nb_req_info_t_num_sais_nf,
    mipc_embms_nb_req_info_t_reserved2,
    mipc_embms_nb_req_info_t_sai_nf,
    mipc_embms_sai_cf_info_t_num_intra_freq,
    mipc_embms_sai_cf_info_t_padding,
    mipc_embms_sai_cf_info_t_intra_freq,
    mipc_embms_sai_cf_info_t_num_sais,
    mipc_embms_sai_cf_info_t_reserved,
    mipc_embms_sai_cf_info_t_sais,
    mipc_embms_sai_nf_info_t_index,
    mipc_embms_sai_nf_info_t_padding,
    mipc_embms_sai_nf_info_t_nf,
    mipc_embms_sai_nf_info_t_num_bands_nf,
    mipc_embms_sai_nf_info_t_reserved1,
    mipc_embms_sai_nf_info_t_band_nf,
    mipc_embms_sai_nf_info_t_num_sais_nf,
    mipc_embms_sai_nf_info_t_reserved2,
    mipc_embms_sai_nf_info_t_sai_nf,
    mipc_internal_set_filter_req_t_nccmni_net_if,
    mipc_internal_set_filter_req_t_reserve1,
    mipc_internal_set_filter_req_t_nccmni_seq,
    mipc_internal_set_filter_req_t_valid_field,
    mipc_internal_set_filter_req_t_ip_type,
    mipc_internal_set_filter_req_t_ctrl_protocol,
    mipc_internal_set_filter_req_t_src_port,
    mipc_internal_set_filter_req_t_dst_port,
    mipc_internal_set_filter_req_t_tcp_flags,
    mipc_internal_set_filter_req_t_spi,
    mipc_internal_set_filter_req_t_src_v4_addr,
    mipc_internal_set_filter_req_t_dst_v4_addr,
    mipc_internal_set_filter_req_t_src_v6_addr,
    mipc_internal_set_filter_req_t_dst_v6_addr,
    mipc_internal_set_filter_req_t_icmpv4_type,
    mipc_internal_set_filter_req_t_icmpv6_type,
    mipc_internal_set_filter_req_t_reserve,
    mipc_internal_set_filter_req_t_features,
    mipc_internal_set_filter_cnf_t_nccmni_net_if,
    mipc_internal_set_filter_cnf_t_reserve1,
    mipc_internal_set_filter_cnf_t_nccmni_seq,
    mipc_internal_set_filter_cnf_t_filter_id,
    mipc_internal_reset_filter_req_t_nccmni_net_if,
    mipc_internal_reset_filter_req_t_reserve1,
    mipc_internal_reset_filter_req_t_nccmni_seq,
    mipc_internal_reset_filter_req_t_is_deregister_all_filter,
    mipc_internal_reset_filter_req_t_filter_id,
    mipc_internal_reset_filter_cnf_t_nccmni_net_if,
    mipc_internal_reset_filter_cnf_t_reserve1,
    mipc_internal_reset_filter_cnf_t_nccmni_seq,
    mipc_internal_reset_filter_cnf_t_is_success,
    mipc_nw_tx_t_tx,
    mipc_plmn_cag_info_t_plmn_id,
    mipc_plmn_cag_info_t_reserved,
    mipc_plmn_cag_info_t_act,
    mipc_plmn_cag_info_t_only_via_cag,
    mipc_plmn_cag_info_t_cag_id_info_count,
    mipc_plmn_cag_info_t_padding1,
    mipc_plmn_cag_info_t_cag_id,
    mipc_plmn_cag_info_t_hrnn,
    mipc_plmn_cag_info_t_cag_status,
    mipc_plmn_cag_info_t_padding2,
    mipc_nw_congestion_info_t_op,
    mipc_nw_congestion_info_t_serv_type,
    mipc_nw_congestion_info_t_rat,
    mipc_nw_congestion_info_t_det_time,
    mipc_nw_congestion_info_t_duration,
    mipc_nw_congestion_info_t_cond_grant_bytes,
    mipc_nw_congestion_info_t_cond_bsr,
    mipc_nw_congestion_info_t_cond_pdcp_discard_rate,
    mipc_nw_congestion_info_t_cond_phr,
    mipc_nw_congestion_info_t_cond_s_rsrp,
    mipc_nw_congestion_info_t_cond_s_sinr,
    mipc_nw_congestion_info_t_cond_n_rsrp,
    mipc_nw_congestion_info_t_cond_n_sinr,
    mipc_mbms_session_status_t_is_activate,
    mipc_mbms_session_status_t_plmn_id,
    mipc_mbms_session_status_t_service_id,
    mipc_mbms_freq_info_t_freq,
    mipc_mbms_tmgi_info_t_plmn_id,
    mipc_mbms_tmgi_info_t_service_id,
    mipc_mbs_nrarfcn_info_t_nrarfcn,
    mipc_mbs_fsai_info_t_mbs_fsai,
    mipc_mbms_usd_fsai_info_t_num_of_nrarfcn,
    mipc_mbms_usd_fsai_info_t_num_of_fsai,
    mipc_mbms_usd_fsai_info_t_nrarfcn,
    mipc_mbms_tac_info_t_plmn_id,
    mipc_mbms_tac_info_t_ta_code,
    mipc_mbms_ip_address_info_t_src_ip_address,
    mipc_mbms_ip_address_info_t_dest_ip_address,
    mipc_mbms_cell_id_info_t_plmn_id,
    mipc_mbms_cell_id_info_t_cell_id,
    mipc_data_tsn_info_t_port_mac_present,
    mipc_data_tsn_info_t_port_mac,
    mipc_data_tsn_info_t_res_time_present,
    mipc_data_tsn_info_t_res_time,
    mipc_data_tsn_info_t_pmic_present,
    mipc_data_tsn_info_t_padding,
    mipc_data_tsn_info_t_pmic_len,
    mipc_data_tsn_info_t_pmic,
    mipc_data_tsn_time_t_day,
    mipc_data_tsn_time_t_second,
    mipc_data_tsn_time_t_milli_second,
    mipc_data_tsn_time_t_nano_second,
    mipc_data_tsn_time_t_uncertainly,
    mipc_data_tsn_time_t_timeinfotype,
    mipc_data_tsn_time_t_referencesfn,
    mipc_ftai_info_t_plmn_id,
    mipc_ftai_info_t_padding,
    mipc_ftai_info_t_tac,
    mipc_sys_idc_gpio_cfg_t_gpio_0,
    mipc_sys_idc_gpio_cfg_t_gpio_1,
    mipc_sys_idc_gpio_cfg_t_gpio_2,
    mipc_track_item_t_track_index,
    mipc_track_item_t_mipc_msg_id,
    mipc_track_item_t_pending_time,
    mipc_track_item_t_mipc_txid,
    mipc_track_item_t_mipc_id,
    mipc_wfp_filter_struct_t_filter_config,
    mipc_wfp_filter_struct_t_operation_config,
    mipc_wfp_filter_struct_t_priority,
    mipc_wfp_filter_struct_t_ip_ver,
    mipc_wfp_filter_struct_t_protocol,
    mipc_wfp_filter_struct_t_icmp_type,
    mipc_wfp_filter_struct_t_icmp_code,
    mipc_wfp_filter_struct_t_reserved,
    mipc_wfp_filter_struct_t_ip_src,
    mipc_wfp_filter_struct_t_ip_src_mask,
    mipc_wfp_filter_struct_t_reserved2,
    mipc_wfp_filter_struct_t_ip_dest,
    mipc_wfp_filter_struct_t_ip_dest_mask,
    mipc_wfp_filter_struct_t_reserved3,
    mipc_wfp_filter_struct_t_src_port,
    mipc_wfp_filter_struct_t_src_port_mask,
    mipc_wfp_filter_struct_t_dst_port,
    mipc_wfp_filter_struct_t_dst_port_mask,
    mipc_wfp_filter_struct_t_tcp_flags,
    mipc_wfp_filter_struct_t_tcp_flags_mask,
    mipc_wfp_filter_struct_t_tcp_flags_operation,
    mipc_wfp_filter_struct_t_reserved4,
    mipc_wfp_filter_struct_t_icmp_src_ip,
    mipc_wfp_filter_struct_t_icmp_src_port,
    mipc_wfp_filter_struct_t_icmp_src_mask,
    mipc_wfp_filter_struct_t_esp_spi,
    mipc_wfp_filter_struct_t_esp_spi_mask,
    mipc_stk_menu_select_t_item_id,
    mipc_stk_menu_select_t_help_req,
    mipc_stk_address_t_ton_npi,
    mipc_stk_address_t_valid_dialling_number_len,
    mipc_stk_address_t_dialling_number,
    mipc_stk_ussdstring_t_dcs,
    mipc_stk_ussdstring_t_valid_ussd_data_len,
    mipc_stk_ussdstring_t_ussd_data,
    mipc_stk_call_control_param_t_call_control_param_type,
    mipc_stk_event_dl_mt_call_t_call_id,
    mipc_stk_event_dl_call_con_t_ismo,
    mipc_stk_event_dl_call_con_t_call_id,
    mipc_stk_event_dl_call_discon_t_transaction_id,
    mipc_stk_event_dl_call_discon_t_is_near_end,
    mipc_stk_ims_registration_status_t_valid_impu_list_len,
    mipc_stk_ims_registration_status_t_impu_list,
    mipc_stk_ims_registration_status_t_valid_ims_status_code_len,
    mipc_stk_ims_registration_status_t_ims_status_code,
    mipc_stk_sms_pp_data_dl_t_valid_sms_tpdu_len,
    mipc_stk_sms_pp_data_dl_t_sms_tpdu,
    mipc_stk_call_control_rsp_t_cc_result,
    mipc_stk_call_control_rsp_t_valid_capability_params1_len,
    mipc_stk_call_control_rsp_t_capability_params1,
    mipc_stk_call_control_rsp_t_valid_sub_address_len,
    mipc_stk_call_control_rsp_t_sub_address,
    mipc_stk_call_control_rsp_t_valid_alpha_id_len,
    mipc_stk_call_control_rsp_t_alpha_id,
    mipc_stk_call_control_rsp_t_repeat_indicator,
    mipc_stk_call_control_rsp_t_valid_capability_params2_len,
    mipc_stk_call_control_rsp_t_capability_params2,
    mipc_stk_call_control_sms_rsp_t_cc_result,
    mipc_stk_call_control_sms_rsp_t_valid_alpha_id_len,
    mipc_stk_call_control_sms_rsp_t_alpha_id,
    mipc_srvcc_call_ctxt_struct_t_call_id,
    mipc_srvcc_call_ctxt_struct_t_call_mode,
    mipc_srvcc_call_ctxt_struct_t_call_direction,
    mipc_srvcc_call_ctxt_struct_t_call_state,
    mipc_srvcc_call_ctxt_struct_t_call_ecc_category,
    mipc_srvcc_call_ctxt_struct_t_num_of_conf_parts,
    mipc_srvcc_call_ctxt_struct_t_call_number,
    mipc_ntn_ephemeris_state_t_position_x,
    mipc_ntn_ephemeris_state_t_position_y,
    mipc_ntn_ephemeris_state_t_position_z,
    mipc_ntn_ephemeris_state_t_velocity_vx,
    mipc_ntn_ephemeris_state_t_velocity_vy,
    mipc_ntn_ephemeris_state_t_velocity_vz,
    mipc_pcie_link_status_t_lane_num,
    mipc_pcie_link_status_t_rate_level,
    mipc_pcie_counter_register_t_l0,
    mipc_pcie_counter_register_t_l0s,
    mipc_pcie_counter_register_t_l1,
    mipc_pcie_counter_register_t_l11,
    mipc_pcie_counter_register_t_l12,
    mipc_pcie_counter_register_t_l2,
    mipc_pcie_counter_register_t_rcvr,
    mipc_pcie_counter_register_t_others,
    mipc_nw_lte_meas_cell_t_earfcn,
    mipc_nw_lte_meas_cell_t_pci,
    mipc_nw_lte_meas_cell_t_rsrp,
    mipc_nw_nr_meas_cell_t_narfcn,
    mipc_nw_nr_meas_cell_t_pci,
    mipc_nw_nr_meas_cell_t_rsrp,
    mipc_sys_modem_t_modem_id,
    mipc_sys_modem_t_executor_number,
    mipc_sys_modem_t_sim_number,
    mipc_sys_modem_t_concurrency,
    mipc_sys_modem_t_padding,
    mipc_sys_adpclk_freq_info_t_center_frequency,
    mipc_sys_adpclk_freq_info_t_frequency_spread,
    mipc_sys_adpclk_freq_info_t_noise_power,
    mipc_sys_adpclk_freq_info_t_relative_signal_strength,
    mipc_sys_adpclk_freq_info_t_connect_status,
    mipc_data_5gqos_info_v1_t_cid,
    mipc_data_5gqos_info_v1_t_vqi,
    mipc_data_5gqos_info_v1_t_averaging_window,
    mipc_data_5gqos_info_v1_t_dl_gfbr,
    mipc_data_5gqos_info_v1_t_ul_gfbr,
    mipc_data_5gqos_info_v1_t_dl_mfbr,
    mipc_data_5gqos_info_v1_t_ul_mfbr,
    mipc_data_5gqos_info_v1_t_dl_sambr,
    mipc_data_5gqos_info_v1_t_ul_sambr,
    mipc_nw_nr_cell_v2_t_state,
    mipc_nw_nr_cell_v2_t_provider_id,
    mipc_nw_nr_cell_v2_t_cid,
    mipc_nw_nr_cell_v2_t_physical_cell_id,
    mipc_nw_nr_cell_v2_t_nr_arfcn,
    mipc_nw_nr_cell_v2_t_tac,
    mipc_nw_nr_cell_v2_t_rsrp,
    mipc_nw_nr_cell_v2_t_rsrq,
    mipc_nw_nr_cell_v2_t_sinr,
    mipc_nw_nr_cell_v2_t_ta,
    mipc_nw_nr_cell_v2_t_csirsrp,
    mipc_nw_nr_cell_v2_t_csirsrq,
    mipc_nw_nr_cell_v2_t_csisinr,
    mipc_nw_nr_cell_v2_t_dl_freq_band,
    mipc_nw_nr_cell_v2_t_registered,
    mipc_nw_nr_cell_v2_t_long_name,
    mipc_nw_nr_cell_v2_t_short_name,
    mipc_nw_nr_cell_v2_t_csi_cqi_table_index,
    mipc_nw_nr_cell_v2_t_csi_cqi_report_num,
    mipc_nw_nr_cell_v2_t_csi_cqi_report_list,
    mipc_nw_nr_cell_v2_t_padding,
    mipc_nw_reg_change_info_v1_t_stat,
    mipc_nw_reg_change_info_v1_t_padding1,
    mipc_nw_reg_change_info_v1_t_lac_tac,
    mipc_nw_reg_change_info_v1_t_cell_id,
    mipc_nw_reg_change_info_v1_t_eact,
    mipc_nw_reg_change_info_v1_t_rac,
    mipc_nw_reg_change_info_v1_t_nw_existence,
    mipc_nw_reg_change_info_v1_t_roam_indicator,
    mipc_nw_reg_change_info_v1_t_cause_type,
    mipc_nw_reg_change_info_v1_t_reject_cause,
    mipc_nw_reg_change_info_v1_t_dcnr_restricted,
    mipc_nw_reg_change_info_v1_t_endc_sib_status,
    mipc_nw_reg_change_info_v1_t_endc_available,
    mipc_nw_reg_change_info_v1_t_padding2,
    mipc_nw_ps_reg_info_v1_t_stat,
    mipc_nw_ps_reg_info_v1_t_padding1,
    mipc_nw_ps_reg_info_v1_t_rat,
    mipc_nw_ps_reg_info_v1_t_reason_for_denial,
    mipc_nw_ps_reg_info_v1_t_max_data_calls,
    mipc_nw_ps_reg_info_v1_t_is_vops_supported,
    mipc_nw_ps_reg_info_v1_t_is_emc_bearer_supported,
    mipc_nw_ps_reg_info_v1_t_is_endc_available,
    mipc_nw_ps_reg_info_v1_t_is_dcnr_restricted,
    mipc_nw_ps_reg_info_v1_t_is_nr_available,
    mipc_nw_ps_reg_info_v1_t_roaming_ind,
    mipc_nw_ps_reg_info_v1_t_is_in_prl,
    mipc_nw_ps_reg_info_v1_t_padding2,
    mipc_nw_ps_reg_info_v1_t_def_roaming_ind,
    mipc_nw_ps_reg_info_v1_t_cell_id,
    mipc_nw_ps_reg_info_v1_t_cache_endc_connect,
    mipc_nw_ps_reg_info_v1_t_padding3,
    mipc_nw_ps_reg_info_v1_t_lac_tac,
    mipc_nw_cellmeasurement_info_v1_t_rat,
    mipc_nw_cellmeasurement_info_v1_t_padding,
    mipc_nw_cellmeasurement_info_v1_t_arfcn,
    mipc_nw_cellmeasurement_info_v1_t_pci,
    mipc_nw_cellmeasurement_info_v1_t_rsrp,
    mipc_nw_cellmeasurement_info_v1_t_rsrq,
    mipc_nw_cellmeasurement_info_v1_t_snr,
    mipc_nw_cellmeasurement_info_v1_t_cid,
    mipc_nw_pseudocell_info_v1_t_type,
    mipc_nw_pseudocell_info_v1_t_plmn,
    mipc_nw_pseudocell_info_v1_t_long_name,
    mipc_nw_pseudocell_info_v1_t_short_name,
    mipc_nw_pseudocell_info_v1_t_lac,
    mipc_nw_pseudocell_info_v1_t_padding1,
    mipc_nw_pseudocell_info_v1_t_cell_id,
    mipc_nw_pseudocell_info_v1_t_arfcn,
    mipc_nw_pseudocell_info_v1_t_bsic,
    mipc_nw_pseudocell_info_v1_t_si3_raw_data,
    mipc_nw_pseudocell_info_v1_t_padding2,
    mipc_nw_handover_rat_info_v1_t_cell_id,
    mipc_nw_handover_rat_info_v1_t_para_number,
    mipc_nw_handover_rat_info_v1_t_rat,
    mipc_nw_handover_rat_info_v1_t_mnc_digit_num,
    mipc_nw_handover_rat_info_v1_t_padding1,
    mipc_nw_handover_rat_info_v1_t_mcc,
    mipc_nw_handover_rat_info_v1_t_mnc,
    mipc_nw_handover_rat_info_v1_t_band,
    mipc_nw_handover_rat_info_v1_t_padding2,
    mipc_nw_handover_rat_info_v1_t_area_code,
    mipc_nw_handover_rat_info_v1_t_arfcn,
    mipc_nw_handover_rat_info_v1_t_padding3,
    mipc_ntn_ephemeris_orbital_t_semi_major_axis,
    mipc_ntn_ephemeris_orbital_t_eccentricity,
    mipc_ntn_ephemeris_orbital_t_periapsis,
    mipc_ntn_ephemeris_orbital_t_longitude,
    mipc_ntn_ephemeris_orbital_t_inclination,
    mipc_ntn_ephemeris_orbital_t_anomaly,
    mipc_ntn_ephemeris_orbital_t_padding,
    mipc_ntn_sib31_info_t_ephemeris_state_vector_present,
    mipc_ntn_sib31_info_t_padding1,
    mipc_ntn_sib31_info_t_ephemeris_orbital_present,
    mipc_ntn_sib31_info_t_padding2,
    mipc_ntn_sib31_info_t_nta_common,
    mipc_ntn_sib31_info_t_nta_common_drift,
    mipc_ntn_sib31_info_t_nta_common_drift_variation,
    mipc_ntn_sib31_info_t_satellite_type,
    mipc_ntn_sib31_info_t_sib31_scheduling_cycle,
    mipc_ntn_sib31_info_t_padding3,
}

function unreference_struct(struct_tree, data)
    struct_tree:add_le(mipc_unreference_struct_param, data)
end

function mipc_v4_full_addr_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_v4_full_addr_t_mtu, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_v4_full_addr_t_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_v4_full_addr_t_mask, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_v6_full_addr_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_v6_full_addr_t_mtu, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_v6_full_addr_t_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_v6_full_addr_t_prefix, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_addr_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_addr_t_addr_len, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_addr_t_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_full_addr_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_full_addr_t_addr_len, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_full_addr_t_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_full_addr_t_mtu, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_full_addr_t_mask, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_full_addr_t_prefix, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_apn_ia_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_ia_t_apn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_apn_ia_t_apn_idx, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_ia_t_userid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_ia_t_password, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_apn_ia_t_bearer_bitmask, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_ia_t_pdp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_ia_t_roaming_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_ia_t_auth_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_ia_t_compression, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_apn_profile_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_apn_profile_t_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 7
    struct_tree:add_le(mipc_apn_profile_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_apn_profile_t_reserved, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_profile_t_apn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_apn_profile_t_apn_idx, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_profile_t_userid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_profile_t_password, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_apn_profile_t_bearer_bitmask, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_t_apn_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_t_pdp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_roaming_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_auth_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_compression, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_reserve1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_reserve2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_reserve3, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_t_enabled, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_apn_profile_v2_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_apn_profile_v2_t_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 7
    struct_tree:add_le(mipc_apn_profile_v2_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_apn_profile_v2_t_reserved, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_profile_v2_t_apn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_apn_profile_v2_t_apn_idx, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_profile_v2_t_userid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_apn_profile_v2_t_password, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_apn_profile_v2_t_bearer_bitmask, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_apn_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_pdp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_v2_t_roaming_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_v2_t_auth_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_v2_t_compression, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_apn_profile_v2_t_enabled, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_apn_profile_v2_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_apn_profile_v2_t_max_conns, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_max_conn_t, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_wait_time, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_inact_timer, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_v4_mtu, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_apn_profile_v2_t_v6_mtu, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_md_apn_profile_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_md_apn_profile_t_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 7
    struct_tree:add_le(mipc_md_apn_profile_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_md_apn_profile_t_act_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_md_apn_profile_t_apn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_md_apn_profile_t_apn_idx, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_md_apn_profile_t_userid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_md_apn_profile_t_password, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_md_apn_profile_t_bearer_bitmask, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_md_apn_profile_t_apn_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_md_apn_profile_t_pdp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_md_apn_profile_t_roaming_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_md_apn_profile_t_auth_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_md_apn_profile_t_reserve, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_op12_apn_profile_legacy_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_op12_apn_profile_legacy_t_apn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 10
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_op12_apn_profile_legacy_t_apnb, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_pdp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_apnclass, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_enabled, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_max_conn, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_max_conn_t, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_wait_time, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_act_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_reserve1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_reserve2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_legacy_t_reserve3, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_op12_apn_profile_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_op12_apn_profile_t_apn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 10
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_op12_apn_profile_t_apn_bear, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_op12_apn_profile_t_pdp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_t_act_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_op12_apn_profile_t_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_op12_apn_profile_t_apn_class, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_op12_apn_profile_t_enabled, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_op12_apn_profile_t_max_conn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_op12_apn_profile_t_max_conn_t, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_op12_apn_profile_t_wait_time, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_data_nitz_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_nitz_info_t_year, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_nitz_info_t_month, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_nitz_info_t_day, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_nitz_info_t_hour, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_nitz_info_t_minute, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_nitz_info_t_second, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_data_v4_addr_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_data_v4_addr_t_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_v6_addr_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_data_v6_addr_t_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_pco_ie_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 5
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_data_pco_ie_t_ie, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_data_pco_ie_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 80
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_data_pco_ie_t_content, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_data_ran_result_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_ran_result_t_ran, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_data_ran_result_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_data_ran_result_t_deact_cause, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_ran_result_t_modify_cause, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_tmgi_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_tmgi_struct_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_tmgi_struct_t_service_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbs_session_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_mbs_session_info_t_op, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mbs_session_info_t_sesson_id_type, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    -- sub_struct tmgi_struct
    local sub_struct_tree = struct_tree:add("tmgi")
    sub_struct_len = mipc_tmgi_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_mbs_session_info_t_src_ip_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_mbs_session_info_t_dest_ip_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbs_session_update_ind_struct(struct_tree, struct_data)
    local struct_offset = 0
    -- sub_struct tmgi_struct
    local sub_struct_tree = struct_tree:add("tmgi")
    sub_struct_len = mipc_tmgi_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_mbs_session_update_ind_t_psi, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mbs_session_update_ind_t_ip_addr_present, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_mbs_session_update_ind_t_src_ip_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_mbs_session_update_ind_t_dest_ip_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_mbs_session_update_ind_t_mbs_decision, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mbs_session_update_ind_t_reject_cause, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mbs_session_update_ind_t_mbs_sec_container_raw_present, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 673
    struct_tree:add_le(mipc_mbs_session_update_ind_t_mbs_sec_container_raw, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_mbs_session_update_ind_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_cell_global_id_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_cell_global_id_struct_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_cell_global_id_struct_t_cell_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_tac_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_tac_struct_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_tac_struct_t_ta_code, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_packet_filter_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_packet_filter_t_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_data_packet_filter_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 192
    struct_tree:add_le(mipc_data_packet_filter_t_pattern, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 192
    struct_tree:add_le(mipc_data_packet_filter_t_mask, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_secondary_pdp_context_present_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_cid_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_p_cid_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_bearer_id_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_im_cn_signalling_flag_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_wlan_offload_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_pdu_session_id_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_present_info_t_qfi_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_data_secondary_pdp_context_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_cid, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_p_cid, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_bearer_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_im_cn_signalling_flag, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_wlan_offload, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_pdu_session_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_secondary_pdp_context_info_t_qfi, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_mipi_device_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_mipi_device_t_instance_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_mipi_device_t_trans_port, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_mipi_device_t_mipi_port, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_mipi_device_t_usid, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_mipi_device_t_mid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mipi_device_t_pid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mipi_device_t_hw_mid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mipi_device_t_hw_pid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_data_qos_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_qos_info_t_cid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_qos_info_t_qci, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_qos_info_t_dl_gbr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_qos_info_t_ul_gbr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_qos_info_t_dl_mbr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_qos_info_t_ul_mbr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_qos_info_t_dl_ambr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_qos_info_t_ul_ambr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_data_5gqos_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_5gqos_info_t_cid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_5gqos_info_t_vqi, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_5gqos_info_t_dl_gfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_t_ul_gfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_t_dl_mfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_t_ul_mfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_t_dl_sambr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_t_ul_sambr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_t_averaging_window, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_data_tft_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_tft_info_t_cid, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_packet_filter_identifier, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_evaluation_precedence_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_remote_v4_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_remote_v6_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_protocol_number_next_header, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_tos_traffic_class, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_tos_mask, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_direction, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_nw_packet_filter_identifier, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_local_v4_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_local_v6_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("remote_v4_addr")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v4_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_remote_v4_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("remote_v4_subnet_mask")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v4_subnet_mask ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_remote_v4_subnet_mask, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("remote_v6_addr")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v6_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_remote_v6_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("remote_v6_subnet_mask")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v6_subnet_mask ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_remote_v6_subnet_mask, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_t_local_port_low, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_local_port_high, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_remote_port_low, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_remote_port_high, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_ipsec_spi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tft_info_t_flow_label, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("local_v4_addr")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v4_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_local_v4_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("local_v4_subnet_mask")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v4_subnet_mask ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_local_v4_subnet_mask, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("local_v6_addr")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v6_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_local_v6_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("local_v6_subnet_mask")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v6_subnet_mask ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_local_v6_subnet_mask, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_t_qri, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tft_info_t_dest_mac_addr_present, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_src_mac_addr_present, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local array = struct_tree:add("dest_MAC_addr")
    local array_size = 6
    for i=0, array_size-1 do
        local sub_tree = array:add("dest_MAC_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_dest_mac_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("src_MAC_addr")
    local array_size = 6
    for i=0, array_size-1 do
        local sub_tree = array:add("src_MAC_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_t_src_mac_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_t_c_tag_vid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_s_tag_vid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_c_tag_pcp_dei, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_s_tag_pcp_dei, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_ethertype, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_t_packet_filter_identifier_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_evaluation_precedence_index_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_protocol_number_next_header_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_ipsec_spi_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_tos_traffic_class_and_mask_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_flow_label_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_direction_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_nw_packet_filter_identifier_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_qri_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_c_tag_vid_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_s_tag_vid_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_c_tag_pcp_dei_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_s_tag_pcp_dei_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_t_ethertype_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_data_tft_info_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_tft_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_tft_info_v1_t_cid, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_packet_filter_identifier_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_packet_filter_identifier, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_evaluation_precedence_index_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_evaluation_precedence_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_remote_v4_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("remote_v4_addr")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v4_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_remote_v4_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("remote_v4_subnet_mask")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v4_subnet_mask ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_remote_v4_subnet_mask, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_v1_t_remote_v6_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("remote_v6_addr")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v6_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_remote_v6_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("remote_v6_prefix")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("remote_v6_prefix ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_remote_v6_prefix, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_v1_t_protocol_number_next_header_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_protocol_number_next_header, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_padding1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_local_port_low, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_v1_t_local_port_high, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_v1_t_remote_port_low, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_v1_t_remote_port_high, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_v1_t_ipsec_spi_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_padding2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_ipsec_spi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tft_info_v1_t_tos_traffic_class_and_mask_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_tos_traffic_class, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_tos_mask, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_flow_label_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_flow_label, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tft_info_v1_t_direction_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_direction, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_nw_packet_filter_identifier_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_nw_packet_filter_identifier, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_local_v4_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("local_v4_addr")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v4_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_local_v4_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("local_v4_subnet_mask")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v4_subnet_mask ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_local_v4_subnet_mask, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_v1_t_local_v6_addr_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("local_v6_addr")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v6_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_local_v6_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("local_v6_prefix")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("local_v6_prefix ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_local_v6_prefix, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_v1_t_qri_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_padding3, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_qri, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tft_info_v1_t_dest_mac_addr_present, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local array = struct_tree:add("dest_MAC_addr")
    local array_size = 6
    for i=0, array_size-1 do
        local sub_tree = array:add("dest_MAC_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_dest_mac_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_v1_t_src_mac_addr_present, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local array = struct_tree:add("src_MAC_addr")
    local array_size = 6
    for i=0, array_size-1 do
        local sub_tree = array:add("src_MAC_addr ["..i.."]")
        sub_tree:add_le(mipc_data_tft_info_v1_t_src_mac_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_data_tft_info_v1_t_c_tag_vid_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_padding4, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_c_tag_vid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_v1_t_s_tag_vid_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_padding5, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_s_tag_vid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_tft_info_v1_t_c_tag_pcp_dei_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_c_tag_pcp_dei, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_s_tag_pcp_dei_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_s_tag_pcp_dei, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_ethertype_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_padding6, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_data_tft_info_v1_t_ethertype, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_data_start_keepalive_request_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_start_keepalive_request_t_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_start_keepalive_request_t_sourceport, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_start_keepalive_request_t_destinationport, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_start_keepalive_request_t_maxkeepaliveintervalmillis, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_start_keepalive_request_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 68
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_data_start_keepalive_request_t_sourceaddress, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 68
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_data_start_keepalive_request_t_destinationaddress, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_s_nssai_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_s_nssai_struct_t_sst_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_sst, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_sd_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_sd, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_s_nssai_struct_t_mapped_sst_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_mapped_sst, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_mapped_sd_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_padding2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_s_nssai_struct_t_mapped_sd, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_ursp_route_sel_desc_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_p_val, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_ssc_mode, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_dnn_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_s_nssai_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    -- sub_struct s_nssai_struct
    local sub_struct_tree = struct_tree:add("s_nssai")
    sub_struct_len = mipc_s_nssai_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ursp_route_sel_desc_struct_t_dnn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_pdu_session_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_pref_access_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_ursp_route_sel_desc_struct_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ursp_traffic_desc_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_is_match_all, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_dnn_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ursp_traffic_desc_struct_t_dnn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_os_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_app_id_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 255
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_app_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_reserved3, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_ipv4_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_ipv4_mask, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_ipv6_addr, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_ipv6_prefix_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_reserved4, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_port_num, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_min_port_num, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_max_port_num, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_prot_id_next_hdr, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_dst_fqdn_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 255
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_dst_fqdn, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ursp_traffic_desc_struct_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_ursp_ue_local_conf_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_ssc_mode, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_dnn_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_reserved, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_s_nssai_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    -- sub_struct s_nssai_struct
    local sub_struct_tree = struct_tree:add("s_nssai")
    sub_struct_len = mipc_s_nssai_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    local mipc_string_length = 100
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ursp_ue_local_conf_struct_t_dnn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_pdu_session_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_pref_access_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_ursp_ue_local_conf_struct_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ursp_get_route_supp_profile_ind_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ursp_get_route_supp_profile_ind_struct_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ursp_get_route_supp_profile_ind_struct_t_supp_profile_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    -- sub_struct ursp_traffic_desc_struct
    local sub_struct_tree = struct_tree:add("traffic_desc")
    sub_struct_len = mipc_ursp_traffic_desc_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    -- sub_struct ursp_ue_local_conf_struct
    local sub_struct_tree = struct_tree:add("ue_local_conf")
    sub_struct_len = mipc_ursp_ue_local_conf_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_ursp_get_route_supp_profile_ind_struct_t_is_match_all_disallowed, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ursp_get_route_supp_profile_ind_struct_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ursp_rule_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ursp_rule_struct_t_p_val, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ursp_rule_struct_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    -- sub_struct ursp_traffic_desc_struct
    local sub_struct_tree = struct_tree:add("traffic_desc")
    sub_struct_len = mipc_ursp_traffic_desc_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_ursp_rule_struct_t_num_of_rsd, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ursp_rule_struct_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    -- sub_struct_array ursp_route_sel_desc_struct
    local array_tree = struct_tree:add("route_sel_desc_list")
    for i=0, 8 do
        local sub_struct_tree = array_tree:add("route_sel_desc_list ["..i.."]")
        sub_struct_len = mipc_ursp_route_sel_desc_struct_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
        struct_offset = struct_offset + sub_struct_len
    end
    return struct_offset
end

function mipc_ursp_ue_policy_plmn_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ursp_ue_policy_plmn_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_plmn_specific_s_nssai_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_plmn_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_sst_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_sst, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_sd_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_sd, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_mapped_sst_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_mapped_sst, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_mapped_sd_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_padding2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_specific_s_nssai_struct_t_mapped_sd, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_rejected_s_nssai_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_rejected_s_nssai_struct_t_cause_value, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_rejected_s_nssai_struct_t_sst_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_rejected_s_nssai_struct_t_sst, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_rejected_s_nssai_struct_t_sd_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_rejected_s_nssai_struct_t_sd, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_lte_cc_meas_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 12
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_lte_cc_meas_info_t_lte_cc_type, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_lte_cc_meas_info_t_path_loss, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_lte_cc_meas_info_t_rank_indicator, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_lte_cc_meas_info_t_serv_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_t_serv_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_t_serv_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_t_serv_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_lte_cc_meas_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 12
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_lte_cc_meas_info_v1_t_lte_cc_type, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_cell_index, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_path_loss, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_rank_indicator, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_serv_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_serv_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_serv_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_serv_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_cc_meas_info_v1_t_measbw_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nr_cc_meas_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 12
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nr_cc_meas_info_t_nr_cc_type, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nr_cc_meas_info_t_path_loss, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nr_cc_meas_info_t_rank_indicator, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nr_cc_meas_info_t_brsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_serv_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_serv_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_ssb_best_beam_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_ssb_snr_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_ssb_rsrp_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_trs_snr_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_trs_rsrp_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_serv_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_t_serv_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nr_cc_meas_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 12
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nr_cc_meas_info_v1_t_nr_cc_type, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_cell_index, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_path_loss, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_rank_indicator, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_brsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_serv_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_serv_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_ssb_best_beam_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_ssb_snr_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_ssb_rsrp_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_trs_snr_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_trs_rsrp_avg, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_serv_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_serv_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nr_cc_meas_info_v1_t_bwp_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_wcdma_current_cell_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_wcdma_current_cell_info_t_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_wcdma_current_cell_info_t_pci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_wcdma_current_cell_info_t_uarfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_wcdma_current_cell_info_t_dl_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wcdma_current_cell_info_t_ul_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_current_cell_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_current_cell_info_t_scc_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_scc_ul_configured, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_t_cc_pci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_t_cc_dl_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_t_cc_ul_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_mimo, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_mimo, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_modulation, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_modulation, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_rb, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_rb, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_mcs, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_mcs, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_t_cc_pucch_tx_pwr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_pusch_tx_pwr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_lte_dl_tm, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_t_cc_lte_ul_tm, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_bwp_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_bwp_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_t_cc_dl_bwp_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_t_cc_ul_bwp_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_current_cell_info_t_cc_dl_spectral_efficiency, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_t_cc_ul_spectral_efficiency, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_current_cell_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_current_cell_info_v1_t_scc_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cell_index, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_v1_t_scc_ul_configured, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_padding1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_pci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_v1_t_cc_dl_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_v1_t_cc_ul_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_mimo, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_mimo, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_modulation, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_modulation, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_rb, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_rb, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_mcs, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_mcs, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_pucch_tx_pwr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_pusch_tx_pwr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_lte_dl_tm, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_lte_ul_tm, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_bwp_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_bwp_bandwidth, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_v1_t_cc_dl_bwp_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_current_cell_info_v1_t_cc_ul_bwp_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_spectral_efficiency, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_spectral_efficiency, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_dl_bwp_central_freq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_ul_bwp_central_freq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_lte_target_pwr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_cc_lte_meas_bandwidth, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_current_cell_info_v1_t_central_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_provider_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_provider_t_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_provider_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_provider_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_provider_t_network_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_provider_t_network_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_provider_t_act, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_provider_t_act_supported, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_provider_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_provider_t_rssi, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_provider_t_error_rate, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_provider_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_nitz_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nitz_info_t_year, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_month, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_day, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_hour, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_minute, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_second, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_time_zone_offset_minutes, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nitz_info_t_daylight_saving_offset_minutes, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_anbr_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_anbr_info_t_anbrq_config, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_anbr_info_t_ebi, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_anbr_info_t_is_ul, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_anbr_info_t_beare_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_anbr_info_t_bitrate, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_anbr_info_t_pdu_session_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_anbr_info_t_ext_param, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_irat_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_irat_info_t_irat_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_irat_info_t_is_successful, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_reg_state_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_reg_state_t_ps_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_state_t_cs_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_reg_state_t_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_reg_state_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_reg_state_t_cs_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_reg_state_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_reg_state_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_t_cs_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_t_ci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_t_cs_ci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_t_is_roaming, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_state_t_cs_is_roaming, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_reg_state_t_padding3, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_reg_state_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_reg_state_v1_t_ps_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_state_v1_t_cs_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_reg_state_v1_t_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_reg_state_v1_t_cs_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_reg_state_v1_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_v1_t_cs_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_v1_t_ci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_v1_t_cs_ci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_state_v1_t_is_roaming, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_state_v1_t_cs_is_roaming, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_reg_state_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_reg_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_reg_info_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_reg_info_t_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_reg_info_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_info_t_ci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_location_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_location_info_t_location_area_code, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_location_info_t_tracking_area_code, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_location_info_t_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_gsm_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_gsm_cell_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_gsm_cell_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_gsm_cell_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_base_station_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_rx_level, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_biterrorrate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_cell_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_gsm_cell_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_gsm_cell_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_umts_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_umts_cell_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_umts_cell_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_umts_cell_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_t_uarfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_t_psc, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_t_rscp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_t_ecno, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_umts_cell_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_umts_cell_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_lte_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_cell_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_lte_cell_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_earfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_rssnr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_dl_freq_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_lte_cell_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_v1_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_earfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_rssnr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_dl_freq_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v1_t_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_v1_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_v1_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_lte_cell_v2_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_v2_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_cid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_earfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_rssnr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_dl_freq_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_v2_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_cell_v2_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_lte_cell_v2_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_nr_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_cell_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_nr_cell_t_cid, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_nr_cell_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_nr_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_csirsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_csirsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_csisinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_dl_freq_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_nr_cell_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_cid, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_nr_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_csirsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_csirsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_csisinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_dl_freq_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_csi_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_nr_cell_v1_t_csi_cqi_report_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_v1_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_v1_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_v1_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local array = struct_tree:add("csi_cqi_report_list")
    local array_size = 19
    for i=0, array_size-1 do
        local sub_tree = array:add("csi_cqi_report_list ["..i.."]")
        sub_tree:add_le(mipc_nw_nr_cell_v1_t_csi_cqi_report_list, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    return struct_offset
end

function mipc_nw_cdma_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cdma_cell_t_networkid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_systemid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_basestationid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_longitude, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_latitude, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_dbm_cdma, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_ecio_cdma, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_dbm_evdo, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_ecio_evdo, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_snr_evdo, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cdma_cell_t_registered, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_cdma_cell_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_networkid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_systemid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_basestationid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_longitude, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_latitude, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_dbm_cdma, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_ecio_cdma, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_dbm_evdo, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_ecio_evdo, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_snr_evdo, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_registered, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_cdma_cell_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_tdscdma_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_tdscdma_cell_t_tbd, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_reg_change_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_reg_change_info_t_stat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_lac_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_change_info_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_reg_change_info_t_eact, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_reg_change_info_t_rac, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_nw_existence, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_roam_indicator, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_cause_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_reject_cause, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_reg_change_info_t_dcnr_restricted, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_endc_sib_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_t_endc_available, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_cs_reg_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cs_reg_info_t_stat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_t_rat, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_cs_reg_info_t_css, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_t_roaming_ind, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_t_is_in_prl, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_t_def_roaming_ind, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_cs_reg_info_t_reason_for_denial, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_nw_cs_reg_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_stat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_padding1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_rat, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_css, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_roaming_ind, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_is_in_prl, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_padding2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_def_roaming_ind, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_cs_reg_info_v1_t_reason_for_denial, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_nw_ps_reg_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_ps_reg_info_t_stat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_rat, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_t_reason_for_denial, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_t_max_data_calls, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_t_is_vops_supported, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ps_reg_info_t_is_emc_bearer_supported, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ps_reg_info_t_is_endc_available, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_is_dcnr_restricted, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_is_nr_available, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_roaming_ind, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_is_in_prl, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_def_roaming_ind, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_ps_reg_info_t_cache_endc_connect, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_t_lac_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_channel_lock_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_channel_lock_info_t_opt, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_channel_lock_info_t_act, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("band_info")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("band_info ["..i.."]")
        sub_tree:add_le(mipc_nw_channel_lock_info_t_band_info, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    struct_tree:add_le(mipc_nw_channel_lock_info_t_channel_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("arfcn_list")
    local array_size = 32
    for i=0, array_size-1 do
        local sub_tree = array:add("arfcn_list ["..i.."]")
        sub_tree:add_le(mipc_nw_channel_lock_info_t_arfcn_list, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    struct_tree:add_le(mipc_nw_channel_lock_info_t_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_channel_lock_info_t_lock_mode, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_channel_lock_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_channel_lock_info_v1_t_opt, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_channel_lock_info_v1_t_act, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("band_info")
    local array_size = 32
    for i=0, array_size-1 do
        local sub_tree = array:add("band_info ["..i.."]")
        sub_tree:add_le(mipc_nw_channel_lock_info_v1_t_band_info, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    struct_tree:add_le(mipc_nw_channel_lock_info_v1_t_channel_num, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("arfcn_list")
    local array_size = 32
    for i=0, array_size-1 do
        local sub_tree = array:add("arfcn_list ["..i.."]")
        sub_tree:add_le(mipc_nw_channel_lock_info_v1_t_arfcn_list, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    struct_tree:add_le(mipc_nw_channel_lock_info_v1_t_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_channel_lock_info_v1_t_lock_mode, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_gsm_signal_strength_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_gsm_signal_strength_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_signal_strength_t_bit_error_rate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_gsm_signal_strength_t_timing_advance, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_umts_signal_strength_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_umts_signal_strength_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_signal_strength_t_bit_error_rate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_signal_strength_t_rscp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_signal_strength_t_ecno, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_lte_signal_strength_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_signal_strength_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_t_rssnr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_t_timing_advance, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_lte_signal_strength_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_rssnr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_timing_advance, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v1_t_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_lte_signal_strength_v2_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_rssnr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_timing_advance, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_lte_signal_strength_v2_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_nr_signal_strength_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_ss_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_ss_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_ss_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_csi_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_csi_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_t_csi_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_nr_signal_strength_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_ss_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_ss_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_ss_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_csi_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_csi_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_csi_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_csi_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_nr_signal_strength_v1_t_csi_cqi_report_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("csi_cqi_report_list")
    local array_size = 19
    for i=0, array_size-1 do
        local sub_tree = array:add("csi_cqi_report_list ["..i.."]")
        sub_tree:add_le(mipc_nw_nr_signal_strength_v1_t_csi_cqi_report_list, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    return struct_offset
end

function mipc_nw_nr_signal_strength_v3_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_ss_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_ss_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_ss_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_csi_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_csi_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_csi_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_csi_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_csi_cqi_report_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("csi_cqi_report_list")
    local array_size = 19
    for i=0, array_size-1 do
        local sub_tree = array:add("csi_cqi_report_list ["..i.."]")
        sub_tree:add_le(mipc_nw_nr_signal_strength_v3_t_csi_cqi_report_list, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_nr_signal_strength_v3_t_timing_advance, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_cdma_signal_strength_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cdma_signal_strength_t_dbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_signal_strength_t_ecio, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cdma_signal_strength_t_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_cscon_status_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cscon_status_t_mode, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cscon_status_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cscon_status_t_access, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cscon_status_t_core_network, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_pol_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_pol_info_t_start_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_pol_info_t_end_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_pol_info_t_format_first, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_pol_info_t_format_last, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_pol_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_pol_info_v1_t_start_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_pol_info_v1_t_end_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_pol_info_v1_t_format_first, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_pol_info_v1_t_format_last, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_pol_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_ps_cs_reg_roaming_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_ps_cs_reg_roaming_info_t_m_voice_reg_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_cs_reg_roaming_info_t_m_data_reg_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_cs_reg_roaming_info_t_m_voice_roaming_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_cs_reg_roaming_info_t_m_data_roaming_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_cs_reg_roaming_info_t_m_ril_voice_reg_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_cs_reg_roaming_info_t_m_ril_data_reg_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_cellmeasurement_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_rat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_pci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_t_cid, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    return struct_offset
end

function mipc_nw_cell_band_bandwidth_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cell_band_bandwidth_t_cell_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_cell_band_bandwidth_t_cell_bandwidth, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_cell_band_bandwidth_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cell_band_bandwidth_v1_t_cell_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_cell_band_bandwidth_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_cell_band_bandwidth_v1_t_cell_bandwidth, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_lte_nr_ca_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cell_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cell_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cc_cw0_cqi, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cc_cw1_cqi, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cell_bandwidth, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cell_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cc_pci, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_lte_nr_ca_info_t_cc_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 8
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_lte_nr_ca_info_t_cell_bandwidth_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_umts_cell_frequency_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_umts_cell_frequency_info_t_ul_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_frequency_info_t_dl_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_umts_cell_frequency_info_t_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_cell_plmn_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_cell_plmn_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 32
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_cell_plmn_t_plmn_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_raw_signal_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_raw_signal_info_t_sig1, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_sig2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_rssi_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_rscp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_ecn0_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_eact, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_serv_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_second_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_second_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_second_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_t_signal_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_raw_signal_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_sig1, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_sig2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_rssi_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_rscp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_ecn0_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_eact, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_serv_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_second_rsrq_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_second_rsrp_in_qdbm, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_second_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_signal_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_raw_signal_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_physical_channel_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_physical_channel_info_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_t_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_physical_channel_info_t_cell_bandwidth_downlink, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_t_channel_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_t_num_cids, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_physical_channel_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_physical_channel_info_v1_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_physical_channel_info_v1_t_cell_bandwidth_downlink, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_cell_bandwidth_uplink, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_downlink_channel_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_uplink_channel_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_num_cids, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v1_t_frequency_range, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_physical_channel_info_v2_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_physical_channel_info_v2_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_physical_channel_info_v2_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_physical_channel_info_v2_t_cell_bandwidth_downlink, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_cell_bandwidth_uplink, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_downlink_channel_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_uplink_channel_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_num_cids, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_physical_channel_info_v2_t_frequency_range, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_name_pair_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_name_pair_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_name_pair_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_band_power_pair_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_band_power_pair_t_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_band_power_pair_t_power, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_suggested_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_suggested_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_t_network_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_t_network_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 10
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_t_lac, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_suggested_t_act, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_suggested_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_suggested_v1_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_v1_t_network_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_v1_t_network_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_v1_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 10
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_suggested_v1_t_lac, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_suggested_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_suggested_v1_t_act, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_arfcn_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_arfcn_t_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_femtocell_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_t_oper_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_t_oper_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_femtocell_info_t_act, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_femtocell_info_t_num_csg, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_femtocell_info_t_csg_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_femtocell_info_t_csg_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 50
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_t_hnb_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_t_sig, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_femtocell_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_v1_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_v1_t_oper_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_v1_t_oper_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_femtocell_info_v1_t_act, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_femtocell_info_v1_t_num_csg, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_femtocell_info_v1_t_padding1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_femtocell_info_v1_t_csg_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_femtocell_info_v1_t_csg_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 50
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_v1_t_hnb_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_femtocell_info_v1_t_sig, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_femtocell_info_v1_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_pseudocell_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_pseudocell_info_t_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_t_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_pseudocell_info_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_pseudocell_info_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_pseudocell_info_t_arfcn, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_pseudocell_info_t_bsic, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 50
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_t_si3_raw_data, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_barring_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_barring_info_t_service_type, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_barring_info_t_barring_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_barring_info_t_factor, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_barring_info_t_time_seconds, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_barring_info_t_is_barred, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_barring_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_barring_info_v1_t_service_type, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_barring_info_v1_t_barring_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_barring_info_v1_t_factor, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_barring_info_v1_t_time_seconds, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_barring_info_v1_t_is_barred, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_barring_info_v1_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_nw_threshold_array_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_threshold_array_t_num_of_threshold, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("threshold_dbm")
    local array_size = 10
    for i=0, array_size-1 do
        local sub_tree = array:add("threshold_dbm ["..i.."]")
        sub_tree:add_le(mipc_nw_threshold_array_t_threshold_dbm, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_nw_threshold_array_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_threshold_array_v1_t_num_of_threshold, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_threshold_array_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("threshold_dbm")
    local array_size = 10
    for i=0, array_size-1 do
        local sub_tree = array:add("threshold_dbm ["..i.."]")
        sub_tree:add_le(mipc_nw_threshold_array_v1_t_threshold_dbm, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_nw_extend_provider_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_extend_provider_t_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_stat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_extend_provider_t_oper_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_extend_provider_t_oper_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_extend_provider_t_oper_numeric_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_extend_provider_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 20
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_extend_provider_t_lac, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_extend_provider_t_act, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_csq_rssi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_register_state, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_timestamp_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_timestamp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_connection_stat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 20
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_extend_provider_t_cell_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_extend_provider_t_freq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_bsic_psc_cpid_pci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_sig2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_sig4, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_sig5, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_bit_error_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_timing_advance, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_extend_provider_t_cqi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_ecainfo_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_ecainfo_t_ca_info, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ecainfo_t_pcell_bw, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ecainfo_t_scell_bw1, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ecainfo_t_scell_bw2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ecainfo_t_scell_bw3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ecainfo_t_scell_bw4, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_1xrtt_cell_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_1xrtt_cell_info_t_sid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_1xrtt_cell_info_t_nid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_1xrtt_cell_info_t_bsid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_band_combo_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 16
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_band_combo_info_t_band_combo, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_ca_band_struct(struct_tree, struct_data)
    local struct_offset = 0
    local array = struct_tree:add("ca_band_class")
    local array_size = 8
    for i=0, array_size-1 do
        local sub_tree = array:add("ca_band_class ["..i.."]")
        sub_tree:add_le(mipc_nw_ca_band_t_ca_band_class, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_nw_tuw_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_tuw_info_t_tuw_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_tuw_info_t_tuw_length, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_tuw_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_tuw_info_v1_t_tuw_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_tuw_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_tuw_info_v1_t_tuw_length, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nr_ca_band_struct(struct_tree, struct_data)
    local struct_offset = 0
    local array = struct_tree:add("band")
    local array_size = 10
    for i=0, array_size-1 do
        local sub_tree = array:add("band ["..i.."]")
        sub_tree:add_le(mipc_nr_ca_band_t_band, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_lte_bound_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_lte_bound_info_t_sbp_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_bound_info_t_event_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_bound_info_t_threshold, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_bound_info_t_signal_quality_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_bound_info_t_upper_bound, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_lte_bound_info_t_lower_bound, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_allowed_mcc_list_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_allowed_mcc_list_t_allowed_mcc_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("allowed_mcc")
    local array_size = 20
    for i=0, array_size-1 do
        local sub_tree = array:add("allowed_mcc ["..i.."]")
        sub_tree:add_le(mipc_nw_allowed_mcc_list_t_allowed_mcc, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    return struct_offset
end

function mipc_nw_record_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_record_info_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_record_info_t_num_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("band")
    local array_size = 8
    for i=0, array_size-1 do
        local sub_tree = array:add("band ["..i.."]")
        sub_tree:add_le(mipc_nw_record_info_t_band, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    struct_tree:add_le(mipc_nw_record_info_t_num_channel, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("channel")
    local array_size = 32
    for i=0, array_size-1 do
        local sub_tree = array:add("channel ["..i.."]")
        sub_tree:add_le(mipc_nw_record_info_t_channel, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_nw_plmn_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_plmn_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_scan_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_scan_info_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_xarfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_pcid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_scan_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 32
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_scan_info_t_cell_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 20
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_scan_info_t_lac_or_tac, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_scan_info_t_plmn_status, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_srv_cell_status, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_sig1, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_sig2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_sig4, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_t_sig5, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_scan_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_scan_info_v1_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_xarfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_pcid, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_scan_info_v1_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 32
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_scan_info_v1_t_cell_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 20
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_scan_info_v1_t_lac_or_tac, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_scan_info_v1_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_scan_info_v1_t_plmn_status, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_srv_cell_status, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_sig1, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_sig2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_sig3, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_sig4, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_scan_info_v1_t_sig5, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_os_id_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_os_id_info_t_os_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_congestion_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_mode, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_op, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_serv_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_det_time, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_duration, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_bar_duration, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_grant_bytes, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_bsr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_pdcp_discard_rate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_phr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_s_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_s_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_n_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_n_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_ul_bler, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_dl_bler, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_ul_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_dl_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_ul_alloc_rate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_dl_alloc_rate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_v1_t_cond_ul_pending_data, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_handover_rat_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_handover_rat_info_t_para_number, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_handover_rat_info_t_rat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_handover_rat_info_t_mcc, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_handover_rat_info_t_mnc, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_handover_rat_info_t_mnc_digit_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_handover_rat_info_t_padding1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_handover_rat_info_t_area_code, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_handover_rat_info_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_handover_rat_info_t_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_handover_rat_info_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_handover_rat_info_t_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sim_msisdn_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 24
    struct_tree:add_le(mipc_sim_msisdn_t_msisdn, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_sim_pin_desc_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sim_pin_desc_t_pin_mode, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sim_pin_desc_t_pin_format, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sim_pin_desc_t_pin_len_min, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sim_pin_desc_t_pin_len_max, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_sim_app_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sim_app_info_t_app_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sim_app_info_t_app_id_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 20
    struct_tree:add_le(mipc_sim_app_info_t_sim_app_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_sim_app_info_t_name_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 32
    struct_tree:add_le(mipc_sim_app_info_t_name, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_sim_app_info_t_num_of_pins, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_sim_app_info_t_pin_ref, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_sim_slots_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 20
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_slots_info_t_card_state, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_sim_slots_info_t_slots_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sim_slots_info_t_logical_idx, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_sim_slots_info_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 80
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_slots_info_t_atr, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 32
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_slots_info_t_eid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 21
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_slots_info_t_iccid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_eid_byte_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_eid_byte_struct_t_is_valid, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_eid_byte_struct_t_eid, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_port_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 21
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_port_info_t_iccid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 3
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_port_info_t_reserved1, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_port_info_t_lsi, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_port_info_t_port_active, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 2
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_port_info_t_reserved2, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_app_status_desc_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_app_status_desc_t_app_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_app_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_pin_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_sub_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_pin1_replaced, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_pin1_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_pin2_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_app_status_desc_t_reserved1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 41
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_app_status_desc_t_aid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_app_status_desc_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 33
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_app_status_desc_t_app_label, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_app_status_desc_t_reserved3, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_file_list_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 9
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_file_list_t_path, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 50
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_file_list_t_data, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_sid_nid_list_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 6
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sid_nid_list_t_sid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_sid_nid_list_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 6
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sid_nid_list_t_nid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_sim_carrier_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 4
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_carrier_struct_t_mcc, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 4
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_carrier_struct_t_mnc, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_sim_carrier_struct_t_match_cat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 21
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sim_carrier_struct_t_match_data, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_sms_pdu_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sms_pdu_t_message_index, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_sms_pdu_t_pdu_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sms_pdu_t_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sms_pdu_t_sms_class, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_sms_pdu_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 256
    struct_tree:add_le(mipc_sms_pdu_t_pdu, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ss_call_forward_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ss_call_forward_t_call_forward_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 183
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ss_call_forward_t_dial_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_ss_call_forward_t_service_class, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_ss_call_forward_t_type_of_address, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ss_call_forward_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ss_call_forward_t_timer, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ss_call_forward_t_reason, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ss_call_forward_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 128
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ss_call_forward_t_time_slot_begin, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 128
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ss_call_forward_t_time_slot_end, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_ss_call_waiting_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ss_call_waiting_t_call_waiting_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ss_call_waiting_t_padding, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ss_call_waiting_t_service_class, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_ss_cb_dialnumber_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ss_cb_dialnumber_t_number_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 183
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ss_cb_dialnumber_t_dial_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_sys_mapping_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_mapping_t_ps_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_lte_band_struct(struct_tree, struct_data)
    local struct_offset = 0
    local array = struct_tree:add("lte_band_class")
    local array_size = 8
    for i=0, array_size-1 do
        local sub_tree = array:add("lte_band_class ["..i.."]")
        sub_tree:add_le(mipc_sys_lte_band_t_lte_band_class, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_sys_nr_band_struct(struct_tree, struct_data)
    local struct_offset = 0
    local array = struct_tree:add("nr_band_class")
    local array_size = 32
    for i=0, array_size-1 do
        local sub_tree = array:add("nr_band_class ["..i.."]")
        sub_tree:add_le(mipc_sys_nr_band_t_nr_band_class, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_sys_thermal_sensor_config_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_enable, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_sensor_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_alarm_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_threshold, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_hysteresis, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_interval, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_t_alarm_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_thermal_sensor_config_e_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_enable, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_sensor_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_alarm_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_threshold, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_hysteresis, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_interval, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_config_e_t_alarm_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_thermal_actuator_state_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_actuator_state_info_t_actuator_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_actuator_state_info_t_num_throttling_state, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_actuator_state_info_t_current_throttling_state, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 40
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_sys_thermal_actuator_state_info_t_actuator_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_sys_thermal_sensor_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_sensor_info_t_sensor_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_info_t_temperature, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_thermal_sensor_info_e_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_sensor_info_e_t_sensor_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_sensor_info_e_t_temperature, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_thermal_trip_map_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_trip_map_t_val_trip_map, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_map_t_threshold_value, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_map_t_hysteresis_value, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_map_t_sampling_period, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_map_t_sensor_alarm_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_map_t_throttle_level, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_thermal_trip_change_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_thermal_trip_change_t_sensor_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_change_t_before_trip_temp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_change_t_after_trip_temp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_thermal_trip_change_t_save_cfg_to_nv, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_sys_mia_metrics_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_mia_metrics_t_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_mia_metrics_t_latency, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_mia_metrics_t_ul_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_mia_metrics_t_dl_tput, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_call_detail_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_call_detail_info_t_number_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_call_detail_info_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 128
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_call_detail_info_t_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_call_detail_info_t_name_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_call_detail_info_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 80
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_call_detail_info_t_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_call_detail_info_t_display_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_call_detail_info_t_verstat, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 64
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_call_detail_info_t_privacy, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_call_video_cap_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_call_video_cap_t_local_video_cap_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_call_video_cap_t_local_video_cap, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_call_video_cap_t_remote_video_cap_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_call_video_cap_t_remote_video_cap, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_ecc_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ecc_info_t_is_fake_ecc, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ecc_info_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ecc_info_t_category, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_ecc_info_t_type, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_string_length = 10
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ecc_info_t_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_ecc_info_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ecc_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ecc_info_v1_t_is_fake_ecc, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_ecc_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ecc_info_v1_t_category, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_ecc_info_v1_t_type, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_string_length = 10
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ecc_info_v1_t_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 128
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ecc_info_v1_t_sub_service, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_nw_srxlev_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_srxlev_info_t_srxlev_in_qdb, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_srxlev_info_t_squal_in_qdb, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_phb_name_str_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 168
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_name_str_t_name_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_phb_name_str_t_encode_method, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_phb_email_str_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 248
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_email_str_t_name_str, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_phb_email_str_t_encode_method, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_phb_anr_entry_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_phb_anr_entry_t_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_phb_anr_entry_t_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_phb_anr_entry_t_ton, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 40
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_anr_entry_t_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_phb_entry_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_phb_entry_t_index, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_phb_entry_t_ton, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 40
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_entry_t_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 168
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_entry_t_alphaid, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 40
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_entry_t_adnumber, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_phb_entry_t_adtype, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 248
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_phb_entry_t_email, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_phb_entry_t_encode_method, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_embms_area_id_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_embms_area_id_info_t_num_area_ids, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_area_id_info_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("area_id")
    local array_size = 8
    for i=0, array_size-1 do
        local sub_tree = array:add("area_id ["..i.."]")
        sub_tree:add_le(mipc_embms_area_id_info_t_area_id, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    return struct_offset
end

function mipc_embms_session_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_embms_session_info_t_index, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_embms_session_info_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 13
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_embms_session_info_t_tmgi, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_session_info_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_string_length = 3
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_embms_session_info_t_session_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_embms_session_info_t_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_embms_nb_req_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_embms_nb_req_info_t_num_nf, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_embms_nb_req_info_t_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_embms_nb_req_info_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_embms_nb_req_info_t_nf, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_embms_nb_req_info_t_num_bands_nf, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_nb_req_info_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("band_nf")
    local array_size = 8
    for i=0, array_size-1 do
        local sub_tree = array:add("band_nf ["..i.."]")
        sub_tree:add_le(mipc_embms_nb_req_info_t_band_nf, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    struct_tree:add_le(mipc_embms_nb_req_info_t_num_sais_nf, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_nb_req_info_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("sai_nf")
    local array_size = 64
    for i=0, array_size-1 do
        local sub_tree = array:add("sai_nf ["..i.."]")
        sub_tree:add_le(mipc_embms_nb_req_info_t_sai_nf, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    return struct_offset
end

function mipc_embms_sai_cf_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_embms_sai_cf_info_t_num_intra_freq, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_sai_cf_info_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("intra_freq")
    local array_size = 2
    for i=0, array_size-1 do
        local sub_tree = array:add("intra_freq ["..i.."]")
        sub_tree:add_le(mipc_embms_sai_cf_info_t_intra_freq, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    struct_tree:add_le(mipc_embms_sai_cf_info_t_num_sais, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_sai_cf_info_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("sais")
    local array_size = 64
    for i=0, array_size-1 do
        local sub_tree = array:add("sais ["..i.."]")
        sub_tree:add_le(mipc_embms_sai_cf_info_t_sais, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    return struct_offset
end

function mipc_embms_sai_nf_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_embms_sai_nf_info_t_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_sai_nf_info_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_embms_sai_nf_info_t_nf, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_embms_sai_nf_info_t_num_bands_nf, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_sai_nf_info_t_reserved1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("band_nf")
    local array_size = 8
    for i=0, array_size-1 do
        local sub_tree = array:add("band_nf ["..i.."]")
        sub_tree:add_le(mipc_embms_sai_nf_info_t_band_nf, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    struct_tree:add_le(mipc_embms_sai_nf_info_t_num_sais_nf, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_embms_sai_nf_info_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("sai_nf")
    local array_size = 64
    for i=0, array_size-1 do
        local sub_tree = array:add("sai_nf ["..i.."]")
        sub_tree:add_le(mipc_embms_sai_nf_info_t_sai_nf, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    return struct_offset
end

function mipc_internal_set_filter_req_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_internal_set_filter_req_t_nccmni_net_if, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_req_t_reserve1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_req_t_nccmni_seq, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_set_filter_req_t_valid_field, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_internal_set_filter_req_t_ip_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_req_t_ctrl_protocol, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_req_t_src_port, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_set_filter_req_t_dst_port, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_set_filter_req_t_tcp_flags, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_set_filter_req_t_spi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local array = struct_tree:add("src_v4_addr")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("src_v4_addr ["..i.."]")
        sub_tree:add_le(mipc_internal_set_filter_req_t_src_v4_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("dst_v4_addr")
    local array_size = 4
    for i=0, array_size-1 do
        local sub_tree = array:add("dst_v4_addr ["..i.."]")
        sub_tree:add_le(mipc_internal_set_filter_req_t_dst_v4_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("src_v6_addr")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("src_v6_addr ["..i.."]")
        sub_tree:add_le(mipc_internal_set_filter_req_t_src_v6_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local array = struct_tree:add("dst_v6_addr")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("dst_v6_addr ["..i.."]")
        sub_tree:add_le(mipc_internal_set_filter_req_t_dst_v6_addr, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_internal_set_filter_req_t_icmpv4_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_req_t_icmpv6_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_req_t_reserve, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_set_filter_req_t_features, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_internal_set_filter_cnf_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_internal_set_filter_cnf_t_nccmni_net_if, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_cnf_t_reserve1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_set_filter_cnf_t_nccmni_seq, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_set_filter_cnf_t_filter_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_internal_reset_filter_req_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_internal_reset_filter_req_t_nccmni_net_if, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_reset_filter_req_t_reserve1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_reset_filter_req_t_nccmni_seq, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_reset_filter_req_t_is_deregister_all_filter, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_internal_reset_filter_req_t_filter_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_internal_reset_filter_cnf_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_internal_reset_filter_cnf_t_nccmni_net_if, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_reset_filter_cnf_t_reserve1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_internal_reset_filter_cnf_t_nccmni_seq, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_internal_reset_filter_cnf_t_is_success, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_tx_struct(struct_tree, struct_data)
    local struct_offset = 0
    local array = struct_tree:add("tx")
    local array_size = 5
    for i=0, array_size-1 do
        local sub_tree = array:add("tx ["..i.."]")
        sub_tree:add_le(mipc_nw_tx_t_tx, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    return struct_offset
end

function mipc_plmn_cag_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_plmn_cag_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_plmn_cag_info_t_reserved, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_cag_info_t_act, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_cag_info_t_only_via_cag, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_cag_info_t_cag_id_info_count, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_cag_info_t_padding1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_plmn_cag_info_t_cag_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 48
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_plmn_cag_info_t_hrnn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_plmn_cag_info_t_cag_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_plmn_cag_info_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_congestion_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_congestion_info_t_op, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_serv_type, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_rat, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_det_time, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_duration, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_grant_bytes, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_bsr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_pdcp_discard_rate, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_phr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_s_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_s_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_n_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_congestion_info_t_cond_n_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_mbms_session_status_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_mbms_session_status_t_is_activate, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_mbms_session_status_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_mbms_session_status_t_service_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbms_freq_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_mbms_freq_info_t_freq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_mbms_tmgi_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_mbms_tmgi_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_mbms_tmgi_info_t_service_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbs_nrarfcn_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_mbs_nrarfcn_info_t_nrarfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_mbs_fsai_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_mbs_fsai_info_t_mbs_fsai, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbms_usd_fsai_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_mbms_usd_fsai_info_t_num_of_nrarfcn, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_mbms_usd_fsai_info_t_num_of_fsai, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local array = struct_tree:add("nrarfcn")
    local array_size = 5
    for i=0, array_size-1 do
        local sub_tree = array:add("nrarfcn ["..i.."]")
        sub_tree:add_le(mipc_mbms_usd_fsai_info_t_nrarfcn, struct_data:range(struct_offset,4))
        struct_offset = struct_offset + 4
    end
    -- sub_struct_array mbs_fsai_info
    local array_tree = struct_tree:add("fsai")
    for i=0, 64 do
        local sub_struct_tree = array_tree:add("fsai ["..i.."]")
        sub_struct_len = mipc_mbs_fsai_info_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
        struct_offset = struct_offset + sub_struct_len
    end
    return struct_offset
end

function mipc_mbms_tac_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_mbms_tac_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 5
    struct_tree:add_le(mipc_mbms_tac_info_t_ta_code, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbms_ip_address_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_mbms_ip_address_info_t_src_ip_address, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_mbms_ip_address_info_t_dest_ip_address, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_mbms_cell_id_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_mbms_cell_id_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 5
    struct_tree:add_le(mipc_mbms_cell_id_info_t_cell_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_tsn_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_tsn_info_t_port_mac_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 6
    struct_tree:add_le(mipc_data_tsn_info_t_port_mac, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_data_tsn_info_t_res_time_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 8
    struct_tree:add_le(mipc_data_tsn_info_t_res_time, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_data_tsn_info_t_pmic_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_data_tsn_info_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_data_tsn_info_t_pmic_len, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 8192
    struct_tree:add_le(mipc_data_tsn_info_t_pmic, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_data_tsn_time_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_tsn_time_t_day, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tsn_time_t_second, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tsn_time_t_milli_second, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tsn_time_t_nano_second, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tsn_time_t_uncertainly, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tsn_time_t_timeinfotype, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_tsn_time_t_referencesfn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_ftai_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_ftai_info_t_plmn_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_ftai_info_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_ftai_info_t_tac, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_sys_idc_gpio_cfg_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_idc_gpio_cfg_t_gpio_0, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sys_idc_gpio_cfg_t_gpio_1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_sys_idc_gpio_cfg_t_gpio_2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_track_item_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_track_item_t_track_index, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_track_item_t_mipc_msg_id, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_track_item_t_pending_time, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_track_item_t_mipc_txid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_track_item_t_mipc_id, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_wfp_filter_struct_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_wfp_filter_struct_t_filter_config, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_wfp_filter_struct_t_operation_config, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_wfp_filter_struct_t_priority, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_wfp_filter_struct_t_ip_ver, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_wfp_filter_struct_t_protocol, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_wfp_filter_struct_t_icmp_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_wfp_filter_struct_t_icmp_code, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_wfp_filter_struct_t_reserved, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("ip_src")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("ip_src ["..i.."]")
        sub_tree:add_le(mipc_wfp_filter_struct_t_ip_src, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_wfp_filter_struct_t_ip_src_mask, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_wfp_filter_struct_t_reserved2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("ip_dest")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("ip_dest ["..i.."]")
        sub_tree:add_le(mipc_wfp_filter_struct_t_ip_dest, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    struct_tree:add_le(mipc_wfp_filter_struct_t_ip_dest_mask, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_wfp_filter_struct_t_reserved3, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_wfp_filter_struct_t_src_port, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_src_port_mask, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_dst_port, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_dst_port_mask, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_tcp_flags, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_tcp_flags_mask, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_tcp_flags_operation, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_reserved4, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    local array = struct_tree:add("icmp_src_ip")
    local array_size = 16
    for i=0, array_size-1 do
        local sub_tree = array:add("icmp_src_ip ["..i.."]")
        sub_tree:add_le(mipc_wfp_filter_struct_t_icmp_src_ip, struct_data:range(struct_offset,2))
        struct_offset = struct_offset + 2
    end
    struct_tree:add_le(mipc_wfp_filter_struct_t_icmp_src_port, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_icmp_src_mask, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_wfp_filter_struct_t_esp_spi, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_wfp_filter_struct_t_esp_spi_mask, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_stk_menu_select_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_menu_select_t_item_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_stk_menu_select_t_help_req, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_stk_address_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_address_t_ton_npi, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_stk_address_t_valid_dialling_number_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 40
    struct_tree:add_le(mipc_stk_address_t_dialling_number, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_stk_ussdstring_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_ussdstring_t_dcs, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_stk_ussdstring_t_valid_ussd_data_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 183
    struct_tree:add_le(mipc_stk_ussdstring_t_ussd_data, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_stk_call_control_param_data_struct(struct_tree, struct_data)
    local struct_offset = 0
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("address")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("ss_string")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    -- sub_struct stk_ussdstring
    local sub_struct_tree = struct_tree:add("ussd_string")
    sub_struct_len = mipc_stk_ussdstring_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    return struct_offset
end

function mipc_stk_call_control_param_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_call_control_param_t_call_control_param_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    -- sub_struct stk_call_control_param_data
    local sub_struct_tree = struct_tree:add("call_control_param_data")
    sub_struct_len = mipc_stk_call_control_param_data_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    return struct_offset
end

function mipc_stk_call_ctrl_voice_struct(struct_tree, struct_data)
    local struct_offset = 0
    -- sub_struct stk_call_control_param
    local sub_struct_tree = struct_tree:add("call_control_param")
    sub_struct_len = mipc_stk_call_control_param_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    return struct_offset
end

function mipc_stk_call_ctrl_sms_struct(struct_tree, struct_data)
    local struct_offset = 0
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("service_center_num")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("dest_num")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    return struct_offset
end

function mipc_stk_event_dl_mt_call_struct(struct_tree, struct_data)
    local struct_offset = 0
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("dest_num")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_stk_event_dl_mt_call_t_call_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_stk_event_dl_call_con_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_event_dl_call_con_t_ismo, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_stk_event_dl_call_con_t_call_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_stk_event_dl_call_discon_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_event_dl_call_discon_t_transaction_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_stk_event_dl_call_discon_t_is_near_end, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    return struct_offset
end

function mipc_stk_ims_registration_status_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_ims_registration_status_t_valid_impu_list_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 242
    struct_tree:add_le(mipc_stk_ims_registration_status_t_impu_list, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_stk_ims_registration_status_t_valid_ims_status_code_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 5
    struct_tree:add_le(mipc_stk_ims_registration_status_t_ims_status_code, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_stk_sms_pp_data_dl_struct(struct_tree, struct_data)
    local struct_offset = 0
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("addr")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_stk_sms_pp_data_dl_t_valid_sms_tpdu_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 176
    struct_tree:add_le(mipc_stk_sms_pp_data_dl_t_sms_tpdu, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_stk_call_control_rsp_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_call_control_rsp_t_cc_result, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    -- sub_struct stk_call_control_param
    local sub_struct_tree = struct_tree:add("call_control_param")
    sub_struct_len = mipc_stk_call_control_param_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_stk_call_control_rsp_t_valid_capability_params1_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_stk_call_control_rsp_t_capability_params1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_stk_call_control_rsp_t_valid_sub_address_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 40
    struct_tree:add_le(mipc_stk_call_control_rsp_t_sub_address, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_stk_call_control_rsp_t_valid_alpha_id_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 32
    struct_tree:add_le(mipc_stk_call_control_rsp_t_alpha_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_stk_call_control_rsp_t_repeat_indicator, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_stk_call_control_rsp_t_valid_capability_params2_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 16
    struct_tree:add_le(mipc_stk_call_control_rsp_t_capability_params2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_stk_call_control_sms_rsp_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_stk_call_control_sms_rsp_t_cc_result, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("service_center_num")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    -- sub_struct stk_address
    local sub_struct_tree = struct_tree:add("dest_num")
    sub_struct_len = mipc_stk_address_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_stk_call_control_sms_rsp_t_valid_alpha_id_len, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 32
    struct_tree:add_le(mipc_stk_call_control_sms_rsp_t_alpha_id, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_SRVCC_CALL_CTXT_STRUCT_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_srvcc_call_ctxt_struct_t_call_id, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_srvcc_call_ctxt_struct_t_call_mode, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_srvcc_call_ctxt_struct_t_call_direction, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_srvcc_call_ctxt_struct_t_call_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_srvcc_call_ctxt_struct_t_call_ecc_category, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_srvcc_call_ctxt_struct_t_num_of_conf_parts, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 81
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_srvcc_call_ctxt_struct_t_call_number, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    return struct_offset
end

function mipc_ntn_ephemeris_state_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ntn_ephemeris_state_t_position_x, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_state_t_position_y, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_state_t_position_z, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_state_t_velocity_vx, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_state_t_velocity_vy, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_state_t_velocity_vz, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_pcie_link_status_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_pcie_link_status_t_lane_num, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_link_status_t_rate_level, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_pcie_counter_register_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_pcie_counter_register_t_l0, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_l0s, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_l1, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_l11, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_l12, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_l2, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_rcvr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_pcie_counter_register_t_others, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_lte_meas_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_lte_meas_cell_t_earfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_lte_meas_cell_t_pci, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_lte_meas_cell_t_rsrp, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_nw_nr_meas_cell_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_meas_cell_t_narfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_meas_cell_t_pci, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_nr_meas_cell_t_rsrp, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    return struct_offset
end

function mipc_sys_modem_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_modem_t_modem_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_sys_modem_t_executor_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_modem_t_sim_number, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_modem_t_concurrency, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_sys_modem_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_sys_adpclk_freq_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_sys_adpclk_freq_info_t_center_frequency, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_sys_adpclk_freq_info_t_frequency_spread, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_adpclk_freq_info_t_noise_power, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_adpclk_freq_info_t_relative_signal_strength, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_sys_adpclk_freq_info_t_connect_status, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_data_5gqos_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_cid, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_vqi, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_averaging_window, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_dl_gfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_ul_gfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_dl_mfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_ul_mfbr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_dl_sambr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_data_5gqos_info_v1_t_ul_sambr, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    return struct_offset
end

function mipc_nw_nr_cell_v2_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_state, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_v2_t_provider_id, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_cid, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_physical_cell_id, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_nr_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_sinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_ta, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_csirsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_csirsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_csisinr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_dl_freq_band, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_registered, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_v2_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_nr_cell_v2_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_csi_cqi_table_index, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_csi_cqi_report_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local array = struct_tree:add("csi_cqi_report_list")
    local array_size = 19
    for i=0, array_size-1 do
        local sub_tree = array:add("csi_cqi_report_list ["..i.."]")
        sub_tree:add_le(mipc_nw_nr_cell_v2_t_csi_cqi_report_list, struct_data:range(struct_offset,1))
        struct_offset = struct_offset + 1
    end
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_nr_cell_v2_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_reg_change_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_stat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_padding1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_lac_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_eact, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_rac, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_nw_existence, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_roam_indicator, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_cause_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_reject_cause, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_dcnr_restricted, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_endc_sib_status, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_endc_available, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 5
    struct_tree:add_le(mipc_nw_reg_change_info_v1_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_ps_reg_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_stat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_padding1, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_rat, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_reason_for_denial, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_max_data_calls, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_is_vops_supported, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_is_emc_bearer_supported, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_is_endc_available, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_is_dcnr_restricted, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_is_nr_available, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_roaming_ind, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_is_in_prl, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_padding2, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_def_roaming_ind, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_cache_endc_connect, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_padding3, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_ps_reg_info_v1_t_lac_tac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    return struct_offset
end

function mipc_nw_cellmeasurement_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_rat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_pci, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_rsrp, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_rsrq, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_snr, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_cellmeasurement_info_v1_t_cid, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    return struct_offset
end

function mipc_nw_pseudocell_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 7
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_v1_t_plmn, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_v1_t_long_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_string_length = 60
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_v1_t_short_name, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_lac, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_padding1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_arfcn, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_bsic, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_string_length = 50
    local mipc_string = bytestostring(struct_data:range(struct_offset, mipc_string_length), mipc_string_length)
    struct_tree:add(mipc_nw_pseudocell_info_v1_t_si3_raw_data, struct_data:range(struct_offset, mipc_string_length), mipc_string) 
    struct_offset = struct_offset + mipc_string_length
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_nw_pseudocell_info_v1_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_nw_handover_rat_info_v1_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_cell_id, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_para_number, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_rat, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_mnc_digit_num, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 1
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_padding1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_mcc, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_mnc, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_band, struct_data:range(struct_offset,2))
    struct_offset = struct_offset + 2
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_area_code, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_arfcn, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_nw_handover_rat_info_v1_t_padding3, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ntn_ephemeris_orbital_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_semi_major_axis, struct_data:range(struct_offset,8))
    struct_offset = struct_offset + 8
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_eccentricity, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_periapsis, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_longitude, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_inclination, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_anomaly, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    local mipc_byte_array_length = 4
    struct_tree:add_le(mipc_ntn_ephemeris_orbital_t_padding, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

function mipc_ntn_sib31_info_struct(struct_tree, struct_data)
    local struct_offset = 0
    struct_tree:add_le(mipc_ntn_sib31_info_t_ephemeris_state_vector_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ntn_sib31_info_t_padding1, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    -- sub_struct ntn_ephemeris_state
    local sub_struct_tree = struct_tree:add("ephemeris_state_vector")
    sub_struct_len = mipc_ntn_ephemeris_state_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_ntn_sib31_info_t_ephemeris_orbital_present, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 3
    struct_tree:add_le(mipc_ntn_sib31_info_t_padding2, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    -- sub_struct ntn_ephemeris_orbital
    local sub_struct_tree = struct_tree:add("ephemeris_orbital")
    sub_struct_len = mipc_ntn_ephemeris_orbital_struct(sub_struct_tree, struct_data:range(struct_offset,struct_data:len()-struct_offset))
    struct_offset = struct_offset + sub_struct_len
    struct_tree:add_le(mipc_ntn_sib31_info_t_nta_common, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_sib31_info_t_nta_common_drift, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_sib31_info_t_nta_common_drift_variation, struct_data:range(struct_offset,4))
    struct_offset = struct_offset + 4
    struct_tree:add_le(mipc_ntn_sib31_info_t_satellite_type, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    struct_tree:add_le(mipc_ntn_sib31_info_t_sib31_scheduling_cycle, struct_data:range(struct_offset,1))
    struct_offset = struct_offset + 1
    local mipc_byte_array_length = 2
    struct_tree:add_le(mipc_ntn_sib31_info_t_padding3, struct_data:range(struct_offset, mipc_byte_array_length))
    struct_offset = struct_offset + mipc_byte_array_length
    return struct_offset
end

