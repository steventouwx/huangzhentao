#ifndef _MIPC_CHECKER_H_
#define _MIPC_CHECKER_H_

typedef struct {
    uint16_t tlv_type;
    uint16_t option;
    uint16_t array_num;
    union {
        struct {
            uint32_t min_value;
            uint32_t max_value;
        } min_max;
        struct {
            uint32_t fixed_value;
        } fixed;
        struct {
            uint32_t count_type;
            uint32_t struct_size;
        } count_struct_size;
        struct {
            uint32_t multiple_value;
        } multiple;
    } check_item;
} mipc_tlv_checker_info_t;

typedef struct {
    uint16_t msg_id;
    uint8_t msg_version;
    char *name_string;
    uint32_t checker_info_size;
    mipc_tlv_checker_info_t *checker_info;
} mipc_checker_info_t;

#define MIPC_CHECKER_TYPE_INT (0x8000)
#define MIPC_CHECKER_TYPE_MANDATORY (0x4000)
#define MIPC_CHECKER_TYPE_ARR (0x2000)

#define MIPC_CHECKER_OPTION_MIN (0x0100)
#define MIPC_CHECKER_OPTION_MAX (0x0200)
#define MIPC_CHECKER_OPTION_FIXED (0x0400)
#define MIPC_CHECKER_OPTION_COUNT_STRUCT (0x0800)
#define MIPC_CHECKER_OPTION_MULTIPLE (0x1000)

#define MIPC_CHECKER_INT_TYPE_SIGNED (0x0080)

#define MIPC_CHECKER_INT_SIZE_8 (0x0001)
#define MIPC_CHECKER_INT_SIZE_16 (0x0002)
#define MIPC_CHECKER_INT_SIZE_32 (0x0004)


int mipc_check_int(mipc_msg_t *msg_ptr, mipc_msg_tlv_t *tlv_ptr, mipc_tlv_checker_info_t *tlv_checker_info);
int mipc_check_non_int(mipc_msg_t *msg_ptr, mipc_msg_tlv_t *tlv_ptr, mipc_tlv_checker_info_t *tlv_checker_info);
int mipc_check_non_int_value(uint32_t val, mipc_msg_t *msg_ptr, mipc_tlv_checker_info_t *tlv_checker_info);

static mipc_tlv_checker_info_t mipc_sys_get_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_SYS_CELLULAR_CLASS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_VOICE_CLASS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_SIM_CLASS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_DATA_CLASS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_GSM_BAND_CLASS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_UMTS_BAND_CLASS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_TDS_BAND_CLASS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_C2K_BAND_CLASS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_LTE_BAND_CLASS, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_NR_BAND_CLASS, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_SMS_CAPS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_CTRL_CAPS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_AUTH_ALGO_CAPS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_SERVICE_CAPS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_MULTI_MD, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_DEVICE_ID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_MANUFCTR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_FIRMWARE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_HARDWARE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 30 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_MAX_ACTIVE_CTXT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_EXECUTOR_IDX, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_CUSTOM_CLASS_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_PRODUCT_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_ESN, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_IMEISV, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_MEID, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_FIRMWARE_CUSTOM, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_HARDWARE_ID, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_SERIAL_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_PROJECT_NAME, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_FLAVOR_NAME, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_ESN_V1, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_MEID_V1, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_SYS_GET_INFO_CNF_T_SYS_CELLULAR_CLASS_V1, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_at_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_AT_REQ_T_ATCMD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_sys_at_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_AT_CNF_T_ATCMD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_sys_reboot_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_REBOOT_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SYS_REBOOT_REQ_T_TIMEOUT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_mapping_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MAPPING_REQ_T_MSG, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_mapping_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MAPPING_CNF_T_MAPPING_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_MAPPING_CNF_T_MAPPING_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_SYS_GET_MAPPING_CNF_T_MAPPING_TLV_ARRAY, .option = 0xe004, .array_num = 16, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_mapping_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MAPPING_REQ_T_MAPPING_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_MAPPING_REQ_T_MAPPING_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_SYS_SET_MAPPING_REQ_T_MAPPING_TLV_ARRAY, .option = 0xa004, .array_num = 16, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_mapping_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MAPPING_CNF_T_MAPPING_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_MAPPING_CNF_T_MAPPING_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_SYS_SET_MAPPING_CNF_T_MAPPING_TLV_ARRAY, .option = 0xe004, .array_num = 16, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_num_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_NUM_CNF_T_NUM, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_REQ_T_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_NAME, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_MEAS_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_MIN_TEMPATURE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_MAX_TEMPATURE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_ACCURACY, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_RESOLUTION, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_WARN_TEMPATURE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_HW_SHUTDOWN_TEMPERATURE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF_T_MIN_SAMPLING_PERIOD, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_thermal_sensor_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_THERMAL_SENSOR_REQ_T_CONFIG_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_SENSOR_REQ_T_CONFIG_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 28 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_SENSOR_REQ_T_CONFIG_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 28 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_thermal_sensor_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_THERMAL_SENSOR_CNF_T_CONFIG_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_SENSOR_CNF_T_CONFIG_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 28 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_SENSOR_CNF_T_CONFIG_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 28 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_REQ_T_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_CNF_T_TEMPERATURE, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_actuator_num_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_NUM_CNF_T_NUM, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_thermal_actuator_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_THERMAL_ACTUATOR_REQ_T_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_ACTUATOR_REQ_T_LEVEL, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_ACTUATOR_REQ_T_STATE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_actuator_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_REQ_T_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_actuator_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF_T_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF_T_NAME, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF_T_TOTAL_LEVEL, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF_T_CURRENT_LEVEL, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF_T_USER_IMPACT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF_T_EFFICIENCY, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_CONFIG_REQ_T_CLASS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SYS_SET_CONFIG_REQ_T_TYPE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SYS_SET_CONFIG_REQ_T_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_config_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_CONFIG_CNF_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_CONFIG_REQ_T_CLASS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SYS_GET_CONFIG_REQ_T_TYPE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_config_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_CONFIG_CNF_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_reg_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_REG_CONFIG_REQ_T_CLASS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SYS_REG_CONFIG_REQ_T_TYPE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_adpclk_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_ADPCLK_REQ_T_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_adpclk_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_ADPCLK_CNF_T_FREQ_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_ADPCLK_CNF_T_FREQ_INFO_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 24 }},
    {.tlv_type = MIPC_SYS_GET_ADPCLK_CNF_T_FREQ_INFO_TLV_ARRAY, .option = 0x6400, .array_num = 1, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_md_log_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MD_LOG_MODE_REQ_T_MODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_md_log_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MD_LOG_MODE_CNF_T_MODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_md_log_level_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MD_LOG_LEVEL_REQ_T_LEVEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_md_log_level_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MD_LOG_LEVEL_CNF_T_LEVEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_md_log_location_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MD_LOG_LOCATION_REQ_T_ENABLE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_md_log_location_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MD_LOG_LOCATION_CNF_T_ENABLE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_write_nvram_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_WRITE_NVRAM_REQ_T_FILE_IDX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_WRITE_NVRAM_REQ_T_RECORD_IDX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_WRITE_NVRAM_REQ_T_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_write_nvram_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_WRITE_NVRAM_CNF_T_DATA_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_WRITE_NVRAM_CNF_T_CAUSE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 17 }},
};

static mipc_tlv_checker_info_t mipc_sys_read_nvram_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_READ_NVRAM_REQ_T_FILE_IDX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_READ_NVRAM_REQ_T_RECORD_IDX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_read_nvram_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_READ_NVRAM_CNF_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
    {.tlv_type = MIPC_SYS_READ_NVRAM_CNF_T_CAUSE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 17 }},
};

static mipc_tlv_checker_info_t mipc_sys_auth_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_AUTH_REQ_T_OP, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_AUTH_REQ_T_ENCDATA, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sys_auth_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_AUTH_CNF_T_RAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_dat_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_DAT_REQ_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_dat_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_DAT_CNF_T_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_mcf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MCF_REQ_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 11 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_CONFIG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_DUMP_LIDS, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1024 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_PATH_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_TRIGGER_DSBP, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_ACTION, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_FORMAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_NUM, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_REC_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_VALUE, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 512 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_CONFIG1, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1024 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_CONFIG, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1024 }},
    {.tlv_type = MIPC_SYS_MCF_REQ_T_IS_RESET, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_mcf_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MCF_CNF_T_MCF_RESULT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_DSBP_RESULT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 11 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_CONFIG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_PATH_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_ACTION, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_FORMAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_VALUE, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 512 }},
    {.tlv_type = MIPC_SYS_MCF_CNF_T_CONFIG1, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1024 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_fcc_lock_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_FCC_LOCK_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_time_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_YEAR, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_MONTH, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_DAY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_HOUR, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_MINUTE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_SECOND, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_TIME_REQ_T_TZ_OFF_MIN, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_time_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_YEAR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_MONTH, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_DAY, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_HOUR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_MINUTE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_SECOND, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_TIMESTAMP, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_TIME_CNF_T_TZ_OFF_MIN, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_sar_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_SAR_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_SAR_REQ_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_sar_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_SAR_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_SAR_CNF_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_sar_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_SAR_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_SAR_CNF_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_power_saving_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_POWER_SAVING_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_connectivity_statistics_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_REQ_T_READ_FLAG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_REQ_T_START, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_REQ_T_STOP, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_REQ_T_PERIOD_VALUE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_connectivity_statistics_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_SMS_TX_COUNTER, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_SMS_RX_COUNTER, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_TX_DATA, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_RX_DATA, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_MAX_MESSAGE_SIZE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_AVERAGE_MESSAGE_SIZE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_PERIOD_VALUE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_TX_DATA_EXT, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SYS_CONNECTIVITY_STATISTICS_CNF_T_RX_DATA_EXT, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_sys_query_sbp_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_QUERY_SBP_CNF_T_SBP_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_QUERY_SBP_CNF_T_SIM_SBP_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_QUERY_SBP_CNF_T_SBP_FEATURE_BYTE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SYS_QUERY_SBP_CNF_T_SBP_DATA_BYTE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_tx_ind_interval_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_TX_IND_INTERVAL_REQ_T_INTERVAL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_geo_location_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ACCOUNT_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_BROADCAST_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_LATITUDE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_LONGITUDE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ACCURACY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_METHOD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_CITY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_STATE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ZIP, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_COUNTRY_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_UE_WLAN_MAC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_CONFIDENCE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ALTITUDE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ACCURACY_SEMI_MAJOR_AXIS, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ACCURACY_SEMI_MINOR_AXIS, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_GEO_LOCATION_REQ_T_ACCURACY_VERTICAL_AXIS, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_dsbp_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_DSBP_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_sys_send_sar_ind_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SEND_SAR_IND_REQ_T_CMD_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SEND_SAR_IND_REQ_T_CMD_PARAM, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sys_silent_reboot_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SILENT_REBOOT_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_multi_sim_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MULTI_SIM_CONFIG_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_reboot_set_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_REBOOT_SET_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_actuator_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_REQ_T_GET_ACTUATOR_NUM, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_REQ_T_ACTUATOR_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_actuator_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_CNF_T_ACTUATOR_NUM, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_ACTUATOR_CNF_T_ACTUATOR_STATE_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 52 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_runtime_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_RUNTIME_REQ_T_GET_MD_AUTO_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_RUNTIME_REQ_T_SENSOR_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_thermal_sensor_runtime_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_RUNTIME_CNF_T_MD_AUTO_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_THERMAL_SENSOR_RUNTIME_CNF_T_TRIP_TLV_ARRAY, .option = 0x6400, .array_num = 16, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_thermal_runtime_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_THERMAL_RUNTIME_REQ_T_RESET_CFG_FROM_NV, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_RUNTIME_REQ_T_MD_AUTO_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_RUNTIME_REQ_T_TRIP_CHANGE, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_SYS_SET_THERMAL_RUNTIME_REQ_T_SAVE_CFG_TO_NV, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_or_get_sbp_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_OR_GET_SBP_INFO_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8 }},
    {.tlv_type = MIPC_SYS_SET_OR_GET_SBP_INFO_REQ_T_FEATURE_INT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_OR_GET_SBP_INFO_REQ_T_FEATURE_STR, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_OR_GET_SBP_INFO_REQ_T_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_OR_GET_SBP_INFO_REQ_T_PARAM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_or_get_sbp_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_OR_GET_SBP_INFO_CNF_T_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_all_thermal_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_ALL_THERMAL_INFO_CNF_T_AUTO_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_ALL_THERMAL_INFO_CNF_T_THERMAL_TEMP_INFO_TLV_ARRAY, .option = 0x6400, .array_num = 8, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SYS_GET_ALL_THERMAL_INFO_CNF_T_ACTUATOR_STATE_INFO_TLV_ARRAY, .option = 0x6400, .array_num = 32, .check_item = { .fixed.fixed_value = 52 }},
};

static mipc_tlv_checker_info_t mipc_sys_meta_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_META_REQ_T_LOCAL, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SYS_META_REQ_T_PEER, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SYS_META_REQ_T_CHECKSUM, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sys_meta_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_META_CNF_T_LOCAL, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SYS_META_CNF_T_PEER, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SYS_META_CNF_T_CHECKSUM, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sys_dmf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_DMF_REQ_T_CATEGORY_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_DMF_REQ_T_RAWDATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_sys_dmf_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_DMF_CNF_T_CATEGORY_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_DMF_CNF_T_RAWDATA_TLV_ARRAY, .option = 0x2200, .array_num = 10, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2048 }},
    {.tlv_type = MIPC_SYS_DMF_CNF_T_ATSTRING_TLV_ARRAY, .option = 0x2300, .array_num = 10, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_sys_meta_forwarder_ctrl_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_META_FORWARDER_CTRL_REQ_T_SELECTOR, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SYS_META_FORWARDER_CTRL_REQ_T_CHECKSUM, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sys_meta_forwarder_ctrl_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_META_FORWARDER_CTRL_CNF_T_SELECTOR, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SYS_META_FORWARDER_CTRL_CNF_T_CHECKSUM, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_md_log_flush_interval_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MD_LOG_FLUSH_INTERVAL_REQ_T_FLUSH_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_md_log_flush_interval_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MD_LOG_FLUSH_INTERVAL_CNF_T_FLUSH_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_establish_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IF_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_HITCHHIKE_INTERVAL, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_HB_PATTERN, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_HB_ACK_PATTERN, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_ALLOW_DYNAMIC_CYCLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_CYCLE_VALUE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_MAX_CYCLE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_CYCLE_STEP, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_CYCLE_STEP_SUCCESS_NUM, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IPV4_TOS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IPV4_TTL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IPV4_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IPV6_FLOW_LABEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IPV6_HOP_LIMIT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IPV6_TCLASS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_RCV_WSCALE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_SND_WSCALE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_WSCALE_OK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_SND_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_RCV_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_SND_NXT_SEQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_TCP_RCV_NXT_SEQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_V4_SRC_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_V4_DEST_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_V6_SRC_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_V6_DEST_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_IS_IPV6, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_PROTOCOL, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_SRC_PORT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_DEST_PORT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_REQ_T_MAX_RETRY_TIMES, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_establish_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_ESTABLISH_CNF_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_ctrl_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_CTRL_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_REQ_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_ctrl_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_IPV4_TOS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_IPV4_TTL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_IPV4_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_IPV6_FLOW_LABEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_IPV6_HOP_LIMIT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_IPV6_TCLASS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_RCV_WSCALE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_SND_WSCALE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_WSCALE_OK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_SND_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_RCV_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_SND_NXT_SEQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_TCP_RCV_NXT_SEQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_SEND_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_RECV_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_SHORT_RRC_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_HITCHHIKE_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_CTRL_CNF_T_CURRENT_CYCLE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_send_now_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_SEND_NOW_REQ_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_send_now_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_SEND_NOW_CNF_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_resume_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_IPV4_TOS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_IPV4_TTL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_IPV4_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_IPV6_FLOW_LABEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_IPV6_HOP_LIMIT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_IPV6_TCLASS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_RCV_WSCALE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_SND_WSCALE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_WSCALE_OK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_SND_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_RCV_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_SND_NXT_SEQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_RESUME_REQ_T_TCP_RCV_NXT_SEQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_resume_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_RESUME_CNF_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sys_mia_start_scenario_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MIA_START_SCENARIO_REQ_T_SCENARIO_METRICS, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sys_mia_stop_scenario_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MIA_STOP_SCENARIO_REQ_T_SCENARIO_METRICS, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sys_mia_update_metrics_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MIA_UPDATE_METRICS_REQ_T_SCENARIO_METRICS, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sys_trigger_md_log_flush_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_TRIGGER_MD_LOG_FLUSH_CNF_T_TRIGGER_RESULT, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 15 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_md_log_flush_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_MD_LOG_FLUSH_STATUS_CNF_T_STATUS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_gnss_coclock_nvdata_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_GNSS_COCLOCK_NVDATA_CNF_T_C0, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_GNSS_COCLOCK_NVDATA_CNF_T_C1, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_GNSS_COCLOCK_NVDATA_CNF_T_CAPID_TEMP, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_sbp_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_SBP_INFO_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SYS_SET_SBP_INFO_REQ_T_FEATURE_INT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_SBP_INFO_REQ_T_FEATURE_STR, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_SET_SBP_INFO_REQ_T_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_SBP_INFO_REQ_T_PARAM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_sbp_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_SBP_INFO_CNF_T_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_sbp_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_SBP_INFO_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 3, .min_max.max_value = 8 }},
    {.tlv_type = MIPC_SYS_GET_SBP_INFO_REQ_T_FEATURE_INT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_SBP_INFO_REQ_T_FEATURE_STR, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GET_SBP_INFO_REQ_T_PARAM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_sbp_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_SBP_INFO_CNF_T_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_spv_control_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_SPV_CONTROL_REQ_T_CONTROL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SYS_SET_SPV_CONTROL_REQ_T_CONTROL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_SPV_CONTROL_REQ_T_CONFIG1, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_SPV_CONTROL_REQ_T_CONFIG2, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_SPV_CONTROL_REQ_T_CONFIG3, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_lowv_actuator_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_LOWV_ACTUATOR_REQ_T_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_LOWV_ACTUATOR_REQ_T_STATE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_lowv_actuator_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_LOWV_ACTUATOR_REQ_T_GET_ACTUATOR_NUM, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GET_LOWV_ACTUATOR_REQ_T_ACTUATOR_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_lowv_actuator_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_LOWV_ACTUATOR_CNF_T_ACTUATOR_NUM, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_GET_LOWV_ACTUATOR_CNF_T_ACTUATOR_STATE_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 52 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_mspm_session_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MSPM_SESSION_REQ_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SYS_SET_MSPM_SESSION_REQ_T_PROCEDURE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 50 }},
    {.tlv_type = MIPC_SYS_SET_MSPM_SESSION_REQ_T_BLOCK_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_MSPM_SESSION_REQ_T_WAIT_TIME, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_errc_offset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_ERRC_OFFSET_REQ_T_VALID_FLAG, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_ERRC_OFFSET_REQ_T_NONNBR_NONOFFSET, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_ERRC_OFFSET_REQ_T_NBR_OFFSET, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_ERRC_OFFSET_REQ_T_NONNBR_OFFSET, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_mddbg_control_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_CONTROL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_CONTROL, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_POOL_INDEX, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 39 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_START_COUNT, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_SCAN_BUFFER_NO, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_ENABLE_SET, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_TIMER_VALUE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 500 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_VPEINDEX, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 33554432 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_SELECTWP, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_WP_ADDR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_SELECTBP, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_BP_ADDR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_ADDR_MASK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SET_MDDBG_CONTROL_REQ_T_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_sys_trigger_chip_diagnosis_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_TRIGGER_CHIP_DIAGNOSIS_REQ_T_OP, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SYS_TRIGGER_CHIP_DIAGNOSIS_REQ_T_DVFS_SWITCH, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_hac_flag_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_HAC_FLAG_REQ_T_HAC_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sys_at_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_AT_IND_T_ATCMD, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_sys_thermal_sensor_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_THERMAL_SENSOR_IND_T_TEMPERATURE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_THERMAL_SENSOR_IND_T_THRESHOLD, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 28 }},
    {.tlv_type = MIPC_SYS_THERMAL_SENSOR_IND_T_INFO_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_THERMAL_SENSOR_IND_T_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SYS_THERMAL_SENSOR_IND_T_CONFIG_E, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 28 }},
    {.tlv_type = MIPC_SYS_THERMAL_SENSOR_IND_T_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 8, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_sys_config_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_CONFIG_IND_T_REASON, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_CONFIG_IND_T_CLASS, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_sys_adpclk_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_ADPCLK_IND_T_FREQ_INFO_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_ADPCLK_IND_T_FREQ_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 24 }},
    {.tlv_type = MIPC_SYS_ADPCLK_IND_T_FREQ_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 1, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_sys_mcf_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MCF_IND_T_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_MCF_IND_T_RESULT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_sbp_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SBP_IND_T_SBP_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_SBP_IND_T_SIM_SBP_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_el2_ip_ul_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_EL2_IP_UL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_el2_ip_dl_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_EL2_IP_DL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_el2_mac_ul_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_EL2_MAC_UL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_el2_mac_dl_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_EL2_MAC_DL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_el2_pdcp_ul_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_EL2_PDCP_UL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_el2_pdcp_dl_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_EL2_PDCP_DL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_nl2_mac_ul_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_NL2_MAC_UL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_nl2_mac_dl_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_NL2_MAC_DL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_nl2_pdcp_ul_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_NL2_PDCP_UL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_nl2_pdcp_dl_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_NL2_PDCP_DL_IND_T_TX_BPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_geo_location_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_ACCOUNT_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_BROADCAST_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_LATITUDE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_LONGITUDE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_ACCURACY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_METHOD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_CITY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_STATE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_ZIP, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_COUNTRY_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_UE_WLAN_MAC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_GEO_LOCATION_IND_T_CONFIDENCE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_md_init_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_MD_INIT_IND_T_INIT_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_sys_warning_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_WARNING_IND_T_INFO, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sys_nv_sig_err_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_NV_SIG_ERR_IND_T_ERROR_CODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_vodata_statistics_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_VODATA_STATISTICS_IND_T_SIM_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_VODATA_STATISTICS_IND_T_TX_BYTES, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_VODATA_STATISTICS_IND_T_RX_BYTES, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_VODATA_STATISTICS_IND_T_TX_PKT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_VODATA_STATISTICS_IND_T_RX_PKT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_thermal_actuator_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_THERMAL_ACTUATOR_IND_T_IMS_ONLY_IND, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_THERMAL_ACTUATOR_IND_T_FLIGHT_MODE_IND, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SYS_THERMAL_ACTUATOR_IND_T_CHARGE_IND, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sys_dmf_urc_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_DMF_URC_IND_T_CATEGORY_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_DMF_URC_IND_T_RAWDATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2048 }},
    {.tlv_type = MIPC_SYS_DMF_URC_IND_T_ATSTRING, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_sys_meta_control_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_META_CONTROL_IND_T_SYSTRACE, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_timeout_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_PROXY_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_IPV4_TOS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_IPV4_TTL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_IPV4_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_IPV6_FLOW_LABEL, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_IPV6_HOP_LIMIT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_IPV6_TCLASS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_RCV_WSCALE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_SND_WSCALE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_WSCALE_OK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_SND_WINDOW, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_RCV_WINDOW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_SND_NXT_SEQ, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_TCP_RCV_NXT_SEQ, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_CURRENT_CYCLE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_SEND_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_RECV_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_SHORT_RRC_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_HBA_TIMEOUT_IND_T_HITCHHIKE_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_hba_hw_filter_src_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_HBA_HW_FILTER_SRC_STATE_IND_T_HW_FILTER_SRC_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_dmf_em_icd_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_DMF_EM_ICD_INFO_IND_T_DMF_RAWDATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16384 }},
};

static mipc_tlv_checker_info_t mipc_sys_reboot_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_REBOOT_CMD_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SYS_REBOOT_CMD_T_TIMEOUT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SYS_REBOOT_CMD_T_SBP_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_config_dipc_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_CONFIG_DIPC_CMD_T_CLASS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SYS_SET_CONFIG_DIPC_CMD_T_TYPE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SYS_SET_CONFIG_DIPC_CMD_T_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_config_dipc_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_CONFIG_DIPC_RSP_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_config_needed_to_update_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_CONFIG_NEEDED_TO_UPDATE_CMD_T_CLASS, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SYS_CONFIG_NEEDED_TO_UPDATE_CMD_T_TYPE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_config_dipc_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_CONFIG_DIPC_CMD_T_CLASS, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SYS_GET_CONFIG_DIPC_CMD_T_TYPE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sys_get_config_dipc_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_GET_CONFIG_DIPC_RSP_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_sys_set_time_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SYS_SET_TIME_CMD_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_SYS_SET_TIME_CMD_T_TZ_VALID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_apn_set_ia_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_PDP_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_ROAMING_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_AUTH_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_USERID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_PASSWORD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_BEARER_BITMASK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_IA_REQ_T_COMPRESSION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_apn_set_ia_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_SET_IA_CNF_T_IA_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_IA_CNF_T_IA_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 12 }},
    {.tlv_type = MIPC_APN_SET_IA_CNF_T_IA_TLV_ARRAY, .option = 0x6400, .array_num = 3, .check_item = { .fixed.fixed_value = 240 }},
};

static mipc_tlv_checker_info_t mipc_apn_get_ia_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_GET_IA_CNF_T_IA_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_GET_IA_CNF_T_IA_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 12 }},
    {.tlv_type = MIPC_APN_GET_IA_CNF_T_IA_TLV_ARRAY, .option = 0x2400, .array_num = 3, .check_item = { .fixed.fixed_value = 240 }},
};

static mipc_tlv_checker_info_t mipc_apn_add_profile_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_PLMN_ID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_APN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2147483648 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_PDP_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_ROAMING_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_AUTH_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_USERID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_PASSWORD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_BEARER_BITMASK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_COMPRESSION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_REQ_T_ENABLED, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_apn_add_profile_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_ADD_PROFILE_CNF_T_APN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_CNF_T_APN_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 25 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_CNF_T_APN_TLV_ARRAY, .option = 0x6400, .array_num = 10, .check_item = { .fixed.fixed_value = 260 }},
};

static mipc_tlv_checker_info_t mipc_apn_list_profile_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_LIST_PROFILE_CNF_T_APN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_LIST_PROFILE_CNF_T_APN_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 25 }},
    {.tlv_type = MIPC_APN_LIST_PROFILE_CNF_T_APN_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 260 }},
};

static mipc_tlv_checker_info_t mipc_apn_del_profile_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_DEL_PROFILE_REQ_T_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_apn_del_profile_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_DEL_PROFILE_CNF_T_APN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_DEL_PROFILE_CNF_T_APN_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 25 }},
    {.tlv_type = MIPC_APN_DEL_PROFILE_CNF_T_APN_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 260 }},
};

static mipc_tlv_checker_info_t mipc_apn_set_profile_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_SET_PROFILE_STATUS_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_apn_list_md_profile_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_LIST_MD_PROFILE_CNF_T_APN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_LIST_MD_PROFILE_CNF_T_APN_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 21 }},
    {.tlv_type = MIPC_APN_LIST_MD_PROFILE_CNF_T_APN_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 260 }},
};

static mipc_tlv_checker_info_t mipc_apn_set_op12_apn_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_APN_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_CLASS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_NETWORK_IDENTIFIER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_PDP_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_APN_BEARER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 10 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_ENABLED, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_REQ_T_APN_TIMER, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_apn_set_op12_apn_timer_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_SET_OP12_APN_TIMER_REQ_T_APN_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_TIMER_REQ_T_MAX_CONN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_TIMER_REQ_T_MAX_CONN_T, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_TIMER_REQ_T_WAIT_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_SET_OP12_APN_TIMER_REQ_T_THROTTLE_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_apn_add_profile_list_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_ADD_PROFILE_LIST_REQ_T_PROFILE_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_LIST_REQ_T_PROFILE_TLV_ARRAY, .option = 0x6400, .array_num = 20, .check_item = { .fixed.fixed_value = 284 }},
};

static mipc_tlv_checker_info_t mipc_apn_add_profile_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_ADD_PROFILE_LIST_CNF_T_PROFILE_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_ADD_PROFILE_LIST_CNF_T_PROFILE_TLV_ARRAY, .option = 0x6400, .array_num = 20, .check_item = { .fixed.fixed_value = 284 }},
};

static mipc_tlv_checker_info_t mipc_apn_set_ia_md_prefer_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_SET_IA_MD_PREFER_REQ_T_IA_MD_PREFER, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_apn_op12_chg_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_APN_OP12_CHG_IND_T_APN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_APN_OP12_CHG_IND_T_APN_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 14 }},
    {.tlv_type = MIPC_APN_OP12_CHG_IND_T_APN_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 136 }},
};

static mipc_tlv_checker_info_t mipc_data_act_call_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_APN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2147483648 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_PDP_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_ROAMING_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_AUTH_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_USERID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_PASSWORD, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_IPV4V6_FALLBACK, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_BEARER_BITMASK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_REUSE_FLAG, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_IF_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_APN_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_URSP_TRAFFIC_DESC, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 672 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_URSP_UE_LOCAL_CONF, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 108 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_URSP_EVAL_FLAG, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_IF_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_IS_HANDOVER, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_MBS_SESSION_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 36 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_REQ_T_TSN_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8212 }},
};

static mipc_tlv_checker_info_t mipc_data_act_call_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PDP_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_GW_V4, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_GW_V6, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_MTU_V4, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_MTU_V6, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_INTERFACE_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_P_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_FB_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_IPv4_NETMASK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_IPv6_NETMASK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_TRANS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_RAN_INFO, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_BEARER_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_IM_CN_SIGNALLING_FLAG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_MTU_ETHERNET, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_DNS_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_PCSCF_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_MBS_SESSION_UPDATE_IND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 80 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_CELL_ID_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_CNF_T_TAC_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_data_deact_call_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_DEACT_CALL_REQ_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_DEACT_CALL_REQ_T_DEACT_REASON, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_data_deact_call_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_DEACT_CALL_CNF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_call_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_CALL_REQ_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_call_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PDP_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_GW_V4, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_GW_V6, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_MTU_V4, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_MTU_V6, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_INTERFACE_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_IPv4_NETMASK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_IPv6_NETMASK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_APN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2147483648 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_TRANS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_RAN_INFO, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_BEARER_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_IM_CN_SIGNALLING_FLAG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_QFI, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_MTU_ETHERNET, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_DNS_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_CALL_CNF_T_PCSCF_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_data_set_packet_filter_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_REQ_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_REQ_T_FILTER_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_REQ_T_FILTER_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_REQ_T_FILTER_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 388 }},
};

static mipc_tlv_checker_info_t mipc_data_set_packet_filter_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_CNF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_CNF_T_FILTER_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_CNF_T_FILTER_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_DATA_SET_PACKET_FILTER_CNF_T_FILTER_TLV_ARRAY, .option = 0x6400, .array_num = 16, .check_item = { .fixed.fixed_value = 388 }},
};

static mipc_tlv_checker_info_t mipc_data_get_packet_filter_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_PACKET_FILTER_REQ_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_packet_filter_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_PACKET_FILTER_CNF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PACKET_FILTER_CNF_T_FILTER_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PACKET_FILTER_CNF_T_FILTER_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_DATA_GET_PACKET_FILTER_CNF_T_FILTER_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 388 }},
};

static mipc_tlv_checker_info_t mipc_data_get_pco_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_PCO_REQ_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PCO_REQ_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_GET_PCO_REQ_T_APN_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PCO_REQ_T_PCO_IE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_data_get_pco_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_PCO_CNF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PCO_CNF_T_PCO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PCO_CNF_T_PCO_LIST, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 88 }},
    {.tlv_type = MIPC_DATA_GET_PCO_CNF_T_PCO_TLV_ARRAY, .option = 0x2400, .array_num = 20, .check_item = { .fixed.fixed_value = 88 }},
};

static mipc_tlv_checker_info_t mipc_data_set_data_allow_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_DATA_ALLOW_REQ_T_CLEAR, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_md_data_call_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_MD_DATA_CALL_LIST_CNF_T_CID_LIST, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 200 }},
};

static mipc_tlv_checker_info_t mipc_data_set_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_MOBILE_DATA, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_DATA_ROAMING, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_VOLTE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_IMS_TEST_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_DATA_DOMESTIC_ROAMING, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_DATA_INTERNATIONAL_ROAMING, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_CONFIG_REQ_T_DEFAULT_DATA_SIM_CARD, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_config_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_CONFIG_CNF_T_MOBILE_DATA, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_GET_CONFIG_CNF_T_DATA_ROAMING, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_GET_CONFIG_CNF_T_VOLTE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_GET_CONFIG_CNF_T_IMS_TEST_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_GET_CONFIG_CNF_T_DATA_DOMESTIC_ROAMING, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_GET_CONFIG_CNF_T_DATA_INTERNATIONAL_ROAMING, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_data_abort_call_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_ABORT_CALL_REQ_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
};

static mipc_tlv_checker_info_t mipc_data_get_call_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_REQ_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_REQ_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_call_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_CNF_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_CNF_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_CNF_T_ESTBLISHED_TIME, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_CNF_T_END_TIME, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_DATA_GET_CALL_INFO_CNF_T_REJECT_CAUSE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_pdp_cid_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_PDP_CID_CNF_T_MIN_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_PDP_CID_CNF_T_MAX_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_retry_timer_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_RETRY_TIMER_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_RETRY_TIMER_REQ_T_APN_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
};

static mipc_tlv_checker_info_t mipc_data_retry_timer_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_RETRY_TIMER_CNF_T_RETRY_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_RETRY_TIMER_CNF_T_RETRY_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_set_link_capacity_reporting_criteria_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_HYSTERESIS_MS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_HYSTERESIS_DL_KBPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_HYSTERESIS_UL_KBPS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_THRESHOLD_DL_KBPS_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_THRESHOLD_DL_KBPS_LIST, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_THRESHOLD_UL_KBPS_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_THRESHOLD_UL_KBPS_LIST, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ_T_ACCESS_NETWORK, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_dedicate_bearer_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_DEDICATE_BEARER_INFO_REQ_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_dedicate_bearer_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_DEDICATE_BEARER_INFO_CNF_T_CONTEXT_TLV_ARRAY, .option = 0x2400, .array_num = 200, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_data_get_qos_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_QOS_REQ_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_qos_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_QOS_CNF_T_QOS_TLV_ARRAY, .option = 0x2400, .array_num = 200, .check_item = { .fixed.fixed_value = 28 }},
};

static mipc_tlv_checker_info_t mipc_data_get_tft_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_TFT_REQ_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_tft_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_TFT_CNF_T_TFT_TLV_ARRAY, .option = 0x2400, .array_num = 200, .check_item = { .fixed.fixed_value = 136 }},
};

static mipc_tlv_checker_info_t mipc_data_set_lgdcont_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_LGDCONT_REQ_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_SET_LGDCONT_REQ_T_APN_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_LGDCONT_REQ_T_REQUEST_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_DATA_SET_LGDCONT_REQ_T_RAT_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_data_set_nssai_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_NSSAI_REQ_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_SET_NSSAI_REQ_T_APN_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_NSSAI_REQ_T_SNSSAI, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_data_keepalive_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_KEEPALIVE_REQ_T_STOP_KEEPALIVE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_KEEPALIVE_REQ_T_START_KEEPALIVE, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 156 }},
};

static mipc_tlv_checker_info_t mipc_data_keepalive_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_KEEPALIVE_CNF_T_SESSION_HANDLE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_KEEPALIVE_CNF_T_STATUS_CODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_data_get_dsda_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_DSDA_STATE_CNF_T_DSDA_ALLOWED, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_GET_DSDA_STATE_CNF_T_DSDA_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_GET_DSDA_STATE_CNF_T_IS_DR_DSDA, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_GET_DSDA_STATE_CNF_T_IS_DR_DSDS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_data_get_5gqos_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_5GQOS_REQ_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_5gqos_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_5GQOS_CNF_T_QOS_TLV_ARRAY, .option = 0x2400, .array_num = 200, .check_item = { .fixed.fixed_value = 56 }},
};

static mipc_tlv_checker_info_t mipc_data_set_psi_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_PSI_REQ_T_ACTION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_SET_PSI_REQ_T_PSI, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_PSI_REQ_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_SET_PSI_REQ_T_APN_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_set_psi_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_PSI_CNF_T_PSI, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_nssai_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_NSSAI_REQ_T_NSSAI_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_REQ_T_PLMN_ID, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_data_get_nssai_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_DEFAULT_CONFIGURED_NSSAI_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_DEFAULT_CONFIGURED_NSSAI_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_REJECTED_NSSAI_3GPP_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_REJECTED_NSSAI_3GPP_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_REJECTED_NSSAI_NON3GPP_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_REJECTED_NSSAI_NON3GPP_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_CONFIGURED_NSSAI_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_CONFIGURED_NSSAI_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_ALLOWED_NSSAI_3GPP_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_ALLOWED_NSSAI_3GPP_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_ALLOWED_NSSAI_NON3GPP_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_ALLOWED_NSSAI_NON3GPP_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_PREFERRED_NSSAI_3GPP_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_PREFERRED_NSSAI_3GPP_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_PREFERRED_NSSAI_NON3GPP_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_NSSAI_CNF_T_PREFERRED_NSSAI_NON3GPP_TLV_ARRAY, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_data_get_ursp_route_profile_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_URSP_ROUTE_PROFILE_REQ_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_ursp_route_profile_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_URSP_ROUTE_PROFILE_CNF_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_URSP_ROUTE_PROFILE_CNF_T_EST_REQ_PARAM, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 108 }},
    {.tlv_type = MIPC_DATA_GET_URSP_ROUTE_PROFILE_CNF_T_ATTR, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_URSP_ROUTE_PROFILE_CNF_T_ROUTE_SUPP_PROFILE_LIST_NUM, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_URSP_ROUTE_PROFILE_CNF_T_ROUTE_SUPP_PROFILE_TLV_ARRAY, .option = 0x3000, .array_num = 200, .check_item = { .multiple.multiple_value = 9 }},
};

static mipc_tlv_checker_info_t mipc_data_set_ursp_preconf_ue_policy_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_URSP_PRECONF_UE_POLICY_REQ_T_PLMN_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_DATA_SET_URSP_PRECONF_UE_POLICY_REQ_T_RULE_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_URSP_PRECONF_UE_POLICY_REQ_T_RULE_TLV_ARRAY, .option = 0x6400, .array_num = 8, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_data_get_ursp_ue_policy_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_URSP_UE_POLICY_REQ_T_PLMN_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_data_get_ursp_ue_policy_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_URSP_UE_POLICY_CNF_T_PLMN_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_DATA_GET_URSP_UE_POLICY_CNF_T_RULE_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_GET_URSP_UE_POLICY_CNF_T_RULE_TLV_ARRAY, .option = 0x2400, .array_num = 8, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_GET_URSP_UE_POLICY_CNF_T_RAW_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1024 }},
};

static mipc_tlv_checker_info_t mipc_data_set_reserved_if_id_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_RESERVED_IF_ID_REQ_T_IF_ID_LIST, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_data_set_pco_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_PCO_REQ_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_SET_PCO_REQ_T_APN_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_PCO_REQ_T_PCO_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 88 }},
};

static mipc_tlv_checker_info_t mipc_data_set_paging_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_PAGING_REQ_T_PAGING_RESTRICTIONS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_DATA_SET_PAGING_REQ_T_CID, .option = 0xa001, .array_num = 50, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_get_paging_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_PAGING_CNF_T_PAGING_RESTRICTIONS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_DATA_GET_PAGING_CNF_T_CID, .option = 0xa001, .array_num = 50, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_mod_call_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MOD_CALL_REQ_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_REQ_T_MBS_SESSION_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 36 }},
};

static mipc_tlv_checker_info_t mipc_data_mod_call_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MOD_CALL_CNF_T_CID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_CNF_T_MBS_SESSION_UPDATE_IND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 80 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_CNF_T_CELL_ID_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_CNF_T_TAC_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_data_set_tsn_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_TSN_REQ_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_SET_TSN_REQ_T_PMIC, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8192 }},
    {.tlv_type = MIPC_DATA_SET_TSN_REQ_T_MT_PMIC_TRACK_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_set_tsn_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_SET_TSN_CNF_T_PMIC, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8192 }},
};

static mipc_tlv_checker_info_t mipc_data_get_ursp_ue_policy_plmn_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_GET_URSP_UE_POLICY_PLMN_LIST_CNF_T_PLMN_TLV_ARRAY, .option = 0x2400, .array_num = 1024, .check_item = { .fixed.fixed_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_data_act_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PDP_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_GW_V4, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_GW_V6, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_MTU_V4, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_MTU_V6, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_INTERFACE_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_P_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_FB_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_TRANS_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_IPv4_NETMASK, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_RAN_INFO, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_BEARER_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_IM_CN_SIGNALLING_FLAG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_MTU_ETHERNET, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_DNS_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_PCSCF_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_IND_T_IS_DEDICATED_BEARER, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_data_deact_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_DEACT_CALL_IND_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_DEACT_CALL_IND_T_RES, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_DEACT_CALL_IND_T_NEW_RES, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_mod_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PDP_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V4_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V4_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V4_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V4_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V4_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V6_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V6_0, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V6_1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V6_2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_V6_3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_GW_V4, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_GW_V6, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_MTU_V4, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_MTU_V6, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_INTERFACE_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_TRANS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_RAN_INFO, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_BEARER_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_IM_CN_SIGNALLING_FLAG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_P_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_MTU_ETHERNET, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_CHANGE_REASON, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_EVENT_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_DNS_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_IPV4_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PCSCF_IPV6_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_IS_DEDICATED_BEARER, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_MT_PMIC_TRACK_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_CALL_IND_T_PMIC, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8192 }},
};

static mipc_tlv_checker_info_t mipc_data_mod_pco_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MOD_PCO_IND_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_PCO_IND_T_PCO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_PCO_IND_T_PCO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_DATA_MOD_PCO_IND_T_PCO_TLV_ARRAY, .option = 0x2400, .array_num = 20, .check_item = { .fixed.fixed_value = 88 }},
};

static mipc_tlv_checker_info_t mipc_data_wwan_act_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_INTERFACE_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_APN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2147483648 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_PDP_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V4_MTU, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V6_MTU, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V4_ADDR_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V4_ADDR_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V6_ADDR_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V6_ADDR_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_DNS_V4_ADDR_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_DNS_V4_ADDR_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_DNS_V6_ADDR_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_DNS_V6_ADDR_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V4_ADDR_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_V6_ADDR_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_DNS_V4_ADDR_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_DATA_WWAN_ACT_CALL_IND_T_DNS_V6_ADDR_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_data_wwan_deact_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_WWAN_DEACT_CALL_IND_T_INTERFACE_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_DEACT_CALL_IND_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_WWAN_DEACT_CALL_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_WWAN_DEACT_CALL_IND_T_APN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2147483648 }},
};

static mipc_tlv_checker_info_t mipc_data_md_act_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MD_ACT_CALL_IND_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MD_ACT_CALL_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_MD_ACT_CALL_IND_T_APN_IDX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_md_deact_call_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MD_DEACT_CALL_IND_T_CID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_iwlan_priority_list_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_CMD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 8 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_TYPE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_SETUP_PRIORITY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_CELLULAR_PRIORITY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_WIFI_PRIORITY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_DESCRIPTION, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_RAT_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_IWLAN_PRIORITY_LIST_IND_T_RAT_LIST, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_data_link_capacity_estimate_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_LINK_CAPACITY_ESTIMATE_IND_T_DL_KBPS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_LINK_CAPACITY_ESTIMATE_IND_T_UL_KBPS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_LINK_CAPACITY_ESTIMATE_IND_T_SECOND_DL_KBPS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_LINK_CAPACITY_ESTIMATE_IND_T_SECOND_UL_KBPS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_nw_limit_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_NW_LIMIT_IND_T_STATE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_timer_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_TIMER_IND_T_SRC_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_DATA_TIMER_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_DATA_TIMER_IND_T_CAUSE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_TIMER_IND_T_TIMER_STATE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_TIMER_IND_T_EXPIRE_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_keepalive_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_KEEPALIVE_STATUS_IND_T_SESSION_HANDLE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_KEEPALIVE_STATUS_IND_T_STATUS_CODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_data_mobile_data_usage_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_MOBILE_DATA_USAGE_IND_T_TX_BYTES, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOBILE_DATA_USAGE_IND_T_TX_PACKETS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOBILE_DATA_USAGE_IND_T_RX_BYTES, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_MOBILE_DATA_USAGE_IND_T_RX_PACKETS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_network_reject_cause_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_NETWORK_REJECT_CAUSE_IND_T_EMM_CAUSE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_NETWORK_REJECT_CAUSE_IND_T_ESM_CAUSE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_NETWORK_REJECT_CAUSE_IND_T_EVENT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_dsda_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_DSDA_STATE_IND_T_DSDA_ALLOWED, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_DSDA_STATE_IND_T_DSDA_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_DSDA_STATE_IND_T_IS_DR_DSDA, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_DATA_DSDA_STATE_IND_T_IS_DR_DSDS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_data_umts_ps_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_UMTS_PS_STATE_IND_T_CONN_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_data_retry_timer_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_RETRY_TIMER_IND_T_APN_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
};

static mipc_tlv_checker_info_t mipc_data_ursp_reeval_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_URSP_REEVAL_IND_T_ID_LIST_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_URSP_REEVAL_IND_T_ID_LIST, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 200 }},
    {.tlv_type = MIPC_DATA_URSP_REEVAL_IND_T_EVENT, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2147483647 }},
};

static mipc_tlv_checker_info_t mipc_data_ursp_ue_policy_chg_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_URSP_UE_POLICY_CHG_IND_T_PLMN_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_DATA_URSP_UE_POLICY_CHG_IND_T_EVENT, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2147483647 }},
};

static mipc_tlv_checker_info_t mipc_data_pdn_nw_cause_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_PDN_NW_CAUSE_IND_T_EMM_CAUSE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_PDN_NW_CAUSE_IND_T_ESM_CAUSE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_PDN_NW_CAUSE_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
};

static mipc_tlv_checker_info_t mipc_data_paging_restrictions_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_PAGING_RESTRICTIONS_IND_T_PAGING_RESTRICT_RESULT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_data_tsn_time_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_TSN_TIME_IND_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_TSN_TIME_IND_T_NW_REF_TIME, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 28 }},
};

static mipc_tlv_checker_info_t mipc_data_act_call_ntf_tlv_checker_info[] = {
    {.tlv_type = MIPC_DATA_ACT_CALL_NTF_T_CID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_DATA_ACT_CALL_NTF_T_RESPONSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_internal_open_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_OPEN_REQ_T_VERSION, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_OPEN_REQ_T_CLIENT_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 160 }},
    {.tlv_type = MIPC_INTERNAL_OPEN_REQ_T_USIR_SUPPORT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_INTERNAL_OPEN_REQ_T_IS_META, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_internal_open_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_OPEN_CNF_T_VERSION, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_OPEN_CNF_T_TIMEOUT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_test_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_TEST_CNF_T_TEST, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_register_ind_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_REGISTER_IND_REQ_T_MSG_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_REGISTER_IND_REQ_T_MSG_ID_GROUP, .option = 0xa002, .array_num = 256, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_unregister_ind_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_UNREGISTER_IND_REQ_T_MSG_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_UNREGISTER_IND_REQ_T_MSG_ID_GROUP, .option = 0xa002, .array_num = 256, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_UNREGISTER_IND_REQ_T_UNREG_ALL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_internal_register_cmd_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_REGISTER_CMD_REQ_T_MSG_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_unregister_cmd_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_UNREGISTER_CMD_REQ_T_MSG_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_set_filter_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_SET_FILTER_REQ_T_STRUCT, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 68 }},
};

static mipc_tlv_checker_info_t mipc_internal_set_filter_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_SET_FILTER_CNF_T_STRUCT, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_internal_reset_filter_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_RESET_FILTER_REQ_T_STRUCT, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_internal_reset_filter_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_RESET_FILTER_CNF_T_STRUCT, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_internal_eif_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_EIF_REQ_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIF_REQ_T_CMD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8 }},
    {.tlv_type = MIPC_INTERNAL_EIF_REQ_T_NEW_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_INTERNAL_EIF_REQ_T_OLD_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_INTERNAL_EIF_REQ_T_ADDRESS_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_internal_set_long_standby_monitor_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_internal_set_long_standby_monitor_time_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_TIME_REQ_T_MINUTE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_TIME_REQ_T_SECOND, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_set_long_standby_monitor_warning_ratio_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_WARNING_RATIO_REQ_T_M, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_WARNING_RATIO_REQ_T_X, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_WARNING_RATIO_REQ_T_Y, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_WARNING_RATIO_REQ_T_Z, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_eif_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_CMD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_CAUSE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_MTU, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_NET_V4_ADDR_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_NET_V4_ADDR_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_NET_V6_ADDR_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_NET_V6_ADDR_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 8 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_PDP_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_NET_V4_ADDR_TLV_ARRAY, .option = 0x6400, .array_num = 4, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_INTERNAL_EIF_IND_T_NET_V6_ADDR_TLV_ARRAY, .option = 0x6400, .array_num = 4, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_internal_ho_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_PROGRESS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_SRC_RAN, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_DST_RAN, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_IS_SUCC, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_V4_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_V6_ADDR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_INTERNAL_HO_IND_T_TRANS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_mipc_pending_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_MIPC_PENDING_IND_T_TRACK_TLV_ARRAY, .option = 0x2400, .array_num = 256, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_internal_eipport_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_EIPPORT_CMD_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_CMD_T_ACTION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_CMD_T_IFID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_CMD_T_ADDR, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_CMD_T_PROTO, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_CMD_T_PORT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_eipport_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_EIPPORT_RSP_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_RSP_T_ACTION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_INTERNAL_EIPPORT_RSP_T_RESULT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_internal_eipspi_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_ACTION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_SRC_ADDR, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_DST_ADDR, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_PROTO, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 50, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_MIN_SPI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_MAX_SPI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_CMD_T_SPI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_eipspi_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_EIPSPI_RSP_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_RSP_T_ACTION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_EIPSPI_RSP_T_SPI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_internal_multi_eipspi_free_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD_T_MULTI_FREE_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD_T_SRC_ADDR_TLV_ARRAY, .option = 0x7000, .array_num = 50, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD_T_DST_ADDR_TLV_ARRAY, .option = 0x7000, .array_num = 50, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD_T_PROTO_LIST, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 50 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD_T_SPI_LIST, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 50 }},
};

static mipc_tlv_checker_info_t mipc_internal_multi_eipspi_free_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_RSP_T_TRANSID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_RSP_T_MULTI_FREE_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_RSP_T_SPI_LIST, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 50 }},
    {.tlv_type = MIPC_INTERNAL_MULTI_EIPSPI_FREE_RSP_T_STATUS_LIST, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 50 }},
};

static mipc_tlv_checker_info_t mipc_internal_inject_tst_ntf_tlv_checker_info[] = {
    {.tlv_type = MIPC_INTERNAL_INJECT_TST_NTF_T_MODULE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_INTERNAL_INJECT_TST_NTF_T_INDEX, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_INTERNAL_INJECT_TST_NTF_T_INJECT_STRING, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_radio_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_RADIO_STATE_CNF_T_SW_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_RADIO_STATE_CNF_T_HW_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_radio_state_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_RADIO_STATE_REQ_T_SW_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_RADIO_STATE_REQ_T_CAUSE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_NW_SET_RADIO_STATE_REQ_T_HW_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_radio_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_RADIO_STATE_CNF_T_SW_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_RADIO_STATE_CNF_T_HW_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_register_state_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_FORMAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_OPER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_ACT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_ARFCN, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_RAT_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_BLOCK, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_CTRL_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_SEARCH_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_REQ_T_RSRP, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_register_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_STATE, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 38 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_NW_ERR, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_DATA_SPEED, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_NW_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_ROAMING_TEXT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_NW_LONG_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_SET_REGISTER_STATE_CNF_T_PS_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_register_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_STATE, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 38 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_NW_ERR, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_DATA_SPEED, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_NW_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_ROAMING_TEXT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_FAIL_CAUSE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_NW_LONG_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_GET_REGISTER_STATE_CNF_T_PS_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_plmn_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PLMN_LIST_CNF_T_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PLMN_LIST_CNF_T_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 15 }},
    {.tlv_type = MIPC_NW_GET_PLMN_LIST_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PLMN_LIST_CNF_T_EXTEND_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 68 }},
    {.tlv_type = MIPC_NW_GET_PLMN_LIST_CNF_T_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 144 }},
    {.tlv_type = MIPC_NW_GET_PLMN_LIST_CNF_T_EXTEND_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 236 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ps_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PS_REQ_T_ACTION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_PS_REQ_T_CTRL_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ps_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PS_CNF_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_PS_CNF_T_DATA_SPEED, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_SET_PS_CNF_T_NW_FREQUENCY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PS_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ps_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_DATA_SPEED, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_NW_FREQUENCY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_REG_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 35 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_CELL_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_NSA_EXT_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 184 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_GSM_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_UMTS_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 156 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_LTE_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_NR_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 184 }},
    {.tlv_type = MIPC_NW_GET_PS_CNF_T_CDMA_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 42 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_signal_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SIGNAL_REQ_T_SIGNAL_STRENGTH_INTERVAL, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REQ_T_RSSI_THRESHOLD, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REQ_T_ERR_RATE_THRESHOLD, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REQ_T_RSRP_THRESHOLD, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REQ_T_SNR_THRESHOLD, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REQ_T_THRESHOLD_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_signal_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RSSI, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_ERR_RATE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RSRP, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_SNR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_SIGNAL_STRENGTH_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RSSI_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_ERR_RATE_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RSRP_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_SNR_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_SIGNAL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_GSM_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_UMTS_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_LTE_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_NR_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 28 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RAW_SIGNAL_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 53 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RAW_SIGNAL_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_CDMA_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_CNF_T_RAW_SIGNAL_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 2, .check_item = { .fixed.fixed_value = 53 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_signal_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RSSI, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_ERR_RATE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RSRP, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_SNR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_SIGNAL_STRENGTH_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RSSI_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_ERR_RATE_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RSRP_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_SNR_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_SIGNAL_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_GSM_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_UMTS_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_LTE_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_NR_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 28 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RAW_SIGNAL_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 53 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RAW_SIGNAL_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_CDMA_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_LTE_SIGNAL_V1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 25 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_NR_SIGNAL_V1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 49 }},
    {.tlv_type = MIPC_NW_GET_SIGNAL_CNF_T_RAW_SIGNAL_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 2, .check_item = { .fixed.fixed_value = 53 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_preferred_provider_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PREFERRED_PROVIDER_CNF_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PREFERRED_PROVIDER_CNF_T_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 15 }},
    {.tlv_type = MIPC_NW_GET_PREFERRED_PROVIDER_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PREFERRED_PROVIDER_CNF_T_NW_PROVIDER_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 144 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_preferred_provider_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_REQ_T_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_REQ_T_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 15 }},
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_REQ_T_NW_PROVIDER_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 144 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_preferred_provider_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_CNF_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_CNF_T_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 15 }},
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PREFERRED_PROVIDER_CNF_T_NW_PROVIDER_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 144 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_home_provider_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_HOME_PROVIDER_REQ_T_PROVIDER, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 144 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_home_provider_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_HOME_PROVIDER_CNF_T_PROVIDER, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 144 }},
    {.tlv_type = MIPC_NW_SET_HOME_PROVIDER_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_home_provider_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_HOME_PROVIDER_CNF_T_PROVIDER, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 144 }},
    {.tlv_type = MIPC_NW_GET_HOME_PROVIDER_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ia_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_PDP_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_AUTH_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_USERID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_PASSWORD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_GET_IA_STATUS_CNF_T_CAUSE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nitz_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NITZ_CNF_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_GET_NITZ_CNF_T_TZ_VALID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_idle_hint_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_IDLE_HINT_REQ_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_SET_IDLE_HINT_REQ_T_PARAM_1, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_IDLE_HINT_REQ_T_PARAM_2, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_idle_hint_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_IDLE_HINT_CNF_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_SET_IDLE_HINT_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_idle_hint_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_IDLE_HINT_CNF_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_GET_IDLE_HINT_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_IDLE_HINT_CNF_T_R8_FD_STATUS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_base_stations_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_GSM_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_GSM_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 33 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_UMTS_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_UMTS_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 29 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_TDSCDMA_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_TDSCDMA_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_LTE_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_LTE_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 53 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_CDMA_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_CDMA_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 42 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_NR_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_NR_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 57 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_LTE_CELL_LIST_V1, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 181 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_NR_CELL_LIST_V1, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 205 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_GSM_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_UMTS_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 156 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_TDSCDMA_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_LTE_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_CDMA_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 42 }},
    {.tlv_type = MIPC_NW_GET_BASE_STATIONS_CNF_T_NR_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 184 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_location_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LOCATION_INFO_CNF_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_GET_LOCATION_INFO_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_rat_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_RAT_REQ_T_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_RAT_REQ_T_PREFER_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_RAT_REQ_T_BIT_RAT, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_provider_name_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_REQ_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_REQ_T_LAC, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_REQ_T_OPTION, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_REQ_T_OPL_INDEX, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_provider_name_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_LAC, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_NW_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_NW_NAME_LONG, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_EONS_NAME, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 120 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_NITZ_NAME, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 120 }},
    {.tlv_type = MIPC_NW_GET_PROVIDER_NAME_CNF_T_TS25_NAME, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 120 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_rat_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_ACT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 7, .min_max.max_value = 14 }},
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_GPRS_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_RAT_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_PREFER_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_LOCK, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_BIT_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_RAT_CNF_T_RADIO_CAPABILITY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_nr_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_NR_REQ_T_NR_OPT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_REQ_T_ACT_OPERATION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cs_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_REG_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_CELL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_GSM_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_UMTS_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 156 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_LTE_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_NR_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 184 }},
    {.tlv_type = MIPC_NW_GET_CS_CNF_T_CDMA_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 42 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_band_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_BAND_MODE_REQ_T_OPTION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_band_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_BAND_MODE_CNF_T_GSM_BAND, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BAND_MODE_CNF_T_UMTS_BAND, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BAND_MODE_CNF_T_LTE_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_GET_BAND_MODE_CNF_T_NR_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_GET_BAND_MODE_CNF_T_NR_NSA_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_band_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_BAND_MODE_REQ_T_GSM_BAND, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_BAND_MODE_REQ_T_UMTS_BAND, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_BAND_MODE_REQ_T_LTE_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_SET_BAND_MODE_REQ_T_NR_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_SET_BAND_MODE_REQ_T_NR_NSA_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_channel_lock_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CHANNEL_LOCK_REQ_T_CH_LOCK_INFO_LIST_COUNT, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CHANNEL_LOCK_REQ_T_CH_LOCK_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 8 }},
    {.tlv_type = MIPC_NW_SET_CHANNEL_LOCK_REQ_T_CH_LOCK_INFO_TLV_ARRAY_V1, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 276 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_pol_capability_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_POL_CAPABILITY_CNF_T_POL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_prefer_rat_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PREFER_RAT_REQ_T_RAT_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PREFER_RAT_REQ_T_RAT_LIST, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_operator_name_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_OPERATOR_NAME_REQ_T_PLMN_ID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_operator_name_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_OPERATOR_NAME_CNF_T_PROVIDER_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 144 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_endc_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_ENDC_CONFIG_REQ_T_ENDC_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_lte_carrier_aggregation_switch_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_LTE_CARRIER_AGGREGATION_SWITCH_REQ_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ps_cs_registration_state_roaming_type_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PS_CS_REGISTRATION_STATE_ROAMING_TYPE_REQ_T_PS_CS_REG_ROAMING_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_lte_carrier_aggregation_switch_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LTE_CARRIER_AGGREGATION_SWITCH_CNF_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_current_band_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CURRENT_BAND_INFO_REQ_T_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_current_band_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CURRENT_BAND_INFO_CNF_T_BAND_LIST_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CURRENT_BAND_INFO_CNF_T_BAND_LIST, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CURRENT_BAND_INFO_CNF_T_BAND_WIDTH_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CURRENT_BAND_INFO_CNF_T_BAND_WIDTH_LIST, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_cell_measurement_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_REQ_T_ACTION, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_REQ_T_LTE_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_REQ_T_NR_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_REQ_T_SCAN_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_cell_measurement_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_CELL_LIST_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 29 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_PLMN_ARRAY, .option = 0x3000, .array_num = 12, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_CELL_LIST_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 29 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_PLMN_ARRAY, .option = 0x3000, .array_num = 12, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_CELL_LIST_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 29 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_PLMN_ARRAY, .option = 0x3000, .array_num = 12, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_CELL_BAND_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 6 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_CELL_BAND_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 6 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 29 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_PLMN_TLV_ARRAY, .option = 0x2000, .array_num = 255, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 29 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_PLMN_TLV_ARRAY, .option = 0x2000, .array_num = 255, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_LTE_CELL_BAND_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 6 }},
    {.tlv_type = MIPC_NW_CELL_MEASUREMENT_CNF_T_NR_CELL_BAND_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_nw_cell_band_white_list_lock_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_LTE_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_NR_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_LTE_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_LTE_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 53 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_NR_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_NR_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 57 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_LTE_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ_T_NR_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 184 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cell_band_bandwidth_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_REQ_T_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cell_band_bandwidth_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NUM_SERVING_CELL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 6 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 6 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_DL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_UL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_DL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_UL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_DL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_UL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_DL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_UL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_DL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_LTE_UL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_DL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF_T_NR_UL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nr_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NR_CNF_T_NR_OPT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_srxlev_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SRXLEV_CNF_T_LTE_SRXLEV_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_NW_GET_SRXLEV_CNF_T_NR_SRXLEV_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_roaming_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_ROAMING_MODE_REQ_T_ROAMING_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_roaming_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_ROAMING_MODE_CNF_T_ROAMING_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_urc_enable_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_URC_ENABLE_REQ_T_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_URC_ENABLE_REQ_T_ENABLE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_suggested_plmn_list_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_REQ_T_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_REQ_T_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_REQ_T_TIMER, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_suggested_plmn_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_CNF_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_CNF_T_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_SUGGESTED_PLMN_LIST_CNF_T_PLMN_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 142 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_search_store_frequency_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ_T_OPER, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ_T_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ_T_PLMN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ_T_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ_T_ARFCN, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ_T_ARFCN_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_select_femtocell_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SELECT_FEMTOCELL_REQ_T_PLMN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_SELECT_FEMTOCELL_REQ_T_ACT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SELECT_FEMTOCELL_REQ_T_CSG_ID, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_config_a2_offset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CONFIG_A2_OFFSET_REQ_T_OFFSET, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CONFIG_A2_OFFSET_REQ_T_THRESH_BOUND, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_config_b1_offset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CONFIG_B1_OFFSET_REQ_T_OFFSET, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CONFIG_B1_OFFSET_REQ_T_THRESH_BOUND, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_report_anbr_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_EBI, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_IS_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_BEARE_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_BITRATE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_PDU_SESSION_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_REPORT_ANBR_REQ_T_EXT_PARAM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_network_event_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_NETWORK_EVENT_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_enable_ca_plus_filter_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_ENABLE_CA_PLUS_FILTER_REQ_T_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_femtocell_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_FEMTOCELL_LIST_CNF_T_CELL_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_FEMTOCELL_LIST_CNF_T_FEMTOCELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_NW_GET_FEMTOCELL_LIST_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_FEMTOCELL_LIST_CNF_T_FEMTOCELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 191 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_pseudo_cell_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PSEUDO_CELL_MODE_REQ_T_APC_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PSEUDO_CELL_MODE_REQ_T_URC_ENABLE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_PSEUDO_CELL_MODE_REQ_T_TIMER, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_pseudo_cell_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_APC_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_URC_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_TIMER, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_CELL_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_PSEUDOCELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_PSEUDO_CELL_INFO_CNF_T_PSEUDOCELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 193 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_roaming_enable_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_ROAMING_ENABLE_REQ_T_PROTOCOL_INDEX, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_ROAMING_ENABLE_REQ_T_DOM_VOICE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_ROAMING_ENABLE_REQ_T_DOM_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_ROAMING_ENABLE_REQ_T_INT_VOICE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_ROAMING_ENABLE_REQ_T_INT_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_ROAMING_ENABLE_REQ_T_LTE_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_roaming_enable_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_PROTOCOL_INDEX, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_DOM_VOICE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_DOM_DATA, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_INT_VOICE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_INT_DATA, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_LTE_DATA, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ROAMING_ENABLE_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_femtocell_system_selection_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_FEMTOCELL_SYSTEM_SELECTION_MODE_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_query_femtocell_system_selection_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_QUERY_FEMTOCELL_SYSTEM_SELECTION_MODE_CNF_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_QUERY_FEMTOCELL_SYSTEM_SELECTION_MODE_CNF_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_nw_ind_report_level_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_NW_IND_REPORT_LEVEL_REQ_T_PS_STATE_LEVEL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NW_IND_REPORT_LEVEL_REQ_T_CS_STATE_LEVEL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_disable_2g_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_DISABLE_2G_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_disable_2g_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_DISABLE_2G_CNF_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_smart_rat_switch_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SMART_RAT_SWITCH_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_NW_SET_SMART_RAT_SWITCH_REQ_T_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_smart_rat_switch_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SMART_RAT_SWITCH_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_smart_rat_switch_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SMART_RAT_SWITCH_CNF_T_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_vss_antenna_conf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_VSS_ANTENNA_CONF_REQ_T_ANTENNA_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_vss_antenna_conf_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_VSS_ANTENNA_CONF_CNF_T_ANTENNA_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_vss_antenna_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_VSS_ANTENNA_INFO_CNF_T_PRIMARY_ANTENNA_RSSI, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_VSS_ANTENNA_INFO_CNF_T_RELATIVE_PHASE, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_VSS_ANTENNA_INFO_CNF_T_SECONDARY_ANTENNA_RSSI, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_VSS_ANTENNA_INFO_CNF_T_PHASE1, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_VSS_ANTENNA_INFO_CNF_T_RX_STATE_0, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_VSS_ANTENNA_INFO_CNF_T_RX_STATE_1, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_radio_capability_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_RADIO_CAPABILITY_REQ_T_RADIO_CAPABILITY, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_RADIO_CAPABILITY_REQ_T_SWITCH_MODE_BY_DATA, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cdma_roaming_preference_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CDMA_ROAMING_PREFERENCE_REQ_T_ROAMING_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cdma_roaming_preference_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CDMA_ROAMING_PREFERENCE_CNF_T_ROAMING_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_barring_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_BARRING_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_RAT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_COUNT_UMTS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_BARRING_LIST_UMTS, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_COUNT_LTE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_BARRING_LIST_LTE, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_COUNT_NR, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_BARRING_LIST_NR, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_BARRING_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_UMTS_BARRING_TLV_ARRAY, .option = 0x2400, .array_num = 4, .check_item = { .fixed.fixed_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_LTE_BARRING_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BARRING_INFO_CNF_T_NR_BARRING_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ehrpd_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_REV, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_MCC, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_MNC, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_NID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_SID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_BS_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_BS_LAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_BS_LONG, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_SECTOR_ID, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EHRPD_INFO_CNF_T_SUBNET_MASK, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_egmss_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_EGMSS_CNF_T_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EGMSS_CNF_T_MCC, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EGMSS_CNF_T_STATUS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EGMSS_CNF_T_CUR_REPORTED_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_EGMSS_CNF_T_IS_HOME_COUNTRY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cache_endc_connect_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CACHE_ENDC_CONNECT_MODE_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CACHE_ENDC_CONNECT_MODE_REQ_T_TIMER1, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CACHE_ENDC_CONNECT_MODE_REQ_T_TIMER2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ps_test_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PS_TEST_MODE_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_SET_PS_TEST_MODE_REQ_T_PROFILE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ps_test_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PS_TEST_MODE_CNF_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_GET_PS_TEST_MODE_CNF_T_PROFILE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_signal_report_criteria_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ_T_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ_T_SIGNAL_MEASUREMENT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ_T_HYSTERESIS_MS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ_T_HYSTERESIS_DB, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ_T_THRESHOLD, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 41 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ecainfo_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_ECAINFO_CNF_T_ECAINFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_activity_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_ACTIVITY_INFO_CNF_T_TX, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 20 }},
    {.tlv_type = MIPC_NW_GET_ACTIVITY_INFO_CNF_T_RX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ACTIVITY_INFO_CNF_T_SLEEP_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ACTIVITY_INFO_CNF_T_IDLE_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ACTIVITY_INFO_CNF_T_NUM_TX_LEVELS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ca_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CA_REQ_T_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CA_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_lte_rrc_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LTE_RRC_STATE_CNF_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_RRC_STATE_CNF_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_lte_1xrtt_cell_list_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LTE_1XRTT_CELL_LIST_REQ_T_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_lte_1xrtt_cell_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LTE_1XRTT_CELL_LIST_CNF_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_1XRTT_CELL_LIST_CNF_T_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 12 }},
    {.tlv_type = MIPC_NW_GET_LTE_1XRTT_CELL_LIST_CNF_T_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ca_link_capability_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CA_LINK_CAPABILITY_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ca_link_capability_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CA_LINK_CAPABILITY_CNF_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CA_LINK_CAPABILITY_CNF_T_BAND_COMBO, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CA_LINK_CAPABILITY_CNF_T_BAND_COMBO_TLV_ARRAY, .option = 0x2400, .array_num = 600, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ca_link_enable_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CA_LINK_ENABLE_STATUS_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 2, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_GET_CA_LINK_ENABLE_STATUS_REQ_T_BAND_COMBO, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ca_link_enable_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CA_LINK_ENABLE_STATUS_CNF_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_tm9_enable_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_TM9_ENABLE_STATUS_CNF_T_TM9_FDD_SETTING, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_TM9_ENABLE_STATUS_CNF_T_TM9_TDD_SETTING, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_tm9_enable_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_TM9_ENABLE_STATUS_REQ_T_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_TM9_ENABLE_STATUS_REQ_T_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_omadm_conf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_OMADM_CONF_REQ_T_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_omadm_conf_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_OMADM_CONF_CNF_T_NODE_VALUE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_omadm_conf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_OMADM_CONF_REQ_T_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_OMADM_CONF_REQ_T_NODE_VALUE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ca_band_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CA_BAND_MODE_REQ_T_PRIMARY_ID, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ca_band_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CA_BAND_MODE_CNF_T_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ca_link_enable_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CA_LINK_ENABLE_STATUS_REQ_T_LIST_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CA_LINK_ENABLE_STATUS_REQ_T_CA_COMB_LIST, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1632 }},
    {.tlv_type = MIPC_NW_SET_CA_LINK_ENABLE_STATUS_REQ_T_LINK_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_lte_data_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_REG_STATE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_MCC, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_MNC, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_CELL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_BAND, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_BANDWIDTH, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_UL_CHANNEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_DL_CHANNEL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_RSSI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_RSRP, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_RSRQ, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_TX_POWER, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_DATA_CNF_T_TX_POWER_V1, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_tuw_timer_length_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_TUW_TIMER_LENGTH_REQ_T_TUW_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_TUW_TIMER_LENGTH_REQ_T_TUW, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_NW_SET_TUW_TIMER_LENGTH_REQ_T_TUW_TLV_ARRAY, .option = 0x2400, .array_num = 3, .check_item = { .fixed.fixed_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_tuw_timer_length_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_TUW_TIMER_LENGTH_CNF_T_TUW1, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_TUW_TIMER_LENGTH_CNF_T_TUW2, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_TUW_TIMER_LENGTH_CNF_T_TUW3, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_5guw_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_5GUW_INFO_CNF_T_DISPLAY_5GUW, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_5GUW_INFO_CNF_T_ON_N77_BAND, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_5GUW_INFO_CNF_T_ON_FR2_BAND, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_5GUW_INFO_CNF_T_5GUW_ALLOWED, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nr_ca_band_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NR_CA_BAND_CNF_T_IS_ENDC, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_CA_BAND_CNF_T_BAND_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_CA_BAND_CNF_T_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 40 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nr_scs_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NR_SCS_CNF_T_SCS, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_physical_channel_configs_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_PHYSICAL_CHANNEL_CONFIGS_CNF_T_PHYSICAL_CHANNEL_CONFIGS_LIST_V1, .option = 0x2400, .array_num = 15, .check_item = { .fixed.fixed_value = 37 }},
};

static mipc_tlv_checker_info_t mipc_nw_os_id_update_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_OS_ID_UPDATE_REQ_T_OS_ID_LIST, .option = 0x2400, .array_num = 15, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_start_network_scan_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_SCAN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_MAX_SEARCH_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_INCREMENTAL_RESULTS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_INCREMENTAL_RESULT_PERIODICITY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_RECORD_LIST, .option = 0x2400, .array_num = 8, .check_item = { .fixed.fixed_value = 172 }},
    {.tlv_type = MIPC_NW_START_NETWORK_SCAN_REQ_T_PLMN_LIST, .option = 0x2400, .array_num = 20, .check_item = { .fixed.fixed_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_pref_nssai_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PREF_NSSAI_REQ_T_PREFERRED_NSSAI_3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_SET_PREF_NSSAI_REQ_T_PREFERRED_NSSAI_NON3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_pref_nssai_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_PREF_NSSAI_CNF_T_PREFERRED_NSSAI_3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_SET_PREF_NSSAI_CNF_T_PREFERRED_NSSAI_NON3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_default_nssai_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_DEFAULT_NSSAI_REQ_T_DEFAULT_CONFIGURED_NSSAI_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_default_nssai_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_DEFAULT_NSSAI_CNF_T_DEFAULT_CONFIGURED_NSSAI_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nssai_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NSSAI_REQ_T_NSSAI_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_REQ_T_PLMN_ID, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nssai_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_DEFAULT_CONFIGURED_NSSAI_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_REJECTED_NSSAI_3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_REJECTED_NSSAI_NON3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_CONFIGURED_NSSAI_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_ALLOWED_NSSAI_3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_ALLOWED_NSSAI_NON3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_PREFERRED_NSSAI_3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_GET_NSSAI_CNF_T_PREFERRED_NSSAI_NON3GPP_LIST, .option = 0x2400, .array_num = 64, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_5guc_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_5GUC_REQ_T_REFRESH_TIMER_LENGTH, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_5GUC_REQ_T_NSA_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_SET_5GUC_REQ_T_SA_BAND, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_SET_5GUC_REQ_T_BW_CHECK_ENABLE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_5GUC_REQ_T_BW_CHECK_THRESHOLD, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_5guc_setting_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_5GUC_SETTING_CNF_T_REFRESH_TIMER_LENGTH, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_5GUC_SETTING_CNF_T_NSA_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_GET_5GUC_SETTING_CNF_T_SA_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 128 }},
    {.tlv_type = MIPC_NW_GET_5GUC_SETTING_CNF_T_BW_CHECK_ENABLE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_5GUC_SETTING_CNF_T_BW_CHECK_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_5guc_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_5GUC_INFO_CNF_T_DISPLAY_5GUC, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_5GUC_INFO_CNF_T_ON_UC_BAND, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_5GUC_INFO_CNF_T_AGG_BW, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_first_plmn_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_FIRST_PLMN_CNF_T_MCC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_FIRST_PLMN_CNF_T_MNC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_ue_usage_setting_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_UE_USAGE_SETTING_REQ_T_USAGE_SETTING, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_ue_usage_setting_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_UE_USAGE_SETTING_CNF_T_USAGE_SETTING, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cag_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CAG_STATUS_REQ_T_STATUS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cag_select_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CAG_SELECT_MODE_REQ_T_SELECT_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CAG_SELECT_MODE_REQ_T_PLMN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_CAG_SELECT_MODE_REQ_T_CAG_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_CAG_SELECT_MODE_REQ_T_ACT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cag_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CAG_LIST_CNF_T_PLMN_CAG_LIST, .option = 0x2400, .array_num = 1920, .check_item = { .fixed.fixed_value = 68 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_allowed_mcc_list_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_ALLOWED_MCC_LIST_REQ_T_ACTION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_ALLOWED_MCC_LIST_REQ_T_ALLOWED_MCC_LIST, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 44 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_edrx_setting_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_EDRX_SETTING_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_EDRX_SETTING_REQ_T_ACT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_NW_SET_EDRX_SETTING_REQ_T_REQUESTED_EDRX_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_EDRX_SETTING_REQ_T_REQUESTED_PAGING_TIME_WINDOW, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_edrx_setting_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_EDRX_SETTING_CNF_T_ACT, .option = 0xa301, .array_num = 6, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_NW_GET_EDRX_SETTING_CNF_T_REQUESTED_EDRX_VALUE, .option = 0xa001, .array_num = 6, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_edrx_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_EDRX_CNF_T_ACT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_NW_SET_EDRX_CNF_T_REQUESTED_EDRX_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_EDRX_CNF_T_NW_PROVIDED_EDRX_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_EDRX_CNF_T_PAGING_TIME_WINDOW, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_power_saving_mode_setting_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_POWER_SAVING_MODE_SETTING_REQ_T_PSM_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_POWER_SAVING_MODE_SETTING_REQ_T_REQUESTED_PERIODIC_TAU_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_POWER_SAVING_MODE_SETTING_REQ_T_REQUESTED_ACTIVE_TIME_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_power_saving_mode_setting_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_POWER_SAVING_MODE_SETTING_CNF_T_PSM_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_POWER_SAVING_MODE_SETTING_CNF_T_REQUESTED_PERIODIC_TAU_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_POWER_SAVING_MODE_SETTING_CNF_T_REQUESTED_ACTIVE_TIME_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_mobile_initiated_connection_only_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_REQ_T_REQUESTED_MICO_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_REQ_T_REQUESTED_ACTIVE_TIME, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_mobile_initiated_connection_only_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_CURRENT_MICO_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_RAAI_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_SPRT_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_ALLOCATED_ACTIVE_TIME, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_mobile_initiated_connection_only_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_REQUESTED_MICO_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_CURRENT_MICO_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_RAAI_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_SPRT_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_REQUESTED_ACTIVE_TIME, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF_T_ALLOCATED_ACTIVE_TIME, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_latest_ca_measurement_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LATEST_CA_MEASUREMENT_CNF_T_LTE_CC_MEAS_LIST, .option = 0x2400, .array_num = 5, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_GET_LATEST_CA_MEASUREMENT_CNF_T_NR_CC_MEAS_LIST, .option = 0x2400, .array_num = 8, .check_item = { .fixed.fixed_value = 56 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_current_cell_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CURRENT_CELL_INFO_CNF_T_CONNECT_ACT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_CURRENT_CELL_INFO_CNF_T_WCDMA_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_GET_CURRENT_CELL_INFO_CNF_T_LTE_CURRENT_CELL_LIST, .option = 0x2400, .array_num = 8, .check_item = { .fixed.fixed_value = 88 }},
    {.tlv_type = MIPC_NW_GET_CURRENT_CELL_INFO_CNF_T_NR_CURRENT_CELL_LIST, .option = 0x2400, .array_num = 8, .check_item = { .fixed.fixed_value = 88 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cag_selection_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CAG_SELECTION_REQ_T_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAG_SELECTION_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAG_SELECTION_REQ_T_CAG_INFO, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 67 }},
    {.tlv_type = MIPC_NW_SET_CAG_SELECTION_REQ_T_ACT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cag_selection_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CAG_SELECTION_CNF_T_ACT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cag_selection_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CAG_SELECTION_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_CAG_SELECTION_CNF_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_CAG_SELECTION_CNF_T_CAG_INFO, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 67 }},
    {.tlv_type = MIPC_NW_GET_CAG_SELECTION_CNF_T_ACT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_auto_update_nitz_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_AUTO_UPDATE_NITZ_REQ_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_auto_update_nitz_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_AUTO_UPDATE_NITZ_CNF_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cap_nrca_option_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_TT_SA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_TF_SA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_FT_SA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_FF_SA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_TT_NSA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_TF_NSA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_FT_NSA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_NRCA_OPTION_REQ_T_FF_NSA_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_cap_bc_list_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TT_SA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TF_SA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FT_SA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FF_SA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TT_NSA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TF_NSA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FT_NSA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FF_NSA_SRC_TLV_ARRAY, .option = 0x2300, .array_num = 100, .check_item = { .min_max.min_value = 1, .min_max.max_value = 35 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TT_SA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TF_SA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FT_SA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FF_SA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TT_NSA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_TF_NSA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FT_NSA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_FF_NSA_OPTION_TLV_ARRAY, .option = 0xa301, .array_num = 100, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_CAP_BC_LIST_REQ_T_IS_XML_PARSING_DONE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_congestion_cfg_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CONGESTION_CFG_REQ_T_NW_CONGESTION_CFG, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 52 }},
    {.tlv_type = MIPC_NW_CONGESTION_CFG_REQ_T_NW_CONGESTION_CFG_V1, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 88 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_enwcfginfo_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_ENWCFGINFO_CNF_T_4X4MINO_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ENWCFGINFO_CNF_T_256QAM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_ENWCFGINFO_CNF_T_64QAM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_barring_rlf_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_BARRING_RLF_CONFIG_REQ_T_THRESHOLD, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_BARRING_RLF_CONFIG_REQ_T_WATCH_PERIOD, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_BARRING_RLF_CONFIG_REQ_T_BARRING_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_endc_deact_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_ENDC_DEACT_REQ_T_DEACTIVATE_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_ENDC_DEACT_REQ_T_ALLOW_SCG_ADD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_ENDC_DEACT_REQ_T_SEND_FAKE_A2_EVENT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_endc_deact_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_ENDC_DEACT_CNF_T_DEACTIVATE_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_ENDC_DEACT_CNF_T_ALLOW_SCG_ADD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_ENDC_DEACT_CNF_T_SEND_FAKE_A2_EVENT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_sa_silence_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_SA_SILENCE_REQ_T_SILENCE_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_sa_silence_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_SA_SILENCE_CNF_T_SILENCE_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_GET_SA_SILENCE_CNF_T_BLOCKING_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_tx_power_reduction_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_TX_POWER_REDUCTION_REQ_T_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_NW_SET_TX_POWER_REDUCTION_REQ_T_TXPWR_BACKOFF, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_TX_POWER_REDUCTION_REQ_T_CG_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_tx_power_reduction_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_TX_POWER_REDUCTION_CNF_T_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_NW_GET_TX_POWER_REDUCTION_CNF_T_TXPWR_BACKOFF, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_TX_POWER_REDUCTION_CNF_T_CG_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_lte_overheating_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_LTE_OVERHEATING_REQ_T_OH_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_LTE_OVERHEATING_REQ_T_CAT_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_LTE_OVERHEATING_REQ_T_CAT_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_LTE_OVERHEATING_REQ_T_CC_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_LTE_OVERHEATING_REQ_T_CC_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_lte_overheating_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_LTE_OVERHEATING_CNF_T_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_lte_overheating_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_LTE_OVERHEATING_CNF_T_OH_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_LTE_OVERHEATING_CNF_T_CAT_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_OVERHEATING_CNF_T_CAT_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_OVERHEATING_CNF_T_CC_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_OVERHEATING_CNF_T_CC_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_LTE_OVERHEATING_CNF_T_OH_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_nr_overheating_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_OH_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_CC_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_CC_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_BW_FR1_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_BW_FR1_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_BW_FR2_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_BW_FR2_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_MIMO_FR1_DL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_MIMO_FR1_UL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_MIMO_FR2_DL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_REQ_T_MIMO_FR2_UL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_nr_overheating_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_NR_OVERHEATING_CNF_T_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_nr_overheating_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_OH_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_CC_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_CC_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_BW_FR1_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_BW_FR1_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_BW_FR2_DL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_BW_FR2_UL, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_MIMO_FR1_DL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_MIMO_FR1_UL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_MIMO_FR2_DL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_MIMO_FR2_UL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_NR_OVERHEATING_CNF_T_OH_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_uai_power_saving_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_CG_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_UAI_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_OP, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM1, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM3, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM4, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM5, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM6, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM7, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_REQ_T_PARAM8, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_uai_power_saving_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_UAI_POWER_SAVING_CNF_T_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_uai_power_saving_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_MCG_MAX_CC, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_SCG_MAX_CC, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_MCG_MIMO, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_SCG_MIMO, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_MCG_DRX, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_SCG_DRX, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_MCG_BW, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_SCG_BW, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_MCG_MIN_SCHED, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_GET_UAI_POWER_SAVING_CNF_T_SCG_MIN_SCHED, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_rrc_release_preference_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_RRC_RELEASE_PREFERENCE_REQ_T_RELEASE_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_rrc_release_preference_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_RRC_RELEASE_PREFERENCE_CNF_T_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_rrc_release_preference_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_RRC_RELEASE_PREFERENCE_CNF_T_RELEASE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_fake_ri_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_FAKE_RI_REQ_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_FAKE_RI_REQ_T_BAND, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_SET_FAKE_RI_REQ_T_CG_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_FAKE_RI_REQ_T_CTRL_RANK, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_fake_ri_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_FAKE_RI_CNF_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_FAKE_RI_CNF_T_BAND, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_GET_FAKE_RI_CNF_T_CG_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_GET_FAKE_RI_CNF_T_CTRL_RANK, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_mr_thresh_bound_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_MR_THRESH_BOUND_REQ_T_CONF_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_dynamic_ant_bias_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_DYNAMIC_ANT_BIAS_REQ_T_SCEN_IDX, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_DYNAMIC_ANT_BIAS_REQ_T_SIM_IDX, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_DYNAMIC_ANT_BIAS_REQ_T_BIT_RAT, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_cscon_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_CSCON_STATE_CNF_T_CSCON_STATE, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_set_band_priority_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SET_BAND_PRIORITY_REQ_T_CMD_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_NW_SET_BAND_PRIORITY_REQ_T_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_SET_BAND_PRIORITY_REQ_T_PLMN_TLV_ARRAY, .option = 0x6300, .array_num = 25, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_SET_BAND_PRIORITY_REQ_T_BAND_TLV_ARRAY, .option = 0xa002, .array_num = 32, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SET_BAND_PRIORITY_REQ_T_LEVEL_TLV_ARRAY, .option = 0xa001, .array_num = 32, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_band_priority_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_BAND_PRIORITY_REQ_T_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_GET_BAND_PRIORITY_REQ_T_PLMN_TLV_ARRAY, .option = 0x6300, .array_num = 25, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_get_band_priority_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_GET_BAND_PRIORITY_CNF_T_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_GET_BAND_PRIORITY_CNF_T_PLMN_TLV_ARRAY, .option = 0x2300, .array_num = 25, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_GET_BAND_PRIORITY_CNF_T_BAND_TLV_ARRAY, .option = 0xa002, .array_num = 32, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_GET_BAND_PRIORITY_CNF_T_LEVEL_TLV_ARRAY, .option = 0xa001, .array_num = 32, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_register_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_REGISTER_IND_T_STATE, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 38 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_NW_ERR, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_DATA_SPEED, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_NW_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_ROAMING_TEXT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_FAIL_CAUSE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_NW_LONG_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_REGISTER_IND_T_PS_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_nw_signal_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RSSI, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_ERR_RATE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RSRP, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_SNR, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_SIGNAL_STRENGTH_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RSSI_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_ERR_RATE_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RSRP_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_SNR_THRESHOLD, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_SIGNAL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_GSM_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_UMTS_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_LTE_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_NR_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 28 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RAW_SIGNAL_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 53 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RAW_SIGNAL_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_CDMA_SIGNAL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_LTE_SIGNAL_V1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 25 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_NR_SIGNAL_V1, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 49 }},
    {.tlv_type = MIPC_NW_SIGNAL_IND_T_RAW_SIGNAL_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 2, .check_item = { .fixed.fixed_value = 53 }},
};

static mipc_tlv_checker_info_t mipc_nw_ps_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_PS_IND_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_PS_IND_T_DATA_SPEED, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_PS_IND_T_NW_FREQUENCY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_PS_IND_T_REG_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 35 }},
    {.tlv_type = MIPC_NW_PS_IND_T_CELL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_PS_IND_T_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_PS_IND_T_GSM_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_PS_IND_T_UMTS_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 156 }},
    {.tlv_type = MIPC_NW_PS_IND_T_LTE_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_PS_IND_T_NR_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 184 }},
    {.tlv_type = MIPC_NW_PS_IND_T_CDMA_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 42 }},
};

static mipc_tlv_checker_info_t mipc_nw_radio_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_RADIO_IND_T_SW_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_RADIO_IND_T_HW_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_ia_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_IA_IND_T_APN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_NW_IA_IND_T_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_IA_IND_T_PDP_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_NW_IA_IND_T_AUTH_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_IA_IND_T_USERID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_IA_IND_T_PASSWORD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_NW_IA_IND_T_APN_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_IA_IND_T_CAUSE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_nitz_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NITZ_IND_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_NW_NITZ_IND_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_location_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_LOCATION_INFO_IND_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_nw_cs_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CS_IND_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_CS_IND_T_CELL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_CS_IND_T_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_CS_IND_T_GSM_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_CS_IND_T_UMTS_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 156 }},
    {.tlv_type = MIPC_NW_CS_IND_T_LTE_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_CS_IND_T_NR_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 184 }},
    {.tlv_type = MIPC_NW_CS_IND_T_CDMA_CELL_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 42 }},
};

static mipc_tlv_checker_info_t mipc_nw_cscon_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CSCON_IND_T_STATUS, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_preferred_provider_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_PREFERRED_PROVIDER_IND_T_PROVIDER_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_PREFERRED_PROVIDER_IND_T_PROVIDER_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 15 }},
    {.tlv_type = MIPC_NW_PREFERRED_PROVIDER_IND_T_NW_PROVIDER_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 144 }},
};

static mipc_tlv_checker_info_t mipc_nw_cainfo_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CAINFO_IND_T_LTE_DL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_LTE_UL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_NR_DL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_NR_UL_SERVING_CELL_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_LTE_DL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_LTE_UL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_NR_DL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_NR_UL_SERVING_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_LTE_DL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_LTE_UL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_NR_DL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_NW_CAINFO_IND_T_NR_UL_SERVING_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 32, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_nw_eons_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_EONS_IND_T_PNN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EONS_IND_T_OPL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_ciev_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CIEV_IND_T_CIEV_TYPE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CIEV_IND_T_ECBM_STATUS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CIEV_IND_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_CIEV_IND_T_NW_NAME_LONG, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_CIEV_IND_T_NW_NAME_SHORT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_CIEV_IND_T_PRL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_egmss_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_EGMSS_IND_T_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EGMSS_IND_T_MCC, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EGMSS_IND_T_STATUS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EGMSS_IND_T_CUR_REPORTED_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EGMSS_IND_T_IS_HOME_COUNTRY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_psbearer_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_PSBEARER_IND_T_CELL_DATA_SPEED_SUPPORT, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_NW_PSBEARER_IND_T_MAX_DATA_BEARER_CAPABILITY, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 19 }},
    {.tlv_type = MIPC_NW_PSBEARER_IND_T_SEC_CELL_NUM_IN_DL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_PSBEARER_IND_T_SEC_CELL_NUM_IN_UL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_ecell_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_ECELL_IND_T_GSM_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_GSM_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 33 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_UMTS_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_UMTS_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 29 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_LTE_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_LTE_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 53 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_CDMA_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_CDMA_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 42 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_NR_CELL_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_NR_CELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 57 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_FAIL_CAUSE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_LTE_CELL_TLV_ARRAY_V1, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 181 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_NR_CELL_TLV_ARRAY_V1, .option = 0x2400, .array_num = 33, .check_item = { .fixed.fixed_value = 205 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_LTE_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 180 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_NR_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 184 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_GSM_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 160 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_UMTS_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 156 }},
    {.tlv_type = MIPC_NW_ECELL_IND_T_CDMA_CELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 42 }},
};

static mipc_tlv_checker_info_t mipc_nw_anbr_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_ANBR_IND_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_nw_irat_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_IRAT_IND_T_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_ereginfo_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_EREGINFO_IND_T_ACT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EREGINFO_IND_T_EVENT_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_emodcfg_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_EMODCFG_IND_T_MODULATION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_nw_epcellinfo_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_EPCELLINFO_IND_T_LTE_BAND, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_pseudo_cell_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_PSEUDO_CELL_IND_T_CELL_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_PSEUDO_CELL_IND_T_PSEUDOCELL_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_NW_PSEUDO_CELL_IND_T_PSEUDOCELL_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 193 }},
};

static mipc_tlv_checker_info_t mipc_nw_network_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NETWORK_INFO_IND_T_TYPE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NETWORK_INFO_IND_T_NW_INFO, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_NW_NETWORK_INFO_IND_T_NW_INFO_V1, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2048 }},
};

static mipc_tlv_checker_info_t mipc_nw_mccmnc_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_MCCMNC_IND_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_physical_channel_configs_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_PHYSICAL_CHANNEL_CONFIGS_IND_T_PHYSICAL_CH_INFO_LIST_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_PHYSICAL_CHANNEL_CONFIGS_IND_T_PHYSICAL_CH_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 21 }},
    {.tlv_type = MIPC_NW_PHYSICAL_CHANNEL_CONFIGS_IND_T_PHYSICAL_CH_INFO_TLV_ARRAY_V1, .option = 0x2400, .array_num = 15, .check_item = { .fixed.fixed_value = 37 }},
    {.tlv_type = MIPC_NW_PHYSICAL_CHANNEL_CONFIGS_IND_T_PHYSICAL_CH_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 15, .check_item = { .fixed.fixed_value = 21 }},
};

static mipc_tlv_checker_info_t mipc_nw_otacmsg_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_OTACMSG_IND_T_OTA_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_barring_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_BARRING_INFO_IND_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_BARRING_INFO_IND_T_BARRING_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_NW_BARRING_INFO_IND_T_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_BARRING_INFO_IND_T_BARRING_TLV_ARRAY, .option = 0x2400, .array_num = 255, .check_item = { .fixed.fixed_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_nw_radio_capability_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_RADIO_CAPABILITY_IND_T_RADIO_CAPABILITY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_current_rat_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CURRENT_RAT_IND_T_CURRENT_BIT_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CURRENT_RAT_IND_T_CURRENT_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 3, .min_max.max_value = 19 }},
    {.tlv_type = MIPC_NW_CURRENT_RAT_IND_T_PREFER_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_camp_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CAMP_STATE_IND_T_REG_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 35 }},
    {.tlv_type = MIPC_NW_CAMP_STATE_IND_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_CAMP_STATE_IND_T_NW_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
};

static mipc_tlv_checker_info_t mipc_nw_nr_switch_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NR_SWITCH_IND_T_NR_SIM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_femtocell_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_IS_1X_FEMTOCELL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_IS_EVDO_FEMTOCELL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_IS_FEMTOCELL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_DOMAIN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_ACT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_IS_CSG_CELL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_CSG_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_CSG_ICON_TYPE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_CAUSE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_PLMN_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_OPER_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
    {.tlv_type = MIPC_NW_FEMTOCELL_INFO_IND_T_HNBNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 60 }},
};

static mipc_tlv_checker_info_t mipc_nw_etxpwr_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_ETXPWR_IND_T_ACT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ETXPWR_IND_T_TX_POWER, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_etxpwrstus_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_ETXPWRSTUS_IND_T_EVENT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ETXPWRSTUS_IND_T_SAR_SCENARIO_INDEX, .option = 0xc082, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_iwlan_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_IWLAN_IND_T_STATUS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_nw_ch_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CH_INFO_IND_T_RAT, .option = 0xc384, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_NW_CH_INFO_IND_T_BAND, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CH_INFO_IND_T_CHANNEL, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_CH_INFO_IND_T_IS_ENDC, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_nruw_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NRUW_INFO_IND_T_DISPLAY_5GUW, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NRUW_INFO_IND_T_ON_N77_BAND, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NRUW_INFO_IND_T_ON_FR2_BAND, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NRUW_INFO_IND_T_5GUW_ALLOWED, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_nr_ca_band_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NR_CA_BAND_IND_T_IS_ENDC, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NR_CA_BAND_IND_T_BAND_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NR_CA_BAND_IND_T_BAND, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 40 }},
};

static mipc_tlv_checker_info_t mipc_nw_nr_scs_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NR_SCS_IND_T_SCS, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_network_scan_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NETWORK_SCAN_IND_T_SCAN_STATUS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_NETWORK_SCAN_IND_T_RECORD_LIST, .option = 0x6400, .array_num = 20, .check_item = { .fixed.fixed_value = 103 }},
};

static mipc_tlv_checker_info_t mipc_nw_ca_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_CA_INFO_IND_T_CAINFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_nw_nruc_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NRUC_INFO_IND_T_DISPLAY_5GUC, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_NRUC_INFO_IND_T_ON_UC_BAND, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_NW_NRUC_INFO_IND_T_AGG_BW, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_first_plmn_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_FIRST_PLMN_IND_T_MCC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_NW_FIRST_PLMN_IND_T_MNC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_nw_edrx_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_EDRX_IND_T_ACT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_NW_EDRX_IND_T_REQUESTED_EDRX_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EDRX_IND_T_NW_PROVIDED_EDRX_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_EDRX_IND_T_PAGING_TIME_WINDOW, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_mobile_initiated_connection_only_mode_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_MOBILE_INITIATED_CONNECTION_ONLY_MODE_IND_T_CURRENT_MICO_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_MOBILE_INITIATED_CONNECTION_ONLY_MODE_IND_T_RAAI_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_MOBILE_INITIATED_CONNECTION_ONLY_MODE_IND_T_SPRT_VALUE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_MOBILE_INITIATED_CONNECTION_ONLY_MODE_IND_T_ALLOCATED_ACTIVE_TIME, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_basement_detection_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_BASEMENT_DETECTION_IND_T_STATUS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_nw_enwcfginfo_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_ENWCFGINFO_IND_T_4X4MINO_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ENWCFGINFO_IND_T_256QAM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_ENWCFGINFO_IND_T_64QAM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_lcm_hopping_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_LCM_HOPPING_IND_T_MIPI_BITMAP, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_nw_nrrc_rrc_release_uai_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NRRC_RRC_RELEASE_UAI_IND_T_REPORT_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_NW_NRRC_RRC_RELEASE_UAI_IND_T_CONNECTED_REPORTING, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NRRC_RRC_RELEASE_UAI_IND_T_PREFERRED_RRC_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_nw_nrrc_powersaving_uai_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NRRC_POWERSAVING_UAI_IND_T_CELL_GROUP_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_NW_NRRC_POWERSAVING_UAI_IND_T_MAXCC_PREFERENCE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_NW_NRRC_POWERSAVING_UAI_IND_T_MAXMIMO_LAYERPREFERENCE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_NW_NRRC_POWERSAVING_UAI_IND_T_DRX_PREFERENCE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_NW_NRRC_POWERSAVING_UAI_IND_T_MAXBW_PREFERENCE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_NW_NRRC_POWERSAVING_UAI_IND_T_MINSCHEDULINGOFFSET_PREFERENCE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_nw_nrrc_overheatingassistance_uai_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NRRC_OVERHEATINGASSISTANCE_UAI_IND_T_REPORT_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_nw_nrrc_timer_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_NW_NRRC_TIMER_STATUS_IND_T_TIMER_NAME, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_NW_NRRC_TIMER_STATUS_IND_T_TIMER_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_NW_NRRC_TIMER_STATUS_IND_T_TIMER_VALUE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_pin_protect_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_PIN_PROTECT_REQ_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_PIN_PROTECT_REQ_T_PIN_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_PIN_PROTECT_REQ_T_PIN_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_pin_protect_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_PIN_PROTECT_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_PIN_PROTECT_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_PIN_PROTECT_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_change_pin_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CHANGE_PIN_REQ_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_CHANGE_PIN_REQ_T_OLD_PIN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_CHANGE_PIN_REQ_T_NEW_PIN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_change_pin_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CHANGE_PIN_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_CHANGE_PIN_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_CHANGE_PIN_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_verify_pin_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VERIFY_PIN_REQ_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_VERIFY_PIN_REQ_T_PIN_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_verify_pin_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VERIFY_PIN_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_VERIFY_PIN_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_VERIFY_PIN_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_unblock_pin_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_UNBLOCK_PIN_REQ_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_UNBLOCK_PIN_REQ_T_PUK_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_UNBLOCK_PIN_REQ_T_PIN_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_unblock_pin_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_UNBLOCK_PIN_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_UNBLOCK_PIN_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_UNBLOCK_PIN_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_pin_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_PIN_INFO_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_GET_PIN_INFO_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_GET_PIN_INFO_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_pin_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_PIN1, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_PIN2, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_NW_PIN, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_SUB_NW_PIN, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_SP_PIN, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_CORP_PIN, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_PIN_LIST_CNF_T_SIM_PIN, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_sim_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_STATE_CNF_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8 }},
    {.tlv_type = MIPC_SIM_STATE_CNF_T_SIM_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATE_CNF_T_PS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_STATUS_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 21 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_SIM_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PS_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_CARD_PRESENT_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_UPIN_STATUS, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_TEST_SIM, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_GSM_APP_IDX, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_CDMA_APP_IDX, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_ISIM_APP_IDX, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_APP_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_APP_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 8 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_EID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_ICCID, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_ATR, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_MSISDN_READY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PIN1, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PIN2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PUK1, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PUK2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_APP_TLV_ARRAY, .option = 0x2400, .array_num = 20, .check_item = { .fixed.fixed_value = 88 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PHY_SLOT_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_CNF_T_PORT_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_iccid_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ICCID_CNF_T_ICCID, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_imsi_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_IMSI_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_IMSI_REQ_T_APP_ID, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sim_imsi_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_IMSI_CNF_T_IMSI, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SIM_IMSI_CNF_T_MNC_LEN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_msisdn_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_MSISDN_CNF_T_MSISDN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MSISDN_CNF_T_MSISDN_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_SIM_MSISDN_CNF_T_MSISDN_TLV_ARRAY, .option = 0x2400, .array_num = 7, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_atr_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_ATR_INFO_CNF_T_ATR_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_ATR_INFO_CNF_T_ATR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
};

static mipc_tlv_checker_info_t mipc_sim_open_channel_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_REQ_T_APP_ID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_REQ_T_APP_ID, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_REQ_T_P2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_REQ_T_CHANNEL_GROUP, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_open_channel_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_CNF_T_CHANNEL, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_OPEN_CHANNEL_CNF_T_RESP, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_close_channel_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CLOSE_CHANNEL_REQ_T_CHANNEL_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CLOSE_CHANNEL_REQ_T_CHANNEL_GROUP, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_close_channel_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CLOSE_CHANNEL_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_channel_restricted_access_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_APP_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_SESSION_ID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_CMD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 176, .min_max.max_value = 242 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_FILE_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_P1, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_P2, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_P3, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_DATA_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_PATH, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_P3_EX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ_T_FCP_CONVERT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_channel_restricted_access_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_CNF_T_RESP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_CNF_T_RESP_APDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_channel_generic_access_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_REQ_T_APP_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_REQ_T_CHANNEL_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_REQ_T_APDU_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_REQ_T_APDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 261 }},
};

static mipc_tlv_checker_info_t mipc_sim_channel_generic_access_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_CNF_T_RESP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CHANNEL_GENERIC_ACCESS_CNF_T_RESP_APDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_long_apdu_access_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_VERSION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_APP_ID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_APP_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_PATH_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_FILE_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_FILE_OFFSET, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_NUMBER_OF_BYTES, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_LOCAL_PIN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_BINARY_DATA_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_REQ_T_BINARY_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_long_apdu_access_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_CNF_T_VERSION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_CNF_T_DATA_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_LONG_APDU_ACCESS_CNF_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_app_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_APP_LIST_CNF_T_VERSION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_APP_LIST_CNF_T_APP_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_APP_LIST_CNF_T_ACTIVE_APP_idx, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_APP_LIST_CNF_T_APP_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_SIM_APP_LIST_CNF_T_APP_TLV_ARRAY, .option = 0x2400, .array_num = 20, .check_item = { .fixed.fixed_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_sim_file_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_FILE_STATUS_REQ_T_VERSION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_REQ_T_AID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_REQ_T_AID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_REQ_T_FILE_PATH_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_REQ_T_FILE_PATH, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_sim_file_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_VERSION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_FILE_ACCESSIBILITY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_FILE_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_FILE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_ITEM_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_SIZE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_LOCK_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_FILE_STATUS_CNF_T_SIZE_EXT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_reset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_RESET_REQ_T_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_reset_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_RESET_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_reset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_RESET_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_terminal_capability_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_TERMINAL_CAPABILITY_CNF_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_TERMINAL_CAPABILITY_CNF_T_TC_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_TERMINAL_CAPABILITY_CNF_T_TC, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_terminal_capability_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_TERMINAL_CAPABILITY_REQ_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SET_TERMINAL_CAPABILITY_REQ_T_TC_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SET_TERMINAL_CAPABILITY_REQ_T_TC, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_pin_ex_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_PIN_EX_REQ_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_REQ_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_REQ_T_PIN_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_REQ_T_NEW_PIN_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_REQ_T_AID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_REQ_T_AID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_pin_ex_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_PIN_EX_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_SET_PIN_EX_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_pin_ex_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_PIN_EX_REQ_T_VERSION, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_PIN_EX_REQ_T_AID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_PIN_EX_REQ_T_AID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_pin_ex_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_PIN_EX_CNF_T_PIN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 18 }},
    {.tlv_type = MIPC_SIM_GET_PIN_EX_CNF_T_PIN_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_GET_PIN_EX_CNF_T_REMAINING_ATTEMPTS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_gsm_auth_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_REQ_T_RAND1, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_REQ_T_RAND2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_REQ_T_RAND3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_gsm_auth_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_SRES1, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_KC1, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_SRES2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_KC2, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_SRES3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_SIM_GET_GSM_AUTH_CNF_T_KC3, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_ext_auth_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_REQ_T_CH, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_REQ_T_CMD_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_REQ_T_CMD_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_REQ_T_APP_ID, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_ext_auth_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_CNF_T_RSP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EXT_AUTH_CNF_T_RSP_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_facility_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_FACILITY_REQ_T_APP_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SIM_GET_FACILITY_REQ_T_FACILITY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_facility_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_FACILITY_CNF_T_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_facility_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_FACILITY_REQ_T_APP_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SIM_SET_FACILITY_REQ_T_FACILITY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_SET_FACILITY_REQ_T_PASS_WORD, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_SET_FACILITY_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_facility_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_FACILITY_CNF_T_RETRY_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_euicc_slots_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_SLOTS_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_SLOTS_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 2 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_CARD_STATE, .option = 0xe301, .array_num = 2, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_SLOTS_STATE, .option = 0xe001, .array_num = 2, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_LOGICAL_IDX, .option = 0xe001, .array_num = 2, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_ATR, .option = 0x6300, .array_num = 2, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_EID, .option = 0x6300, .array_num = 2, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_ICCID, .option = 0x6500, .array_num = 2, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF_T_SLOTS_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 2, .check_item = { .fixed.fixed_value = 156 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_connect_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_CONNECT_CNF_T_CUR_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_CONNECT_CNF_T_SUPPORT_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_CONNECT_CNF_T_ATR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_power_on_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_POWER_ON_REQ_T_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_power_on_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_POWER_ON_CNF_T_CUR_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_POWER_ON_CNF_T_ATR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_reset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_RESET_REQ_T_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_reset_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_RESET_CNF_T_CUR_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_RESET_CNF_T_ATR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_apdu_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_APDU_REQ_T_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_APDU_REQ_T_APDU, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 522 }},
};

static mipc_tlv_checker_info_t mipc_sim_access_profile_apdu_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ACCESS_PROFILE_APDU_CNF_T_APDU, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 522 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_sim_power_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_SIM_POWER_REQ_T_MODE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SET_SIM_POWER_REQ_T_SIM_POWER, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_set_physical_slots_mapping_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SET_PHYSICAL_SLOTS_MAPPING_REQ_T_SLOTS_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SET_PHYSICAL_SLOTS_MAPPING_REQ_T_SLOTS_MAPPING_LIST, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_sim_extended_channel_generic_access_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_SESSION_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_CLA, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_INS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_P1, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_P2, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_P3, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_DATA_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_extended_channel_generic_access_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_CNF_T_RESP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_CNF_T_RESP_APDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_uicc_file_access_record_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_APP_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_APP_ID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_FILE_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_RECORD_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_DATA_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_PATH, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ_T_PIN2, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_uicc_file_access_record_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_CNF_T_RESP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_RECORD_CNF_T_RESP_APDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_uicc_file_access_binary_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_APP_ID, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_APP_ID_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_FILE_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_OFFSET, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_DATA_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_PATH, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ_T_PIN2, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_sim_uicc_file_access_binary_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_CNF_T_RESP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_UICC_FILE_ACCESS_BINARY_CNF_T_RESP_APDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_physical_slots_mapping_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_PHYSICAL_SLOTS_MAPPING_CNF_T_ACTIVE_PHYSICAL_SLOT_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_sim_auth_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_REQ_T_P2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_REQ_T_AID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 40 }},
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_REQ_T_CMD_LEN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_REQ_T_CMD_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_get_sim_auth_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_CNF_T_SW, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_CNF_T_RSP_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_GET_SIM_AUTH_CNF_T_RSP_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_get_allowed_carriers_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_MULTI_SIM_POLICY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_ALLOWED_CARRIERS_PRIORITIZED, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_ALLOWED_CARRIERS_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_ALLOWED_CARRIERS, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_EXCLUDED_CARRIERS_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_EXCLUDED_CARRIERS, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_ALLOWED_CARRIERS_TLV_ARRAY, .option = 0x2400, .array_num = 25, .check_item = { .fixed.fixed_value = 30 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_EXCLUDED_CARRIERS_TLV_ARRAY, .option = 0x2400, .array_num = 25, .check_item = { .fixed.fixed_value = 30 }},
    {.tlv_type = MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF_T_CARRIER_RESTRICTION_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_set_allowed_carriers_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_MULTI_SIM_POLICY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_ALLOWED_CARRIERS_PRIORITIZED, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_ALLOWED_CARRIERS_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_ALLOWED_CARRIERS, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_EXCLUDED_CARRIERS_NUM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_EXCLUDED_CARRIERS, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_ALLOWED_CARRIERS_TLV_ARRAY, .option = 0x2400, .array_num = 25, .check_item = { .fixed.fixed_value = 30 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ_T_EXCLUDED_CARRIERS_TLV_ARRAY, .option = 0x2400, .array_num = 25, .check_item = { .fixed.fixed_value = 30 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_set_allowed_carriers_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_CNF_T_ALLOWED_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_SET_ALLOWED_CARRIERS_CNF_T_EXCLUDED_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_enter_sim_depersonalization_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_REQ_T_CATEGORY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_REQ_T_PIN_CODE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_enter_sim_depersonalization_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_CNF_T_CATEGORY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_CNF_T_REMAIN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_CNF_T_REMAIN_COUNT_LIST, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_get_lock_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_REQ_T_CATEGORY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_get_lock_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_CATEGORY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_RETRY_CNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_AUTOLOCK_CNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_NUM_SET, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_TOTAL_SET, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_KEY_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_MAX_CNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_LOCK_CNF_T_RSU_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_set_lock_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_SET_LOCK_REQ_T_CATEGORY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_SML_SET_LOCK_REQ_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SIM_SML_SET_LOCK_REQ_T_KEY, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SIM_SML_SET_LOCK_REQ_T_DATA_IMSI, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SIM_SML_SET_LOCK_REQ_T_GID1, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_SET_LOCK_REQ_T_GID2, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_enter_device_depersonalization_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_ENTER_DEVICE_DEPERSONALIZATION_REQ_T_KEY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_enter_device_depersonalization_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_ENTER_DEVICE_DEPERSONALIZATION_CNF_T_REMAIN_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_get_dev_lock_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_GET_DEV_LOCK_CNF_T_LOCK_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_DEV_LOCK_CNF_T_ALGO, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_DEV_LOCK_CNF_T_MAX_CNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_DEV_LOCK_CNF_T_REMAIN_CNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_rsu_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_OPERATOR_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_REQUEST_ID, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 19 }},
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_REQUEST_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_DATA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_RSV1, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_RSV2, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_REQ_T_RSV_STRING, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_rsu_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_OPERATOR_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_REQUEST_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_REQUEST_TYPE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_ERROR_CODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_DATA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_TIME, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_VERSION, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_STATUS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_RSV1, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_RSV2, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_RSV_STRING, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 65535 }},
    {.tlv_type = MIPC_SIM_SML_RSU_CNF_T_LS_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_set_aka_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_SET_AKA_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_set_aka_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_SET_AKA_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_enable_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_ENABLE_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_disable_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_DISABLE_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_plug_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_PLUG_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_VSIM_PLUG_REQ_T_SIM_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_plug_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_PLUG_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_set_timer_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_SET_TIMER_REQ_T_TIMER, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_set_timer_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_SET_TIMER_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_reset_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_RESET_REQ_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_VSIM_RESET_REQ_T_LENGTH, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_VSIM_RESET_REQ_T_DATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 522 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_reset_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_RESET_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_apdu_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_APDU_REQ_T_LENGTH, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_VSIM_APDU_REQ_T_DATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 522 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_apdu_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_APDU_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_auth_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_AUTH_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_auth_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_AUTH_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_cdma_subscription_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_MSISDN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 24 }},
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_SID_NID_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_SID_NID_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_VMIN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 11 }},
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_VPRLID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_SIM_CDMA_SUBSCRIPTION_CNF_T_SID_NID_TLV_ARRAY, .option = 0x2400, .array_num = 20, .check_item = { .fixed.fixed_value = 14 }},
};

static mipc_tlv_checker_info_t mipc_sim_cdma_get_subscription_source_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CDMA_GET_SUBSCRIPTION_SOURCE_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CDMA_GET_SUBSCRIPTION_SOURCE_CNF_T_UIM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_pin_count_query_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_PIN_COUNT_QUERY_CNF_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_PIN_COUNT_QUERY_CNF_T_PIN1, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_PIN_COUNT_QUERY_CNF_T_PIN2, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_PIN_COUNT_QUERY_CNF_T_PUK1, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_PIN_COUNT_QUERY_CNF_T_PUK2, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_get_network_lock_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_CARRIER_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_SUPPORTED_CATS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_VERSION, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_LOCK_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_LOCK_FUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_RSU_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_RULE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_GET_NETWORK_LOCK_CNF_T_SUBRULE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_esim_switch_set_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ESIM_SWITCH_SET_REQ_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_esim_switch_get_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ESIM_SWITCH_GET_CNF_T_ESIM_SUPPORT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ESIM_SWITCH_GET_CNF_T_ESIM_PSIM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_esim_eid_query_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ESIM_EID_QUERY_REQ_T_NVRAM_EID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_esim_eid_query_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ESIM_EID_QUERY_CNF_T_EID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sim_mep_slots_info_get_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_PHY_SLOT_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_CARD_STATE, .option = 0xe301, .array_num = 4, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_ATR, .option = 0x6300, .array_num = 4, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_EID, .option = 0x6300, .array_num = 4, .check_item = { .min_max.min_value = 1, .min_max.max_value = 33 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_PORT_NUM, .option = 0xe001, .array_num = 4, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_PORT_INFO, .option = 0x6000, .array_num = 4, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_GET_CNF_T_MEP_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_sim_mep_slots_mapping_set_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_MEP_SLOTS_MAPPING_SET_REQ_T_SIM_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_MAPPING_SET_REQ_T_PHY_SLOT_ID, .option = 0xe001, .array_num = 2, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_MAPPING_SET_REQ_T_PORT_ID, .option = 0xe001, .array_num = 2, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_STATE_IND_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8 }},
    {.tlv_type = MIPC_SIM_STATE_IND_T_SIM_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATE_IND_T_PS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATE_IND_T_IS_PRESENT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATE_IND_T_SUB_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_sim_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_STATUS_IND_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 21 }},
    {.tlv_type = MIPC_SIM_STATUS_IND_T_SIM_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_STATUS_IND_T_PS_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_euicc_slots_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_SLOTS_INFO_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_SLOTS_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 2 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_CARD_STATE, .option = 0xe301, .array_num = 2, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_SLOTS_STATE, .option = 0xe001, .array_num = 2, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_LOGICAL_IDX, .option = 0xe001, .array_num = 2, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_ATR, .option = 0x6300, .array_num = 2, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_EID, .option = 0x6300, .array_num = 2, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_ICCID, .option = 0x6500, .array_num = 2, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SIM_EUICC_SLOTS_STATUS_IND_T_SLOTS_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 2, .check_item = { .fixed.fixed_value = 156 }},
};

static mipc_tlv_checker_info_t mipc_sim_iccid_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ICCID_IND_T_ICCID, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_event_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_EVENT_IND_T_IS_SIM_INSERTED, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_EVENT_IND_T_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 29 }},
    {.tlv_type = MIPC_SIM_EVENT_IND_T_ADDITIONAL_CAUSE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sim_csim_imsi_change_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CSIM_IMSI_CHANGE_IND_T_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_STATUS_IND_T_LOCK_RULE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_STATUS_IND_T_LOCK_SUB_RULE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_STATUS_IND_T_DEVICE_LOCK_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_STATUS_IND_T_RULE_POLICY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_STATUS_IND_T_SIM_VALIDITY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_STATUS_IND_T_DEVICE_LOCK_REMAIN_CNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_sml_rsu_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SML_RSU_IND_T_OPERATOR_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_IND_T_EVENT_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SML_RSU_IND_T_EVENT_STRING, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_apdu_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_APDU_IND_T_DATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 522 }},
};

static mipc_tlv_checker_info_t mipc_sim_vsim_event_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_VSIM_EVENT_IND_T_EVENT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_VSIM_EVENT_IND_T_DATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 522 }},
};

static mipc_tlv_checker_info_t mipc_sim_simapp_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SIMAPP_IND_T_APP_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SIM_SIMAPP_IND_T_CH_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SIMAPP_IND_T_MCC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SIM_SIMAPP_IND_T_MNC, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_sim_test_sim_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_TEST_SIM_IND_T_TEST_SIM, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sim_ct3g_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CT3G_IND_T_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_card_type_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_CARD_TYPE_IND_T_USIM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CARD_TYPE_IND_T_CSIM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_CARD_TYPE_IND_T_ISIM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_simind_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_EVENT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_APP_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_SPN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 71 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_IMSI, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 20 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_GID1, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 41 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_PNN_FULL_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 101 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_IMPI, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 149 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_FILE_NUM, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_FILE_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_SIM_SIMIND_IND_T_FILE_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 59 }},
};

static mipc_tlv_checker_info_t mipc_sim_eslotesim_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_ESLOTESIM_STATE_IND_T_ESIM_SUPPORT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_ESLOTESIM_STATE_IND_T_ESIM_PSIM_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sim_mep_slots_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_PHY_SLOT_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_CARD_STATE, .option = 0xe301, .array_num = 4, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_ATR, .option = 0x6300, .array_num = 4, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_EID, .option = 0x6300, .array_num = 4, .check_item = { .min_max.min_value = 1, .min_max.max_value = 33 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_PORT_NUM, .option = 0xe001, .array_num = 4, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_PORT_INFO, .option = 0x6000, .array_num = 4, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SIM_MEP_SLOTS_INFO_IND_T_MEP_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_sms_cfg_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_CFG_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_SET_SCA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_GET_SCA, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_GET_SMS_STATE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_GET_STORE_STATUS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_PREFER_ACK, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_PREFER_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_GET_ALL_CAN_GET, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_SET_HOST_MEM_AVAILABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_TEXT_MODE_PARAM_ACTION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_TEXT_MODE_FO, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_TEXT_MODE_VP, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_TEXT_MODE_PID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_TEXT_MODE_DCS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_PREFER_STORAGE_C2K, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_W_R_D_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_T_SAVE_SETTING, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_cfg_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_SET_SCA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 11 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_SAVE_SET, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_GET_SCA, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_MT_HANDLE_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_SAVE_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_MT_ACK_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_SR_ACK_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_MT_ACK_MODE_3GPP2, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_REQ_V2_T_SR_ACK_MODE_3GPP2, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_sms_cfg_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_CFG_CNF_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_SCA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_SMS_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_MAX_MESSAGE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_PREFER_ACK, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_PREFER_STORAGE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_USED_MESSAGE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_TOTAL_MESSAGE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_TEXT_MODE_FO, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_TEXT_MODE_VP, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_TEXT_MODE_PID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_TEXT_MODE_DCS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_PREFER_STORAGE_C2K, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_USED_MESSAGE_C2K, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_MAX_MESSAGE_C2K, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_T_W_R_D_STORAGE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_cfg_cnf_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_SCA, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 11 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_MT_HANDLE_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_SAVE_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_MT_ACK_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_SR_ACK_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_MT_ACK_MODE_3GPP2, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_CNF_V2_T_SR_ACK_MODE_3GPP2, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_sms_send_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_SEND_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_T_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_T_PDU_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_T_SAVE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_T_MORE_MSG_TO_SEND, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_T_PDU_C2K, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_T_NUM_C2K, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sms_send_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_SEND_REQ_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_V2_T_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_SEND_REQ_V2_T_NUM_3GPP2, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_sms_send_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_SEND_CNF_T_MR, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_T_MESSAGE_INDEX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_T_ERR_CLASS_C2K, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_T_FORMAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_T_ERR_CODE_C2K, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 14, .min_max.max_value = 107 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_T_ACK_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_T_MSGID_C2K, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_send_cnf_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_SEND_CNF_V2_T_SMS_ID, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_V2_T_ERROR_CLASS_3GPP2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_SEND_CNF_V2_T_CAUSE_CODE_3GPP2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_read_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_READ_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_READ_REQ_T_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_READ_REQ_T_MESSAGE_INDEX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_READ_REQ_T_STATUS_UNCHANGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_READ_REQ_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_read_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_READ_REQ_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_READ_REQ_V2_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_READ_REQ_V2_T_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_READ_REQ_V2_T_MSG_IDX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_READ_REQ_V2_T_STATUS_UNCHANGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_read_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_READ_CNF_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_READ_CNF_T_PDU_COUNT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_READ_CNF_T_PDU_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_SMS_READ_CNF_T_PDU_C2K, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_read_cnf_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_READ_CNF_V2_T_MSG_IDX, .option = 0xa002, .array_num = 1024, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_READ_CNF_V2_T_PDU, .option = 0x2200, .array_num = 1024, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_READ_CNF_V2_T_STATUS, .option = 0xa301, .array_num = 1024, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_delete_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_DELETE_REQ_T_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_DELETE_REQ_T_MESSAGE_INDEX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_DELETE_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_DELETE_REQ_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_delete_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_DELETE_REQ_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_DELETE_REQ_V2_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_DELETE_REQ_V2_T_FLAG, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_DELETE_REQ_V2_T_MSG_IDX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_get_store_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_REQ_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_get_store_status_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_REQ_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_REQ_V2_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_sms_get_store_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_T_FLAG, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_T_MESSAGE_INDEX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_T_MAX_MESSAGE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_T_USED_MESSAGE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_get_store_status_cnf_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_V2_T_TOTAL, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_GET_STORE_STATUS_CNF_V2_T_USED, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_write_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_WRITE_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_T_PDU_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_T_PDU_C2K, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_write_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_WRITE_REQ_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_V2_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_V2_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_WRITE_REQ_V2_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_write_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_WRITE_CNF_T_MESSAGE_INDEX, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_write_cnf_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_WRITE_CNF_V2_T_MSG_IDX, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_cbm_cfg_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_OPEN_CBM_TYPE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_MSG_ID_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_MSG_ID_RANGE, .option = 0xa004, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_MSG_ID_SINGLE, .option = 0xa002, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_DCS_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_DCS_RANGE, .option = 0xa002, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_DCS_SINGLE, .option = 0xa001, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_ETWS_PRIMARY_CFG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_C2K_CBM_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_T_PDU_3GPP_SEG_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_cbm_cfg_req_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_ETWS_PRIMARY_CFG, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_CH_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_CH_RANGE, .option = 0xa004, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_CH_SINGLE, .option = 0xa002, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_LAN_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_LAN_RANGE, .option = 0xa002, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_LAN_SINGLE, .option = 0xa001, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_REQ_V2_T_SEG_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_cbm_cfg_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_OPEN_CBM_TYPE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_MSG_ID_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_MSG_ID_RANGE, .option = 0xa004, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_MSG_ID_SINGLE, .option = 0xa002, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_DCS_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_DCS_RANGE, .option = 0xa002, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_DCS_SINGLE, .option = 0xa001, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_LANGUAGE_SINGLE, .option = 0xa001, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_FORMAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_T_C2K_CBM_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_cbm_cfg_cnf_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_CH_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_CH_RANGE, .option = 0xa004, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_CH_SINGLE, .option = 0xa002, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_LAN_CFG_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 253 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_LAN_RANGE, .option = 0xa002, .array_num = 30, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_LAN_SINGLE, .option = 0xa001, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CBM_CFG_CNF_V2_T_LANGUAGE_SINGLE, .option = 0xa001, .array_num = 60, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_scbm_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_SCBM_REQ_T_QUIT_SCBM_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_domain_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_DOMAIN_REQ_T_CGSMS_ACTION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_DOMAIN_REQ_T_CGSMS_VALUE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SMS_DOMAIN_REQ_T_SMS_IMS_ACTION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_DOMAIN_REQ_T_SMS_IMS_VALUE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_domain_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_DOMAIN_CNF_T_CGSMS_VALUE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_SMS_DOMAIN_CNF_T_SMS_IMS_VALUE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_cfg_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_CFG_IND_T_FORMAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_SCA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_SMS_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_MAX_MESSAGE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_PREFER_ACK, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_PREFER_STORAGE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_USED_MESSAGE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_PREFER_STORAGE_C2K, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_USED_MESSAGE_C2K, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_MAX_MESSAGE_C2K, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_CFG_IND_T_W_R_D_STORAGE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_cfg_ind_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_CFG_IND_V2_T_MT_HANDLE_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_IND_V2_T_SAVE_STORAGE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_CFG_IND_V2_T_MT_ACK_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_IND_V2_T_SR_ACK_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_IND_V2_T_MT_ACK_MODE_3GPP2, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_CFG_IND_V2_T_SR_ACK_MODE_3GPP2, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_sms_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_T_PDU_COUNT, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_T_PDU_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_T_PDU_C2K, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_sms_ind_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_V2_T_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_V2_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_IND_V2_T_MSG_IDX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_store_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_STORE_STATUS_IND_T_FLAG, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_STORE_STATUS_IND_T_MESSAGE_INDEX, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_STORE_STATUS_IND_T_STORAGE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_sms_store_status_ind_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_STORE_STATUS_IND_V2_T_SIM_FULL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_STORE_STATUS_IND_V2_T_ME_FULL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_STORE_STATUS_IND_V2_T_UIM_FULL, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_status_report_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_IND_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_status_report_ind_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_IND_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_IND_V2_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_cbm_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_CBM_TYPE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_WARNING_TYPE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_MESSAGE_ID, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_SERIAL_NUMBER, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_DCS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1246 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_SECUR_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 50 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_FORMAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_PDU_C2K, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_PDU_3GPP_SEG, .option = 0x2200, .array_num = 15, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_T_WAC_INFO, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_cbm_ind_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_WARNING_TYPE, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_CH, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_LAN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1246 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_SECUR_INFO, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 50 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_SN, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_PDU_3GPP2, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_PDU_SEG, .option = 0x2200, .array_num = 15, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_CBM_IND_V2_T_WAC_INFO, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_sms_scbm_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_SCBM_IND_T_STATUS_UPDATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_sms_ext_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_EXT_INFO_IND_T_EPSI, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_EXT_INFO_IND_T_ESN_OLD, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
    {.tlv_type = MIPC_SMS_EXT_INFO_IND_T_ESN_NEW, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 8 }},
};

static mipc_tlv_checker_info_t mipc_sms_dup_new_sms_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_DUP_NEW_SMS_IND_T_FORMAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_DUP_NEW_SMS_IND_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_dup_new_sms_ind_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_DUP_NEW_SMS_IND_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_DUP_NEW_SMS_IND_V2_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_sms_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_SMS_CMD_T_FORMAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_CMD_T_PDU_COUNT, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_CMD_T_PDU_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_CMD_T_PDU_C2K, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_sms_cmd_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_SMS_CMD_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_CMD_V2_T_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_sms_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_T_NEW_SMS_ACK, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_T_CAUSE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_T_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_T_ERR_CLASS_C2K, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_T_ERR_CODE_C2K, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 14, .min_max.max_value = 107 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_T_ACK_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_sms_rsp_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_V2_T_STANDARD, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_V2_T_ACK, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_V2_T_CAUSE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_V2_T_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_V2_T_ERROR_CLASS_3GPP2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_SMS_RSP_V2_T_CAUSE_CODE_3GPP2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_status_report_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_CMD_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_status_report_cmd_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_CMD_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_CMD_V2_T_PDU, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_status_report_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_T_ACK_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_T_CAUSE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_T_ACK_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_sms_new_status_report_rsp_tlv_checker_info_v2[] = {
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_V2_T_STANDARD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_V2_T_ACK, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_V2_T_CAUSE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_V2_T_PDU, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_V2_T_ERROR_CLASS_3GPP2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SMS_NEW_STATUS_REPORT_RSP_V2_T_CAUSE_CODE_3GPP2, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_send_ussd_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SEND_USSD_REQ_T_DCS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SEND_USSD_REQ_T_PAYLOAD_LEN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SEND_USSD_REQ_T_PAYLOAD, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 160 }},
    {.tlv_type = MIPC_SS_SEND_USSD_REQ_T_LANG, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_ss_send_ussd_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_USSD_RESPONSE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_USSD_SESSION_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_DCS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_PAYLOAD_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_PAYLOAD, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 160 }},
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_PAYLOAD_LEN_EX, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SEND_USSD_CNF_T_PAYLOAD_EX, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 10000 }},
};

static mipc_tlv_checker_info_t mipc_ss_cancel_ussd_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_CANCEL_USSD_CNF_T_USSD_RESPONSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SS_CANCEL_USSD_CNF_T_USSD_SESSION_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_CANCEL_USSD_CNF_T_DCS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_CANCEL_USSD_CNF_T_PAYLOAD_LEN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_CANCEL_USSD_CNF_T_PAYLOAD, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 160 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_clir_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CLIR_REQ_T_N_VALUE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_clir_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CLIR_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_get_clir_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_GET_CLIR_CNF_T_CLIR_N, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_GET_CLIR_CNF_T_CLIR_M, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_GET_CLIR_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_call_waiting_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CALL_WAITING_REQ_T_CW_ENABLE_DISABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_SET_CALL_WAITING_REQ_T_SERVICE_CLASS, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_call_waiting_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CALL_WAITING_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_call_waiting_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_REQ_T_SERVICE_CLASS, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_call_waiting_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_CNF_T_CALL_WAITING_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_CNF_T_SERVICE_CLASS, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_CNF_T_CW_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_CNF_T_CW_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_WAITING_CNF_T_CW_TLV_ARRAY, .option = 0x6400, .array_num = 7, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_call_forward_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_SS_OPERATION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_CALL_FORWARD_REASON, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 2, .min_max.max_value = 68 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_DIAL_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 182 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_SERVICE_CLASS, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_TOA, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_TIMER_SECONDS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_TIME_SLOT_BEGIN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_REQ_T_TIME_SLOT_END, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_call_forward_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CALL_FORWARD_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_call_forward_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CALL_FORWARD_REQ_T_SERVICE_CLASS, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_FORWARD_REQ_T_CALL_FORWARD_REASON, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 2, .min_max.max_value = 68 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_call_forward_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CALL_FORWARD_CNF_T_CALL_FORWARD_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_FORWARD_CNF_T_CALL_FORWARD_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 452 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_FORWARD_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_call_barring_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_REQ_T_LOCK, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_REQ_T_FACILITY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_REQ_T_PASSWORD, .option = 0x500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_REQ_T_SERVICE_CLASS, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_REQ_T_DIAL_NUMBER_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_REQ_T_DIAL_NUMBER_LIST, .option = 0x2300, .array_num = 10, .check_item = { .min_max.min_value = 1, .min_max.max_value = 183 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_call_barring_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CALL_BARRING_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_call_barring_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CALL_BARRING_REQ_T_FACILITY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_BARRING_REQ_T_SERVICE_CLASS, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1023 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_call_barring_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CALL_BARRING_CNF_T_CALL_BARRING_STATUS, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_BARRING_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_BARRING_CNF_T_DIAL_NUMBER_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_QUERY_CALL_BARRING_CNF_T_DIAL_NUMBER_TLV_ARRAY, .option = 0x2400, .array_num = 10, .check_item = { .fixed.fixed_value = 184 }},
};

static mipc_tlv_checker_info_t mipc_ss_change_barring_password_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_CHANGE_BARRING_PASSWORD_REQ_T_FACILITY, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_SS_CHANGE_BARRING_PASSWORD_REQ_T_OLD_PWD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_SS_CHANGE_BARRING_PASSWORD_REQ_T_NEW_PWD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_SS_CHANGE_BARRING_PASSWORD_REQ_T_NEW_PWD_CONFIRM, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 9 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_supp_svc_notification_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_SUPP_SVC_NOTIFICATION_REQ_T_STATUS_I, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_SET_SUPP_SVC_NOTIFICATION_REQ_T_STATUS_U, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_query_clip_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_QUERY_CLIP_CNF_T_CODE_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_QUERY_CLIP_CNF_T_NW_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_QUERY_CLIP_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_clip_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CLIP_REQ_T_STATUS, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_clip_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_CLIP_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_run_gba_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_RUN_GBA_REQ_T_NAF_FQDN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SS_RUN_GBA_REQ_T_NAF_SECURE_PROTOCOL_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SS_RUN_GBA_REQ_T_FORCE_RUN, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_RUN_GBA_REQ_T_NET_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_run_gba_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_RUN_GBA_CNF_T_KEY, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SS_RUN_GBA_CNF_T_KEY_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_RUN_GBA_CNF_T_BIT_ID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_SS_RUN_GBA_CNF_T_KEY_LIFETIME, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_ss_get_colp_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_GET_COLP_CNF_T_COLP_N, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_GET_COLP_CNF_T_COLP_M, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_GET_COLP_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_colp_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_COLP_REQ_T_N_VALUE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_colp_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_COLP_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_get_colr_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_GET_COLR_CNF_T_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_GET_COLR_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_send_cnap_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SEND_CNAP_CNF_T_CNAP_N, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_SEND_CNAP_CNF_T_CNAP_M, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_colr_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_COLR_REQ_T_N_VALUE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_colr_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_COLR_CNF_T_ERRMESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_setup_xcap_user_agent_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SETUP_XCAP_USER_AGENT_REQ_T_STR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_set_xcap_cfg_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_SET_XCAP_CFG_REQ_T_CFG_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_SS_SET_XCAP_CFG_REQ_T_VALUE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ss_ussd_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_USSD_IND_T_USSD_RESPONSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_SS_USSD_IND_T_USSD_SESSION_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_USSD_IND_T_DCS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_USSD_IND_T_PAYLOAD_LEN, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_USSD_IND_T_PAYLOAD, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 160 }},
    {.tlv_type = MIPC_SS_USSD_IND_T_PAYLOAD_LEN_EX, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_USSD_IND_T_PAYLOAD_EX, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 10000 }},
};

static mipc_tlv_checker_info_t mipc_ss_ecmccss_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_ECMCCSS_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_ECMCCSS_IND_T_SERVICE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_ECMCCSS_IND_T_RAW_STRING, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_ss_cfu_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_CFU_IND_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_SS_CFU_IND_T_LINE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_xcap_rcn_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_XCAP_RCN_IND_T_CODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_XCAP_RCN_IND_T_RESPONSE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ss_ims_xui_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_SS_IMS_XUI_IND_T_ACCOUNT_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_IMS_XUI_IND_T_BROADCAST_FLAG, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_SS_IMS_XUI_IND_T_XUI_INFO, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 512 }},
};

static mipc_tlv_checker_info_t mipc_stk_set_pac_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SET_PAC_REQ_T_PAC_BITMASK_PTR, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_stk_set_pac_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SET_PAC_CNF_T_PAC_PROFILE, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_stk_get_pac_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_GET_PAC_CNF_T_PAC_PROFILE, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_stk_send_terminal_response_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_TR_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_TR_PTR, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 261 }},
};

static mipc_tlv_checker_info_t mipc_stk_send_terminal_response_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_STATUS_WORDS, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_TR_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_TR_PTR, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 261 }},
};

static mipc_tlv_checker_info_t mipc_stk_send_envelope_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SEND_ENVELOPE_REQ_T_ENVELOPE_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SEND_ENVELOPE_REQ_T_ENVELOPE_PTR, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 261 }},
};

static mipc_tlv_checker_info_t mipc_stk_send_envelope_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SEND_ENVELOPE_CNF_T_STATUS_WORDS, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SEND_ENVELOPE_CNF_T_ENVELOPE_RESPONSE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 261 }},
};

static mipc_tlv_checker_info_t mipc_stk_get_envelope_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_GET_ENVELOPE_INFO_CNF_T_ENVELOPE_BITMASK, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_stk_handle_call_setup_from_sim_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_HANDLE_CALL_SETUP_FROM_SIM_REQ_T_DATA, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_stk_send_bipconf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SEND_BIPCONF_REQ_T_CMD_NUM, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SEND_BIPCONF_REQ_T_RESULT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_stk_pac_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_PAC_IND_T_PAC_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_STK_PAC_IND_T_PAC_LEN, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_PAC_IND_T_PAC, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 512 }},
};

static mipc_tlv_checker_info_t mipc_stk_sim_refresh_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_SIM_REFRESH_IND_T_SIM_REFRESH_RESULT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_STK_SIM_REFRESH_IND_T_EF_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_STK_SIM_REFRESH_IND_T_AID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_stk_bip_event_notify_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_STK_BIP_EVENT_NOTIFY_IND_T_CMD_DATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_call_dial_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_DIAL_ADDRESS, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_DIAL_ADDRESS_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_DOMAIN, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_ECC_RETRY_DOMAIN, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_ECC_CATEGORY, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_CLIR, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_IS_ECC_TESTING, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_DIAL_REQ_T_CLIR_EXT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_call_ss_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SS_REQ_T_ACTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 132 }},
    {.tlv_type = MIPC_CALL_SS_REQ_T_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SS_REQ_T_ECT_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_SS_REQ_T_ECT_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_call_hangup_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_HANGUP_REQ_T_MODE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_HANGUP_REQ_T_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_HANGUP_REQ_T_CAUSE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_call_answer_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ANSWER_REQ_T_MODE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_ANSWER_REQ_T_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_get_call_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_REQ_T_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_get_call_status_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_CALLID, .option = 0xe004, .array_num = 7, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_DIRECTION, .option = 0xe304, .array_num = 7, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_MODE, .option = 0xe304, .array_num = 7, .check_item = { .min_max.min_value = 0, .min_max.max_value = 43 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_CALL_CLCC_STATE, .option = 0xe304, .array_num = 7, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_NUMBER_TYPE, .option = 0xe304, .array_num = 7, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_TON, .option = 0xe004, .array_num = 7, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_NUMBER, .option = 0x6300, .array_num = 7, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_RAT, .option = 0xa304, .array_num = 7, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_TYPE, .option = 0xe004, .array_num = 7, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_DETAIL_INFO, .option = 0x6400, .array_num = 7, .check_item = { .fixed.fixed_value = 408 }},
    {.tlv_type = MIPC_CALL_GET_CALL_STATUS_CNF_T_VIDEO_CAP, .option = 0x6400, .array_num = 7, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_call_conference_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CONFERENCE_REQ_T_CONF_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_REQ_T_ACTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_REQ_T_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_REQ_T_TARGET_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_conference_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CONFERENCE_CNF_T_CAUSE, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 65535 }},
};

static mipc_tlv_checker_info_t mipc_call_get_conference_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_REQ_T_CONF_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_get_conference_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_DIRECTION, .option = 0xe304, .array_num = 40, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_PARTICIPANT_NUMBER, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_PARTICIPANT_NAME, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_PARTICIPANT_STATUS, .option = 0xe304, .array_num = 40, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_PARTICIPANT_USER_ENTITY, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_CALL_GET_CONFERENCE_INFO_CNF_T_PARTICIPANT_ENDPOINT_ENTITY, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
};

static mipc_tlv_checker_info_t mipc_call_get_finish_reason_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_FINISH_REASON_CNF_T_REASON, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_FINISH_REASON_CNF_T_REASON_STR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_call_dtmf_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_DTMF_REQ_T_MODE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_DTMF_REQ_T_DIGIT, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_call_get_ecc_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_ECC_LIST_CNF_T_INFO_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GET_ECC_LIST_CNF_T_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_CALL_GET_ECC_LIST_CNF_T_INFO_TLV_ARRAY, .option = 0x6400, .array_num = 128, .check_item = { .fixed.fixed_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_call_set_ecc_list_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_ECC_LIST_REQ_T_INFO_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_ECC_LIST_REQ_T_INFO_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 5 }},
    {.tlv_type = MIPC_CALL_SET_ECC_LIST_REQ_T_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 128, .check_item = { .fixed.fixed_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_call_set_flight_mode_ecc_session_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_FLIGHT_MODE_ECC_SESSION_REQ_T_IS_FLIGHT_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_ivs_onekey_ecall_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_IVS_ONEKEY_ECALL_REQ_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_IVS_ONEKEY_ECALL_REQ_T_MSD_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_IVS_ONEKEY_ECALL_REQ_T_MSD, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 140 }},
};

static mipc_tlv_checker_info_t mipc_call_set_sip_header_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_SIP_HEADER_REQ_T_TOTAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_SIP_HEADER_REQ_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_SIP_HEADER_REQ_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_SIP_HEADER_REQ_T_VALUE_PAIR, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 232 }},
};

static mipc_tlv_checker_info_t mipc_call_enable_ims_sip_header_report_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ENABLE_IMS_SIP_HEADER_REPORT_REQ_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ENABLE_IMS_SIP_HEADER_REPORT_REQ_T_HEADER_TYPE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_set_call_additional_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ_T_TOTAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ_T_ADDITIONAL_INFO, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1950 }},
};

static mipc_tlv_checker_info_t mipc_call_peer_rtt_modify_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_PEER_RTT_MODIFY_REQ_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_PEER_RTT_MODIFY_REQ_T_RESULT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_local_rtt_modify_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_LOCAL_RTT_MODIFY_REQ_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_LOCAL_RTT_MODIFY_REQ_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_local_rtt_modify_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_LOCAL_RTT_MODIFY_CNF_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_LOCAL_RTT_MODIFY_CNF_T_RESULT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_rtt_text_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RTT_TEXT_REQ_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_TEXT_REQ_T_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_TEXT_REQ_T_TEXT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1024 }},
};

static mipc_tlv_checker_info_t mipc_call_rtt_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RTT_MODE_REQ_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_call_rtt_audio_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RTT_AUDIO_REQ_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_AUDIO_REQ_T_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_set_rcs_state_and_feature_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_RCS_STATE_AND_FEATURE_REQ_T_STATE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_SET_RCS_STATE_AND_FEATURE_REQ_T_FEATURE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 8192 }},
};

static mipc_tlv_checker_info_t mipc_call_update_rcs_session_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_UPDATE_RCS_SESSION_INFO_REQ_T_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_get_voice_domain_preference_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_VOICE_DOMAIN_PREFERENCE_CNF_T_SETTING, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_call_pull_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_PULL_REQ_T_URI, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_PULL_REQ_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_get_tty_mode_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GET_TTY_MODE_CNF_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_call_set_ims_call_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_IMS_CALL_MODE_REQ_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_call_set_tty_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_TTY_MODE_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_call_set_voice_domain_preference_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_VOICE_DOMAIN_PREFERENCE_REQ_T_SETTING, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_call_conference_dial_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CONFERENCE_DIAL_REQ_T_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_DIAL_REQ_T_CLIR, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_DIAL_REQ_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_DIAL_REQ_T_DIAL_ADDRESS, .option = 0x2300, .array_num = 7, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_DIAL_REQ_T_CLIR_EXT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_call_set_gwsd_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_GWSD_MODE_REQ_T_ACTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_SET_GWSD_MODE_REQ_T_MODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_GWSD_MODE_REQ_T_KA_MODE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SET_GWSD_MODE_REQ_T_KA_CYCLE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_call_approve_csfb_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_APPROVE_CSFB_REQ_T_IS_APPROVE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_set_gwsd_call_valid_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_GWSD_CALL_VALID_REQ_T_TIMER, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_set_gwsd_ignore_call_interval_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_GWSD_IGNORE_CALL_INTERVAL_REQ_T_INTERVAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_set_gwsd_ka_pdcp_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_GWSD_KA_PDCP_REQ_T_PDATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_call_set_gwsd_ka_ipdata_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SET_GWSD_KA_IPDATA_REQ_T_PDATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_call_uis_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_UIS_INFO_REQ_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_REQ_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_REQ_T_DATA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_REQ_T_DURATION, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_auto_answer_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_AUTO_ANSWER_REQ_T_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_data_prefer_set_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_DATA_PREFER_SET_REQ_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_DATA_PREFER_SET_REQ_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_ecc_redial_approve_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ECC_REDIAL_APPROVE_REQ_T_APPROVE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ECC_REDIAL_APPROVE_REQ_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_STATUS_IND_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_DIRECTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_MODE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 43 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_TON, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_NUMBER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_TYPE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_DETAIL_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 408 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_VIDEO_CAP, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_MSG_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 136 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_DISC_CAUSE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 380, .min_max.max_value = 2005 }},
    {.tlv_type = MIPC_CALL_STATUS_IND_T_PAU, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 512 }},
};

static mipc_tlv_checker_info_t mipc_call_event_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_EVENT_IND_T_EVENT, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_REJECT_REASON, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_SRVCCH, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_REDIRECT_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_AUDIO_CODEC, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 33 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_SPEECH_ON, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_SPEECH_RAT, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_SPEECH_IRHO_ON, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_EVENT_IND_T_CALL_ID, .option = 0xa004, .array_num = 7, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_mode_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_MODE_IND_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_MODE_IND_T_MODE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 43 }},
    {.tlv_type = MIPC_CALL_MODE_IND_T_SDP_CAMERA_DIRECTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_MODE_IND_T_SDP_AUDIO_DIRECTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_MODE_IND_T_SDP_AUDIO_CODEC, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 17 }},
};

static mipc_tlv_checker_info_t mipc_call_sip_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SIP_IND_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SIP_IND_T_DIRECTION, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_SIP_IND_T_MSG_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_SIP_IND_T_METHOD, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 13 }},
    {.tlv_type = MIPC_CALL_SIP_IND_T_RESPONSE_CODE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SIP_IND_T_REASON_TEXT, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 120 }},
};

static mipc_tlv_checker_info_t mipc_call_conference_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_CONF_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_DIRECTION, .option = 0xe304, .array_num = 40, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_PARTICIPANT_NUMBER, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_PARTICIPANT_NAME, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_PARTICIPANT_STATUS, .option = 0xe304, .array_num = 40, .check_item = { .min_max.min_value = 0, .min_max.max_value = 9 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_PARTICIPANT_USER_ENTITY, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_CALL_CONFERENCE_IND_T_PARTICIPANT_ENDPOINT_ENTITY, .option = 0x6300, .array_num = 40, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
};

static mipc_tlv_checker_info_t mipc_call_ims_event_package_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_IMS_EVENT_PACKAGE_IND_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_IMS_EVENT_PACKAGE_IND_T_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_CALL_IMS_EVENT_PACKAGE_IND_T_DATA, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64000 }},
};

static mipc_tlv_checker_info_t mipc_call_ss_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_SS_IND_T_CODE1, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 12 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_CODE2, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_INDEX, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_TOA, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_SUBADDR, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_SATYPE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_SS_IND_T_RAW_STRING, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_call_ecbm_change_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ECBM_CHANGE_IND_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_call_crss_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CRSS_IND_T_CRSS_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_NUMBER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_CALL_NUMBER_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_NUMBER_PRESENTATION, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_SUB_ADDRESS, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_SA_TYPE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_ALPHAID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_CRSS_IND_T_NAME, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 80 }},
};

static mipc_tlv_checker_info_t mipc_call_ect_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ECT_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ECT_IND_T_ECT_RESULT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_ECT_IND_T_CAUSE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_cipher_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CIPHER_IND_T_SIM_CIPHER_IND, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_CIPHER_IND_T_MM_CONNECTION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_CIPHER_IND_T_CS_CIPHER_ON, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_CALL_CIPHER_IND_T_PS_CIPHER_ON, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_call_rtt_audio_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RTT_AUDIO_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_AUDIO_IND_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_rtt_capability_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RTT_CAPABILITY_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_CAPABILITY_IND_T_LOCAL_TEXT_CAPABILITY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_CAPABILITY_IND_T_REMOTE_TEXT_CAPABILITY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_CAPABILITY_IND_T_LOCAL_TEXT_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_CAPABILITY_IND_T_REAL_REMOTE_TEXT_CAPABILITY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_local_rtt_modify_result_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_LOCAL_RTT_MODIFY_RESULT_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_LOCAL_RTT_MODIFY_RESULT_IND_T_RESULT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_peer_rtt_modify_result_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_PEER_RTT_MODIFY_RESULT_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_PEER_RTT_MODIFY_RESULT_IND_T_OP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_call_rtt_text_receive_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RTT_TEXT_RECEIVE_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_TEXT_RECEIVE_IND_T_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_RTT_TEXT_RECEIVE_IND_T_TEXT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1024 }},
};

static mipc_tlv_checker_info_t mipc_call_rcs_digits_line_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RCS_DIGITS_LINE_IND_T_DIGITS_LINE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_call_display_and_signals_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_DISPLAY_AND_SIGNALS_INFO_IND_T_DISPLAY, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
    {.tlv_type = MIPC_CALL_DISPLAY_AND_SIGNALS_INFO_IND_T_SIGNAL_TYPE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_DISPLAY_AND_SIGNALS_INFO_IND_T_ALERT_PITCH, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_DISPLAY_AND_SIGNALS_INFO_IND_T_SIGNAL, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_extended_display_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_EXTENDED_DISPLAY_INFO_IND_T_DISPLAY_TAG, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_EXTENDED_DISPLAY_INFO_IND_T_INFO, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_call_line_control_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_LINE_CONTROL_INFO_IND_T_POLARITY_INCLUDED, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_LINE_CONTROL_INFO_IND_T_TOGGLE_MODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_LINE_CONTROL_INFO_IND_T_REVERSE_POLARITY, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_LINE_CONTROL_INFO_IND_T_POWER_DENIAL_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_redirecting_number_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_EXT_BIT_1, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_NUMBER_TYPE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_NUMBER_PLAN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_EXT_BIT_2, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_PI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_SI, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_EXT_BIT_3, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_REDIRECTION_REASON, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_REDIRECTING_NUMBER_INFO_IND_T_NUMBER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_call_gwsd_event_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_GWSD_EVENT_IND_T_EVENT, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_GWSD_EVENT_IND_T_CALL_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GWSD_EVENT_IND_T_UPDATE_STATUS, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GWSD_EVENT_IND_T_TON, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_GWSD_EVENT_IND_T_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_GWSD_EVENT_IND_T_RESULT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_econf_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ECONF_IND_T_CONF_CALL_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ECONF_IND_T_OPERATION, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ECONF_IND_T_NUMBER, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_ECONF_IND_T_RESULT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ECONF_IND_T_CAUSE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_ECONF_IND_T_JOINED_CALL_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_ims_sip_header_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_IMS_SIP_HEADER_IND_T_CALL_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_IMS_SIP_HEADER_IND_T_HEADER_TYPE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_IMS_SIP_HEADER_IND_T_TOTAL_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_IMS_SIP_HEADER_IND_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_IMS_SIP_HEADER_IND_T_VALUE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1950 }},
};

static mipc_tlv_checker_info_t mipc_call_ecc_redial_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_ECC_REDIAL_IND_T_CALL_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_emergency_bearer_support_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND_T_S1_SUPPORT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND_T_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND_T_SUPPORT_EMC, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND_T_EMB_IU_SUPP, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND_T_EMS_5G_SUPP, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND_T_EMF_5G_SUPP, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_call_uis_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_UIS_INFO_IND_T_CALLID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_IND_T_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_IND_T_DATA, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_IND_T_RESULT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_UIS_INFO_IND_T_CAUSE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_call_call_additional_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_MODE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_TOTAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_COUNT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_CALL_ADDITIONAL_INFO_IND_T_ADDITIONAL_INFO, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1950 }},
};

static mipc_tlv_checker_info_t mipc_call_mt_sip_invite_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_MT_SIP_INVITE_IND_T_FROM_NUMBER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_MT_SIP_INVITE_IND_T_TOTAL_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_MT_SIP_INVITE_IND_T_INDEX, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_MT_SIP_INVITE_IND_T_MT_SIP_INVITE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1950 }},
};

static mipc_tlv_checker_info_t mipc_call_recv_dtmf_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_RECV_DTMF_IND_T_MODE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_CALL_RECV_DTMF_IND_T_DIGIT, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_call_approve_incoming_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_CMD_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_CMD_T_NUMBER, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_CMD_T_TOA, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_CMD_T_SEQ_NO, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_CMD_T_MODE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 43 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_CMD_T_EVOLTESI_FLOW, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_call_approve_incoming_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_RSP_T_IS_APPROVE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_RSP_T_CAUSE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_RSP_T_CALLID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_CALL_APPROVE_INCOMING_RSP_T_SEQ_NO, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_CONFIG_REQ_T_CLASS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_IMS_SET_CONFIG_REQ_T_TYPE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_IMS_SET_CONFIG_REQ_T_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_config_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_CONFIG_CNF_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_ims_get_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_GET_CONFIG_REQ_T_CLASS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_IMS_GET_CONFIG_REQ_T_TYPE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
};

static mipc_tlv_checker_info_t mipc_ims_get_config_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_GET_CONFIG_CNF_T_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_ims_get_state_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_GET_STATE_REQ_T_EVENT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
};

static mipc_tlv_checker_info_t mipc_ims_get_state_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_EVENT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_REG_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_EXT_INFO, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_WFC, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_ACCOUNT_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_URI, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_EXPIRE_TIME, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_ERROR_CODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_GET_STATE_CNF_T_ERROR_MESSAGE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_pdis_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_PDIS_REQ_T_TRANSACTION_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_PDIS_REQ_T_METHOD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_IMS_SET_PDIS_REQ_T_IS_SUCCESS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_naptr_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_TRANSACTION_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_MOD_ID, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_RESULT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_ORDER, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_PREF, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_FLAGS, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_SERVICE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_REGEXP, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_IMS_SET_NAPTR_REQ_T_FQDN, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_ims_get_nw_rpt_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_GET_NW_RPT_CNF_T_REPORT_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_IMS_GET_NW_RPT_CNF_T_NW_IMS_VOPS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_test_mode_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_TEST_MODE_REQ_T_TEST_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_eireg_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_REG_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_REG_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_EXT_INFO, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_DEREG_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_IMS_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_SIP_URI_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_DETAIL_IMS_STATE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_REASON, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SET_EIREG_REQ_T_IMS_RETRY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_scm_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_SCM_REQ_T_APPLICATION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_IMS_SET_SCM_REQ_T_INDICATION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_service_session_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_SERVICE_SESSION_REQ_T_SERVICE_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_IMS_SET_SERVICE_SESSION_REQ_T_SERVICE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_uac_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_UAC_REQ_T_SERVICE_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_IMS_SET_UAC_REQ_T_SERVICE_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
};

static mipc_tlv_checker_info_t mipc_ims_set_evodata_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SET_EVODATA_REQ_T_EN, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_SET_EVODATA_REQ_T_DATA_MODE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_SET_EVODATA_REQ_T_ALLOW_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_SET_EVODATA_REQ_T_REPORT_METRIC, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_cfg_addition_service_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_CFG_ADDITION_SERVICE_REQ_T_SERVICE_CAP, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_ims_config_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_CONFIG_IND_T_REASON, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_CONFIG_IND_T_CONFIG_DATA, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 60000 }},
};

static mipc_tlv_checker_info_t mipc_ims_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_STATE_IND_T_EVENT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_REG_STATE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_EXT_INFO, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_WFC, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_ACCOUNT_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_URI, .option = 0x200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 256 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_EXPIRE_TIME, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_ERROR_CODE, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_STATE_IND_T_ERROR_MESSAGE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 256 }},
};

static mipc_tlv_checker_info_t mipc_ims_support_ecc_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SUPPORT_ECC_IND_T_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_IMS_SUPPORT_ECC_IND_T_SUPPORT_EMC, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_ims_pdn_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_PDN_IND_T_IND_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 127 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_PDN_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_APN_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2147483648 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_INTERFACE_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_V4_DNS_ADDR_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_V4_DNS_ADDR_TLV_ARRAY, .option = 0x3000, .array_num = 2, .check_item = { .multiple.multiple_value = 0 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_V6_DNS_ADDR_COUNT, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_PDN_IND_T_V6_DNS_ADDR_TLV_ARRAY, .option = 0x3000, .array_num = 2, .check_item = { .multiple.multiple_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_naptr_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_NAPTR_IND_T_TRANSACTION_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_NAPTR_IND_T_MOD_ID, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
    {.tlv_type = MIPC_IMS_NAPTR_IND_T_FQDN, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_reg_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_REG_IND_T_REG_STATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_REG_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_EXT_INFO, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_DEREG_CAUSE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_IMS_RETRY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_RAT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_SIP_URI_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_IND_T_REG_SUB_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_ims_sip_reg_info_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_ACCOUNT_ID, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_DIRECTION, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_SIP_MSG_TYPE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_METHOD, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_RESPONSE_CODE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_REASON_PHRASE, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_IMS_SIP_REG_INFO_IND_T_WARN_TEXT, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
};

static mipc_tlv_checker_info_t mipc_ims_vops_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_VOPS_IND_T_NWIMSVOPS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_reg_remain_time_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_REG_REMAIN_TIME_IND_T_REG_REMAIN_TIME, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_REG_REMAIN_TIME_IND_T_SUB_REMAIN_TIME, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_ui_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_UI_IND_T_ICONFLAG, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_ims_pdis_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_PDIS_CMD_T_TRANSACTION_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_PDIS_CMD_T_EM_ID, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_IMS_PDIS_CMD_T_METHOD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_IMS_PDIS_CMD_T_NW_INTERFACE_NAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 64 }},
};

static mipc_tlv_checker_info_t mipc_ims_pdis_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_IMS_PDIS_RSP_T_TRANSACTION_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_IMS_PDIS_RSP_T_METHOD, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_IMS_PDIS_RSP_T_IS_SUCCESS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_register_cell_signal_ind_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ_T_SIGNAL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ_T_ENABLE_RPT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ_T_TIME, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ_T_THRESHOLD_IN, .option = 0x8082, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ_T_THRESHOLD_OUT, .option = 0x8082, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ_T_THRESHOLD_EXT, .option = 0xa082, .array_num = 16, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_cssac_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_CSSAC_CNF_T_BF_VOICE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_CSSAC_CNF_T_BF_VIDEO, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_CSSAC_CNF_T_BT_VOICE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_CSSAC_CNF_T_BT_VIDEO, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_set_emc_aid_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_SET_EMC_AID_REQ_T_AID, .option = 0x4500, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_cfg_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_CFG_REQ_T_LOCATION_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_CFG_REQ_T_WFC_PREFER, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_wfc_cell_signal_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_CELL_SIGNAL_IND_T_SIGNAL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_CELL_SIGNAL_IND_T_VALUE, .option = 0xc082, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_wifi_pdn_count_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_WIFI_PDN_COUNT_IND_T_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_pdn_ho_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_PDN_HO_IND_T_PDN_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_PDN_HO_IND_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_PDN_HO_IND_T_SRC_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_PDN_HO_IND_T_DST_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_wfc_rove_out_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_ROVE_OUT_IND_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_ROVE_OUT_IND_T_RVOUT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_ROVE_OUT_IND_T_MOBIKE_IND, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_wfc_ssac_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_SSAC_IND_T_BF_VOICE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_SSAC_IND_T_BF_VIDEO, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_SSAC_IND_T_BT_VOICE, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_SSAC_IND_T_BT_VIDEO, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_wifi_pdn_err_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_WIFI_PDN_ERR_IND_T_CAUSE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_PDN_ERR_IND_T_SUB_CAUSE, .option = 0x8084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_PDN_ERR_IND_T_LAST_RETRY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_wfc_wifi_pdn_oos_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_WIFI_PDN_OOS_IND_T_APN, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 100 }},
    {.tlv_type = MIPC_WFC_WIFI_PDN_OOS_IND_T_CID, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_PDN_OOS_IND_T_OOS_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_wfc_wfc_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_WFC_IND_T_WIFI_PDN_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_WFC_IND_T_DATA_SIM, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WFC_IND_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_WFC_IND_T_LOCK, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WFC_IND_T_WIFI_IMS_PDN_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_wfc_ping_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_PING_CMD_T_RAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_wfc_ping_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_PING_RSP_T_RAT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_PING_RSP_T_AVE_LATENCY, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_PING_RSP_T_LOSS_RATE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_get_mac_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_GET_MAC_CMD_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_GET_MAC_CMD_T_IP, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_wfc_get_mac_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_GET_MAC_RSP_T_GET_RESULT, .option = 0xc084, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_GET_MAC_RSP_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_GET_MAC_RSP_T_IP, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_WFC_GET_MAC_RSP_T_MAC, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 6 }},
};

static mipc_tlv_checker_info_t mipc_wfc_natt_keep_alive_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_CMD_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_CMD_T_INTERVAL, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_CMD_T_SRC_IP, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_CMD_T_SRC_PORT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_CMD_T_DST_IP, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_CMD_T_DST_PORT, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_wfc_natt_keep_alive_rsp_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_RSP_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_RSP_T_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_RSP_T_SRC_IP, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_RSP_T_SRC_PORT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_RSP_T_DST_IP, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_WFC_NATT_KEEP_ALIVE_RSP_T_DST_PORT, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_register_wifi_signal_ntf_cmd_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_REGISTER_WIFI_SIGNAL_NTF_CMD_T_ENABLE_NTF, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_REGISTER_WIFI_SIGNAL_NTF_CMD_T_RSSI_THRESHOLD, .option = 0xe082, .array_num = 16, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_wifi_signal_ntf_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_WIFI_SIGNAL_NTF_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_WIFI_SIGNAL_NTF_T_RSSI, .option = 0xc082, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_SIGNAL_NTF_T_SNR, .option = 0xc082, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_wfc_epdg_screen_state_ntf_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_EPDG_SCREEN_STATE_NTF_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_wfc_wifi_info_ntf_tlv_checker_info[] = {
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IFNAME, .option = 0x4300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 128 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_ENABLE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_CAUSE, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_ASSOCIATED, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_SSID, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 33 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_AP_MAC, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 6 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_WIFI_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_MTU, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_UE_MAC, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 6 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IPV4, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IPV4_PREFIX_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IPV4_GATEWAY, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 4 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IPV6, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IPV6_PREFIX_LEN, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IPV6_GATEWAY, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 16 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_DNS, .option = 0x2200, .array_num = 10, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_IP_UPDATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_WIFI_TYPE_STR, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 32 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_WIFI_EXTEND_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_CONN_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_CONN_READY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_WFC_WIFI_INFO_NTF_T_APM_STATE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_phb_set_upb_entry_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_OP, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_ADN_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_EF_ENTRY_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_TON, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_AAS_ID, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_GRP_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_GRP_ID_LIST, .option = 0xa004, .array_num = 10, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_LINE, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 248 }},
    {.tlv_type = MIPC_PHB_SET_UPB_ENTRY_REQ_T_ENCODE_METHOD, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_upb_anr_email_sne_entry_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_REQ_T_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_REQ_T_ADN_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_REQ_T_EF_ENTRY_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_upb_anr_email_sne_entry_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_CNF_T_PHB_ENTRY, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 52 }},
    {.tlv_type = MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_CNF_T_EMAIL, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 252 }},
    {.tlv_type = MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_CNF_T_SNESTR, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 172 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_upb_aas_gas_grp_list_entry_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_REQ_T_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_REQ_T_BINDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_REQ_T_EINDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_upb_aas_gas_grp_list_entry_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_AAS_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_AAS_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_GAS_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_GAS_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 4 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_GRP_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_GRP_ID_LIST, .option = 0xa004, .array_num = 10, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_AAS_TLV_ARRAY, .option = 0x2400, .array_num = 65535, .check_item = { .fixed.fixed_value = 172 }},
    {.tlv_type = MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF_T_GAS_TLV_ARRAY, .option = 0x2400, .array_num = 65535, .check_item = { .fixed.fixed_value = 172 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_storage_info_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_STORAGE_INFO_REQ_T_STORAGE_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_storage_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_STORAGE_INFO_CNF_T_USED, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STORAGE_INFO_CNF_T_TOTAL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STORAGE_INFO_CNF_T_NLENGTH, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STORAGE_INFO_CNF_T_TLENGTH, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STORAGE_INFO_CNF_T_STORAGE_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
};

static mipc_tlv_checker_info_t mipc_phb_set_phb_mem_storage_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_SET_PHB_MEM_STORAGE_REQ_T_STORAGE_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_PHB_SET_PHB_MEM_STORAGE_REQ_T_PASSWORD, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 50 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_entry_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_REQ_T_BINDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_REQ_T_EINDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_REQ_T_STORAGE_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_REQ_T_EXT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_entry_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_CNF_T_ENTRY_COUNT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_CNF_T_ENTRY_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 16 }},
    {.tlv_type = MIPC_PHB_GET_PHB_ENTRY_CNF_T_ENTRY_TLV_ARRAY, .option = 0x2400, .array_num = 65535, .check_item = { .fixed.fixed_value = 512 }},
};

static mipc_tlv_checker_info_t mipc_phb_set_phb_entry_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_SET_PHB_ENTRY_REQ_T_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 7 }},
    {.tlv_type = MIPC_PHB_SET_PHB_ENTRY_REQ_T_EXT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_SET_PHB_ENTRY_REQ_T_ENTRY, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 512 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_stringslength_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF_T_MAX_NUM_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF_T_MAX_ALPHA_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF_T_MAX_AAS_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF_T_MAX_GAS_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF_T_MAX_SNE_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF_T_MAX_EMAIL_LEN, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_upb_capability_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_NUM_ANR, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_NUM_EMAIL, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_NUM_SNE, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_NUM_AAS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_LEN_AAS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_NUM_GAS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_LEN_GAS, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_UPB_CAPABILITY_CNF_T_NUM_GRP, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_available_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_AVAILABLE_REQ_T_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_PHB_GET_PHB_AVAILABLE_REQ_T_INDEX, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_get_phb_available_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_GET_PHB_AVAILABLE_CNF_T_MAX_NUM, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_AVAILABLE_CNF_T_AVAILABLE_NUM, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_PHB_GET_PHB_AVAILABLE_CNF_T_MAX_LEN, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_phb_ready_state_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_PHB_READY_STATE_IND_T_READY, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_emslu_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_EMSLU_CNF_T_IS_ENABLED, .option = 0x8001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_EMSLU_CNF_T_SESSION_COUNT, .option = 0x8002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_EMSLU_CNF_T_SESSION_LIST, .option = 0x1000, .array_num = 0, .check_item = { .multiple.multiple_value = 3 }},
    {.tlv_type = MIPC_EMBMS_EMSLU_CNF_T_SESSION_TLV_ARRAY, .option = 0x2400, .array_num = 435, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_embms_get_sai_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_GET_SAI_LIST_CNF_T_IS_ENABLED, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_GET_SAI_LIST_CNF_T_SAI_CF_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 144 }},
    {.tlv_type = MIPC_EMBMS_GET_SAI_LIST_CNF_T_SAI_NF_COUNT, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_GET_SAI_LIST_CNF_T_SAI_NF_LIST, .option = 0x5000, .array_num = 0, .check_item = { .multiple.multiple_value = 7 }},
    {.tlv_type = MIPC_EMBMS_GET_SAI_LIST_CNF_T_SAI_NF_TLV_ARRAY, .option = 0x6400, .array_num = 16, .check_item = { .fixed.fixed_value = 160 }},
};

static mipc_tlv_checker_info_t mipc_embms_notify_hvolte_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_NOTIFY_HVOLTE_STATUS_REQ_T_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_set_service_enable_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_SET_SERVICE_ENABLE_REQ_T_BROADCAST_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_SET_SERVICE_ENABLE_REQ_T_MULTICAST_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_get_service_enable_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_GET_SERVICE_ENABLE_CNF_T_BROADCAST_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_GET_SERVICE_ENABLE_CNF_T_MULTICAST_ENABLE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_set_broadcast_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_SET_BROADCAST_CONFIG_REQ_T_ACTION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_SET_BROADCAST_CONFIG_REQ_T_TMGI, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
    {.tlv_type = MIPC_EMBMS_SET_BROADCAST_CONFIG_REQ_T_USD_FSAI, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 152 }},
};

static mipc_tlv_checker_info_t mipc_embms_update_mbs_session_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_UPDATE_MBS_SESSION_REQ_T_MBS_OPTION, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_UPDATE_MBS_SESSION_REQ_T_SESSION_ID_TYPE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_UPDATE_MBS_SESSION_REQ_T_TMGI, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
    {.tlv_type = MIPC_EMBMS_UPDATE_MBS_SESSION_REQ_T_IP_ADDRESS, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_EMBMS_UPDATE_MBS_SESSION_REQ_T_CELL_ID_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_EMBMS_UPDATE_MBS_SESSION_REQ_T_TAC_TLV_ARRAY, .option = 0x2400, .array_num = 16, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_embms_query_mbs_multicast_remain_time_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_QUERY_MBS_MULTICAST_REMAIN_TIME_REQ_T_TGMI, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
};

static mipc_tlv_checker_info_t mipc_embms_query_mbs_multicast_remain_time_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_QUERY_MBS_MULTICAST_REMAIN_TIME_CNF_T_REMAINING_TIME, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_emsrv_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_EMSRV_IND_T_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_EMSRV_IND_T_AREA_ID_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_embms_emslui_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_EMSLUI_IND_T_NUM_SESSIONS, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_EMSLUI_IND_T_SESSIONS_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
};

static mipc_tlv_checker_info_t mipc_embms_emsailnf_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_EMSAILNF_IND_T_MBMS_NB_FREQ_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 160 }},
};

static mipc_tlv_checker_info_t mipc_embms_emsess_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_EMSESS_IND_T_NUM_SESSIONS, .option = 0xc002, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_EMSESS_IND_T_MBMS_SESSION_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 24 }},
    {.tlv_type = MIPC_EMBMS_EMSESS_IND_T_CAUSE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_EMSESS_IND_T_SUB_CAUSE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_ehvolte_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_EHVOLTE_IND_T_MODE, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_service_coverage_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_SERVICE_COVERAGE_IND_T_MBMS_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_embms_broadcast_session_list_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_BROADCAST_SESSION_LIST_IND_T_SESSION_STATUS_TLV_ARRAY, .option = 0x6400, .array_num = 128, .check_item = { .fixed.fixed_value = 11 }},
};

static mipc_tlv_checker_info_t mipc_embms_mbs_freq_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_MBS_FREQ_IND_T_FREQ_TLV_ARRAY, .option = 0x6400, .array_num = 128, .check_item = { .fixed.fixed_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_embms_session_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_SESSION_STATUS_IND_T_SERVICE_STATUS, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_SESSION_STATUS_IND_T_TMGI_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
};

static mipc_tlv_checker_info_t mipc_embms_sai_intra_list_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_SAI_INTRA_LIST_IND_T_USD_FSAI, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 152 }},
};

static mipc_tlv_checker_info_t mipc_embms_sai_neighbor_list_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_SAI_NEIGHBOR_LIST_IND_T_FSAI_NEIGHBOR_TLV_ARRAY, .option = 0x6400, .array_num = 8, .check_item = { .fixed.fixed_value = 132 }},
};

static mipc_tlv_checker_info_t mipc_embms_mbs_multicast_area_info_update_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_MBS_MULTICAST_AREA_INFO_UPDATE_IND_T_TMGI_TLV_ARRAY, .option = 0x6400, .array_num = 16, .check_item = { .fixed.fixed_value = 10 }},
    {.tlv_type = MIPC_EMBMS_MBS_MULTICAST_AREA_INFO_UPDATE_IND_T_AREA_INFO_LIST, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 16 }},
};

static mipc_tlv_checker_info_t mipc_embms_mbs_session_update_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_TMGI_INFO, .option = 0x4400, .array_num = 0, .check_item = { .fixed.fixed_value = 10 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_PSI, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_IP_ADDRESS, .option = 0x400, .array_num = 0, .check_item = { .fixed.fixed_value = 32 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_MBS_DECISION, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 161 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_MBS_REJ_CAUSE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 6 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_MBS_SEC_CONTAINER_RAW, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 38 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_CELL_ID_TLV_ARRAY, .option = 0x6400, .array_num = 16, .check_item = { .fixed.fixed_value = 12 }},
    {.tlv_type = MIPC_EMBMS_MBS_SESSION_UPDATE_IND_T_TAC_TLV_ARRAY, .option = 0x6400, .array_num = 16, .check_item = { .fixed.fixed_value = 12 }},
};

static mipc_tlv_checker_info_t mipc_ecall_ivs_update_msd_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_ECALL_IVS_UPDATE_MSD_REQ_T_MSD_FORMAT, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_ECALL_IVS_UPDATE_MSD_REQ_T_MSD_DATA, .option = 0x4200, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 140 }},
};

static mipc_tlv_checker_info_t mipc_ecall_ivs_set_test_addr_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_ECALL_IVS_SET_TEST_ADDR_REQ_T_ADDR_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_ECALL_IVS_SET_TEST_ADDR_REQ_T_ADDRESS, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
};

static mipc_tlv_checker_info_t mipc_ecall_ivs_set_reconf_addr_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_ECALL_IVS_SET_RECONF_ADDR_REQ_T_ADDR_TYPE, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_ECALL_IVS_SET_RECONF_ADDR_REQ_T_ADDRESS, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
};

static mipc_tlv_checker_info_t mipc_ecall_ivs_set_addr_pri_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_ECALL_IVS_SET_ADDR_PRI_REQ_T_FIRST_PRI, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_ECALL_IVS_SET_ADDR_PRI_REQ_T_SECOND_PRI, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_ECALL_IVS_SET_ADDR_PRI_REQ_T_THIRD_PRI, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
    {.tlv_type = MIPC_ECALL_IVS_SET_ADDR_PRI_REQ_T_FOURTH_PRI, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 4 }},
};

static mipc_tlv_checker_info_t mipc_ecall_ivs_get_sim_info_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_ECALL_IVS_GET_SIM_INFO_CNF_T_SIM_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_ECALL_IVS_GET_SIM_INFO_CNF_T_TEST_ECALL_URI, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_ECALL_IVS_GET_SIM_INFO_CNF_T_TEST_ECALL_NUM, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_ECALL_IVS_GET_SIM_INFO_CNF_T_RECONF_ECALL_URI, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_ECALL_IVS_GET_SIM_INFO_CNF_T_RECONF_ECALL_NUM, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
};

static mipc_tlv_checker_info_t mipc_ecall_status_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_ECALL_STATUS_IND_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_ECALL_STATUS_IND_T_CALL_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_exims_update_session_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UPDATE_SESSION_STATUS_REQ_T_SESSION_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SESSION_STATUS_REQ_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SESSION_STATUS_REQ_T_CALLBACK_MODE_RAT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SESSION_STATUS_REQ_T_IS_AIRPLANE_MODE_EMERGENCY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_get_call_domain_select_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_REQ_T_CALL_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_REQ_T_CALL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_REQ_T_AVAILABLE_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_REQ_T_PREFER_RAT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_exims_get_call_domain_select_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_CNF_T_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_CNF_T_CAUSE, .option = 0x8302, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 255 }},
};

static mipc_tlv_checker_info_t mipc_exims_update_call_status_event_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_CALL_ID, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_CALL_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_CALL_STATUS, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 5 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_CAUSE, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 255 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_IS_FAR_END, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_DIR, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_ADDRESS, .option = 0x300, .array_num = 0, .check_item = { .min_max.min_value = 1, .min_max.max_value = 180 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ_T_ADDRESS_TYPE, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_exims_update_ims_ho_status_event_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UPDATE_IMS_HO_STATUS_EVENT_REQ_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_IMS_HO_STATUS_EVENT_REQ_T_SOURCE_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_IMS_HO_STATUS_EVENT_REQ_T_TARGET_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_IMS_HO_STATUS_EVENT_REQ_T_RESULT, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_get_sms_domain_select_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_REQ_T_SMS_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_REQ_T_AVAILABLE_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_REQ_T_PREFER_DOMAIN, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_get_sms_domain_select_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_CNF_T_AVAILABLE_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_CNF_T_SMS_DOMAIN, .option = 0x8304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_update_sms_status_event_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_REQ_T_DIR, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_REQ_T_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_REQ_T_SMS_DOMAIN, .option = 0xc304, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_REQ_T_SMS_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_REQ_T_STATUS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
};

static mipc_tlv_checker_info_t mipc_exims_update_reg_status_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_STATE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_TYPE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_EXT_INFO, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_DEREG_CAUSE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 2 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_RAT, .option = 0x8004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_SIP_URI_TYPE, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_REG_STATUS_REQ_T_IMS_RETRY, .option = 0x8301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_update_config_req_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UPDATE_CONFIG_REQ_T_IS_IMS_CFG_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CONFIG_REQ_T_Vo3GPP_CFG, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CONFIG_REQ_T_Vi3GPP_CFG, .option = 0xc302, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CONFIG_REQ_T_IS_VoWiFi_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CONFIG_REQ_T_IS_ViWiFi_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_UPDATE_CONFIG_REQ_T_IS_IMS_SMS_ENABLE, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_get_ecc_list_cnf_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_GET_ECC_LIST_CNF_T_INFO_TLV_ARRAY, .option = 0x2400, .array_num = 128, .check_item = { .fixed.fixed_value = 20 }},
};

static mipc_tlv_checker_info_t mipc_exims_imsvops_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_IMSVOPS_IND_T_IS_SUPPORT_IMSVOPS, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_emergency_service_support_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_EMERGENCY_SERVICE_SUPPORT_IND_T_RAT, .option = 0xc004, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
    {.tlv_type = MIPC_EXIMS_EMERGENCY_SERVICE_SUPPORT_IND_T_IS_SUPPORT_EMC, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_emergency_bearer_support_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_EMERGENCY_BEARER_SUPPORT_IND_T_IS_SUPPORT_S1, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
    {.tlv_type = MIPC_EXIMS_EMERGENCY_BEARER_SUPPORT_IND_T_EMS_5G_SUPP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_EXIMS_EMERGENCY_BEARER_SUPPORT_IND_T_EMF_5G_SUPP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 3 }},
    {.tlv_type = MIPC_EXIMS_EMERGENCY_BEARER_SUPPORT_IND_T_EMB_IU_SUPP, .option = 0xc301, .array_num = 0, .check_item = { .min_max.min_value = 0, .min_max.max_value = 1 }},
};

static mipc_tlv_checker_info_t mipc_exims_unlock_call_bar_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UNLOCK_CALL_BAR_IND_T_BAR, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_tlv_checker_info_t mipc_exims_unlock_sms_bar_ind_tlv_checker_info[] = {
    {.tlv_type = MIPC_EXIMS_UNLOCK_SMS_BAR_IND_T_BAR, .option = 0xc001, .array_num = 0, .check_item = { .fixed.fixed_value = 0 }},
};

static mipc_checker_info_t mipc_checker_info[] = {
    {MIPC_SYS_GET_INFO_REQ, 1, "GET_INFO_REQ", 0, NULL},
    {MIPC_SYS_GET_INFO_CNF, 1, "GET_INFO_CNF", 34, mipc_sys_get_info_cnf_tlv_checker_info},
    {MIPC_SYS_AT_REQ, 1, "AT_REQ", 1, mipc_sys_at_req_tlv_checker_info},
    {MIPC_SYS_AT_CNF, 1, "AT_CNF", 1, mipc_sys_at_cnf_tlv_checker_info},
    {MIPC_SYS_REBOOT_REQ, 1, "REBOOT_REQ", 2, mipc_sys_reboot_req_tlv_checker_info},
    {MIPC_SYS_REBOOT_CNF, 1, "REBOOT_CNF", 0, NULL},
    {MIPC_SYS_GET_MAPPING_REQ, 1, "GET_MAPPING_REQ", 1, mipc_sys_get_mapping_req_tlv_checker_info},
    {MIPC_SYS_GET_MAPPING_CNF, 1, "GET_MAPPING_CNF", 3, mipc_sys_get_mapping_cnf_tlv_checker_info},
    {MIPC_SYS_SET_MAPPING_REQ, 1, "SET_MAPPING_REQ", 3, mipc_sys_set_mapping_req_tlv_checker_info},
    {MIPC_SYS_SET_MAPPING_CNF, 1, "SET_MAPPING_CNF", 3, mipc_sys_set_mapping_cnf_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_NUM_REQ, 1, "GET_THERMAL_SENSOR_NUM_REQ", 0, NULL},
    {MIPC_SYS_GET_THERMAL_SENSOR_NUM_CNF, 1, "GET_THERMAL_SENSOR_NUM_CNF", 1, mipc_sys_get_thermal_sensor_num_cnf_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_INFO_REQ, 1, "GET_THERMAL_SENSOR_INFO_REQ", 1, mipc_sys_get_thermal_sensor_info_req_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_INFO_CNF, 1, "GET_THERMAL_SENSOR_INFO_CNF", 11, mipc_sys_get_thermal_sensor_info_cnf_tlv_checker_info},
    {MIPC_SYS_SET_THERMAL_SENSOR_REQ, 1, "SET_THERMAL_SENSOR_REQ", 3, mipc_sys_set_thermal_sensor_req_tlv_checker_info},
    {MIPC_SYS_SET_THERMAL_SENSOR_CNF, 1, "SET_THERMAL_SENSOR_CNF", 3, mipc_sys_set_thermal_sensor_cnf_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_REQ, 1, "GET_THERMAL_SENSOR_REQ", 1, mipc_sys_get_thermal_sensor_req_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_CNF, 1, "GET_THERMAL_SENSOR_CNF", 1, mipc_sys_get_thermal_sensor_cnf_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_ACTUATOR_NUM_REQ, 1, "GET_THERMAL_ACTUATOR_NUM_REQ", 0, NULL},
    {MIPC_SYS_GET_THERMAL_ACTUATOR_NUM_CNF, 1, "GET_THERMAL_ACTUATOR_NUM_CNF", 1, mipc_sys_get_thermal_actuator_num_cnf_tlv_checker_info},
    {MIPC_SYS_SET_THERMAL_ACTUATOR_REQ, 1, "SET_THERMAL_ACTUATOR_REQ", 3, mipc_sys_set_thermal_actuator_req_tlv_checker_info},
    {MIPC_SYS_SET_THERMAL_ACTUATOR_CNF, 1, "SET_THERMAL_ACTUATOR_CNF", 0, NULL},
    {MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_REQ, 1, "GET_THERMAL_ACTUATOR_INFO_REQ", 1, mipc_sys_get_thermal_actuator_info_req_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_ACTUATOR_INFO_CNF, 1, "GET_THERMAL_ACTUATOR_INFO_CNF", 6, mipc_sys_get_thermal_actuator_info_cnf_tlv_checker_info},
    {MIPC_SYS_SET_CONFIG_REQ, 1, "SET_CONFIG_REQ", 3, mipc_sys_set_config_req_tlv_checker_info},
    {MIPC_SYS_SET_CONFIG_CNF, 1, "SET_CONFIG_CNF", 1, mipc_sys_set_config_cnf_tlv_checker_info},
    {MIPC_SYS_GET_CONFIG_REQ, 1, "GET_CONFIG_REQ", 2, mipc_sys_get_config_req_tlv_checker_info},
    {MIPC_SYS_GET_CONFIG_CNF, 1, "GET_CONFIG_CNF", 1, mipc_sys_get_config_cnf_tlv_checker_info},
    {MIPC_SYS_REG_CONFIG_REQ, 1, "REG_CONFIG_REQ", 2, mipc_sys_reg_config_req_tlv_checker_info},
    {MIPC_SYS_REG_CONFIG_CNF, 1, "REG_CONFIG_CNF", 0, NULL},
    {MIPC_SYS_SET_ADPCLK_REQ, 1, "SET_ADPCLK_REQ", 1, mipc_sys_set_adpclk_req_tlv_checker_info},
    {MIPC_SYS_SET_ADPCLK_CNF, 1, "SET_ADPCLK_CNF", 0, NULL},
    {MIPC_SYS_GET_ADPCLK_REQ, 1, "GET_ADPCLK_REQ", 0, NULL},
    {MIPC_SYS_GET_ADPCLK_CNF, 1, "GET_ADPCLK_CNF", 3, mipc_sys_get_adpclk_cnf_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_MODE_REQ, 1, "SET_MD_LOG_MODE_REQ", 1, mipc_sys_set_md_log_mode_req_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_MODE_CNF, 1, "SET_MD_LOG_MODE_CNF", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_MODE_REQ, 1, "GET_MD_LOG_MODE_REQ", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_MODE_CNF, 1, "GET_MD_LOG_MODE_CNF", 1, mipc_sys_get_md_log_mode_cnf_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_LEVEL_REQ, 1, "SET_MD_LOG_LEVEL_REQ", 1, mipc_sys_set_md_log_level_req_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_LEVEL_CNF, 1, "SET_MD_LOG_LEVEL_CNF", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_LEVEL_REQ, 1, "GET_MD_LOG_LEVEL_REQ", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_LEVEL_CNF, 1, "GET_MD_LOG_LEVEL_CNF", 1, mipc_sys_get_md_log_level_cnf_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_LOCATION_REQ, 1, "SET_MD_LOG_LOCATION_REQ", 1, mipc_sys_set_md_log_location_req_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_LOCATION_CNF, 1, "SET_MD_LOG_LOCATION_CNF", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_LOCATION_REQ, 1, "GET_MD_LOG_LOCATION_REQ", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_LOCATION_CNF, 1, "GET_MD_LOG_LOCATION_CNF", 1, mipc_sys_get_md_log_location_cnf_tlv_checker_info},
    {MIPC_SYS_WRITE_NVRAM_REQ, 1, "WRITE_NVRAM_REQ", 3, mipc_sys_write_nvram_req_tlv_checker_info},
    {MIPC_SYS_WRITE_NVRAM_CNF, 1, "WRITE_NVRAM_CNF", 2, mipc_sys_write_nvram_cnf_tlv_checker_info},
    {MIPC_SYS_READ_NVRAM_REQ, 1, "READ_NVRAM_REQ", 2, mipc_sys_read_nvram_req_tlv_checker_info},
    {MIPC_SYS_READ_NVRAM_CNF, 1, "READ_NVRAM_CNF", 2, mipc_sys_read_nvram_cnf_tlv_checker_info},
    {MIPC_SYS_AUTH_REQ, 1, "AUTH_REQ", 2, mipc_sys_auth_req_tlv_checker_info},
    {MIPC_SYS_AUTH_CNF, 1, "AUTH_CNF", 1, mipc_sys_auth_cnf_tlv_checker_info},
    {MIPC_SYS_SET_DAT_REQ, 1, "SET_DAT_REQ", 1, mipc_sys_set_dat_req_tlv_checker_info},
    {MIPC_SYS_SET_DAT_CNF, 1, "SET_DAT_CNF", 0, NULL},
    {MIPC_SYS_GET_DAT_REQ, 1, "GET_DAT_REQ", 0, NULL},
    {MIPC_SYS_GET_DAT_CNF, 1, "GET_DAT_CNF", 1, mipc_sys_get_dat_cnf_tlv_checker_info},
    {MIPC_SYS_MCF_REQ, 1, "MCF_REQ", 14, mipc_sys_mcf_req_tlv_checker_info},
    {MIPC_SYS_MCF_CNF, 1, "MCF_CNF", 10, mipc_sys_mcf_cnf_tlv_checker_info},
    {MIPC_SYS_SET_FCC_LOCK_REQ, 1, "SET_FCC_LOCK_REQ", 1, mipc_sys_set_fcc_lock_req_tlv_checker_info},
    {MIPC_SYS_SET_FCC_LOCK_CNF, 1, "SET_FCC_LOCK_CNF", 0, NULL},
    {MIPC_SYS_SET_TIME_REQ, 1, "SET_TIME_REQ", 7, mipc_sys_set_time_req_tlv_checker_info},
    {MIPC_SYS_SET_TIME_CNF, 1, "SET_TIME_CNF", 0, NULL},
    {MIPC_SYS_GET_TIME_REQ, 1, "GET_TIME_REQ", 0, NULL},
    {MIPC_SYS_GET_TIME_CNF, 1, "GET_TIME_CNF", 8, mipc_sys_get_time_cnf_tlv_checker_info},
    {MIPC_SYS_SET_SAR_REQ, 1, "SET_SAR_REQ", 2, mipc_sys_set_sar_req_tlv_checker_info},
    {MIPC_SYS_SET_SAR_CNF, 1, "SET_SAR_CNF", 2, mipc_sys_set_sar_cnf_tlv_checker_info},
    {MIPC_SYS_GET_SAR_REQ, 1, "GET_SAR_REQ", 0, NULL},
    {MIPC_SYS_GET_SAR_CNF, 1, "GET_SAR_CNF", 2, mipc_sys_get_sar_cnf_tlv_checker_info},
    {MIPC_SYS_SET_POWER_SAVING_REQ, 1, "SET_POWER_SAVING_REQ", 1, mipc_sys_set_power_saving_req_tlv_checker_info},
    {MIPC_SYS_SET_POWER_SAVING_CNF, 1, "SET_POWER_SAVING_CNF", 0, NULL},
    {MIPC_SYS_CONNECTIVITY_STATISTICS_REQ, 1, "CONNECTIVITY_STATISTICS_REQ", 4, mipc_sys_connectivity_statistics_req_tlv_checker_info},
    {MIPC_SYS_CONNECTIVITY_STATISTICS_CNF, 1, "CONNECTIVITY_STATISTICS_CNF", 9, mipc_sys_connectivity_statistics_cnf_tlv_checker_info},
    {MIPC_SYS_QUERY_SBP_REQ, 1, "QUERY_SBP_REQ", 0, NULL},
    {MIPC_SYS_QUERY_SBP_CNF, 1, "QUERY_SBP_CNF", 4, mipc_sys_query_sbp_cnf_tlv_checker_info},
    {MIPC_SYS_SET_TX_IND_INTERVAL_REQ, 1, "SET_TX_IND_INTERVAL_REQ", 1, mipc_sys_set_tx_ind_interval_req_tlv_checker_info},
    {MIPC_SYS_SET_TX_IND_INTERVAL_CNF, 1, "SET_TX_IND_INTERVAL_CNF", 0, NULL},
    {MIPC_SYS_SET_GEO_LOCATION_REQ, 1, "SET_GEO_LOCATION_REQ", 16, mipc_sys_set_geo_location_req_tlv_checker_info},
    {MIPC_SYS_SET_GEO_LOCATION_CNF, 1, "SET_GEO_LOCATION_CNF", 0, NULL},
    {MIPC_SYS_SET_DSBP_REQ, 1, "SET_DSBP_REQ", 1, mipc_sys_set_dsbp_req_tlv_checker_info},
    {MIPC_SYS_SET_DSBP_CNF, 1, "SET_DSBP_CNF", 0, NULL},
    {MIPC_SYS_SEND_SAR_IND_REQ, 1, "SEND_SAR_IND_REQ", 2, mipc_sys_send_sar_ind_req_tlv_checker_info},
    {MIPC_SYS_SEND_SAR_IND_CNF, 1, "SEND_SAR_IND_CNF", 0, NULL},
    {MIPC_SYS_SILENT_REBOOT_REQ, 1, "SILENT_REBOOT_REQ", 1, mipc_sys_silent_reboot_req_tlv_checker_info},
    {MIPC_SYS_SILENT_REBOOT_CNF, 1, "SILENT_REBOOT_CNF", 0, NULL},
    {MIPC_SYS_MULTI_SIM_CONFIG_REQ, 1, "MULTI_SIM_CONFIG_REQ", 1, mipc_sys_multi_sim_config_req_tlv_checker_info},
    {MIPC_SYS_MULTI_SIM_CONFIG_CNF, 1, "MULTI_SIM_CONFIG_CNF", 0, NULL},
    {MIPC_SYS_REBOOT_SET_REQ, 1, "REBOOT_SET_REQ", 1, mipc_sys_reboot_set_req_tlv_checker_info},
    {MIPC_SYS_REBOOT_SET_CNF, 1, "REBOOT_SET_CNF", 0, NULL},
    {MIPC_SYS_GET_THERMAL_ACTUATOR_REQ, 1, "GET_THERMAL_ACTUATOR_REQ", 2, mipc_sys_get_thermal_actuator_req_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_ACTUATOR_CNF, 1, "GET_THERMAL_ACTUATOR_CNF", 2, mipc_sys_get_thermal_actuator_cnf_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_RUNTIME_REQ, 1, "GET_THERMAL_SENSOR_RUNTIME_REQ", 2, mipc_sys_get_thermal_sensor_runtime_req_tlv_checker_info},
    {MIPC_SYS_GET_THERMAL_SENSOR_RUNTIME_CNF, 1, "GET_THERMAL_SENSOR_RUNTIME_CNF", 2, mipc_sys_get_thermal_sensor_runtime_cnf_tlv_checker_info},
    {MIPC_SYS_SET_THERMAL_RUNTIME_REQ, 1, "SET_THERMAL_RUNTIME_REQ", 4, mipc_sys_set_thermal_runtime_req_tlv_checker_info},
    {MIPC_SYS_SET_THERMAL_RUNTIME_CNF, 1, "SET_THERMAL_RUNTIME_CNF", 0, NULL},
    {MIPC_SYS_SET_OR_GET_SBP_INFO_REQ, 1, "SET_OR_GET_SBP_INFO_REQ", 5, mipc_sys_set_or_get_sbp_info_req_tlv_checker_info},
    {MIPC_SYS_SET_OR_GET_SBP_INFO_CNF, 1, "SET_OR_GET_SBP_INFO_CNF", 1, mipc_sys_set_or_get_sbp_info_cnf_tlv_checker_info},
    {MIPC_SYS_GET_ALL_THERMAL_INFO_REQ, 1, "GET_ALL_THERMAL_INFO_REQ", 0, NULL},
    {MIPC_SYS_GET_ALL_THERMAL_INFO_CNF, 1, "GET_ALL_THERMAL_INFO_CNF", 3, mipc_sys_get_all_thermal_info_cnf_tlv_checker_info},
    {MIPC_SYS_META_REQ, 1, "META_REQ", 3, mipc_sys_meta_req_tlv_checker_info},
    {MIPC_SYS_META_CNF, 1, "META_CNF", 3, mipc_sys_meta_cnf_tlv_checker_info},
    {MIPC_SYS_DMF_REQ, 1, "DMF_REQ", 2, mipc_sys_dmf_req_tlv_checker_info},
    {MIPC_SYS_DMF_CNF, 1, "DMF_CNF", 3, mipc_sys_dmf_cnf_tlv_checker_info},
    {MIPC_SYS_ECHO_REQ, 1, "ECHO_REQ", 0, NULL},
    {MIPC_SYS_ECHO_CNF, 1, "ECHO_CNF", 0, NULL},
    {MIPC_SYS_META_FORWARDER_CTRL_REQ, 1, "META_FORWARDER_CTRL_REQ", 2, mipc_sys_meta_forwarder_ctrl_req_tlv_checker_info},
    {MIPC_SYS_META_FORWARDER_CTRL_CNF, 1, "META_FORWARDER_CTRL_CNF", 2, mipc_sys_meta_forwarder_ctrl_cnf_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_FLUSH_INTERVAL_REQ, 1, "SET_MD_LOG_FLUSH_INTERVAL_REQ", 1, mipc_sys_set_md_log_flush_interval_req_tlv_checker_info},
    {MIPC_SYS_SET_MD_LOG_FLUSH_INTERVAL_CNF, 1, "SET_MD_LOG_FLUSH_INTERVAL_CNF", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_FLUSH_INTERVAL_REQ, 1, "GET_MD_LOG_FLUSH_INTERVAL_REQ", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_FLUSH_INTERVAL_CNF, 1, "GET_MD_LOG_FLUSH_INTERVAL_CNF", 1, mipc_sys_get_md_log_flush_interval_cnf_tlv_checker_info},
    {MIPC_SYS_HBA_ESTABLISH_REQ, 1, "HBA_ESTABLISH_REQ", 32, mipc_sys_hba_establish_req_tlv_checker_info},
    {MIPC_SYS_HBA_ESTABLISH_CNF, 1, "HBA_ESTABLISH_CNF", 1, mipc_sys_hba_establish_cnf_tlv_checker_info},
    {MIPC_SYS_HBA_CTRL_REQ, 1, "HBA_CTRL_REQ", 2, mipc_sys_hba_ctrl_req_tlv_checker_info},
    {MIPC_SYS_HBA_CTRL_CNF, 1, "HBA_CTRL_CNF", 20, mipc_sys_hba_ctrl_cnf_tlv_checker_info},
    {MIPC_SYS_HBA_SEND_NOW_REQ, 1, "HBA_SEND_NOW_REQ", 1, mipc_sys_hba_send_now_req_tlv_checker_info},
    {MIPC_SYS_HBA_SEND_NOW_CNF, 1, "HBA_SEND_NOW_CNF", 1, mipc_sys_hba_send_now_cnf_tlv_checker_info},
    {MIPC_SYS_HBA_RESUME_REQ, 1, "HBA_RESUME_REQ", 14, mipc_sys_hba_resume_req_tlv_checker_info},
    {MIPC_SYS_HBA_RESUME_CNF, 1, "HBA_RESUME_CNF", 1, mipc_sys_hba_resume_cnf_tlv_checker_info},
    {MIPC_SYS_MIA_START_SCENARIO_REQ, 1, "MIA_START_SCENARIO_REQ", 1, mipc_sys_mia_start_scenario_req_tlv_checker_info},
    {MIPC_SYS_MIA_START_SCENARIO_CNF, 1, "MIA_START_SCENARIO_CNF", 0, NULL},
    {MIPC_SYS_MIA_STOP_SCENARIO_REQ, 1, "MIA_STOP_SCENARIO_REQ", 1, mipc_sys_mia_stop_scenario_req_tlv_checker_info},
    {MIPC_SYS_MIA_STOP_SCENARIO_CNF, 1, "MIA_STOP_SCENARIO_CNF", 0, NULL},
    {MIPC_SYS_MIA_UPDATE_METRICS_REQ, 1, "MIA_UPDATE_METRICS_REQ", 1, mipc_sys_mia_update_metrics_req_tlv_checker_info},
    {MIPC_SYS_MIA_UPDATE_METRICS_CNF, 1, "MIA_UPDATE_METRICS_CNF", 0, NULL},
    {MIPC_SYS_TRIGGER_MD_LOG_FLUSH_REQ, 1, "TRIGGER_MD_LOG_FLUSH_REQ", 0, NULL},
    {MIPC_SYS_TRIGGER_MD_LOG_FLUSH_CNF, 1, "TRIGGER_MD_LOG_FLUSH_CNF", 1, mipc_sys_trigger_md_log_flush_cnf_tlv_checker_info},
    {MIPC_SYS_GET_MD_LOG_FLUSH_STATUS_REQ, 1, "GET_MD_LOG_FLUSH_STATUS_REQ", 0, NULL},
    {MIPC_SYS_GET_MD_LOG_FLUSH_STATUS_CNF, 1, "GET_MD_LOG_FLUSH_STATUS_CNF", 1, mipc_sys_get_md_log_flush_status_cnf_tlv_checker_info},
    {MIPC_SYS_GET_GNSS_COCLOCK_NVDATA_REQ, 1, "GET_GNSS_COCLOCK_NVDATA_REQ", 0, NULL},
    {MIPC_SYS_GET_GNSS_COCLOCK_NVDATA_CNF, 1, "GET_GNSS_COCLOCK_NVDATA_CNF", 3, mipc_sys_get_gnss_coclock_nvdata_cnf_tlv_checker_info},
    {MIPC_SYS_SET_SBP_INFO_REQ, 1, "SET_SBP_INFO_REQ", 5, mipc_sys_set_sbp_info_req_tlv_checker_info},
    {MIPC_SYS_SET_SBP_INFO_CNF, 1, "SET_SBP_INFO_CNF", 1, mipc_sys_set_sbp_info_cnf_tlv_checker_info},
    {MIPC_SYS_GET_SBP_INFO_REQ, 1, "GET_SBP_INFO_REQ", 4, mipc_sys_get_sbp_info_req_tlv_checker_info},
    {MIPC_SYS_GET_SBP_INFO_CNF, 1, "GET_SBP_INFO_CNF", 1, mipc_sys_get_sbp_info_cnf_tlv_checker_info},
    {MIPC_SYS_SET_SPV_CONTROL_REQ, 1, "SET_SPV_CONTROL_REQ", 5, mipc_sys_set_spv_control_req_tlv_checker_info},
    {MIPC_SYS_SET_SPV_CONTROL_CNF, 1, "SET_SPV_CONTROL_CNF", 0, NULL},
    {MIPC_SYS_SET_LOWV_ACTUATOR_REQ, 1, "SET_LOWV_ACTUATOR_REQ", 2, mipc_sys_set_lowv_actuator_req_tlv_checker_info},
    {MIPC_SYS_SET_LOWV_ACTUATOR_CNF, 1, "SET_LOWV_ACTUATOR_CNF", 0, NULL},
    {MIPC_SYS_GET_LOWV_ACTUATOR_REQ, 1, "GET_LOWV_ACTUATOR_REQ", 2, mipc_sys_get_lowv_actuator_req_tlv_checker_info},
    {MIPC_SYS_GET_LOWV_ACTUATOR_CNF, 1, "GET_LOWV_ACTUATOR_CNF", 2, mipc_sys_get_lowv_actuator_cnf_tlv_checker_info},
    {MIPC_SYS_SET_MSPM_SESSION_REQ, 1, "SET_MSPM_SESSION_REQ", 4, mipc_sys_set_mspm_session_req_tlv_checker_info},
    {MIPC_SYS_SET_MSPM_SESSION_CNF, 1, "SET_MSPM_SESSION_CNF", 0, NULL},
    {MIPC_SYS_SET_ERRC_OFFSET_REQ, 1, "SET_ERRC_OFFSET_REQ", 4, mipc_sys_set_errc_offset_req_tlv_checker_info},
    {MIPC_SYS_SET_ERRC_OFFSET_CNF, 1, "SET_ERRC_OFFSET_CNF", 0, NULL},
    {MIPC_SYS_SET_MDDBG_CONTROL_REQ, 1, "SET_MDDBG_CONTROL_REQ", 14, mipc_sys_set_mddbg_control_req_tlv_checker_info},
    {MIPC_SYS_SET_MDDBG_CONTROL_CNF, 1, "SET_MDDBG_CONTROL_CNF", 0, NULL},
    {MIPC_SYS_TRIGGER_CHIP_DIAGNOSIS_REQ, 1, "TRIGGER_CHIP_DIAGNOSIS_REQ", 2, mipc_sys_trigger_chip_diagnosis_req_tlv_checker_info},
    {MIPC_SYS_TRIGGER_CHIP_DIAGNOSIS_CNF, 1, "TRIGGER_CHIP_DIAGNOSIS_CNF", 0, NULL},
    {MIPC_APN_SET_IA_REQ, 1, "SET_IA_REQ", 8, mipc_apn_set_ia_req_tlv_checker_info},
    {MIPC_APN_SET_IA_CNF, 1, "SET_IA_CNF", 3, mipc_apn_set_ia_cnf_tlv_checker_info},
    {MIPC_APN_GET_IA_REQ, 1, "GET_IA_REQ", 0, NULL},
    {MIPC_APN_GET_IA_CNF, 1, "GET_IA_CNF", 3, mipc_apn_get_ia_cnf_tlv_checker_info},
    {MIPC_APN_ADD_PROFILE_REQ, 1, "ADD_PROFILE_REQ", 12, mipc_apn_add_profile_req_tlv_checker_info},
    {MIPC_APN_ADD_PROFILE_CNF, 1, "ADD_PROFILE_CNF", 3, mipc_apn_add_profile_cnf_tlv_checker_info},
    {MIPC_APN_LIST_PROFILE_REQ, 1, "LIST_PROFILE_REQ", 0, NULL},
    {MIPC_APN_LIST_PROFILE_CNF, 1, "LIST_PROFILE_CNF", 3, mipc_apn_list_profile_cnf_tlv_checker_info},
    {MIPC_APN_DEL_PROFILE_REQ, 1, "DEL_PROFILE_REQ", 1, mipc_apn_del_profile_req_tlv_checker_info},
    {MIPC_APN_DEL_PROFILE_CNF, 1, "DEL_PROFILE_CNF", 3, mipc_apn_del_profile_cnf_tlv_checker_info},
    {MIPC_APN_SET_PROFILE_STATUS_REQ, 1, "SET_PROFILE_STATUS_REQ", 1, mipc_apn_set_profile_status_req_tlv_checker_info},
    {MIPC_APN_SET_PROFILE_STATUS_CNF, 1, "SET_PROFILE_STATUS_CNF", 0, NULL},
    {MIPC_APN_LIST_MD_PROFILE_REQ, 1, "LIST_MD_PROFILE_REQ", 0, NULL},
    {MIPC_APN_LIST_MD_PROFILE_CNF, 1, "LIST_MD_PROFILE_CNF", 3, mipc_apn_list_md_profile_cnf_tlv_checker_info},
    {MIPC_APN_SET_OP12_APN_REQ, 1, "SET_OP12_APN_REQ", 7, mipc_apn_set_op12_apn_req_tlv_checker_info},
    {MIPC_APN_SET_OP12_APN_CNF, 1, "SET_OP12_APN_CNF", 0, NULL},
    {MIPC_APN_SET_OP12_APN_TIMER_REQ, 1, "SET_OP12_APN_TIMER_REQ", 5, mipc_apn_set_op12_apn_timer_req_tlv_checker_info},
    {MIPC_APN_SET_OP12_APN_TIMER_CNF, 1, "SET_OP12_APN_TIMER_CNF", 0, NULL},
    {MIPC_APN_ADD_PROFILE_LIST_REQ, 1, "ADD_PROFILE_LIST_REQ", 2, mipc_apn_add_profile_list_req_tlv_checker_info},
    {MIPC_APN_ADD_PROFILE_LIST_CNF, 1, "ADD_PROFILE_LIST_CNF", 2, mipc_apn_add_profile_list_cnf_tlv_checker_info},
    {MIPC_APN_SET_IA_MD_PREFER_REQ, 1, "SET_IA_MD_PREFER_REQ", 1, mipc_apn_set_ia_md_prefer_req_tlv_checker_info},
    {MIPC_APN_SET_IA_MD_PREFER_CNF, 1, "SET_IA_MD_PREFER_CNF", 0, NULL},
    {MIPC_DATA_ACT_CALL_REQ, 1, "ACT_CALL_REQ", 19, mipc_data_act_call_req_tlv_checker_info},
    {MIPC_DATA_ACT_CALL_CNF, 1, "ACT_CALL_CNF", 56, mipc_data_act_call_cnf_tlv_checker_info},
    {MIPC_DATA_DEACT_CALL_REQ, 1, "DEACT_CALL_REQ", 2, mipc_data_deact_call_req_tlv_checker_info},
    {MIPC_DATA_DEACT_CALL_CNF, 1, "DEACT_CALL_CNF", 1, mipc_data_deact_call_cnf_tlv_checker_info},
    {MIPC_DATA_GET_CALL_REQ, 1, "GET_CALL_REQ", 1, mipc_data_get_call_req_tlv_checker_info},
    {MIPC_DATA_GET_CALL_CNF, 1, "GET_CALL_CNF", 53, mipc_data_get_call_cnf_tlv_checker_info},
    {MIPC_DATA_SET_PACKET_FILTER_REQ, 1, "SET_PACKET_FILTER_REQ", 4, mipc_data_set_packet_filter_req_tlv_checker_info},
    {MIPC_DATA_SET_PACKET_FILTER_CNF, 1, "SET_PACKET_FILTER_CNF", 4, mipc_data_set_packet_filter_cnf_tlv_checker_info},
    {MIPC_DATA_GET_PACKET_FILTER_REQ, 1, "GET_PACKET_FILTER_REQ", 1, mipc_data_get_packet_filter_req_tlv_checker_info},
    {MIPC_DATA_GET_PACKET_FILTER_CNF, 1, "GET_PACKET_FILTER_CNF", 4, mipc_data_get_packet_filter_cnf_tlv_checker_info},
    {MIPC_DATA_GET_PCO_REQ, 1, "GET_PCO_REQ", 4, mipc_data_get_pco_req_tlv_checker_info},
    {MIPC_DATA_GET_PCO_CNF, 1, "GET_PCO_CNF", 4, mipc_data_get_pco_cnf_tlv_checker_info},
    {MIPC_DATA_SET_DATA_ALLOW_REQ, 1, "SET_DATA_ALLOW_REQ", 1, mipc_data_set_data_allow_req_tlv_checker_info},
    {MIPC_DATA_SET_DATA_ALLOW_CNF, 1, "SET_DATA_ALLOW_CNF", 0, NULL},
    {MIPC_DATA_GET_MD_DATA_CALL_LIST_REQ, 1, "GET_MD_DATA_CALL_LIST_REQ", 0, NULL},
    {MIPC_DATA_GET_MD_DATA_CALL_LIST_CNF, 1, "GET_MD_DATA_CALL_LIST_CNF", 1, mipc_data_get_md_data_call_list_cnf_tlv_checker_info},
    {MIPC_DATA_SET_CONFIG_REQ, 1, "SET_CONFIG_REQ", 7, mipc_data_set_config_req_tlv_checker_info},
    {MIPC_DATA_SET_CONFIG_CNF, 1, "SET_CONFIG_CNF", 0, NULL},
    {MIPC_DATA_GET_CONFIG_REQ, 1, "GET_CONFIG_REQ", 0, NULL},
    {MIPC_DATA_GET_CONFIG_CNF, 1, "GET_CONFIG_CNF", 6, mipc_data_get_config_cnf_tlv_checker_info},
    {MIPC_DATA_ABORT_CALL_REQ, 1, "ABORT_CALL_REQ", 1, mipc_data_abort_call_req_tlv_checker_info},
    {MIPC_DATA_ABORT_CALL_CNF, 1, "ABORT_CALL_CNF", 0, NULL},
    {MIPC_DATA_GET_CALL_INFO_REQ, 1, "GET_CALL_INFO_REQ", 2, mipc_data_get_call_info_req_tlv_checker_info},
    {MIPC_DATA_GET_CALL_INFO_CNF, 1, "GET_CALL_INFO_CNF", 5, mipc_data_get_call_info_cnf_tlv_checker_info},
    {MIPC_DATA_GET_PDP_CID_REQ, 1, "GET_PDP_CID_REQ", 0, NULL},
    {MIPC_DATA_GET_PDP_CID_CNF, 1, "GET_PDP_CID_CNF", 2, mipc_data_get_pdp_cid_cnf_tlv_checker_info},
    {MIPC_DATA_RETRY_TIMER_REQ, 1, "RETRY_TIMER_REQ", 2, mipc_data_retry_timer_req_tlv_checker_info},
    {MIPC_DATA_RETRY_TIMER_CNF, 1, "RETRY_TIMER_CNF", 2, mipc_data_retry_timer_cnf_tlv_checker_info},
    {MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ, 1, "SET_LINK_CAPACITY_REPORTING_CRITERIA_REQ", 9, mipc_data_set_link_capacity_reporting_criteria_req_tlv_checker_info},
    {MIPC_DATA_SET_LINK_CAPACITY_REPORTING_CRITERIA_CNF, 1, "SET_LINK_CAPACITY_REPORTING_CRITERIA_CNF", 0, NULL},
    {MIPC_DATA_GET_DEDICATE_BEARER_INFO_REQ, 1, "GET_DEDICATE_BEARER_INFO_REQ", 1, mipc_data_get_dedicate_bearer_info_req_tlv_checker_info},
    {MIPC_DATA_GET_DEDICATE_BEARER_INFO_CNF, 1, "GET_DEDICATE_BEARER_INFO_CNF", 1, mipc_data_get_dedicate_bearer_info_cnf_tlv_checker_info},
    {MIPC_DATA_GET_QOS_REQ, 1, "GET_QOS_REQ", 1, mipc_data_get_qos_req_tlv_checker_info},
    {MIPC_DATA_GET_QOS_CNF, 1, "GET_QOS_CNF", 1, mipc_data_get_qos_cnf_tlv_checker_info},
    {MIPC_DATA_GET_TFT_REQ, 1, "GET_TFT_REQ", 1, mipc_data_get_tft_req_tlv_checker_info},
    {MIPC_DATA_GET_TFT_CNF, 1, "GET_TFT_CNF", 1, mipc_data_get_tft_cnf_tlv_checker_info},
    {MIPC_DATA_SET_LGDCONT_REQ, 1, "SET_LGDCONT_REQ", 4, mipc_data_set_lgdcont_req_tlv_checker_info},
    {MIPC_DATA_SET_LGDCONT_CNF, 1, "SET_LGDCONT_CNF", 0, NULL},
    {MIPC_DATA_SET_NSSAI_REQ, 1, "SET_NSSAI_REQ", 3, mipc_data_set_nssai_req_tlv_checker_info},
    {MIPC_DATA_SET_NSSAI_CNF, 1, "SET_NSSAI_CNF", 0, NULL},
    {MIPC_DATA_KEEPALIVE_REQ, 1, "KEEPALIVE_REQ", 2, mipc_data_keepalive_req_tlv_checker_info},
    {MIPC_DATA_KEEPALIVE_CNF, 1, "KEEPALIVE_CNF", 2, mipc_data_keepalive_cnf_tlv_checker_info},
    {MIPC_DATA_GET_DSDA_STATE_REQ, 1, "GET_DSDA_STATE_REQ", 0, NULL},
    {MIPC_DATA_GET_DSDA_STATE_CNF, 1, "GET_DSDA_STATE_CNF", 4, mipc_data_get_dsda_state_cnf_tlv_checker_info},
    {MIPC_DATA_GET_5GQOS_REQ, 1, "GET_5GQOS_REQ", 1, mipc_data_get_5gqos_req_tlv_checker_info},
    {MIPC_DATA_GET_5GQOS_CNF, 1, "GET_5GQOS_CNF", 1, mipc_data_get_5gqos_cnf_tlv_checker_info},
    {MIPC_DATA_SET_PSI_REQ, 1, "SET_PSI_REQ", 4, mipc_data_set_psi_req_tlv_checker_info},
    {MIPC_DATA_SET_PSI_CNF, 1, "SET_PSI_CNF", 1, mipc_data_set_psi_cnf_tlv_checker_info},
    {MIPC_DATA_GET_NSSAI_REQ, 1, "GET_NSSAI_REQ", 2, mipc_data_get_nssai_req_tlv_checker_info},
    {MIPC_DATA_GET_NSSAI_CNF, 1, "GET_NSSAI_CNF", 16, mipc_data_get_nssai_cnf_tlv_checker_info},
    {MIPC_DATA_GET_URSP_ROUTE_PROFILE_REQ, 1, "GET_URSP_ROUTE_PROFILE_REQ", 1, mipc_data_get_ursp_route_profile_req_tlv_checker_info},
    {MIPC_DATA_GET_URSP_ROUTE_PROFILE_CNF, 1, "GET_URSP_ROUTE_PROFILE_CNF", 5, mipc_data_get_ursp_route_profile_cnf_tlv_checker_info},
    {MIPC_DATA_SET_URSP_PRECONF_UE_POLICY_REQ, 1, "SET_URSP_PRECONF_UE_POLICY_REQ", 3, mipc_data_set_ursp_preconf_ue_policy_req_tlv_checker_info},
    {MIPC_DATA_SET_URSP_PRECONF_UE_POLICY_CNF, 1, "SET_URSP_PRECONF_UE_POLICY_CNF", 0, NULL},
    {MIPC_DATA_GET_URSP_UE_POLICY_REQ, 1, "GET_URSP_UE_POLICY_REQ", 1, mipc_data_get_ursp_ue_policy_req_tlv_checker_info},
    {MIPC_DATA_GET_URSP_UE_POLICY_CNF, 1, "GET_URSP_UE_POLICY_CNF", 4, mipc_data_get_ursp_ue_policy_cnf_tlv_checker_info},
    {MIPC_DATA_SET_RESERVED_IF_ID_REQ, 1, "SET_RESERVED_IF_ID_REQ", 1, mipc_data_set_reserved_if_id_req_tlv_checker_info},
    {MIPC_DATA_SET_RESERVED_IF_ID_CNF, 1, "SET_RESERVED_IF_ID_CNF", 0, NULL},
    {MIPC_DATA_SET_PCO_REQ, 1, "SET_PCO_REQ", 3, mipc_data_set_pco_req_tlv_checker_info},
    {MIPC_DATA_SET_PCO_CNF, 1, "SET_PCO_CNF", 0, NULL},
    {MIPC_DATA_SET_PAGING_REQ, 1, "SET_PAGING_REQ", 2, mipc_data_set_paging_req_tlv_checker_info},
    {MIPC_DATA_SET_PAGING_CNF, 1, "SET_PAGING_CNF", 0, NULL},
    {MIPC_DATA_GET_PAGING_REQ, 1, "GET_PAGING_REQ", 0, NULL},
    {MIPC_DATA_GET_PAGING_CNF, 1, "GET_PAGING_CNF", 2, mipc_data_get_paging_cnf_tlv_checker_info},
    {MIPC_DATA_MOD_CALL_REQ, 1, "MOD_CALL_REQ", 2, mipc_data_mod_call_req_tlv_checker_info},
    {MIPC_DATA_MOD_CALL_CNF, 1, "MOD_CALL_CNF", 4, mipc_data_mod_call_cnf_tlv_checker_info},
    {MIPC_DATA_SET_TSN_REQ, 1, "SET_TSN_REQ", 3, mipc_data_set_tsn_req_tlv_checker_info},
    {MIPC_DATA_SET_TSN_CNF, 1, "SET_TSN_CNF", 1, mipc_data_set_tsn_cnf_tlv_checker_info},
    {MIPC_DATA_GET_URSP_UE_POLICY_PLMN_LIST_REQ, 1, "GET_URSP_UE_POLICY_PLMN_LIST_REQ", 0, NULL},
    {MIPC_DATA_GET_URSP_UE_POLICY_PLMN_LIST_CNF, 1, "GET_URSP_UE_POLICY_PLMN_LIST_CNF", 1, mipc_data_get_ursp_ue_policy_plmn_list_cnf_tlv_checker_info},
    {MIPC_INTERNAL_OPEN_REQ, 1, "OPEN_REQ", 4, mipc_internal_open_req_tlv_checker_info},
    {MIPC_INTERNAL_OPEN_CNF, 1, "OPEN_CNF", 2, mipc_internal_open_cnf_tlv_checker_info},
    {MIPC_INTERNAL_CLOSE_REQ, 1, "CLOSE_REQ", 0, NULL},
    {MIPC_INTERNAL_CLOSE_CNF, 1, "CLOSE_CNF", 0, NULL},
    {MIPC_INTERNAL_TEST_REQ, 1, "TEST_REQ", 0, NULL},
    {MIPC_INTERNAL_TEST_CNF, 1, "TEST_CNF", 1, mipc_internal_test_cnf_tlv_checker_info},
    {MIPC_INTERNAL_REGISTER_IND_REQ, 1, "REGISTER_IND_REQ", 2, mipc_internal_register_ind_req_tlv_checker_info},
    {MIPC_INTERNAL_REGISTER_IND_CNF, 1, "REGISTER_IND_CNF", 0, NULL},
    {MIPC_INTERNAL_UNREGISTER_IND_REQ, 1, "UNREGISTER_IND_REQ", 3, mipc_internal_unregister_ind_req_tlv_checker_info},
    {MIPC_INTERNAL_UNREGISTER_IND_CNF, 1, "UNREGISTER_IND_CNF", 0, NULL},
    {MIPC_INTERNAL_REGISTER_CMD_REQ, 1, "REGISTER_CMD_REQ", 1, mipc_internal_register_cmd_req_tlv_checker_info},
    {MIPC_INTERNAL_REGISTER_CMD_CNF, 1, "REGISTER_CMD_CNF", 0, NULL},
    {MIPC_INTERNAL_UNREGISTER_CMD_REQ, 1, "UNREGISTER_CMD_REQ", 1, mipc_internal_unregister_cmd_req_tlv_checker_info},
    {MIPC_INTERNAL_UNREGISTER_CMD_CNF, 1, "UNREGISTER_CMD_CNF", 0, NULL},
    {MIPC_INTERNAL_SET_FILTER_REQ, 1, "SET_FILTER_REQ", 1, mipc_internal_set_filter_req_tlv_checker_info},
    {MIPC_INTERNAL_SET_FILTER_CNF, 1, "SET_FILTER_CNF", 1, mipc_internal_set_filter_cnf_tlv_checker_info},
    {MIPC_INTERNAL_RESET_FILTER_REQ, 1, "RESET_FILTER_REQ", 1, mipc_internal_reset_filter_req_tlv_checker_info},
    {MIPC_INTERNAL_RESET_FILTER_CNF, 1, "RESET_FILTER_CNF", 1, mipc_internal_reset_filter_cnf_tlv_checker_info},
    {MIPC_INTERNAL_EIF_REQ, 1, "EIF_REQ", 5, mipc_internal_eif_req_tlv_checker_info},
    {MIPC_INTERNAL_EIF_CNF, 1, "EIF_CNF", 0, NULL},
    {MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_REQ, 1, "SET_LONG_STANDBY_MONITOR_REQ", 1, mipc_internal_set_long_standby_monitor_req_tlv_checker_info},
    {MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_CNF, 1, "SET_LONG_STANDBY_MONITOR_CNF", 0, NULL},
    {MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_TIME_REQ, 1, "SET_LONG_STANDBY_MONITOR_TIME_REQ", 2, mipc_internal_set_long_standby_monitor_time_req_tlv_checker_info},
    {MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_TIME_CNF, 1, "SET_LONG_STANDBY_MONITOR_TIME_CNF", 0, NULL},
    {MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_WARNING_RATIO_REQ, 1, "SET_LONG_STANDBY_MONITOR_WARNING_RATIO_REQ", 4, mipc_internal_set_long_standby_monitor_warning_ratio_req_tlv_checker_info},
    {MIPC_INTERNAL_SET_LONG_STANDBY_MONITOR_WARNING_RATIO_CNF, 1, "SET_LONG_STANDBY_MONITOR_WARNING_RATIO_CNF", 0, NULL},
    {MIPC_NW_GET_RADIO_STATE_REQ, 1, "GET_RADIO_STATE_REQ", 0, NULL},
    {MIPC_NW_GET_RADIO_STATE_CNF, 1, "GET_RADIO_STATE_CNF", 2, mipc_nw_get_radio_state_cnf_tlv_checker_info},
    {MIPC_NW_SET_RADIO_STATE_REQ, 1, "SET_RADIO_STATE_REQ", 3, mipc_nw_set_radio_state_req_tlv_checker_info},
    {MIPC_NW_SET_RADIO_STATE_CNF, 1, "SET_RADIO_STATE_CNF", 2, mipc_nw_set_radio_state_cnf_tlv_checker_info},
    {MIPC_NW_SET_REGISTER_STATE_REQ, 1, "SET_REGISTER_STATE_REQ", 10, mipc_nw_set_register_state_req_tlv_checker_info},
    {MIPC_NW_SET_REGISTER_STATE_CNF, 1, "SET_REGISTER_STATE_CNF", 9, mipc_nw_set_register_state_cnf_tlv_checker_info},
    {MIPC_NW_GET_REGISTER_STATE_REQ, 1, "GET_REGISTER_STATE_REQ", 0, NULL},
    {MIPC_NW_GET_REGISTER_STATE_CNF, 1, "GET_REGISTER_STATE_CNF", 10, mipc_nw_get_register_state_cnf_tlv_checker_info},
    {MIPC_NW_GET_PLMN_LIST_REQ, 1, "GET_PLMN_LIST_REQ", 0, NULL},
    {MIPC_NW_GET_PLMN_LIST_CNF, 1, "GET_PLMN_LIST_CNF", 6, mipc_nw_get_plmn_list_cnf_tlv_checker_info},
    {MIPC_NW_SET_PS_REQ, 1, "SET_PS_REQ", 2, mipc_nw_set_ps_req_tlv_checker_info},
    {MIPC_NW_SET_PS_CNF, 1, "SET_PS_CNF", 4, mipc_nw_set_ps_cnf_tlv_checker_info},
    {MIPC_NW_GET_PS_REQ, 1, "GET_PS_REQ", 0, NULL},
    {MIPC_NW_GET_PS_CNF, 1, "GET_PS_CNF", 13, mipc_nw_get_ps_cnf_tlv_checker_info},
    {MIPC_NW_SET_SIGNAL_REQ, 1, "SET_SIGNAL_REQ", 6, mipc_nw_set_signal_req_tlv_checker_info},
    {MIPC_NW_SET_SIGNAL_CNF, 1, "SET_SIGNAL_CNF", 19, mipc_nw_set_signal_cnf_tlv_checker_info},
    {MIPC_NW_GET_SIGNAL_REQ, 1, "GET_SIGNAL_REQ", 0, NULL},
    {MIPC_NW_GET_SIGNAL_CNF, 1, "GET_SIGNAL_CNF", 21, mipc_nw_get_signal_cnf_tlv_checker_info},
    {MIPC_NW_GET_PREFERRED_PROVIDER_REQ, 1, "GET_PREFERRED_PROVIDER_REQ", 0, NULL},
    {MIPC_NW_GET_PREFERRED_PROVIDER_CNF, 1, "GET_PREFERRED_PROVIDER_CNF", 4, mipc_nw_get_preferred_provider_cnf_tlv_checker_info},
    {MIPC_NW_SET_PREFERRED_PROVIDER_REQ, 1, "SET_PREFERRED_PROVIDER_REQ", 3, mipc_nw_set_preferred_provider_req_tlv_checker_info},
    {MIPC_NW_SET_PREFERRED_PROVIDER_CNF, 1, "SET_PREFERRED_PROVIDER_CNF", 4, mipc_nw_set_preferred_provider_cnf_tlv_checker_info},
    {MIPC_NW_SET_HOME_PROVIDER_REQ, 1, "SET_HOME_PROVIDER_REQ", 1, mipc_nw_set_home_provider_req_tlv_checker_info},
    {MIPC_NW_SET_HOME_PROVIDER_CNF, 1, "SET_HOME_PROVIDER_CNF", 2, mipc_nw_set_home_provider_cnf_tlv_checker_info},
    {MIPC_NW_GET_HOME_PROVIDER_REQ, 1, "GET_HOME_PROVIDER_REQ", 0, NULL},
    {MIPC_NW_GET_HOME_PROVIDER_CNF, 1, "GET_HOME_PROVIDER_CNF", 2, mipc_nw_get_home_provider_cnf_tlv_checker_info},
    {MIPC_NW_GET_IA_STATUS_REQ, 1, "GET_IA_STATUS_REQ", 0, NULL},
    {MIPC_NW_GET_IA_STATUS_CNF, 1, "GET_IA_STATUS_CNF", 7, mipc_nw_get_ia_status_cnf_tlv_checker_info},
    {MIPC_NW_GET_NITZ_REQ, 1, "GET_NITZ_REQ", 0, NULL},
    {MIPC_NW_GET_NITZ_CNF, 1, "GET_NITZ_CNF", 2, mipc_nw_get_nitz_cnf_tlv_checker_info},
    {MIPC_NW_SET_IDLE_HINT_REQ, 1, "SET_IDLE_HINT_REQ", 3, mipc_nw_set_idle_hint_req_tlv_checker_info},
    {MIPC_NW_SET_IDLE_HINT_CNF, 1, "SET_IDLE_HINT_CNF", 2, mipc_nw_set_idle_hint_cnf_tlv_checker_info},
    {MIPC_NW_GET_IDLE_HINT_REQ, 1, "GET_IDLE_HINT_REQ", 0, NULL},
    {MIPC_NW_GET_IDLE_HINT_CNF, 1, "GET_IDLE_HINT_CNF", 3, mipc_nw_get_idle_hint_cnf_tlv_checker_info},
    {MIPC_NW_GET_BASE_STATIONS_REQ, 1, "GET_BASE_STATIONS_REQ", 0, NULL},
    {MIPC_NW_GET_BASE_STATIONS_CNF, 1, "GET_BASE_STATIONS_CNF", 21, mipc_nw_get_base_stations_cnf_tlv_checker_info},
    {MIPC_NW_GET_LOCATION_INFO_REQ, 1, "GET_LOCATION_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_LOCATION_INFO_CNF, 1, "GET_LOCATION_INFO_CNF", 2, mipc_nw_get_location_info_cnf_tlv_checker_info},
    {MIPC_NW_SET_RAT_REQ, 1, "SET_RAT_REQ", 3, mipc_nw_set_rat_req_tlv_checker_info},
    {MIPC_NW_SET_RAT_CNF, 1, "SET_RAT_CNF", 0, NULL},
    {MIPC_NW_GET_PROVIDER_NAME_REQ, 1, "GET_PROVIDER_NAME_REQ", 4, mipc_nw_get_provider_name_req_tlv_checker_info},
    {MIPC_NW_GET_PROVIDER_NAME_CNF, 1, "GET_PROVIDER_NAME_CNF", 7, mipc_nw_get_provider_name_cnf_tlv_checker_info},
    {MIPC_NW_GET_RAT_REQ, 1, "GET_RAT_REQ", 0, NULL},
    {MIPC_NW_GET_RAT_CNF, 1, "GET_RAT_CNF", 7, mipc_nw_get_rat_cnf_tlv_checker_info},
    {MIPC_NW_SET_NR_REQ, 1, "SET_NR_REQ", 2, mipc_nw_set_nr_req_tlv_checker_info},
    {MIPC_NW_SET_NR_CNF, 1, "SET_NR_CNF", 0, NULL},
    {MIPC_NW_GET_CS_REQ, 1, "GET_CS_REQ", 0, NULL},
    {MIPC_NW_GET_CS_CNF, 1, "GET_CS_CNF", 8, mipc_nw_get_cs_cnf_tlv_checker_info},
    {MIPC_NW_GET_BAND_MODE_REQ, 1, "GET_BAND_MODE_REQ", 1, mipc_nw_get_band_mode_req_tlv_checker_info},
    {MIPC_NW_GET_BAND_MODE_CNF, 1, "GET_BAND_MODE_CNF", 5, mipc_nw_get_band_mode_cnf_tlv_checker_info},
    {MIPC_NW_SET_BAND_MODE_REQ, 1, "SET_BAND_MODE_REQ", 5, mipc_nw_set_band_mode_req_tlv_checker_info},
    {MIPC_NW_SET_BAND_MODE_CNF, 1, "SET_BAND_MODE_CNF", 0, NULL},
    {MIPC_NW_SET_CHANNEL_LOCK_REQ, 1, "SET_CHANNEL_LOCK_REQ", 3, mipc_nw_set_channel_lock_req_tlv_checker_info},
    {MIPC_NW_SET_CHANNEL_LOCK_CNF, 1, "SET_CHANNEL_LOCK_CNF", 0, NULL},
    {MIPC_NW_GET_CHANNEL_LOCK_REQ, 1, "GET_CHANNEL_LOCK_REQ", 0, NULL},
    {MIPC_NW_GET_CHANNEL_LOCK_CNF, 1, "GET_CHANNEL_LOCK_CNF", 0, NULL},
    {MIPC_NW_SET_ABORT_PLMN_LIST_SEARCH_REQ, 1, "SET_ABORT_PLMN_LIST_SEARCH_REQ", 0, NULL},
    {MIPC_NW_SET_ABORT_PLMN_LIST_SEARCH_CNF, 1, "SET_ABORT_PLMN_LIST_SEARCH_CNF", 0, NULL},
    {MIPC_NW_GET_POL_CAPABILITY_REQ, 1, "GET_POL_CAPABILITY_REQ", 0, NULL},
    {MIPC_NW_GET_POL_CAPABILITY_CNF, 1, "GET_POL_CAPABILITY_CNF", 1, mipc_nw_get_pol_capability_cnf_tlv_checker_info},
    {MIPC_NW_SET_PREFER_RAT_REQ, 1, "SET_PREFER_RAT_REQ", 2, mipc_nw_set_prefer_rat_req_tlv_checker_info},
    {MIPC_NW_SET_PREFER_RAT_CNF, 1, "SET_PREFER_RAT_CNF", 0, NULL},
    {MIPC_NW_GET_OPERATOR_NAME_REQ, 1, "GET_OPERATOR_NAME_REQ", 1, mipc_nw_get_operator_name_req_tlv_checker_info},
    {MIPC_NW_GET_OPERATOR_NAME_CNF, 1, "GET_OPERATOR_NAME_CNF", 1, mipc_nw_get_operator_name_cnf_tlv_checker_info},
    {MIPC_NW_SET_ENDC_CONFIG_REQ, 1, "SET_ENDC_CONFIG_REQ", 1, mipc_nw_set_endc_config_req_tlv_checker_info},
    {MIPC_NW_SET_ENDC_CONFIG_CNF, 1, "SET_ENDC_CONFIG_CNF", 0, NULL},
    {MIPC_NW_SET_LTE_CARRIER_AGGREGATION_SWITCH_REQ, 1, "SET_LTE_CARRIER_AGGREGATION_SWITCH_REQ", 1, mipc_nw_set_lte_carrier_aggregation_switch_req_tlv_checker_info},
    {MIPC_NW_SET_LTE_CARRIER_AGGREGATION_SWITCH_CNF, 1, "SET_LTE_CARRIER_AGGREGATION_SWITCH_CNF", 0, NULL},
    {MIPC_NW_SET_PS_CS_REGISTRATION_STATE_ROAMING_TYPE_REQ, 1, "SET_PS_CS_REGISTRATION_STATE_ROAMING_TYPE_REQ", 1, mipc_nw_set_ps_cs_registration_state_roaming_type_req_tlv_checker_info},
    {MIPC_NW_SET_PS_CS_REGISTRATION_STATE_ROAMING_TYPE_CNF, 1, "SET_PS_CS_REGISTRATION_STATE_ROAMING_TYPE_CNF", 0, NULL},
    {MIPC_NW_GET_LTE_CARRIER_AGGREGATION_SWITCH_REQ, 1, "GET_LTE_CARRIER_AGGREGATION_SWITCH_REQ", 0, NULL},
    {MIPC_NW_GET_LTE_CARRIER_AGGREGATION_SWITCH_CNF, 1, "GET_LTE_CARRIER_AGGREGATION_SWITCH_CNF", 1, mipc_nw_get_lte_carrier_aggregation_switch_cnf_tlv_checker_info},
    {MIPC_NW_GET_CURRENT_BAND_INFO_REQ, 1, "GET_CURRENT_BAND_INFO_REQ", 1, mipc_nw_get_current_band_info_req_tlv_checker_info},
    {MIPC_NW_GET_CURRENT_BAND_INFO_CNF, 1, "GET_CURRENT_BAND_INFO_CNF", 4, mipc_nw_get_current_band_info_cnf_tlv_checker_info},
    {MIPC_NW_CELL_MEASUREMENT_REQ, 1, "CELL_MEASUREMENT_REQ", 4, mipc_nw_cell_measurement_req_tlv_checker_info},
    {MIPC_NW_CELL_MEASUREMENT_CNF, 1, "CELL_MEASUREMENT_CNF", 17, mipc_nw_cell_measurement_cnf_tlv_checker_info},
    {MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_REQ, 1, "CELL_BAND_WHITE_LIST_LOCK_REQ", 8, mipc_nw_cell_band_white_list_lock_req_tlv_checker_info},
    {MIPC_NW_CELL_BAND_WHITE_LIST_LOCK_CNF, 1, "CELL_BAND_WHITE_LIST_LOCK_CNF", 0, NULL},
    {MIPC_NW_GET_CELL_BAND_BANDWIDTH_REQ, 1, "GET_CELL_BAND_BANDWIDTH_REQ", 1, mipc_nw_get_cell_band_bandwidth_req_tlv_checker_info},
    {MIPC_NW_GET_CELL_BAND_BANDWIDTH_CNF, 1, "GET_CELL_BAND_BANDWIDTH_CNF", 15, mipc_nw_get_cell_band_bandwidth_cnf_tlv_checker_info},
    {MIPC_NW_GET_NR_REQ, 1, "GET_NR_REQ", 0, NULL},
    {MIPC_NW_GET_NR_CNF, 1, "GET_NR_CNF", 1, mipc_nw_get_nr_cnf_tlv_checker_info},
    {MIPC_NW_GET_SRXLEV_REQ, 1, "GET_SRXLEV_REQ", 0, NULL},
    {MIPC_NW_GET_SRXLEV_CNF, 1, "GET_SRXLEV_CNF", 2, mipc_nw_get_srxlev_cnf_tlv_checker_info},
    {MIPC_NW_SET_ROAMING_MODE_REQ, 1, "SET_ROAMING_MODE_REQ", 1, mipc_nw_set_roaming_mode_req_tlv_checker_info},
    {MIPC_NW_SET_ROAMING_MODE_CNF, 1, "SET_ROAMING_MODE_CNF", 0, NULL},
    {MIPC_NW_GET_ROAMING_MODE_REQ, 1, "GET_ROAMING_MODE_REQ", 0, NULL},
    {MIPC_NW_GET_ROAMING_MODE_CNF, 1, "GET_ROAMING_MODE_CNF", 1, mipc_nw_get_roaming_mode_cnf_tlv_checker_info},
    {MIPC_NW_SET_URC_ENABLE_REQ, 1, "SET_URC_ENABLE_REQ", 2, mipc_nw_set_urc_enable_req_tlv_checker_info},
    {MIPC_NW_SET_URC_ENABLE_CNF, 1, "SET_URC_ENABLE_CNF", 0, NULL},
    {MIPC_NW_GET_SUGGESTED_PLMN_LIST_REQ, 1, "GET_SUGGESTED_PLMN_LIST_REQ", 3, mipc_nw_get_suggested_plmn_list_req_tlv_checker_info},
    {MIPC_NW_GET_SUGGESTED_PLMN_LIST_CNF, 1, "GET_SUGGESTED_PLMN_LIST_CNF", 4, mipc_nw_get_suggested_plmn_list_cnf_tlv_checker_info},
    {MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_REQ, 1, "SET_SEARCH_STORE_FREQUENCY_INFO_REQ", 6, mipc_nw_set_search_store_frequency_info_req_tlv_checker_info},
    {MIPC_NW_SET_SEARCH_STORE_FREQUENCY_INFO_CNF, 1, "SET_SEARCH_STORE_FREQUENCY_INFO_CNF", 0, NULL},
    {MIPC_NW_SET_SELECT_FEMTOCELL_REQ, 1, "SET_SELECT_FEMTOCELL_REQ", 3, mipc_nw_set_select_femtocell_req_tlv_checker_info},
    {MIPC_NW_SET_SELECT_FEMTOCELL_CNF, 1, "SET_SELECT_FEMTOCELL_CNF", 0, NULL},
    {MIPC_NW_SET_CONFIG_A2_OFFSET_REQ, 1, "SET_CONFIG_A2_OFFSET_REQ", 2, mipc_nw_set_config_a2_offset_req_tlv_checker_info},
    {MIPC_NW_SET_CONFIG_A2_OFFSET_CNF, 1, "SET_CONFIG_A2_OFFSET_CNF", 0, NULL},
    {MIPC_NW_SET_CONFIG_B1_OFFSET_REQ, 1, "SET_CONFIG_B1_OFFSET_REQ", 2, mipc_nw_set_config_b1_offset_req_tlv_checker_info},
    {MIPC_NW_SET_CONFIG_B1_OFFSET_CNF, 1, "SET_CONFIG_B1_OFFSET_CNF", 0, NULL},
    {MIPC_NW_SET_REPORT_ANBR_REQ, 1, "SET_REPORT_ANBR_REQ", 7, mipc_nw_set_report_anbr_req_tlv_checker_info},
    {MIPC_NW_SET_REPORT_ANBR_CNF, 1, "SET_REPORT_ANBR_CNF", 0, NULL},
    {MIPC_NW_SET_NETWORK_EVENT_REQ, 1, "SET_NETWORK_EVENT_REQ", 1, mipc_nw_set_network_event_req_tlv_checker_info},
    {MIPC_NW_SET_NETWORK_EVENT_CNF, 1, "SET_NETWORK_EVENT_CNF", 0, NULL},
    {MIPC_NW_SET_ENABLE_CA_PLUS_FILTER_REQ, 1, "SET_ENABLE_CA_PLUS_FILTER_REQ", 1, mipc_nw_set_enable_ca_plus_filter_req_tlv_checker_info},
    {MIPC_NW_SET_ENABLE_CA_PLUS_FILTER_CNF, 1, "SET_ENABLE_CA_PLUS_FILTER_CNF", 0, NULL},
    {MIPC_NW_ABORT_FEMTOCELL_LIST_REQ, 1, "ABORT_FEMTOCELL_LIST_REQ", 0, NULL},
    {MIPC_NW_ABORT_FEMTOCELL_LIST_CNF, 1, "ABORT_FEMTOCELL_LIST_CNF", 0, NULL},
    {MIPC_NW_GET_FEMTOCELL_LIST_REQ, 1, "GET_FEMTOCELL_LIST_REQ", 0, NULL},
    {MIPC_NW_GET_FEMTOCELL_LIST_CNF, 1, "GET_FEMTOCELL_LIST_CNF", 4, mipc_nw_get_femtocell_list_cnf_tlv_checker_info},
    {MIPC_NW_SET_PSEUDO_CELL_MODE_REQ, 1, "SET_PSEUDO_CELL_MODE_REQ", 3, mipc_nw_set_pseudo_cell_mode_req_tlv_checker_info},
    {MIPC_NW_SET_PSEUDO_CELL_MODE_CNF, 1, "SET_PSEUDO_CELL_MODE_CNF", 0, NULL},
    {MIPC_NW_GET_PSEUDO_CELL_INFO_REQ, 1, "GET_PSEUDO_CELL_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_PSEUDO_CELL_INFO_CNF, 1, "GET_PSEUDO_CELL_INFO_CNF", 7, mipc_nw_get_pseudo_cell_info_cnf_tlv_checker_info},
    {MIPC_NW_SET_ROAMING_ENABLE_REQ, 1, "SET_ROAMING_ENABLE_REQ", 6, mipc_nw_set_roaming_enable_req_tlv_checker_info},
    {MIPC_NW_SET_ROAMING_ENABLE_CNF, 1, "SET_ROAMING_ENABLE_CNF", 0, NULL},
    {MIPC_NW_GET_ROAMING_ENABLE_REQ, 1, "GET_ROAMING_ENABLE_REQ", 0, NULL},
    {MIPC_NW_GET_ROAMING_ENABLE_CNF, 1, "GET_ROAMING_ENABLE_CNF", 7, mipc_nw_get_roaming_enable_cnf_tlv_checker_info},
    {MIPC_NW_SET_FEMTOCELL_SYSTEM_SELECTION_MODE_REQ, 1, "SET_FEMTOCELL_SYSTEM_SELECTION_MODE_REQ", 1, mipc_nw_set_femtocell_system_selection_mode_req_tlv_checker_info},
    {MIPC_NW_SET_FEMTOCELL_SYSTEM_SELECTION_MODE_CNF, 1, "SET_FEMTOCELL_SYSTEM_SELECTION_MODE_CNF", 0, NULL},
    {MIPC_NW_QUERY_FEMTOCELL_SYSTEM_SELECTION_MODE_REQ, 1, "QUERY_FEMTOCELL_SYSTEM_SELECTION_MODE_REQ", 0, NULL},
    {MIPC_NW_QUERY_FEMTOCELL_SYSTEM_SELECTION_MODE_CNF, 1, "QUERY_FEMTOCELL_SYSTEM_SELECTION_MODE_CNF", 2, mipc_nw_query_femtocell_system_selection_mode_cnf_tlv_checker_info},
    {MIPC_NW_SET_NW_IND_REPORT_LEVEL_REQ, 1, "SET_NW_IND_REPORT_LEVEL_REQ", 2, mipc_nw_set_nw_ind_report_level_req_tlv_checker_info},
    {MIPC_NW_SET_NW_IND_REPORT_LEVEL_CNF, 1, "SET_NW_IND_REPORT_LEVEL_CNF", 0, NULL},
    {MIPC_NW_SET_DISABLE_2G_REQ, 1, "SET_DISABLE_2G_REQ", 1, mipc_nw_set_disable_2g_req_tlv_checker_info},
    {MIPC_NW_SET_DISABLE_2G_CNF, 1, "SET_DISABLE_2G_CNF", 0, NULL},
    {MIPC_NW_GET_DISABLE_2G_REQ, 1, "GET_DISABLE_2G_REQ", 0, NULL},
    {MIPC_NW_GET_DISABLE_2G_CNF, 1, "GET_DISABLE_2G_CNF", 1, mipc_nw_get_disable_2g_cnf_tlv_checker_info},
    {MIPC_NW_SET_SMART_RAT_SWITCH_REQ, 1, "SET_SMART_RAT_SWITCH_REQ", 2, mipc_nw_set_smart_rat_switch_req_tlv_checker_info},
    {MIPC_NW_SET_SMART_RAT_SWITCH_CNF, 1, "SET_SMART_RAT_SWITCH_CNF", 0, NULL},
    {MIPC_NW_GET_SMART_RAT_SWITCH_REQ, 1, "GET_SMART_RAT_SWITCH_REQ", 1, mipc_nw_get_smart_rat_switch_req_tlv_checker_info},
    {MIPC_NW_GET_SMART_RAT_SWITCH_CNF, 1, "GET_SMART_RAT_SWITCH_CNF", 1, mipc_nw_get_smart_rat_switch_cnf_tlv_checker_info},
    {MIPC_NW_VSS_ANTENNA_CONF_REQ, 1, "VSS_ANTENNA_CONF_REQ", 1, mipc_nw_vss_antenna_conf_req_tlv_checker_info},
    {MIPC_NW_VSS_ANTENNA_CONF_CNF, 1, "VSS_ANTENNA_CONF_CNF", 1, mipc_nw_vss_antenna_conf_cnf_tlv_checker_info},
    {MIPC_NW_VSS_ANTENNA_INFO_REQ, 1, "VSS_ANTENNA_INFO_REQ", 0, NULL},
    {MIPC_NW_VSS_ANTENNA_INFO_CNF, 1, "VSS_ANTENNA_INFO_CNF", 6, mipc_nw_vss_antenna_info_cnf_tlv_checker_info},
    {MIPC_NW_SET_RADIO_CAPABILITY_REQ, 1, "SET_RADIO_CAPABILITY_REQ", 2, mipc_nw_set_radio_capability_req_tlv_checker_info},
    {MIPC_NW_SET_RADIO_CAPABILITY_CNF, 1, "SET_RADIO_CAPABILITY_CNF", 0, NULL},
    {MIPC_NW_SET_CDMA_ROAMING_PREFERENCE_REQ, 1, "SET_CDMA_ROAMING_PREFERENCE_REQ", 1, mipc_nw_set_cdma_roaming_preference_req_tlv_checker_info},
    {MIPC_NW_SET_CDMA_ROAMING_PREFERENCE_CNF, 1, "SET_CDMA_ROAMING_PREFERENCE_CNF", 0, NULL},
    {MIPC_NW_GET_CDMA_ROAMING_PREFERENCE_REQ, 1, "GET_CDMA_ROAMING_PREFERENCE_REQ", 0, NULL},
    {MIPC_NW_GET_CDMA_ROAMING_PREFERENCE_CNF, 1, "GET_CDMA_ROAMING_PREFERENCE_CNF", 1, mipc_nw_get_cdma_roaming_preference_cnf_tlv_checker_info},
    {MIPC_NW_GET_BARRING_INFO_REQ, 1, "GET_BARRING_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_BARRING_INFO_CNF, 1, "GET_BARRING_INFO_CNF", 14, mipc_nw_get_barring_info_cnf_tlv_checker_info},
    {MIPC_NW_GET_EHRPD_INFO_REQ, 1, "GET_EHRPD_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_EHRPD_INFO_CNF, 1, "GET_EHRPD_INFO_CNF", 10, mipc_nw_get_ehrpd_info_cnf_tlv_checker_info},
    {MIPC_NW_GET_EGMSS_REQ, 1, "GET_EGMSS_REQ", 0, NULL},
    {MIPC_NW_GET_EGMSS_CNF, 1, "GET_EGMSS_CNF", 5, mipc_nw_get_egmss_cnf_tlv_checker_info},
    {MIPC_NW_SET_CACHE_ENDC_CONNECT_MODE_REQ, 1, "SET_CACHE_ENDC_CONNECT_MODE_REQ", 3, mipc_nw_set_cache_endc_connect_mode_req_tlv_checker_info},
    {MIPC_NW_SET_CACHE_ENDC_CONNECT_MODE_CNF, 1, "SET_CACHE_ENDC_CONNECT_MODE_CNF", 0, NULL},
    {MIPC_NW_SET_PS_TEST_MODE_REQ, 1, "SET_PS_TEST_MODE_REQ", 2, mipc_nw_set_ps_test_mode_req_tlv_checker_info},
    {MIPC_NW_SET_PS_TEST_MODE_CNF, 1, "SET_PS_TEST_MODE_CNF", 0, NULL},
    {MIPC_NW_GET_PS_TEST_MODE_REQ, 1, "GET_PS_TEST_MODE_REQ", 0, NULL},
    {MIPC_NW_GET_PS_TEST_MODE_CNF, 1, "GET_PS_TEST_MODE_CNF", 2, mipc_nw_get_ps_test_mode_cnf_tlv_checker_info},
    {MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_REQ, 1, "SET_SIGNAL_REPORT_CRITERIA_REQ", 6, mipc_nw_set_signal_report_criteria_req_tlv_checker_info},
    {MIPC_NW_SET_SIGNAL_REPORT_CRITERIA_CNF, 1, "SET_SIGNAL_REPORT_CRITERIA_CNF", 0, NULL},
    {MIPC_NW_GET_ECAINFO_REQ, 1, "GET_ECAINFO_REQ", 0, NULL},
    {MIPC_NW_GET_ECAINFO_CNF, 1, "GET_ECAINFO_CNF", 1, mipc_nw_get_ecainfo_cnf_tlv_checker_info},
    {MIPC_NW_GET_ACTIVITY_INFO_REQ, 1, "GET_ACTIVITY_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_ACTIVITY_INFO_CNF, 1, "GET_ACTIVITY_INFO_CNF", 5, mipc_nw_get_activity_info_cnf_tlv_checker_info},
    {MIPC_NW_SET_CA_REQ, 1, "SET_CA_REQ", 2, mipc_nw_set_ca_req_tlv_checker_info},
    {MIPC_NW_SET_CA_CNF, 1, "SET_CA_CNF", 0, NULL},
    {MIPC_NW_GET_LTE_RRC_STATE_REQ, 1, "GET_LTE_RRC_STATE_REQ", 0, NULL},
    {MIPC_NW_GET_LTE_RRC_STATE_CNF, 1, "GET_LTE_RRC_STATE_CNF", 2, mipc_nw_get_lte_rrc_state_cnf_tlv_checker_info},
    {MIPC_NW_GET_LTE_1XRTT_CELL_LIST_REQ, 1, "GET_LTE_1XRTT_CELL_LIST_REQ", 1, mipc_nw_get_lte_1xrtt_cell_list_req_tlv_checker_info},
    {MIPC_NW_GET_LTE_1XRTT_CELL_LIST_CNF, 1, "GET_LTE_1XRTT_CELL_LIST_CNF", 3, mipc_nw_get_lte_1xrtt_cell_list_cnf_tlv_checker_info},
    {MIPC_NW_CLEAR_LTE_AVAILABLE_FILE_REQ, 1, "CLEAR_LTE_AVAILABLE_FILE_REQ", 0, NULL},
    {MIPC_NW_CLEAR_LTE_AVAILABLE_FILE_CNF, 1, "CLEAR_LTE_AVAILABLE_FILE_CNF", 0, NULL},
    {MIPC_NW_GET_CA_LINK_CAPABILITY_REQ, 1, "GET_CA_LINK_CAPABILITY_REQ", 1, mipc_nw_get_ca_link_capability_req_tlv_checker_info},
    {MIPC_NW_GET_CA_LINK_CAPABILITY_CNF, 1, "GET_CA_LINK_CAPABILITY_CNF", 3, mipc_nw_get_ca_link_capability_cnf_tlv_checker_info},
    {MIPC_NW_GET_CA_LINK_ENABLE_STATUS_REQ, 1, "GET_CA_LINK_ENABLE_STATUS_REQ", 2, mipc_nw_get_ca_link_enable_status_req_tlv_checker_info},
    {MIPC_NW_GET_CA_LINK_ENABLE_STATUS_CNF, 1, "GET_CA_LINK_ENABLE_STATUS_CNF", 1, mipc_nw_get_ca_link_enable_status_cnf_tlv_checker_info},
    {MIPC_NW_GET_TM9_ENABLE_STATUS_REQ, 1, "GET_TM9_ENABLE_STATUS_REQ", 0, NULL},
    {MIPC_NW_GET_TM9_ENABLE_STATUS_CNF, 1, "GET_TM9_ENABLE_STATUS_CNF", 2, mipc_nw_get_tm9_enable_status_cnf_tlv_checker_info},
    {MIPC_NW_SET_TM9_ENABLE_STATUS_REQ, 1, "SET_TM9_ENABLE_STATUS_REQ", 2, mipc_nw_set_tm9_enable_status_req_tlv_checker_info},
    {MIPC_NW_SET_TM9_ENABLE_STATUS_CNF, 1, "SET_TM9_ENABLE_STATUS_CNF", 0, NULL},
    {MIPC_NW_GET_OMADM_CONF_REQ, 1, "GET_OMADM_CONF_REQ", 1, mipc_nw_get_omadm_conf_req_tlv_checker_info},
    {MIPC_NW_GET_OMADM_CONF_CNF, 1, "GET_OMADM_CONF_CNF", 1, mipc_nw_get_omadm_conf_cnf_tlv_checker_info},
    {MIPC_NW_SET_OMADM_CONF_REQ, 1, "SET_OMADM_CONF_REQ", 2, mipc_nw_set_omadm_conf_req_tlv_checker_info},
    {MIPC_NW_SET_OMADM_CONF_CNF, 1, "SET_OMADM_CONF_CNF", 0, NULL},
    {MIPC_NW_GET_CA_BAND_MODE_REQ, 1, "GET_CA_BAND_MODE_REQ", 1, mipc_nw_get_ca_band_mode_req_tlv_checker_info},
    {MIPC_NW_GET_CA_BAND_MODE_CNF, 1, "GET_CA_BAND_MODE_CNF", 1, mipc_nw_get_ca_band_mode_cnf_tlv_checker_info},
    {MIPC_NW_SET_CA_LINK_ENABLE_STATUS_REQ, 1, "SET_CA_LINK_ENABLE_STATUS_REQ", 3, mipc_nw_set_ca_link_enable_status_req_tlv_checker_info},
    {MIPC_NW_SET_CA_LINK_ENABLE_STATUS_CNF, 1, "SET_CA_LINK_ENABLE_STATUS_CNF", 0, NULL},
    {MIPC_NW_GET_LTE_DATA_REQ, 1, "GET_LTE_DATA_REQ", 0, NULL},
    {MIPC_NW_GET_LTE_DATA_CNF, 1, "GET_LTE_DATA_CNF", 13, mipc_nw_get_lte_data_cnf_tlv_checker_info},
    {MIPC_NW_SET_TUW_TIMER_LENGTH_REQ, 1, "SET_TUW_TIMER_LENGTH_REQ", 3, mipc_nw_set_tuw_timer_length_req_tlv_checker_info},
    {MIPC_NW_SET_TUW_TIMER_LENGTH_CNF, 1, "SET_TUW_TIMER_LENGTH_CNF", 0, NULL},
    {MIPC_NW_GET_TUW_TIMER_LENGTH_REQ, 1, "GET_TUW_TIMER_LENGTH_REQ", 0, NULL},
    {MIPC_NW_GET_TUW_TIMER_LENGTH_CNF, 1, "GET_TUW_TIMER_LENGTH_CNF", 3, mipc_nw_get_tuw_timer_length_cnf_tlv_checker_info},
    {MIPC_NW_GET_5GUW_INFO_REQ, 1, "GET_5GUW_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_5GUW_INFO_CNF, 1, "GET_5GUW_INFO_CNF", 4, mipc_nw_get_5guw_info_cnf_tlv_checker_info},
    {MIPC_NW_GET_NR_CA_BAND_REQ, 1, "GET_NR_CA_BAND_REQ", 0, NULL},
    {MIPC_NW_GET_NR_CA_BAND_CNF, 1, "GET_NR_CA_BAND_CNF", 3, mipc_nw_get_nr_ca_band_cnf_tlv_checker_info},
    {MIPC_NW_GET_NR_SCS_REQ, 1, "GET_NR_SCS_REQ", 0, NULL},
    {MIPC_NW_GET_NR_SCS_CNF, 1, "GET_NR_SCS_CNF", 1, mipc_nw_get_nr_scs_cnf_tlv_checker_info},
    {MIPC_NW_GET_PHYSICAL_CHANNEL_CONFIGS_REQ, 1, "GET_PHYSICAL_CHANNEL_CONFIGS_REQ", 0, NULL},
    {MIPC_NW_GET_PHYSICAL_CHANNEL_CONFIGS_CNF, 1, "GET_PHYSICAL_CHANNEL_CONFIGS_CNF", 1, mipc_nw_get_physical_channel_configs_cnf_tlv_checker_info},
    {MIPC_NW_OS_ID_UPDATE_REQ, 1, "OS_ID_UPDATE_REQ", 1, mipc_nw_os_id_update_req_tlv_checker_info},
    {MIPC_NW_OS_ID_UPDATE_CNF, 1, "OS_ID_UPDATE_CNF", 0, NULL},
    {MIPC_NW_START_NETWORK_SCAN_REQ, 1, "START_NETWORK_SCAN_REQ", 7, mipc_nw_start_network_scan_req_tlv_checker_info},
    {MIPC_NW_START_NETWORK_SCAN_CNF, 1, "START_NETWORK_SCAN_CNF", 0, NULL},
    {MIPC_NW_STOP_NETWORK_SCAN_REQ, 1, "STOP_NETWORK_SCAN_REQ", 0, NULL},
    {MIPC_NW_STOP_NETWORK_SCAN_CNF, 1, "STOP_NETWORK_SCAN_CNF", 0, NULL},
    {MIPC_NW_GET_NETWORK_SCAN_SUPPORT_STATUS_REQ, 1, "GET_NETWORK_SCAN_SUPPORT_STATUS_REQ", 0, NULL},
    {MIPC_NW_GET_NETWORK_SCAN_SUPPORT_STATUS_CNF, 1, "GET_NETWORK_SCAN_SUPPORT_STATUS_CNF", 0, NULL},
    {MIPC_NW_SET_PREF_NSSAI_REQ, 1, "SET_PREF_NSSAI_REQ", 2, mipc_nw_set_pref_nssai_req_tlv_checker_info},
    {MIPC_NW_SET_PREF_NSSAI_CNF, 1, "SET_PREF_NSSAI_CNF", 2, mipc_nw_set_pref_nssai_cnf_tlv_checker_info},
    {MIPC_NW_SET_DEFAULT_NSSAI_REQ, 1, "SET_DEFAULT_NSSAI_REQ", 1, mipc_nw_set_default_nssai_req_tlv_checker_info},
    {MIPC_NW_SET_DEFAULT_NSSAI_CNF, 1, "SET_DEFAULT_NSSAI_CNF", 1, mipc_nw_set_default_nssai_cnf_tlv_checker_info},
    {MIPC_NW_GET_NSSAI_REQ, 1, "GET_NSSAI_REQ", 2, mipc_nw_get_nssai_req_tlv_checker_info},
    {MIPC_NW_GET_NSSAI_CNF, 1, "GET_NSSAI_CNF", 8, mipc_nw_get_nssai_cnf_tlv_checker_info},
    {MIPC_NW_SET_5GUC_REQ, 1, "SET_5GUC_REQ", 5, mipc_nw_set_5guc_req_tlv_checker_info},
    {MIPC_NW_SET_5GUC_CNF, 1, "SET_5GUC_CNF", 0, NULL},
    {MIPC_NW_GET_5GUC_SETTING_REQ, 1, "GET_5GUC_SETTING_REQ", 0, NULL},
    {MIPC_NW_GET_5GUC_SETTING_CNF, 1, "GET_5GUC_SETTING_CNF", 5, mipc_nw_get_5guc_setting_cnf_tlv_checker_info},
    {MIPC_NW_GET_5GUC_INFO_REQ, 1, "GET_5GUC_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_5GUC_INFO_CNF, 1, "GET_5GUC_INFO_CNF", 3, mipc_nw_get_5guc_info_cnf_tlv_checker_info},
    {MIPC_NW_GET_FIRST_PLMN_REQ, 1, "GET_FIRST_PLMN_REQ", 0, NULL},
    {MIPC_NW_GET_FIRST_PLMN_CNF, 1, "GET_FIRST_PLMN_CNF", 2, mipc_nw_get_first_plmn_cnf_tlv_checker_info},
    {MIPC_NW_SET_UE_USAGE_SETTING_REQ, 1, "SET_UE_USAGE_SETTING_REQ", 1, mipc_nw_set_ue_usage_setting_req_tlv_checker_info},
    {MIPC_NW_SET_UE_USAGE_SETTING_CNF, 1, "SET_UE_USAGE_SETTING_CNF", 0, NULL},
    {MIPC_NW_GET_UE_USAGE_SETTING_REQ, 1, "GET_UE_USAGE_SETTING_REQ", 0, NULL},
    {MIPC_NW_GET_UE_USAGE_SETTING_CNF, 1, "GET_UE_USAGE_SETTING_CNF", 1, mipc_nw_get_ue_usage_setting_cnf_tlv_checker_info},
    {MIPC_NW_SET_CAG_STATUS_REQ, 1, "SET_CAG_STATUS_REQ", 1, mipc_nw_set_cag_status_req_tlv_checker_info},
    {MIPC_NW_SET_CAG_STATUS_CNF, 1, "SET_CAG_STATUS_CNF", 0, NULL},
    {MIPC_NW_SET_CAG_SELECT_MODE_REQ, 1, "SET_CAG_SELECT_MODE_REQ", 4, mipc_nw_set_cag_select_mode_req_tlv_checker_info},
    {MIPC_NW_SET_CAG_SELECT_MODE_CNF, 1, "SET_CAG_SELECT_MODE_CNF", 0, NULL},
    {MIPC_NW_GET_CAG_LIST_REQ, 1, "GET_CAG_LIST_REQ", 0, NULL},
    {MIPC_NW_GET_CAG_LIST_CNF, 1, "GET_CAG_LIST_CNF", 1, mipc_nw_get_cag_list_cnf_tlv_checker_info},
    {MIPC_NW_SET_ALLOWED_MCC_LIST_REQ, 1, "SET_ALLOWED_MCC_LIST_REQ", 2, mipc_nw_set_allowed_mcc_list_req_tlv_checker_info},
    {MIPC_NW_SET_ALLOWED_MCC_LIST_CNF, 1, "SET_ALLOWED_MCC_LIST_CNF", 0, NULL},
    {MIPC_NW_SET_EDRX_SETTING_REQ, 1, "SET_EDRX_SETTING_REQ", 4, mipc_nw_set_edrx_setting_req_tlv_checker_info},
    {MIPC_NW_SET_EDRX_SETTING_CNF, 1, "SET_EDRX_SETTING_CNF", 0, NULL},
    {MIPC_NW_GET_EDRX_SETTING_REQ, 1, "GET_EDRX_SETTING_REQ", 0, NULL},
    {MIPC_NW_GET_EDRX_SETTING_CNF, 1, "GET_EDRX_SETTING_CNF", 2, mipc_nw_get_edrx_setting_cnf_tlv_checker_info},
    {MIPC_NW_SET_EDRX_REQ, 1, "SET_EDRX_REQ", 0, NULL},
    {MIPC_NW_SET_EDRX_CNF, 1, "SET_EDRX_CNF", 4, mipc_nw_set_edrx_cnf_tlv_checker_info},
    {MIPC_NW_SET_POWER_SAVING_MODE_SETTING_REQ, 1, "SET_POWER_SAVING_MODE_SETTING_REQ", 3, mipc_nw_set_power_saving_mode_setting_req_tlv_checker_info},
    {MIPC_NW_SET_POWER_SAVING_MODE_SETTING_CNF, 1, "SET_POWER_SAVING_MODE_SETTING_CNF", 0, NULL},
    {MIPC_NW_GET_POWER_SAVING_MODE_SETTING_REQ, 1, "GET_POWER_SAVING_MODE_SETTING_REQ", 0, NULL},
    {MIPC_NW_GET_POWER_SAVING_MODE_SETTING_CNF, 1, "GET_POWER_SAVING_MODE_SETTING_CNF", 3, mipc_nw_get_power_saving_mode_setting_cnf_tlv_checker_info},
    {MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_REQ, 1, "SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_REQ", 2, mipc_nw_set_mobile_initiated_connection_only_mode_req_tlv_checker_info},
    {MIPC_NW_SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF, 1, "SET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF", 4, mipc_nw_set_mobile_initiated_connection_only_mode_cnf_tlv_checker_info},
    {MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_REQ, 1, "GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_REQ", 0, NULL},
    {MIPC_NW_GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF, 1, "GET_MOBILE_INITIATED_CONNECTION_ONLY_MODE_CNF", 6, mipc_nw_get_mobile_initiated_connection_only_mode_cnf_tlv_checker_info},
    {MIPC_NW_GET_LATEST_CA_MEASUREMENT_REQ, 1, "GET_LATEST_CA_MEASUREMENT_REQ", 0, NULL},
    {MIPC_NW_GET_LATEST_CA_MEASUREMENT_CNF, 1, "GET_LATEST_CA_MEASUREMENT_CNF", 2, mipc_nw_get_latest_ca_measurement_cnf_tlv_checker_info},
    {MIPC_SIM_PIN_PROTECT_REQ, 1, "PIN_PROTECT_REQ", 3, mipc_sim_pin_protect_req_tlv_checker_info},
    {MIPC_SIM_PIN_PROTECT_CNF, 1, "PIN_PROTECT_CNF", 3, mipc_sim_pin_protect_cnf_tlv_checker_info},
    {MIPC_SIM_CHANGE_PIN_REQ, 1, "CHANGE_PIN_REQ", 3, mipc_sim_change_pin_req_tlv_checker_info},
    {MIPC_SIM_CHANGE_PIN_CNF, 1, "CHANGE_PIN_CNF", 3, mipc_sim_change_pin_cnf_tlv_checker_info},
    {MIPC_SIM_VERIFY_PIN_REQ, 1, "VERIFY_PIN_REQ", 2, mipc_sim_verify_pin_req_tlv_checker_info},
    {MIPC_SIM_VERIFY_PIN_CNF, 1, "VERIFY_PIN_CNF", 3, mipc_sim_verify_pin_cnf_tlv_checker_info},
    {MIPC_SIM_UNBLOCK_PIN_REQ, 1, "UNBLOCK_PIN_REQ", 3, mipc_sim_unblock_pin_req_tlv_checker_info},
    {MIPC_SIM_UNBLOCK_PIN_CNF, 1, "UNBLOCK_PIN_CNF", 3, mipc_sim_unblock_pin_cnf_tlv_checker_info},
    {MIPC_SIM_GET_PIN_INFO_REQ, 1, "GET_PIN_INFO_REQ", 0, NULL},
    {MIPC_SIM_GET_PIN_INFO_CNF, 1, "GET_PIN_INFO_CNF", 3, mipc_sim_get_pin_info_cnf_tlv_checker_info},
    {MIPC_SIM_GET_PIN_LIST_REQ, 1, "GET_PIN_LIST_REQ", 0, NULL},
    {MIPC_SIM_GET_PIN_LIST_CNF, 1, "GET_PIN_LIST_CNF", 7, mipc_sim_get_pin_list_cnf_tlv_checker_info},
    {MIPC_SIM_STATE_REQ, 1, "STATE_REQ", 0, NULL},
    {MIPC_SIM_STATE_CNF, 1, "STATE_CNF", 3, mipc_sim_state_cnf_tlv_checker_info},
    {MIPC_SIM_STATUS_REQ, 1, "STATUS_REQ", 1, mipc_sim_status_req_tlv_checker_info},
    {MIPC_SIM_STATUS_CNF, 1, "STATUS_CNF", 22, mipc_sim_status_cnf_tlv_checker_info},
    {MIPC_SIM_ICCID_REQ, 1, "ICCID_REQ", 0, NULL},
    {MIPC_SIM_ICCID_CNF, 1, "ICCID_CNF", 1, mipc_sim_iccid_cnf_tlv_checker_info},
    {MIPC_SIM_IMSI_REQ, 1, "IMSI_REQ", 2, mipc_sim_imsi_req_tlv_checker_info},
    {MIPC_SIM_IMSI_CNF, 1, "IMSI_CNF", 2, mipc_sim_imsi_cnf_tlv_checker_info},
    {MIPC_SIM_MSISDN_REQ, 1, "MSISDN_REQ", 0, NULL},
    {MIPC_SIM_MSISDN_CNF, 1, "MSISDN_CNF", 3, mipc_sim_msisdn_cnf_tlv_checker_info},
    {MIPC_SIM_GET_ATR_INFO_REQ, 1, "GET_ATR_INFO_REQ", 0, NULL},
    {MIPC_SIM_GET_ATR_INFO_CNF, 1, "GET_ATR_INFO_CNF", 2, mipc_sim_get_atr_info_cnf_tlv_checker_info},
    {MIPC_SIM_OPEN_CHANNEL_REQ, 1, "OPEN_CHANNEL_REQ", 4, mipc_sim_open_channel_req_tlv_checker_info},
    {MIPC_SIM_OPEN_CHANNEL_CNF, 1, "OPEN_CHANNEL_CNF", 3, mipc_sim_open_channel_cnf_tlv_checker_info},
    {MIPC_SIM_CLOSE_CHANNEL_REQ, 1, "CLOSE_CHANNEL_REQ", 2, mipc_sim_close_channel_req_tlv_checker_info},
    {MIPC_SIM_CLOSE_CHANNEL_CNF, 1, "CLOSE_CHANNEL_CNF", 1, mipc_sim_close_channel_cnf_tlv_checker_info},
    {MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_REQ, 1, "CHANNEL_RESTRICTED_ACCESS_REQ", 12, mipc_sim_channel_restricted_access_req_tlv_checker_info},
    {MIPC_SIM_CHANNEL_RESTRICTED_ACCESS_CNF, 1, "CHANNEL_RESTRICTED_ACCESS_CNF", 3, mipc_sim_channel_restricted_access_cnf_tlv_checker_info},
    {MIPC_SIM_CHANNEL_GENERIC_ACCESS_REQ, 1, "CHANNEL_GENERIC_ACCESS_REQ", 4, mipc_sim_channel_generic_access_req_tlv_checker_info},
    {MIPC_SIM_CHANNEL_GENERIC_ACCESS_CNF, 1, "CHANNEL_GENERIC_ACCESS_CNF", 3, mipc_sim_channel_generic_access_cnf_tlv_checker_info},
    {MIPC_SIM_LONG_APDU_ACCESS_REQ, 1, "LONG_APDU_ACCESS_REQ", 10, mipc_sim_long_apdu_access_req_tlv_checker_info},
    {MIPC_SIM_LONG_APDU_ACCESS_CNF, 1, "LONG_APDU_ACCESS_CNF", 4, mipc_sim_long_apdu_access_cnf_tlv_checker_info},
    {MIPC_SIM_APP_LIST_REQ, 1, "APP_LIST_REQ", 0, NULL},
    {MIPC_SIM_APP_LIST_CNF, 1, "APP_LIST_CNF", 5, mipc_sim_app_list_cnf_tlv_checker_info},
    {MIPC_SIM_FILE_STATUS_REQ, 1, "FILE_STATUS_REQ", 5, mipc_sim_file_status_req_tlv_checker_info},
    {MIPC_SIM_FILE_STATUS_CNF, 1, "FILE_STATUS_CNF", 9, mipc_sim_file_status_cnf_tlv_checker_info},
    {MIPC_SIM_GET_RESET_REQ, 1, "GET_RESET_REQ", 1, mipc_sim_get_reset_req_tlv_checker_info},
    {MIPC_SIM_GET_RESET_CNF, 1, "GET_RESET_CNF", 1, mipc_sim_get_reset_cnf_tlv_checker_info},
    {MIPC_SIM_SET_RESET_REQ, 1, "SET_RESET_REQ", 1, mipc_sim_set_reset_req_tlv_checker_info},
    {MIPC_SIM_SET_RESET_CNF, 1, "SET_RESET_CNF", 0, NULL},
    {MIPC_SIM_GET_TERMINAL_CAPABILITY_REQ, 1, "GET_TERMINAL_CAPABILITY_REQ", 0, NULL},
    {MIPC_SIM_GET_TERMINAL_CAPABILITY_CNF, 1, "GET_TERMINAL_CAPABILITY_CNF", 3, mipc_sim_get_terminal_capability_cnf_tlv_checker_info},
    {MIPC_SIM_SET_TERMINAL_CAPABILITY_REQ, 1, "SET_TERMINAL_CAPABILITY_REQ", 3, mipc_sim_set_terminal_capability_req_tlv_checker_info},
    {MIPC_SIM_SET_TERMINAL_CAPABILITY_CNF, 1, "SET_TERMINAL_CAPABILITY_CNF", 0, NULL},
    {MIPC_SIM_SET_PIN_EX_REQ, 1, "SET_PIN_EX_REQ", 6, mipc_sim_set_pin_ex_req_tlv_checker_info},
    {MIPC_SIM_SET_PIN_EX_CNF, 1, "SET_PIN_EX_CNF", 3, mipc_sim_set_pin_ex_cnf_tlv_checker_info},
    {MIPC_SIM_GET_PIN_EX_REQ, 1, "GET_PIN_EX_REQ", 3, mipc_sim_get_pin_ex_req_tlv_checker_info},
    {MIPC_SIM_GET_PIN_EX_CNF, 1, "GET_PIN_EX_CNF", 3, mipc_sim_get_pin_ex_cnf_tlv_checker_info},
    {MIPC_SIM_GET_GSM_AUTH_REQ, 1, "GET_GSM_AUTH_REQ", 3, mipc_sim_get_gsm_auth_req_tlv_checker_info},
    {MIPC_SIM_GET_GSM_AUTH_CNF, 1, "GET_GSM_AUTH_CNF", 7, mipc_sim_get_gsm_auth_cnf_tlv_checker_info},
    {MIPC_SIM_GET_EXT_AUTH_REQ, 1, "GET_EXT_AUTH_REQ", 5, mipc_sim_get_ext_auth_req_tlv_checker_info},
    {MIPC_SIM_GET_EXT_AUTH_CNF, 1, "GET_EXT_AUTH_CNF", 3, mipc_sim_get_ext_auth_cnf_tlv_checker_info},
    {MIPC_SIM_GET_FACILITY_REQ, 1, "GET_FACILITY_REQ", 2, mipc_sim_get_facility_req_tlv_checker_info},
    {MIPC_SIM_GET_FACILITY_CNF, 1, "GET_FACILITY_CNF", 1, mipc_sim_get_facility_cnf_tlv_checker_info},
    {MIPC_SIM_SET_FACILITY_REQ, 1, "SET_FACILITY_REQ", 4, mipc_sim_set_facility_req_tlv_checker_info},
    {MIPC_SIM_SET_FACILITY_CNF, 1, "SET_FACILITY_CNF", 1, mipc_sim_set_facility_cnf_tlv_checker_info},
    {MIPC_SIM_GET_EUICC_SLOTS_STATUS_REQ, 1, "GET_EUICC_SLOTS_STATUS_REQ", 0, NULL},
    {MIPC_SIM_GET_EUICC_SLOTS_STATUS_CNF, 1, "GET_EUICC_SLOTS_STATUS_CNF", 9, mipc_sim_get_euicc_slots_status_cnf_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_CONNECT_REQ, 1, "ACCESS_PROFILE_CONNECT_REQ", 0, NULL},
    {MIPC_SIM_ACCESS_PROFILE_CONNECT_CNF, 1, "ACCESS_PROFILE_CONNECT_CNF", 3, mipc_sim_access_profile_connect_cnf_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_DISCONNECT_REQ, 1, "ACCESS_PROFILE_DISCONNECT_REQ", 0, NULL},
    {MIPC_SIM_ACCESS_PROFILE_DISCONNECT_CNF, 1, "ACCESS_PROFILE_DISCONNECT_CNF", 0, NULL},
    {MIPC_SIM_ACCESS_PROFILE_POWER_ON_REQ, 1, "ACCESS_PROFILE_POWER_ON_REQ", 1, mipc_sim_access_profile_power_on_req_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_POWER_ON_CNF, 1, "ACCESS_PROFILE_POWER_ON_CNF", 2, mipc_sim_access_profile_power_on_cnf_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_POWER_OFF_REQ, 1, "ACCESS_PROFILE_POWER_OFF_REQ", 0, NULL},
    {MIPC_SIM_ACCESS_PROFILE_POWER_OFF_CNF, 1, "ACCESS_PROFILE_POWER_OFF_CNF", 0, NULL},
    {MIPC_SIM_ACCESS_PROFILE_RESET_REQ, 1, "ACCESS_PROFILE_RESET_REQ", 1, mipc_sim_access_profile_reset_req_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_RESET_CNF, 1, "ACCESS_PROFILE_RESET_CNF", 2, mipc_sim_access_profile_reset_cnf_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_APDU_REQ, 1, "ACCESS_PROFILE_APDU_REQ", 2, mipc_sim_access_profile_apdu_req_tlv_checker_info},
    {MIPC_SIM_ACCESS_PROFILE_APDU_CNF, 1, "ACCESS_PROFILE_APDU_CNF", 1, mipc_sim_access_profile_apdu_cnf_tlv_checker_info},
    {MIPC_SIM_SET_SIM_POWER_REQ, 1, "SET_SIM_POWER_REQ", 2, mipc_sim_set_sim_power_req_tlv_checker_info},
    {MIPC_SIM_SET_SIM_POWER_CNF, 1, "SET_SIM_POWER_CNF", 0, NULL},
    {MIPC_SIM_SET_PHYSICAL_SLOTS_MAPPING_REQ, 1, "SET_PHYSICAL_SLOTS_MAPPING_REQ", 2, mipc_sim_set_physical_slots_mapping_req_tlv_checker_info},
    {MIPC_SIM_SET_PHYSICAL_SLOTS_MAPPING_CNF, 1, "SET_PHYSICAL_SLOTS_MAPPING_CNF", 0, NULL},
    {MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_REQ, 1, "EXTENDED_CHANNEL_GENERIC_ACCESS_REQ", 8, mipc_sim_extended_channel_generic_access_req_tlv_checker_info},
    {MIPC_SIM_EXTENDED_CHANNEL_GENERIC_ACCESS_CNF, 1, "EXTENDED_CHANNEL_GENERIC_ACCESS_CNF", 3, mipc_sim_extended_channel_generic_access_cnf_tlv_checker_info},
    {MIPC_SIM_UICC_FILE_ACCESS_RECORD_REQ, 1, "UICC_FILE_ACCESS_RECORD_REQ", 8, mipc_sim_uicc_file_access_record_req_tlv_checker_info},
    {MIPC_SIM_UICC_FILE_ACCESS_RECORD_CNF, 1, "UICC_FILE_ACCESS_RECORD_CNF", 3, mipc_sim_uicc_file_access_record_cnf_tlv_checker_info},
    {MIPC_SIM_UICC_FILE_ACCESS_BINARY_REQ, 1, "UICC_FILE_ACCESS_BINARY_REQ", 8, mipc_sim_uicc_file_access_binary_req_tlv_checker_info},
    {MIPC_SIM_UICC_FILE_ACCESS_BINARY_CNF, 1, "UICC_FILE_ACCESS_BINARY_CNF", 3, mipc_sim_uicc_file_access_binary_cnf_tlv_checker_info},
    {MIPC_SIM_GET_PHYSICAL_SLOTS_MAPPING_REQ, 1, "GET_PHYSICAL_SLOTS_MAPPING_REQ", 0, NULL},
    {MIPC_SIM_GET_PHYSICAL_SLOTS_MAPPING_CNF, 1, "GET_PHYSICAL_SLOTS_MAPPING_CNF", 1, mipc_sim_get_physical_slots_mapping_cnf_tlv_checker_info},
    {MIPC_SIM_GET_SIM_AUTH_REQ, 1, "GET_SIM_AUTH_REQ", 4, mipc_sim_get_sim_auth_req_tlv_checker_info},
    {MIPC_SIM_GET_SIM_AUTH_CNF, 1, "GET_SIM_AUTH_CNF", 3, mipc_sim_get_sim_auth_cnf_tlv_checker_info},
    {MIPC_SIM_SML_GET_ALLOWED_CARRIERS_REQ, 1, "SML_GET_ALLOWED_CARRIERS_REQ", 0, NULL},
    {MIPC_SIM_SML_GET_ALLOWED_CARRIERS_CNF, 1, "SML_GET_ALLOWED_CARRIERS_CNF", 10, mipc_sim_sml_get_allowed_carriers_cnf_tlv_checker_info},
    {MIPC_SIM_SML_SET_ALLOWED_CARRIERS_REQ, 1, "SML_SET_ALLOWED_CARRIERS_REQ", 8, mipc_sim_sml_set_allowed_carriers_req_tlv_checker_info},
    {MIPC_SIM_SML_SET_ALLOWED_CARRIERS_CNF, 1, "SML_SET_ALLOWED_CARRIERS_CNF", 2, mipc_sim_sml_set_allowed_carriers_cnf_tlv_checker_info},
    {MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_REQ, 1, "SML_ENTER_SIM_DEPERSONALIZATION_REQ", 2, mipc_sim_sml_enter_sim_depersonalization_req_tlv_checker_info},
    {MIPC_SIM_SML_ENTER_SIM_DEPERSONALIZATION_CNF, 1, "SML_ENTER_SIM_DEPERSONALIZATION_CNF", 3, mipc_sim_sml_enter_sim_depersonalization_cnf_tlv_checker_info},
    {MIPC_SIM_SML_GET_LOCK_REQ, 1, "SML_GET_LOCK_REQ", 1, mipc_sim_sml_get_lock_req_tlv_checker_info},
    {MIPC_SIM_SML_GET_LOCK_CNF, 1, "SML_GET_LOCK_CNF", 9, mipc_sim_sml_get_lock_cnf_tlv_checker_info},
    {MIPC_SIM_SML_SET_LOCK_REQ, 1, "SML_SET_LOCK_REQ", 6, mipc_sim_sml_set_lock_req_tlv_checker_info},
    {MIPC_SIM_SML_SET_LOCK_CNF, 1, "SML_SET_LOCK_CNF", 0, NULL},
    {MIPC_SIM_SML_ENTER_DEVICE_DEPERSONALIZATION_REQ, 1, "SML_ENTER_DEVICE_DEPERSONALIZATION_REQ", 1, mipc_sim_sml_enter_device_depersonalization_req_tlv_checker_info},
    {MIPC_SIM_SML_ENTER_DEVICE_DEPERSONALIZATION_CNF, 1, "SML_ENTER_DEVICE_DEPERSONALIZATION_CNF", 1, mipc_sim_sml_enter_device_depersonalization_cnf_tlv_checker_info},
    {MIPC_SIM_SML_GET_DEV_LOCK_REQ, 1, "SML_GET_DEV_LOCK_REQ", 0, NULL},
    {MIPC_SIM_SML_GET_DEV_LOCK_CNF, 1, "SML_GET_DEV_LOCK_CNF", 4, mipc_sim_sml_get_dev_lock_cnf_tlv_checker_info},
    {MIPC_SIM_SML_RSU_REQ, 1, "SML_RSU_REQ", 7, mipc_sim_sml_rsu_req_tlv_checker_info},
    {MIPC_SIM_SML_RSU_CNF, 1, "SML_RSU_CNF", 12, mipc_sim_sml_rsu_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_SET_AKA_REQ, 1, "VSIM_SET_AKA_REQ", 1, mipc_sim_vsim_set_aka_req_tlv_checker_info},
    {MIPC_SIM_VSIM_SET_AKA_CNF, 1, "VSIM_SET_AKA_CNF", 1, mipc_sim_vsim_set_aka_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_ENABLE_REQ, 1, "VSIM_ENABLE_REQ", 0, NULL},
    {MIPC_SIM_VSIM_ENABLE_CNF, 1, "VSIM_ENABLE_CNF", 1, mipc_sim_vsim_enable_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_DISABLE_REQ, 1, "VSIM_DISABLE_REQ", 0, NULL},
    {MIPC_SIM_VSIM_DISABLE_CNF, 1, "VSIM_DISABLE_CNF", 1, mipc_sim_vsim_disable_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_PLUG_REQ, 1, "VSIM_PLUG_REQ", 2, mipc_sim_vsim_plug_req_tlv_checker_info},
    {MIPC_SIM_VSIM_PLUG_CNF, 1, "VSIM_PLUG_CNF", 1, mipc_sim_vsim_plug_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_SET_TIMER_REQ, 1, "VSIM_SET_TIMER_REQ", 1, mipc_sim_vsim_set_timer_req_tlv_checker_info},
    {MIPC_SIM_VSIM_SET_TIMER_CNF, 1, "VSIM_SET_TIMER_CNF", 1, mipc_sim_vsim_set_timer_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_RESET_REQ, 1, "VSIM_RESET_REQ", 3, mipc_sim_vsim_reset_req_tlv_checker_info},
    {MIPC_SIM_VSIM_RESET_CNF, 1, "VSIM_RESET_CNF", 1, mipc_sim_vsim_reset_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_APDU_REQ, 1, "VSIM_APDU_REQ", 2, mipc_sim_vsim_apdu_req_tlv_checker_info},
    {MIPC_SIM_VSIM_APDU_CNF, 1, "VSIM_APDU_CNF", 1, mipc_sim_vsim_apdu_cnf_tlv_checker_info},
    {MIPC_SIM_VSIM_AUTH_REQ, 1, "VSIM_AUTH_REQ", 1, mipc_sim_vsim_auth_req_tlv_checker_info},
    {MIPC_SIM_VSIM_AUTH_CNF, 1, "VSIM_AUTH_CNF", 1, mipc_sim_vsim_auth_cnf_tlv_checker_info},
    {MIPC_SIM_CDMA_SUBSCRIPTION_REQ, 1, "CDMA_SUBSCRIPTION_REQ", 0, NULL},
    {MIPC_SIM_CDMA_SUBSCRIPTION_CNF, 1, "CDMA_SUBSCRIPTION_CNF", 7, mipc_sim_cdma_subscription_cnf_tlv_checker_info},
    {MIPC_SIM_CDMA_GET_SUBSCRIPTION_SOURCE_REQ, 1, "CDMA_GET_SUBSCRIPTION_SOURCE_REQ", 0, NULL},
    {MIPC_SIM_CDMA_GET_SUBSCRIPTION_SOURCE_CNF, 1, "CDMA_GET_SUBSCRIPTION_SOURCE_CNF", 2, mipc_sim_cdma_get_subscription_source_cnf_tlv_checker_info},
    {MIPC_SIM_PIN_COUNT_QUERY_REQ, 1, "PIN_COUNT_QUERY_REQ", 0, NULL},
    {MIPC_SIM_PIN_COUNT_QUERY_CNF, 1, "PIN_COUNT_QUERY_CNF", 5, mipc_sim_pin_count_query_cnf_tlv_checker_info},
    {MIPC_SIM_SML_GET_NETWORK_LOCK_REQ, 1, "SML_GET_NETWORK_LOCK_REQ", 0, NULL},
    {MIPC_SIM_SML_GET_NETWORK_LOCK_CNF, 1, "SML_GET_NETWORK_LOCK_CNF", 8, mipc_sim_sml_get_network_lock_cnf_tlv_checker_info},
    {MIPC_SIM_ESIM_SWITCH_SET_REQ, 1, "ESIM_SWITCH_SET_REQ", 1, mipc_sim_esim_switch_set_req_tlv_checker_info},
    {MIPC_SIM_ESIM_SWITCH_SET_CNF, 1, "ESIM_SWITCH_SET_CNF", 0, NULL},
    {MIPC_SIM_ESIM_SWITCH_GET_REQ, 1, "ESIM_SWITCH_GET_REQ", 0, NULL},
    {MIPC_SIM_ESIM_SWITCH_GET_CNF, 1, "ESIM_SWITCH_GET_CNF", 2, mipc_sim_esim_switch_get_cnf_tlv_checker_info},
    {MIPC_SIM_ESIM_EID_QUERY_REQ, 1, "ESIM_EID_QUERY_REQ", 1, mipc_sim_esim_eid_query_req_tlv_checker_info},
    {MIPC_SIM_ESIM_EID_QUERY_CNF, 1, "ESIM_EID_QUERY_CNF", 1, mipc_sim_esim_eid_query_cnf_tlv_checker_info},
    {MIPC_SIM_MEP_SLOTS_INFO_GET_REQ, 1, "MEP_SLOTS_INFO_GET_REQ", 0, NULL},
    {MIPC_SIM_MEP_SLOTS_INFO_GET_CNF, 1, "MEP_SLOTS_INFO_GET_CNF", 7, mipc_sim_mep_slots_info_get_cnf_tlv_checker_info},
    {MIPC_SIM_MEP_SLOTS_MAPPING_SET_REQ, 1, "MEP_SLOTS_MAPPING_SET_REQ", 3, mipc_sim_mep_slots_mapping_set_req_tlv_checker_info},
    {MIPC_SIM_MEP_SLOTS_MAPPING_SET_CNF, 1, "MEP_SLOTS_MAPPING_SET_CNF", 0, NULL},
    {MIPC_SMS_CFG_REQ, 1, "CFG_REQ", 17, mipc_sms_cfg_req_tlv_checker_info},
    {MIPC_SMS_CFG_REQ, 2, "CFG_REQ", 9, mipc_sms_cfg_req_tlv_checker_info_v2},
    {MIPC_SMS_CFG_CNF, 1, "CFG_CNF", 16, mipc_sms_cfg_cnf_tlv_checker_info},
    {MIPC_SMS_CFG_CNF, 2, "CFG_CNF", 7, mipc_sms_cfg_cnf_tlv_checker_info_v2},
    {MIPC_SMS_SEND_REQ, 1, "SEND_REQ", 7, mipc_sms_send_req_tlv_checker_info},
    {MIPC_SMS_SEND_REQ, 2, "SEND_REQ", 3, mipc_sms_send_req_tlv_checker_info_v2},
    {MIPC_SMS_SEND_CNF, 1, "SEND_CNF", 7, mipc_sms_send_cnf_tlv_checker_info},
    {MIPC_SMS_SEND_CNF, 2, "SEND_CNF", 3, mipc_sms_send_cnf_tlv_checker_info_v2},
    {MIPC_SMS_READ_REQ, 1, "READ_REQ", 5, mipc_sms_read_req_tlv_checker_info},
    {MIPC_SMS_READ_REQ, 2, "READ_REQ", 5, mipc_sms_read_req_tlv_checker_info_v2},
    {MIPC_SMS_READ_CNF, 1, "READ_CNF", 4, mipc_sms_read_cnf_tlv_checker_info},
    {MIPC_SMS_READ_CNF, 2, "READ_CNF", 3, mipc_sms_read_cnf_tlv_checker_info_v2},
    {MIPC_SMS_DELETE_REQ, 1, "DELETE_REQ", 4, mipc_sms_delete_req_tlv_checker_info},
    {MIPC_SMS_DELETE_REQ, 2, "DELETE_REQ", 4, mipc_sms_delete_req_tlv_checker_info_v2},
    {MIPC_SMS_DELETE_CNF, 1, "DELETE_CNF", 0, NULL},
    {MIPC_SMS_DELETE_CNF, 2, "DELETE_CNF", 0, NULL},
    {MIPC_SMS_GET_STORE_STATUS_REQ, 1, "GET_STORE_STATUS_REQ", 2, mipc_sms_get_store_status_req_tlv_checker_info},
    {MIPC_SMS_GET_STORE_STATUS_REQ, 2, "GET_STORE_STATUS_REQ", 2, mipc_sms_get_store_status_req_tlv_checker_info_v2},
    {MIPC_SMS_GET_STORE_STATUS_CNF, 1, "GET_STORE_STATUS_CNF", 5, mipc_sms_get_store_status_cnf_tlv_checker_info},
    {MIPC_SMS_GET_STORE_STATUS_CNF, 2, "GET_STORE_STATUS_CNF", 2, mipc_sms_get_store_status_cnf_tlv_checker_info_v2},
    {MIPC_SMS_WRITE_REQ, 1, "WRITE_REQ", 6, mipc_sms_write_req_tlv_checker_info},
    {MIPC_SMS_WRITE_REQ, 2, "WRITE_REQ", 4, mipc_sms_write_req_tlv_checker_info_v2},
    {MIPC_SMS_WRITE_CNF, 1, "WRITE_CNF", 1, mipc_sms_write_cnf_tlv_checker_info},
    {MIPC_SMS_WRITE_CNF, 2, "WRITE_CNF", 1, mipc_sms_write_cnf_tlv_checker_info_v2},
    {MIPC_SMS_CBM_CFG_REQ, 1, "CBM_CFG_REQ", 11, mipc_sms_cbm_cfg_req_tlv_checker_info},
    {MIPC_SMS_CBM_CFG_REQ, 2, "CBM_CFG_REQ", 10, mipc_sms_cbm_cfg_req_tlv_checker_info_v2},
    {MIPC_SMS_CBM_CFG_CNF, 1, "CBM_CFG_CNF", 10, mipc_sms_cbm_cfg_cnf_tlv_checker_info},
    {MIPC_SMS_CBM_CFG_CNF, 2, "CBM_CFG_CNF", 9, mipc_sms_cbm_cfg_cnf_tlv_checker_info_v2},
    {MIPC_SMS_SCBM_REQ, 1, "SCBM_REQ", 1, mipc_sms_scbm_req_tlv_checker_info},
    {MIPC_SMS_SCBM_CNF, 1, "SCBM_CNF", 0, NULL},
    {MIPC_SMS_DOMAIN_REQ, 1, "DOMAIN_REQ", 4, mipc_sms_domain_req_tlv_checker_info},
    {MIPC_SMS_DOMAIN_CNF, 1, "DOMAIN_CNF", 2, mipc_sms_domain_cnf_tlv_checker_info},
    {MIPC_SS_SEND_USSD_REQ, 1, "SEND_USSD_REQ", 4, mipc_ss_send_ussd_req_tlv_checker_info},
    {MIPC_SS_SEND_USSD_CNF, 1, "SEND_USSD_CNF", 7, mipc_ss_send_ussd_cnf_tlv_checker_info},
    {MIPC_SS_CANCEL_USSD_REQ, 1, "CANCEL_USSD_REQ", 0, NULL},
    {MIPC_SS_CANCEL_USSD_CNF, 1, "CANCEL_USSD_CNF", 5, mipc_ss_cancel_ussd_cnf_tlv_checker_info},
    {MIPC_SS_SET_CLIR_REQ, 1, "SET_CLIR_REQ", 1, mipc_ss_set_clir_req_tlv_checker_info},
    {MIPC_SS_SET_CLIR_CNF, 1, "SET_CLIR_CNF", 1, mipc_ss_set_clir_cnf_tlv_checker_info},
    {MIPC_SS_GET_CLIR_REQ, 1, "GET_CLIR_REQ", 0, NULL},
    {MIPC_SS_GET_CLIR_CNF, 1, "GET_CLIR_CNF", 3, mipc_ss_get_clir_cnf_tlv_checker_info},
    {MIPC_SS_SET_CALL_WAITING_REQ, 1, "SET_CALL_WAITING_REQ", 2, mipc_ss_set_call_waiting_req_tlv_checker_info},
    {MIPC_SS_SET_CALL_WAITING_CNF, 1, "SET_CALL_WAITING_CNF", 1, mipc_ss_set_call_waiting_cnf_tlv_checker_info},
    {MIPC_SS_QUERY_CALL_WAITING_REQ, 1, "QUERY_CALL_WAITING_REQ", 1, mipc_ss_query_call_waiting_req_tlv_checker_info},
    {MIPC_SS_QUERY_CALL_WAITING_CNF, 1, "QUERY_CALL_WAITING_CNF", 6, mipc_ss_query_call_waiting_cnf_tlv_checker_info},
    {MIPC_SS_SET_CALL_FORWARD_REQ, 1, "SET_CALL_FORWARD_REQ", 8, mipc_ss_set_call_forward_req_tlv_checker_info},
    {MIPC_SS_SET_CALL_FORWARD_CNF, 1, "SET_CALL_FORWARD_CNF", 1, mipc_ss_set_call_forward_cnf_tlv_checker_info},
    {MIPC_SS_QUERY_CALL_FORWARD_REQ, 1, "QUERY_CALL_FORWARD_REQ", 2, mipc_ss_query_call_forward_req_tlv_checker_info},
    {MIPC_SS_QUERY_CALL_FORWARD_CNF, 1, "QUERY_CALL_FORWARD_CNF", 3, mipc_ss_query_call_forward_cnf_tlv_checker_info},
    {MIPC_SS_SET_CALL_BARRING_REQ, 1, "SET_CALL_BARRING_REQ", 6, mipc_ss_set_call_barring_req_tlv_checker_info},
    {MIPC_SS_SET_CALL_BARRING_CNF, 1, "SET_CALL_BARRING_CNF", 1, mipc_ss_set_call_barring_cnf_tlv_checker_info},
    {MIPC_SS_QUERY_CALL_BARRING_REQ, 1, "QUERY_CALL_BARRING_REQ", 2, mipc_ss_query_call_barring_req_tlv_checker_info},
    {MIPC_SS_QUERY_CALL_BARRING_CNF, 1, "QUERY_CALL_BARRING_CNF", 4, mipc_ss_query_call_barring_cnf_tlv_checker_info},
    {MIPC_SS_CHANGE_BARRING_PASSWORD_REQ, 1, "CHANGE_BARRING_PASSWORD_REQ", 4, mipc_ss_change_barring_password_req_tlv_checker_info},
    {MIPC_SS_CHANGE_BARRING_PASSWORD_CNF, 1, "CHANGE_BARRING_PASSWORD_CNF", 0, NULL},
    {MIPC_SS_SET_SUPP_SVC_NOTIFICATION_REQ, 1, "SET_SUPP_SVC_NOTIFICATION_REQ", 2, mipc_ss_set_supp_svc_notification_req_tlv_checker_info},
    {MIPC_SS_SET_SUPP_SVC_NOTIFICATION_CNF, 1, "SET_SUPP_SVC_NOTIFICATION_CNF", 0, NULL},
    {MIPC_SS_QUERY_CLIP_REQ, 1, "QUERY_CLIP_REQ", 0, NULL},
    {MIPC_SS_QUERY_CLIP_CNF, 1, "QUERY_CLIP_CNF", 3, mipc_ss_query_clip_cnf_tlv_checker_info},
    {MIPC_SS_SET_CLIP_REQ, 1, "SET_CLIP_REQ", 1, mipc_ss_set_clip_req_tlv_checker_info},
    {MIPC_SS_SET_CLIP_CNF, 1, "SET_CLIP_CNF", 1, mipc_ss_set_clip_cnf_tlv_checker_info},
    {MIPC_SS_RUN_GBA_REQ, 1, "RUN_GBA_REQ", 4, mipc_ss_run_gba_req_tlv_checker_info},
    {MIPC_SS_RUN_GBA_CNF, 1, "RUN_GBA_CNF", 4, mipc_ss_run_gba_cnf_tlv_checker_info},
    {MIPC_SS_GET_COLP_REQ, 1, "GET_COLP_REQ", 0, NULL},
    {MIPC_SS_GET_COLP_CNF, 1, "GET_COLP_CNF", 3, mipc_ss_get_colp_cnf_tlv_checker_info},
    {MIPC_SS_SET_COLP_REQ, 1, "SET_COLP_REQ", 1, mipc_ss_set_colp_req_tlv_checker_info},
    {MIPC_SS_SET_COLP_CNF, 1, "SET_COLP_CNF", 1, mipc_ss_set_colp_cnf_tlv_checker_info},
    {MIPC_SS_GET_COLR_REQ, 1, "GET_COLR_REQ", 0, NULL},
    {MIPC_SS_GET_COLR_CNF, 1, "GET_COLR_CNF", 2, mipc_ss_get_colr_cnf_tlv_checker_info},
    {MIPC_SS_SEND_CNAP_REQ, 1, "SEND_CNAP_REQ", 0, NULL},
    {MIPC_SS_SEND_CNAP_CNF, 1, "SEND_CNAP_CNF", 2, mipc_ss_send_cnap_cnf_tlv_checker_info},
    {MIPC_SS_SET_COLR_REQ, 1, "SET_COLR_REQ", 1, mipc_ss_set_colr_req_tlv_checker_info},
    {MIPC_SS_SET_COLR_CNF, 1, "SET_COLR_CNF", 1, mipc_ss_set_colr_cnf_tlv_checker_info},
    {MIPC_SS_SETUP_XCAP_USER_AGENT_REQ, 1, "SETUP_XCAP_USER_AGENT_REQ", 1, mipc_ss_setup_xcap_user_agent_req_tlv_checker_info},
    {MIPC_SS_SETUP_XCAP_USER_AGENT_CNF, 1, "SETUP_XCAP_USER_AGENT_CNF", 0, NULL},
    {MIPC_SS_SET_XCAP_CFG_REQ, 1, "SET_XCAP_CFG_REQ", 2, mipc_ss_set_xcap_cfg_req_tlv_checker_info},
    {MIPC_SS_SET_XCAP_CFG_CNF, 1, "SET_XCAP_CFG_CNF", 0, NULL},
    {MIPC_STK_SET_PAC_REQ, 1, "SET_PAC_REQ", 1, mipc_stk_set_pac_req_tlv_checker_info},
    {MIPC_STK_SET_PAC_CNF, 1, "SET_PAC_CNF", 1, mipc_stk_set_pac_cnf_tlv_checker_info},
    {MIPC_STK_GET_PAC_REQ, 1, "GET_PAC_REQ", 0, NULL},
    {MIPC_STK_GET_PAC_CNF, 1, "GET_PAC_CNF", 1, mipc_stk_get_pac_cnf_tlv_checker_info},
    {MIPC_STK_SEND_TERMINAL_RESPONSE_REQ, 1, "SEND_TERMINAL_RESPONSE_REQ", 2, mipc_stk_send_terminal_response_req_tlv_checker_info},
    {MIPC_STK_SEND_TERMINAL_RESPONSE_CNF, 1, "SEND_TERMINAL_RESPONSE_CNF", 3, mipc_stk_send_terminal_response_cnf_tlv_checker_info},
    {MIPC_STK_SEND_ENVELOPE_REQ, 1, "SEND_ENVELOPE_REQ", 2, mipc_stk_send_envelope_req_tlv_checker_info},
    {MIPC_STK_SEND_ENVELOPE_CNF, 1, "SEND_ENVELOPE_CNF", 2, mipc_stk_send_envelope_cnf_tlv_checker_info},
    {MIPC_STK_GET_ENVELOPE_INFO_REQ, 1, "GET_ENVELOPE_INFO_REQ", 0, NULL},
    {MIPC_STK_GET_ENVELOPE_INFO_CNF, 1, "GET_ENVELOPE_INFO_CNF", 1, mipc_stk_get_envelope_info_cnf_tlv_checker_info},
    {MIPC_STK_HANDLE_CALL_SETUP_FROM_SIM_REQ, 1, "HANDLE_CALL_SETUP_FROM_SIM_REQ", 1, mipc_stk_handle_call_setup_from_sim_req_tlv_checker_info},
    {MIPC_STK_HANDLE_CALL_SETUP_FROM_SIM_CNF, 1, "HANDLE_CALL_SETUP_FROM_SIM_CNF", 0, NULL},
    {MIPC_STK_SEND_BIPCONF_REQ, 1, "SEND_BIPCONF_REQ", 2, mipc_stk_send_bipconf_req_tlv_checker_info},
    {MIPC_STK_SEND_BIPCONF_CNF, 1, "SEND_BIPCONF_CNF", 0, NULL},
    {MIPC_CALL_DIAL_REQ, 1, "DIAL_REQ", 9, mipc_call_dial_req_tlv_checker_info},
    {MIPC_CALL_DIAL_CNF, 1, "DIAL_CNF", 0, NULL},
    {MIPC_CALL_SS_REQ, 1, "SS_REQ", 4, mipc_call_ss_req_tlv_checker_info},
    {MIPC_CALL_SS_CNF, 1, "SS_CNF", 0, NULL},
    {MIPC_CALL_HANGUP_REQ, 1, "HANGUP_REQ", 3, mipc_call_hangup_req_tlv_checker_info},
    {MIPC_CALL_HANGUP_CNF, 1, "HANGUP_CNF", 0, NULL},
    {MIPC_CALL_ANSWER_REQ, 1, "ANSWER_REQ", 2, mipc_call_answer_req_tlv_checker_info},
    {MIPC_CALL_ANSWER_CNF, 1, "ANSWER_CNF", 0, NULL},
    {MIPC_CALL_GET_CALL_STATUS_REQ, 1, "GET_CALL_STATUS_REQ", 1, mipc_call_get_call_status_req_tlv_checker_info},
    {MIPC_CALL_GET_CALL_STATUS_CNF, 1, "GET_CALL_STATUS_CNF", 12, mipc_call_get_call_status_cnf_tlv_checker_info},
    {MIPC_CALL_CONFERENCE_REQ, 1, "CONFERENCE_REQ", 4, mipc_call_conference_req_tlv_checker_info},
    {MIPC_CALL_CONFERENCE_CNF, 1, "CONFERENCE_CNF", 1, mipc_call_conference_cnf_tlv_checker_info},
    {MIPC_CALL_GET_CONFERENCE_INFO_REQ, 1, "GET_CONFERENCE_INFO_REQ", 1, mipc_call_get_conference_info_req_tlv_checker_info},
    {MIPC_CALL_GET_CONFERENCE_INFO_CNF, 1, "GET_CONFERENCE_INFO_CNF", 7, mipc_call_get_conference_info_cnf_tlv_checker_info},
    {MIPC_CALL_GET_FINISH_REASON_REQ, 1, "GET_FINISH_REASON_REQ", 0, NULL},
    {MIPC_CALL_GET_FINISH_REASON_CNF, 1, "GET_FINISH_REASON_CNF", 2, mipc_call_get_finish_reason_cnf_tlv_checker_info},
    {MIPC_CALL_DTMF_REQ, 1, "DTMF_REQ", 2, mipc_call_dtmf_req_tlv_checker_info},
    {MIPC_CALL_DTMF_CNF, 1, "DTMF_CNF", 0, NULL},
    {MIPC_CALL_GET_ECC_LIST_REQ, 1, "GET_ECC_LIST_REQ", 0, NULL},
    {MIPC_CALL_GET_ECC_LIST_CNF, 1, "GET_ECC_LIST_CNF", 3, mipc_call_get_ecc_list_cnf_tlv_checker_info},
    {MIPC_CALL_SET_ECC_LIST_REQ, 1, "SET_ECC_LIST_REQ", 3, mipc_call_set_ecc_list_req_tlv_checker_info},
    {MIPC_CALL_SET_ECC_LIST_CNF, 1, "SET_ECC_LIST_CNF", 0, NULL},
    {MIPC_CALL_SET_FLIGHT_MODE_ECC_SESSION_REQ, 1, "SET_FLIGHT_MODE_ECC_SESSION_REQ", 1, mipc_call_set_flight_mode_ecc_session_req_tlv_checker_info},
    {MIPC_CALL_SET_FLIGHT_MODE_ECC_SESSION_CNF, 1, "SET_FLIGHT_MODE_ECC_SESSION_CNF", 0, NULL},
    {MIPC_CALL_SET_EXIT_ECBM_MODE_REQ, 1, "SET_EXIT_ECBM_MODE_REQ", 0, NULL},
    {MIPC_CALL_SET_EXIT_ECBM_MODE_CNF, 1, "SET_EXIT_ECBM_MODE_CNF", 0, NULL},
    {MIPC_CALL_IVS_ONEKEY_ECALL_REQ, 1, "IVS_ONEKEY_ECALL_REQ", 3, mipc_call_ivs_onekey_ecall_req_tlv_checker_info},
    {MIPC_CALL_IVS_ONEKEY_ECALL_CNF, 1, "IVS_ONEKEY_ECALL_CNF", 0, NULL},
    {MIPC_CALL_SET_SIP_HEADER_REQ, 1, "SET_SIP_HEADER_REQ", 4, mipc_call_set_sip_header_req_tlv_checker_info},
    {MIPC_CALL_SET_SIP_HEADER_CNF, 1, "SET_SIP_HEADER_CNF", 0, NULL},
    {MIPC_CALL_ENABLE_IMS_SIP_HEADER_REPORT_REQ, 1, "ENABLE_IMS_SIP_HEADER_REPORT_REQ", 2, mipc_call_enable_ims_sip_header_report_req_tlv_checker_info},
    {MIPC_CALL_ENABLE_IMS_SIP_HEADER_REPORT_CNF, 1, "ENABLE_IMS_SIP_HEADER_REPORT_CNF", 0, NULL},
    {MIPC_CALL_SET_CALL_ADDITIONAL_INFO_REQ, 1, "SET_CALL_ADDITIONAL_INFO_REQ", 6, mipc_call_set_call_additional_info_req_tlv_checker_info},
    {MIPC_CALL_SET_CALL_ADDITIONAL_INFO_CNF, 1, "SET_CALL_ADDITIONAL_INFO_CNF", 0, NULL},
    {MIPC_CALL_PEER_RTT_MODIFY_REQ, 1, "PEER_RTT_MODIFY_REQ", 2, mipc_call_peer_rtt_modify_req_tlv_checker_info},
    {MIPC_CALL_PEER_RTT_MODIFY_CNF, 1, "PEER_RTT_MODIFY_CNF", 0, NULL},
    {MIPC_CALL_LOCAL_RTT_MODIFY_REQ, 1, "LOCAL_RTT_MODIFY_REQ", 2, mipc_call_local_rtt_modify_req_tlv_checker_info},
    {MIPC_CALL_LOCAL_RTT_MODIFY_CNF, 1, "LOCAL_RTT_MODIFY_CNF", 2, mipc_call_local_rtt_modify_cnf_tlv_checker_info},
    {MIPC_CALL_RTT_TEXT_REQ, 1, "RTT_TEXT_REQ", 3, mipc_call_rtt_text_req_tlv_checker_info},
    {MIPC_CALL_RTT_TEXT_CNF, 1, "RTT_TEXT_CNF", 0, NULL},
    {MIPC_CALL_RTT_MODE_REQ, 1, "RTT_MODE_REQ", 1, mipc_call_rtt_mode_req_tlv_checker_info},
    {MIPC_CALL_RTT_MODE_CNF, 1, "RTT_MODE_CNF", 0, NULL},
    {MIPC_CALL_RTT_AUDIO_REQ, 1, "RTT_AUDIO_REQ", 2, mipc_call_rtt_audio_req_tlv_checker_info},
    {MIPC_CALL_RTT_AUDIO_CNF, 1, "RTT_AUDIO_CNF", 0, NULL},
    {MIPC_CALL_SET_RCS_STATE_AND_FEATURE_REQ, 1, "SET_RCS_STATE_AND_FEATURE_REQ", 2, mipc_call_set_rcs_state_and_feature_req_tlv_checker_info},
    {MIPC_CALL_SET_RCS_STATE_AND_FEATURE_CNF, 1, "SET_RCS_STATE_AND_FEATURE_CNF", 0, NULL},
    {MIPC_CALL_UPDATE_RCS_SESSION_INFO_REQ, 1, "UPDATE_RCS_SESSION_INFO_REQ", 1, mipc_call_update_rcs_session_info_req_tlv_checker_info},
    {MIPC_CALL_UPDATE_RCS_SESSION_INFO_CNF, 1, "UPDATE_RCS_SESSION_INFO_CNF", 0, NULL},
    {MIPC_CALL_GET_VOICE_DOMAIN_PREFERENCE_REQ, 1, "GET_VOICE_DOMAIN_PREFERENCE_REQ", 0, NULL},
    {MIPC_CALL_GET_VOICE_DOMAIN_PREFERENCE_CNF, 1, "GET_VOICE_DOMAIN_PREFERENCE_CNF", 1, mipc_call_get_voice_domain_preference_cnf_tlv_checker_info},
    {MIPC_CALL_PULL_REQ, 1, "PULL_REQ", 2, mipc_call_pull_req_tlv_checker_info},
    {MIPC_CALL_PULL_CNF, 1, "PULL_CNF", 0, NULL},
    {MIPC_CALL_GET_TTY_MODE_REQ, 1, "GET_TTY_MODE_REQ", 0, NULL},
    {MIPC_CALL_GET_TTY_MODE_CNF, 1, "GET_TTY_MODE_CNF", 1, mipc_call_get_tty_mode_cnf_tlv_checker_info},
    {MIPC_CALL_SET_IMS_CALL_MODE_REQ, 1, "SET_IMS_CALL_MODE_REQ", 1, mipc_call_set_ims_call_mode_req_tlv_checker_info},
    {MIPC_CALL_SET_IMS_CALL_MODE_CNF, 1, "SET_IMS_CALL_MODE_CNF", 0, NULL},
    {MIPC_CALL_SET_TTY_MODE_REQ, 1, "SET_TTY_MODE_REQ", 1, mipc_call_set_tty_mode_req_tlv_checker_info},
    {MIPC_CALL_SET_TTY_MODE_CNF, 1, "SET_TTY_MODE_CNF", 0, NULL},
    {MIPC_CALL_SET_VOICE_DOMAIN_PREFERENCE_REQ, 1, "SET_VOICE_DOMAIN_PREFERENCE_REQ", 1, mipc_call_set_voice_domain_preference_req_tlv_checker_info},
    {MIPC_CALL_SET_VOICE_DOMAIN_PREFERENCE_CNF, 1, "SET_VOICE_DOMAIN_PREFERENCE_CNF", 0, NULL},
    {MIPC_CALL_CONFERENCE_DIAL_REQ, 1, "CONFERENCE_DIAL_REQ", 5, mipc_call_conference_dial_req_tlv_checker_info},
    {MIPC_CALL_CONFERENCE_DIAL_CNF, 1, "CONFERENCE_DIAL_CNF", 0, NULL},
    {MIPC_CALL_SET_GWSD_MODE_REQ, 1, "SET_GWSD_MODE_REQ", 4, mipc_call_set_gwsd_mode_req_tlv_checker_info},
    {MIPC_CALL_SET_GWSD_MODE_CNF, 1, "SET_GWSD_MODE_CNF", 0, NULL},
    {MIPC_CALL_APPROVE_CSFB_REQ, 1, "APPROVE_CSFB_REQ", 1, mipc_call_approve_csfb_req_tlv_checker_info},
    {MIPC_CALL_APPROVE_CSFB_CNF, 1, "APPROVE_CSFB_CNF", 0, NULL},
    {MIPC_CALL_SET_GWSD_CALL_VALID_REQ, 1, "SET_GWSD_CALL_VALID_REQ", 1, mipc_call_set_gwsd_call_valid_req_tlv_checker_info},
    {MIPC_CALL_SET_GWSD_CALL_VALID_CNF, 1, "SET_GWSD_CALL_VALID_CNF", 0, NULL},
    {MIPC_CALL_SET_GWSD_IGNORE_CALL_INTERVAL_REQ, 1, "SET_GWSD_IGNORE_CALL_INTERVAL_REQ", 1, mipc_call_set_gwsd_ignore_call_interval_req_tlv_checker_info},
    {MIPC_CALL_SET_GWSD_IGNORE_CALL_INTERVAL_CNF, 1, "SET_GWSD_IGNORE_CALL_INTERVAL_CNF", 0, NULL},
    {MIPC_CALL_SET_GWSD_KA_PDCP_REQ, 1, "SET_GWSD_KA_PDCP_REQ", 1, mipc_call_set_gwsd_ka_pdcp_req_tlv_checker_info},
    {MIPC_CALL_SET_GWSD_KA_PDCP_CNF, 1, "SET_GWSD_KA_PDCP_CNF", 0, NULL},
    {MIPC_CALL_SET_GWSD_KA_IPDATA_REQ, 1, "SET_GWSD_KA_IPDATA_REQ", 1, mipc_call_set_gwsd_ka_ipdata_req_tlv_checker_info},
    {MIPC_CALL_SET_GWSD_KA_IPDATA_CNF, 1, "SET_GWSD_KA_IPDATA_CNF", 0, NULL},
    {MIPC_CALL_UIS_INFO_REQ, 1, "UIS_INFO_REQ", 4, mipc_call_uis_info_req_tlv_checker_info},
    {MIPC_CALL_UIS_INFO_CNF, 1, "UIS_INFO_CNF", 0, NULL},
    {MIPC_CALL_AUTO_ANSWER_REQ, 1, "AUTO_ANSWER_REQ", 1, mipc_call_auto_answer_req_tlv_checker_info},
    {MIPC_CALL_AUTO_ANSWER_CNF, 1, "AUTO_ANSWER_CNF", 0, NULL},
    {MIPC_CALL_DATA_PREFER_SET_REQ, 1, "DATA_PREFER_SET_REQ", 2, mipc_call_data_prefer_set_req_tlv_checker_info},
    {MIPC_CALL_DATA_PREFER_SET_CNF, 1, "DATA_PREFER_SET_CNF", 0, NULL},
    {MIPC_CALL_ECC_REDIAL_APPROVE_REQ, 1, "ECC_REDIAL_APPROVE_REQ", 2, mipc_call_ecc_redial_approve_req_tlv_checker_info},
    {MIPC_CALL_ECC_REDIAL_APPROVE_CNF, 1, "ECC_REDIAL_APPROVE_CNF", 0, NULL},
    {MIPC_IMS_SET_CONFIG_REQ, 1, "SET_CONFIG_REQ", 3, mipc_ims_set_config_req_tlv_checker_info},
    {MIPC_IMS_SET_CONFIG_CNF, 1, "SET_CONFIG_CNF", 1, mipc_ims_set_config_cnf_tlv_checker_info},
    {MIPC_IMS_GET_CONFIG_REQ, 1, "GET_CONFIG_REQ", 2, mipc_ims_get_config_req_tlv_checker_info},
    {MIPC_IMS_GET_CONFIG_CNF, 1, "GET_CONFIG_CNF", 1, mipc_ims_get_config_cnf_tlv_checker_info},
    {MIPC_IMS_GET_STATE_REQ, 1, "GET_STATE_REQ", 1, mipc_ims_get_state_req_tlv_checker_info},
    {MIPC_IMS_GET_STATE_CNF, 1, "GET_STATE_CNF", 9, mipc_ims_get_state_cnf_tlv_checker_info},
    {MIPC_IMS_SET_PDIS_REQ, 1, "SET_PDIS_REQ", 3, mipc_ims_set_pdis_req_tlv_checker_info},
    {MIPC_IMS_SET_PDIS_CNF, 1, "SET_PDIS_CNF", 0, NULL},
    {MIPC_IMS_SET_NAPTR_REQ, 1, "SET_NAPTR_REQ", 9, mipc_ims_set_naptr_req_tlv_checker_info},
    {MIPC_IMS_SET_NAPTR_CNF, 1, "SET_NAPTR_CNF", 0, NULL},
    {MIPC_IMS_GET_NW_RPT_REQ, 1, "GET_NW_RPT_REQ", 0, NULL},
    {MIPC_IMS_GET_NW_RPT_CNF, 1, "GET_NW_RPT_CNF", 2, mipc_ims_get_nw_rpt_cnf_tlv_checker_info},
    {MIPC_IMS_SET_TEST_MODE_REQ, 1, "SET_TEST_MODE_REQ", 1, mipc_ims_set_test_mode_req_tlv_checker_info},
    {MIPC_IMS_SET_TEST_MODE_CNF, 1, "SET_TEST_MODE_CNF", 0, NULL},
    {MIPC_IMS_SET_EIREG_REQ, 1, "SET_EIREG_REQ", 9, mipc_ims_set_eireg_req_tlv_checker_info},
    {MIPC_IMS_SET_EIREG_CNF, 1, "SET_EIREG_CNF", 0, NULL},
    {MIPC_IMS_SET_SCM_REQ, 1, "SET_SCM_REQ", 2, mipc_ims_set_scm_req_tlv_checker_info},
    {MIPC_IMS_SET_SCM_CNF, 1, "SET_SCM_CNF", 0, NULL},
    {MIPC_IMS_SET_SERVICE_SESSION_REQ, 1, "SET_SERVICE_SESSION_REQ", 2, mipc_ims_set_service_session_req_tlv_checker_info},
    {MIPC_IMS_SET_SERVICE_SESSION_CNF, 1, "SET_SERVICE_SESSION_CNF", 0, NULL},
    {MIPC_IMS_SET_UAC_REQ, 1, "SET_UAC_REQ", 2, mipc_ims_set_uac_req_tlv_checker_info},
    {MIPC_IMS_SET_UAC_CNF, 1, "SET_UAC_CNF", 0, NULL},
    {MIPC_IMS_SET_EVODATA_REQ, 1, "SET_EVODATA_REQ", 4, mipc_ims_set_evodata_req_tlv_checker_info},
    {MIPC_IMS_SET_EVODATA_CNF, 1, "SET_EVODATA_CNF", 0, NULL},
    {MIPC_IMS_CFG_ADDITION_SERVICE_REQ, 1, "CFG_ADDITION_SERVICE_REQ", 1, mipc_ims_cfg_addition_service_req_tlv_checker_info},
    {MIPC_IMS_CFG_ADDITION_SERVICE_CNF, 1, "CFG_ADDITION_SERVICE_CNF", 0, NULL},
    {MIPC_WFC_REGISTER_CELL_SIGNAL_IND_REQ, 1, "REGISTER_CELL_SIGNAL_IND_REQ", 6, mipc_wfc_register_cell_signal_ind_req_tlv_checker_info},
    {MIPC_WFC_REGISTER_CELL_SIGNAL_IND_CNF, 1, "REGISTER_CELL_SIGNAL_IND_CNF", 0, NULL},
    {MIPC_WFC_CSSAC_REQ, 1, "CSSAC_REQ", 0, NULL},
    {MIPC_WFC_CSSAC_CNF, 1, "CSSAC_CNF", 4, mipc_wfc_cssac_cnf_tlv_checker_info},
    {MIPC_WFC_SET_EMC_AID_REQ, 1, "SET_EMC_AID_REQ", 1, mipc_wfc_set_emc_aid_req_tlv_checker_info},
    {MIPC_WFC_SET_EMC_AID_CNF, 1, "SET_EMC_AID_CNF", 0, NULL},
    {MIPC_WFC_CFG_REQ, 1, "CFG_REQ", 2, mipc_wfc_cfg_req_tlv_checker_info},
    {MIPC_WFC_CFG_CNF, 1, "CFG_CNF", 0, NULL},
    {MIPC_PHB_SET_UPB_ENTRY_REQ, 1, "SET_UPB_ENTRY_REQ", 10, mipc_phb_set_upb_entry_req_tlv_checker_info},
    {MIPC_PHB_SET_UPB_ENTRY_CNF, 1, "SET_UPB_ENTRY_CNF", 0, NULL},
    {MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_REQ, 1, "GET_UPB_ANR_EMAIL_SNE_ENTRY_REQ", 3, mipc_phb_get_upb_anr_email_sne_entry_req_tlv_checker_info},
    {MIPC_PHB_GET_UPB_ANR_EMAIL_SNE_ENTRY_CNF, 1, "GET_UPB_ANR_EMAIL_SNE_ENTRY_CNF", 3, mipc_phb_get_upb_anr_email_sne_entry_cnf_tlv_checker_info},
    {MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_REQ, 1, "GET_UPB_AAS_GAS_GRP_LIST_ENTRY_REQ", 3, mipc_phb_get_upb_aas_gas_grp_list_entry_req_tlv_checker_info},
    {MIPC_PHB_GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF, 1, "GET_UPB_AAS_GAS_GRP_LIST_ENTRY_CNF", 8, mipc_phb_get_upb_aas_gas_grp_list_entry_cnf_tlv_checker_info},
    {MIPC_PHB_GET_PHB_STORAGE_INFO_REQ, 1, "GET_PHB_STORAGE_INFO_REQ", 1, mipc_phb_get_phb_storage_info_req_tlv_checker_info},
    {MIPC_PHB_GET_PHB_STORAGE_INFO_CNF, 1, "GET_PHB_STORAGE_INFO_CNF", 5, mipc_phb_get_phb_storage_info_cnf_tlv_checker_info},
    {MIPC_PHB_SET_PHB_MEM_STORAGE_REQ, 1, "SET_PHB_MEM_STORAGE_REQ", 2, mipc_phb_set_phb_mem_storage_req_tlv_checker_info},
    {MIPC_PHB_SET_PHB_MEM_STORAGE_CNF, 1, "SET_PHB_MEM_STORAGE_CNF", 0, NULL},
    {MIPC_PHB_GET_PHB_ENTRY_REQ, 1, "GET_PHB_ENTRY_REQ", 4, mipc_phb_get_phb_entry_req_tlv_checker_info},
    {MIPC_PHB_GET_PHB_ENTRY_CNF, 1, "GET_PHB_ENTRY_CNF", 3, mipc_phb_get_phb_entry_cnf_tlv_checker_info},
    {MIPC_PHB_SET_PHB_ENTRY_REQ, 1, "SET_PHB_ENTRY_REQ", 3, mipc_phb_set_phb_entry_req_tlv_checker_info},
    {MIPC_PHB_SET_PHB_ENTRY_CNF, 1, "SET_PHB_ENTRY_CNF", 0, NULL},
    {MIPC_PHB_GET_PHB_STRINGSLENGTH_REQ, 1, "GET_PHB_STRINGSLENGTH_REQ", 0, NULL},
    {MIPC_PHB_GET_PHB_STRINGSLENGTH_CNF, 1, "GET_PHB_STRINGSLENGTH_CNF", 6, mipc_phb_get_phb_stringslength_cnf_tlv_checker_info},
    {MIPC_PHB_GET_UPB_CAPABILITY_REQ, 1, "GET_UPB_CAPABILITY_REQ", 0, NULL},
    {MIPC_PHB_GET_UPB_CAPABILITY_CNF, 1, "GET_UPB_CAPABILITY_CNF", 8, mipc_phb_get_upb_capability_cnf_tlv_checker_info},
    {MIPC_PHB_GET_PHB_AVAILABLE_REQ, 1, "GET_PHB_AVAILABLE_REQ", 2, mipc_phb_get_phb_available_req_tlv_checker_info},
    {MIPC_PHB_GET_PHB_AVAILABLE_CNF, 1, "GET_PHB_AVAILABLE_CNF", 3, mipc_phb_get_phb_available_cnf_tlv_checker_info},
    {MIPC_EMBMS_EMSLU_REQ, 1, "EMSLU_REQ", 0, NULL},
    {MIPC_EMBMS_EMSLU_CNF, 1, "EMSLU_CNF", 4, mipc_embms_emslu_cnf_tlv_checker_info},
    {MIPC_EMBMS_GET_SAI_LIST_REQ, 1, "GET_SAI_LIST_REQ", 0, NULL},
    {MIPC_EMBMS_GET_SAI_LIST_CNF, 1, "GET_SAI_LIST_CNF", 5, mipc_embms_get_sai_list_cnf_tlv_checker_info},
    {MIPC_EMBMS_NOTIFY_HVOLTE_STATUS_REQ, 1, "NOTIFY_HVOLTE_STATUS_REQ", 1, mipc_embms_notify_hvolte_status_req_tlv_checker_info},
    {MIPC_EMBMS_NOTIFY_HVOLTE_STATUS_CNF, 1, "NOTIFY_HVOLTE_STATUS_CNF", 0, NULL},
    {MIPC_EMBMS_SET_SERVICE_ENABLE_REQ, 1, "SET_SERVICE_ENABLE_REQ", 2, mipc_embms_set_service_enable_req_tlv_checker_info},
    {MIPC_EMBMS_SET_SERVICE_ENABLE_CNF, 1, "SET_SERVICE_ENABLE_CNF", 0, NULL},
    {MIPC_EMBMS_GET_SERVICE_ENABLE_REQ, 1, "GET_SERVICE_ENABLE_REQ", 0, NULL},
    {MIPC_EMBMS_GET_SERVICE_ENABLE_CNF, 1, "GET_SERVICE_ENABLE_CNF", 2, mipc_embms_get_service_enable_cnf_tlv_checker_info},
    {MIPC_EMBMS_SET_BROADCAST_CONFIG_REQ, 1, "SET_BROADCAST_CONFIG_REQ", 3, mipc_embms_set_broadcast_config_req_tlv_checker_info},
    {MIPC_EMBMS_SET_BROADCAST_CONFIG_CNF, 1, "SET_BROADCAST_CONFIG_CNF", 0, NULL},
    {MIPC_EMBMS_UPDATE_MBS_SESSION_REQ, 1, "UPDATE_MBS_SESSION_REQ", 6, mipc_embms_update_mbs_session_req_tlv_checker_info},
    {MIPC_EMBMS_UPDATE_MBS_SESSION_CNF, 1, "UPDATE_MBS_SESSION_CNF", 0, NULL},
    {MIPC_EMBMS_QUERY_MBS_MULTICAST_REMAIN_TIME_REQ, 1, "QUERY_MBS_MULTICAST_REMAIN_TIME_REQ", 1, mipc_embms_query_mbs_multicast_remain_time_req_tlv_checker_info},
    {MIPC_EMBMS_QUERY_MBS_MULTICAST_REMAIN_TIME_CNF, 1, "QUERY_MBS_MULTICAST_REMAIN_TIME_CNF", 1, mipc_embms_query_mbs_multicast_remain_time_cnf_tlv_checker_info},
    {MIPC_ECALL_IVS_UPDATE_MSD_REQ, 1, "IVS_UPDATE_MSD_REQ", 2, mipc_ecall_ivs_update_msd_req_tlv_checker_info},
    {MIPC_ECALL_IVS_UPDATE_MSD_CNF, 1, "IVS_UPDATE_MSD_CNF", 0, NULL},
    {MIPC_ECALL_IVS_RESET_REQ, 1, "IVS_RESET_REQ", 0, NULL},
    {MIPC_ECALL_IVS_RESET_CNF, 1, "IVS_RESET_CNF", 0, NULL},
    {MIPC_ECALL_IVS_SET_TEST_ADDR_REQ, 1, "IVS_SET_TEST_ADDR_REQ", 2, mipc_ecall_ivs_set_test_addr_req_tlv_checker_info},
    {MIPC_ECALL_IVS_SET_TEST_ADDR_CNF, 1, "IVS_SET_TEST_ADDR_CNF", 0, NULL},
    {MIPC_ECALL_IVS_SET_RECONF_ADDR_REQ, 1, "IVS_SET_RECONF_ADDR_REQ", 2, mipc_ecall_ivs_set_reconf_addr_req_tlv_checker_info},
    {MIPC_ECALL_IVS_SET_RECONF_ADDR_CNF, 1, "IVS_SET_RECONF_ADDR_CNF", 0, NULL},
    {MIPC_ECALL_IVS_SET_ADDR_PRI_REQ, 1, "IVS_SET_ADDR_PRI_REQ", 4, mipc_ecall_ivs_set_addr_pri_req_tlv_checker_info},
    {MIPC_ECALL_IVS_SET_ADDR_PRI_CNF, 1, "IVS_SET_ADDR_PRI_CNF", 0, NULL},
    {MIPC_ECALL_IVS_GET_SIM_INFO_REQ, 1, "IVS_GET_SIM_INFO_REQ", 0, NULL},
    {MIPC_ECALL_IVS_GET_SIM_INFO_CNF, 1, "IVS_GET_SIM_INFO_CNF", 5, mipc_ecall_ivs_get_sim_info_cnf_tlv_checker_info},
    {MIPC_NW_GET_CURRENT_CELL_INFO_REQ, 1, "GET_CURRENT_CELL_INFO_REQ", 0, NULL},
    {MIPC_NW_GET_CURRENT_CELL_INFO_CNF, 1, "GET_CURRENT_CELL_INFO_CNF", 4, mipc_nw_get_current_cell_info_cnf_tlv_checker_info},
    {MIPC_NW_SET_CAG_SELECTION_REQ, 1, "SET_CAG_SELECTION_REQ", 4, mipc_nw_set_cag_selection_req_tlv_checker_info},
    {MIPC_NW_SET_CAG_SELECTION_CNF, 1, "SET_CAG_SELECTION_CNF", 1, mipc_nw_set_cag_selection_cnf_tlv_checker_info},
    {MIPC_NW_GET_CAG_SELECTION_REQ, 1, "GET_CAG_SELECTION_REQ", 0, NULL},
    {MIPC_NW_GET_CAG_SELECTION_CNF, 1, "GET_CAG_SELECTION_CNF", 4, mipc_nw_get_cag_selection_cnf_tlv_checker_info},
    {MIPC_NW_SET_AUTO_UPDATE_NITZ_REQ, 1, "SET_AUTO_UPDATE_NITZ_REQ", 1, mipc_nw_set_auto_update_nitz_req_tlv_checker_info},
    {MIPC_NW_SET_AUTO_UPDATE_NITZ_CNF, 1, "SET_AUTO_UPDATE_NITZ_CNF", 0, NULL},
    {MIPC_NW_GET_AUTO_UPDATE_NITZ_REQ, 1, "GET_AUTO_UPDATE_NITZ_REQ", 0, NULL},
    {MIPC_NW_GET_AUTO_UPDATE_NITZ_CNF, 1, "GET_AUTO_UPDATE_NITZ_CNF", 1, mipc_nw_get_auto_update_nitz_cnf_tlv_checker_info},
    {MIPC_NW_SET_NAS_CONNECTION_RELEASE_REQ, 1, "SET_NAS_CONNECTION_RELEASE_REQ", 0, NULL},
    {MIPC_NW_SET_NAS_CONNECTION_RELEASE_CNF, 1, "SET_NAS_CONNECTION_RELEASE_CNF", 0, NULL},
    {MIPC_NW_SET_CAP_NRCA_OPTION_REQ, 1, "SET_CAP_NRCA_OPTION_REQ", 8, mipc_nw_set_cap_nrca_option_req_tlv_checker_info},
    {MIPC_NW_SET_CAP_NRCA_OPTION_CNF, 1, "SET_CAP_NRCA_OPTION_CNF", 0, NULL},
    {MIPC_NW_SET_CAP_BC_LIST_REQ, 1, "SET_CAP_BC_LIST_REQ", 17, mipc_nw_set_cap_bc_list_req_tlv_checker_info},
    {MIPC_NW_SET_CAP_BC_LIST_CNF, 1, "SET_CAP_BC_LIST_CNF", 0, NULL},
    {MIPC_NW_CONGESTION_CFG_REQ, 1, "CONGESTION_CFG_REQ", 2, mipc_nw_congestion_cfg_req_tlv_checker_info},
    {MIPC_NW_CONGESTION_CFG_CNF, 1, "CONGESTION_CFG_CNF", 0, NULL},
    {MIPC_NW_GET_ENWCFGINFO_REQ, 1, "GET_ENWCFGINFO_REQ", 0, NULL},
    {MIPC_NW_GET_ENWCFGINFO_CNF, 1, "GET_ENWCFGINFO_CNF", 3, mipc_nw_get_enwcfginfo_cnf_tlv_checker_info},
    {MIPC_NW_SET_BARRING_RLF_CONFIG_REQ, 1, "SET_BARRING_RLF_CONFIG_REQ", 3, mipc_nw_set_barring_rlf_config_req_tlv_checker_info},
    {MIPC_NW_SET_BARRING_RLF_CONFIG_CNF, 1, "SET_BARRING_RLF_CONFIG_CNF", 0, NULL},
    {MIPC_NW_SET_ENDC_DEACT_REQ, 1, "SET_ENDC_DEACT_REQ", 3, mipc_nw_set_endc_deact_req_tlv_checker_info},
    {MIPC_NW_SET_ENDC_DEACT_CNF, 1, "SET_ENDC_DEACT_CNF", 0, NULL},
    {MIPC_NW_GET_ENDC_DEACT_REQ, 1, "GET_ENDC_DEACT_REQ", 0, NULL},
    {MIPC_NW_GET_ENDC_DEACT_CNF, 1, "GET_ENDC_DEACT_CNF", 3, mipc_nw_get_endc_deact_cnf_tlv_checker_info},
    {MIPC_NW_SET_SA_SILENCE_REQ, 1, "SET_SA_SILENCE_REQ", 1, mipc_nw_set_sa_silence_req_tlv_checker_info},
    {MIPC_NW_SET_SA_SILENCE_CNF, 1, "SET_SA_SILENCE_CNF", 0, NULL},
    {MIPC_NW_GET_SA_SILENCE_REQ, 1, "GET_SA_SILENCE_REQ", 0, NULL},
    {MIPC_NW_GET_SA_SILENCE_CNF, 1, "GET_SA_SILENCE_CNF", 2, mipc_nw_get_sa_silence_cnf_tlv_checker_info},
    {MIPC_NW_SET_TX_POWER_REDUCTION_REQ, 1, "SET_TX_POWER_REDUCTION_REQ", 3, mipc_nw_set_tx_power_reduction_req_tlv_checker_info},
    {MIPC_NW_SET_TX_POWER_REDUCTION_CNF, 1, "SET_TX_POWER_REDUCTION_CNF", 0, NULL},
    {MIPC_NW_GET_TX_POWER_REDUCTION_REQ, 1, "GET_TX_POWER_REDUCTION_REQ", 0, NULL},
    {MIPC_NW_GET_TX_POWER_REDUCTION_CNF, 1, "GET_TX_POWER_REDUCTION_CNF", 3, mipc_nw_get_tx_power_reduction_cnf_tlv_checker_info},
    {MIPC_NW_SET_LTE_OVERHEATING_REQ, 1, "SET_LTE_OVERHEATING_REQ", 5, mipc_nw_set_lte_overheating_req_tlv_checker_info},
    {MIPC_NW_SET_LTE_OVERHEATING_CNF, 1, "SET_LTE_OVERHEATING_CNF", 1, mipc_nw_set_lte_overheating_cnf_tlv_checker_info},
    {MIPC_NW_GET_LTE_OVERHEATING_REQ, 1, "GET_LTE_OVERHEATING_REQ", 0, NULL},
    {MIPC_NW_GET_LTE_OVERHEATING_CNF, 1, "GET_LTE_OVERHEATING_CNF", 6, mipc_nw_get_lte_overheating_cnf_tlv_checker_info},
    {MIPC_NW_SET_NR_OVERHEATING_REQ, 1, "SET_NR_OVERHEATING_REQ", 11, mipc_nw_set_nr_overheating_req_tlv_checker_info},
    {MIPC_NW_SET_NR_OVERHEATING_CNF, 1, "SET_NR_OVERHEATING_CNF", 1, mipc_nw_set_nr_overheating_cnf_tlv_checker_info},
    {MIPC_NW_GET_NR_OVERHEATING_REQ, 1, "GET_NR_OVERHEATING_REQ", 0, NULL},
    {MIPC_NW_GET_NR_OVERHEATING_CNF, 1, "GET_NR_OVERHEATING_CNF", 12, mipc_nw_get_nr_overheating_cnf_tlv_checker_info},
    {MIPC_NW_SET_UAI_POWER_SAVING_REQ, 1, "SET_UAI_POWER_SAVING_REQ", 11, mipc_nw_set_uai_power_saving_req_tlv_checker_info},
    {MIPC_NW_SET_UAI_POWER_SAVING_CNF, 1, "SET_UAI_POWER_SAVING_CNF", 1, mipc_nw_set_uai_power_saving_cnf_tlv_checker_info},
    {MIPC_NW_GET_UAI_POWER_SAVING_REQ, 1, "GET_UAI_POWER_SAVING_REQ", 0, NULL},
    {MIPC_NW_GET_UAI_POWER_SAVING_CNF, 1, "GET_UAI_POWER_SAVING_CNF", 10, mipc_nw_get_uai_power_saving_cnf_tlv_checker_info},
    {MIPC_NW_SET_RRC_RELEASE_PREFERENCE_REQ, 1, "SET_RRC_RELEASE_PREFERENCE_REQ", 1, mipc_nw_set_rrc_release_preference_req_tlv_checker_info},
    {MIPC_NW_SET_RRC_RELEASE_PREFERENCE_CNF, 1, "SET_RRC_RELEASE_PREFERENCE_CNF", 1, mipc_nw_set_rrc_release_preference_cnf_tlv_checker_info},
    {MIPC_NW_GET_RRC_RELEASE_PREFERENCE_REQ, 1, "GET_RRC_RELEASE_PREFERENCE_REQ", 0, NULL},
    {MIPC_NW_GET_RRC_RELEASE_PREFERENCE_CNF, 1, "GET_RRC_RELEASE_PREFERENCE_CNF", 1, mipc_nw_get_rrc_release_preference_cnf_tlv_checker_info},
    {MIPC_NW_SET_FAKE_RI_REQ, 1, "SET_FAKE_RI_REQ", 4, mipc_nw_set_fake_ri_req_tlv_checker_info},
    {MIPC_NW_SET_FAKE_RI_CNF, 1, "SET_FAKE_RI_CNF", 0, NULL},
    {MIPC_NW_GET_FAKE_RI_REQ, 1, "GET_FAKE_RI_REQ", 0, NULL},
    {MIPC_NW_GET_FAKE_RI_CNF, 1, "GET_FAKE_RI_CNF", 4, mipc_nw_get_fake_ri_cnf_tlv_checker_info},
    {MIPC_NW_SET_MR_THRESH_BOUND_REQ, 1, "SET_MR_THRESH_BOUND_REQ", 1, mipc_nw_set_mr_thresh_bound_req_tlv_checker_info},
    {MIPC_NW_SET_MR_THRESH_BOUND_CNF, 1, "SET_MR_THRESH_BOUND_CNF", 0, NULL},
    {MIPC_NW_SET_DYNAMIC_ANT_BIAS_REQ, 1, "SET_DYNAMIC_ANT_BIAS_REQ", 3, mipc_nw_set_dynamic_ant_bias_req_tlv_checker_info},
    {MIPC_NW_SET_DYNAMIC_ANT_BIAS_CNF, 1, "SET_DYNAMIC_ANT_BIAS_CNF", 0, NULL},
    {MIPC_NW_GET_CSCON_STATE_REQ, 1, "GET_CSCON_STATE_REQ", 0, NULL},
    {MIPC_NW_GET_CSCON_STATE_CNF, 1, "GET_CSCON_STATE_CNF", 1, mipc_nw_get_cscon_state_cnf_tlv_checker_info},
    {MIPC_NW_LOCAL_REL_WITH_REDIR_TO_LTE_REQ, 1, "LOCAL_REL_WITH_REDIR_TO_LTE_REQ", 0, NULL},
    {MIPC_NW_LOCAL_REL_WITH_REDIR_TO_LTE_CNF, 1, "LOCAL_REL_WITH_REDIR_TO_LTE_CNF", 0, NULL},
    {MIPC_NW_SET_BAND_PRIORITY_REQ, 1, "SET_BAND_PRIORITY_REQ", 5, mipc_nw_set_band_priority_req_tlv_checker_info},
    {MIPC_NW_SET_BAND_PRIORITY_CNF, 1, "SET_BAND_PRIORITY_CNF", 0, NULL},
    {MIPC_NW_GET_BAND_PRIORITY_REQ, 1, "GET_BAND_PRIORITY_REQ", 2, mipc_nw_get_band_priority_req_tlv_checker_info},
    {MIPC_NW_GET_BAND_PRIORITY_CNF, 1, "GET_BAND_PRIORITY_CNF", 4, mipc_nw_get_band_priority_cnf_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_SESSION_STATUS_REQ, 1, "UPDATE_SESSION_STATUS_REQ", 4, mipc_exims_update_session_status_req_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_SESSION_STATUS_CNF, 1, "UPDATE_SESSION_STATUS_CNF", 0, NULL},
    {MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_REQ, 1, "GET_CALL_DOMAIN_SELECT_REQ", 4, mipc_exims_get_call_domain_select_req_tlv_checker_info},
    {MIPC_EXIMS_GET_CALL_DOMAIN_SELECT_CNF, 1, "GET_CALL_DOMAIN_SELECT_CNF", 2, mipc_exims_get_call_domain_select_cnf_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_REQ, 1, "UPDATE_CALL_STATUS_EVENT_REQ", 9, mipc_exims_update_call_status_event_req_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_CALL_STATUS_EVENT_CNF, 1, "UPDATE_CALL_STATUS_EVENT_CNF", 0, NULL},
    {MIPC_EXIMS_UPDATE_IMS_HO_STATUS_EVENT_REQ, 1, "UPDATE_IMS_HO_STATUS_EVENT_REQ", 4, mipc_exims_update_ims_ho_status_event_req_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_IMS_HO_STATUS_EVENT_CNF, 1, "UPDATE_IMS_HO_STATUS_EVENT_CNF", 0, NULL},
    {MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_REQ, 1, "GET_SMS_DOMAIN_SELECT_REQ", 3, mipc_exims_get_sms_domain_select_req_tlv_checker_info},
    {MIPC_EXIMS_GET_SMS_DOMAIN_SELECT_CNF, 1, "GET_SMS_DOMAIN_SELECT_CNF", 2, mipc_exims_get_sms_domain_select_cnf_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_REQ, 1, "UPDATE_SMS_STATUS_EVENT_REQ", 5, mipc_exims_update_sms_status_event_req_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_SMS_STATUS_EVENT_CNF, 1, "UPDATE_SMS_STATUS_EVENT_CNF", 0, NULL},
    {MIPC_EXIMS_UPDATE_REG_STATUS_REQ, 1, "UPDATE_REG_STATUS_REQ", 7, mipc_exims_update_reg_status_req_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_REG_STATUS_CNF, 1, "UPDATE_REG_STATUS_CNF", 0, NULL},
    {MIPC_EXIMS_UPDATE_CONFIG_REQ, 1, "UPDATE_CONFIG_REQ", 6, mipc_exims_update_config_req_tlv_checker_info},
    {MIPC_EXIMS_UPDATE_CONFIG_CNF, 1, "UPDATE_CONFIG_CNF", 0, NULL},
    {MIPC_EXIMS_GET_ECC_LIST_REQ, 1, "GET_ECC_LIST_REQ", 0, NULL},
    {MIPC_EXIMS_GET_ECC_LIST_CNF, 1, "GET_ECC_LIST_CNF", 1, mipc_exims_get_ecc_list_cnf_tlv_checker_info},
    {MIPC_SYS_SET_HAC_FLAG_REQ, 1, "SET_HAC_FLAG_REQ", 1, mipc_sys_set_hac_flag_req_tlv_checker_info},
    {MIPC_SYS_SET_HAC_FLAG_CNF, 1, "SET_HAC_FLAG_CNF", 0, NULL},
    {MIPC_SYS_AT_IND, 1, "AT_IND", 1, mipc_sys_at_ind_tlv_checker_info},
    {MIPC_SYS_THERMAL_SENSOR_IND, 1, "THERMAL_SENSOR_IND", 6, mipc_sys_thermal_sensor_ind_tlv_checker_info},
    {MIPC_SYS_CONFIG_IND, 1, "CONFIG_IND", 2, mipc_sys_config_ind_tlv_checker_info},
    {MIPC_SYS_ADPCLK_IND, 1, "ADPCLK_IND", 3, mipc_sys_adpclk_ind_tlv_checker_info},
    {MIPC_SYS_MCF_IND, 1, "MCF_IND", 2, mipc_sys_mcf_ind_tlv_checker_info},
    {MIPC_SYS_SBP_IND, 1, "SBP_IND", 2, mipc_sys_sbp_ind_tlv_checker_info},
    {MIPC_SYS_EL2_IP_UL_IND, 1, "EL2_IP_UL_IND", 1, mipc_sys_el2_ip_ul_ind_tlv_checker_info},
    {MIPC_SYS_EL2_IP_DL_IND, 1, "EL2_IP_DL_IND", 1, mipc_sys_el2_ip_dl_ind_tlv_checker_info},
    {MIPC_SYS_EL2_MAC_UL_IND, 1, "EL2_MAC_UL_IND", 1, mipc_sys_el2_mac_ul_ind_tlv_checker_info},
    {MIPC_SYS_EL2_MAC_DL_IND, 1, "EL2_MAC_DL_IND", 1, mipc_sys_el2_mac_dl_ind_tlv_checker_info},
    {MIPC_SYS_EL2_PDCP_UL_IND, 1, "EL2_PDCP_UL_IND", 1, mipc_sys_el2_pdcp_ul_ind_tlv_checker_info},
    {MIPC_SYS_EL2_PDCP_DL_IND, 1, "EL2_PDCP_DL_IND", 1, mipc_sys_el2_pdcp_dl_ind_tlv_checker_info},
    {MIPC_SYS_NL2_MAC_UL_IND, 1, "NL2_MAC_UL_IND", 1, mipc_sys_nl2_mac_ul_ind_tlv_checker_info},
    {MIPC_SYS_NL2_MAC_DL_IND, 1, "NL2_MAC_DL_IND", 1, mipc_sys_nl2_mac_dl_ind_tlv_checker_info},
    {MIPC_SYS_NL2_PDCP_UL_IND, 1, "NL2_PDCP_UL_IND", 1, mipc_sys_nl2_pdcp_ul_ind_tlv_checker_info},
    {MIPC_SYS_NL2_PDCP_DL_IND, 1, "NL2_PDCP_DL_IND", 1, mipc_sys_nl2_pdcp_dl_ind_tlv_checker_info},
    {MIPC_SYS_GEO_LOCATION_IND, 1, "GEO_LOCATION_IND", 12, mipc_sys_geo_location_ind_tlv_checker_info},
    {MIPC_SYS_MD_INIT_IND, 1, "MD_INIT_IND", 1, mipc_sys_md_init_ind_tlv_checker_info},
    {MIPC_SYS_WARNING_IND, 1, "WARNING_IND", 1, mipc_sys_warning_ind_tlv_checker_info},
    {MIPC_SYS_NV_SIG_ERR_IND, 1, "NV_SIG_ERR_IND", 1, mipc_sys_nv_sig_err_ind_tlv_checker_info},
    {MIPC_SYS_VODATA_STATISTICS_IND, 1, "VODATA_STATISTICS_IND", 5, mipc_sys_vodata_statistics_ind_tlv_checker_info},
    {MIPC_SYS_THERMAL_ACTUATOR_IND, 1, "THERMAL_ACTUATOR_IND", 3, mipc_sys_thermal_actuator_ind_tlv_checker_info},
    {MIPC_SYS_DMF_URC_IND, 1, "DMF_URC_IND", 3, mipc_sys_dmf_urc_ind_tlv_checker_info},
    {MIPC_SYS_META_CONTROL_IND, 1, "META_CONTROL_IND", 1, mipc_sys_meta_control_ind_tlv_checker_info},
    {MIPC_SYS_HBA_TIMEOUT_IND, 1, "HBA_TIMEOUT_IND", 19, mipc_sys_hba_timeout_ind_tlv_checker_info},
    {MIPC_SYS_HBA_HW_FILTER_SRC_STATE_IND, 1, "HBA_HW_FILTER_SRC_STATE_IND", 1, mipc_sys_hba_hw_filter_src_state_ind_tlv_checker_info},
    {MIPC_SYS_DMF_EM_ICD_INFO_IND, 1, "DMF_EM_ICD_INFO_IND", 1, mipc_sys_dmf_em_icd_info_ind_tlv_checker_info},
    {MIPC_APN_IA_CFG_IND, 1, "IA_CFG_IND", 0, NULL},
    {MIPC_APN_PROFILE_CFG_IND, 1, "PROFILE_CFG_IND", 0, NULL},
    {MIPC_APN_OP12_CHG_IND, 1, "OP12_CHG_IND", 3, mipc_apn_op12_chg_ind_tlv_checker_info},
    {MIPC_DATA_ACT_CALL_IND, 1, "ACT_CALL_IND", 53, mipc_data_act_call_ind_tlv_checker_info},
    {MIPC_DATA_DEACT_CALL_IND, 1, "DEACT_CALL_IND", 3, mipc_data_deact_call_ind_tlv_checker_info},
    {MIPC_DATA_MOD_CALL_IND, 1, "MOD_CALL_IND", 55, mipc_data_mod_call_ind_tlv_checker_info},
    {MIPC_DATA_MOD_PCO_IND, 1, "MOD_PCO_IND", 4, mipc_data_mod_pco_ind_tlv_checker_info},
    {MIPC_DATA_WWAN_ACT_CALL_IND, 1, "WWAN_ACT_CALL_IND", 19, mipc_data_wwan_act_call_ind_tlv_checker_info},
    {MIPC_DATA_WWAN_DEACT_CALL_IND, 1, "WWAN_DEACT_CALL_IND", 4, mipc_data_wwan_deact_call_ind_tlv_checker_info},
    {MIPC_DATA_CALL_ACT_REG_IND, 1, "CALL_ACT_REG_IND", 0, NULL},
    {MIPC_DATA_CALL_DEACT_REG_IND, 1, "CALL_DEACT_REG_IND", 0, NULL},
    {MIPC_DATA_CALL_MOD_REG_IND, 1, "CALL_MOD_REG_IND", 0, NULL},
    {MIPC_DATA_MD_ACT_CALL_IND, 1, "MD_ACT_CALL_IND", 3, mipc_data_md_act_call_ind_tlv_checker_info},
    {MIPC_DATA_MD_DEACT_CALL_IND, 1, "MD_DEACT_CALL_IND", 1, mipc_data_md_deact_call_ind_tlv_checker_info},
    {MIPC_DATA_IWLAN_PRIORITY_LIST_IND, 1, "IWLAN_PRIORITY_LIST_IND", 8, mipc_data_iwlan_priority_list_ind_tlv_checker_info},
    {MIPC_DATA_LINK_CAPACITY_ESTIMATE_IND, 1, "LINK_CAPACITY_ESTIMATE_IND", 4, mipc_data_link_capacity_estimate_ind_tlv_checker_info},
    {MIPC_DATA_NW_LIMIT_IND, 1, "NW_LIMIT_IND", 1, mipc_data_nw_limit_ind_tlv_checker_info},
    {MIPC_DATA_TIMER_IND, 1, "TIMER_IND", 5, mipc_data_timer_ind_tlv_checker_info},
    {MIPC_DATA_KEEPALIVE_STATUS_IND, 1, "KEEPALIVE_STATUS_IND", 2, mipc_data_keepalive_status_ind_tlv_checker_info},
    {MIPC_DATA_MOBILE_DATA_USAGE_IND, 1, "MOBILE_DATA_USAGE_IND", 4, mipc_data_mobile_data_usage_ind_tlv_checker_info},
    {MIPC_DATA_NETWORK_REJECT_CAUSE_IND, 1, "NETWORK_REJECT_CAUSE_IND", 3, mipc_data_network_reject_cause_ind_tlv_checker_info},
    {MIPC_DATA_DSDA_STATE_IND, 1, "DSDA_STATE_IND", 4, mipc_data_dsda_state_ind_tlv_checker_info},
    {MIPC_DATA_UMTS_PS_STATE_IND, 1, "UMTS_PS_STATE_IND", 1, mipc_data_umts_ps_state_ind_tlv_checker_info},
    {MIPC_DATA_RETRY_TIMER_IND, 1, "RETRY_TIMER_IND", 1, mipc_data_retry_timer_ind_tlv_checker_info},
    {MIPC_DATA_URSP_REEVAL_IND, 1, "URSP_REEVAL_IND", 3, mipc_data_ursp_reeval_ind_tlv_checker_info},
    {MIPC_DATA_URSP_UE_POLICY_CHG_IND, 1, "URSP_UE_POLICY_CHG_IND", 2, mipc_data_ursp_ue_policy_chg_ind_tlv_checker_info},
    {MIPC_DATA_PDN_NW_CAUSE_IND, 1, "PDN_NW_CAUSE_IND", 3, mipc_data_pdn_nw_cause_ind_tlv_checker_info},
    {MIPC_DATA_PAGING_RESTRICTIONS_IND, 1, "PAGING_RESTRICTIONS_IND", 1, mipc_data_paging_restrictions_ind_tlv_checker_info},
    {MIPC_DATA_TSN_TIME_IND, 1, "TSN_TIME_IND", 2, mipc_data_tsn_time_ind_tlv_checker_info},
    {MIPC_INTERNAL_TEST_IND, 1, "TEST_IND", 0, NULL},
    {MIPC_INTERNAL_EIF_IND, 1, "EIF_IND", 11, mipc_internal_eif_ind_tlv_checker_info},
    {MIPC_INTERNAL_HO_IND, 1, "HO_IND", 8, mipc_internal_ho_ind_tlv_checker_info},
    {MIPC_INTERNAL_MIPC_PENDING_IND, 1, "MIPC_PENDING_IND", 1, mipc_internal_mipc_pending_ind_tlv_checker_info},
    {MIPC_NW_REGISTER_IND, 1, "REGISTER_IND", 9, mipc_nw_register_ind_tlv_checker_info},
    {MIPC_NW_SIGNAL_IND, 1, "SIGNAL_IND", 20, mipc_nw_signal_ind_tlv_checker_info},
    {MIPC_NW_PS_IND, 1, "PS_IND", 11, mipc_nw_ps_ind_tlv_checker_info},
    {MIPC_NW_RADIO_IND, 1, "RADIO_IND", 2, mipc_nw_radio_ind_tlv_checker_info},
    {MIPC_NW_IA_IND, 1, "IA_IND", 8, mipc_nw_ia_ind_tlv_checker_info},
    {MIPC_NW_NITZ_IND, 1, "NITZ_IND", 2, mipc_nw_nitz_ind_tlv_checker_info},
    {MIPC_NW_LOCATION_INFO_IND, 1, "LOCATION_INFO_IND", 1, mipc_nw_location_info_ind_tlv_checker_info},
    {MIPC_NW_CS_IND, 1, "CS_IND", 8, mipc_nw_cs_ind_tlv_checker_info},
    {MIPC_NW_CSCON_IND, 1, "CSCON_IND", 1, mipc_nw_cscon_ind_tlv_checker_info},
    {MIPC_NW_PREFERRED_PROVIDER_IND, 1, "PREFERRED_PROVIDER_IND", 3, mipc_nw_preferred_provider_ind_tlv_checker_info},
    {MIPC_NW_CAINFO_IND, 1, "CAINFO_IND", 12, mipc_nw_cainfo_ind_tlv_checker_info},
    {MIPC_NW_EONS_IND, 1, "EONS_IND", 2, mipc_nw_eons_ind_tlv_checker_info},
    {MIPC_NW_CIEV_IND, 1, "CIEV_IND", 6, mipc_nw_ciev_ind_tlv_checker_info},
    {MIPC_NW_EGMSS_IND, 1, "EGMSS_IND", 5, mipc_nw_egmss_ind_tlv_checker_info},
    {MIPC_NW_PSBEARER_IND, 1, "PSBEARER_IND", 4, mipc_nw_psbearer_ind_tlv_checker_info},
    {MIPC_NW_ECELL_IND, 1, "ECELL_IND", 18, mipc_nw_ecell_ind_tlv_checker_info},
    {MIPC_NW_ANBR_IND, 1, "ANBR_IND", 1, mipc_nw_anbr_ind_tlv_checker_info},
    {MIPC_NW_IRAT_IND, 1, "IRAT_IND", 1, mipc_nw_irat_ind_tlv_checker_info},
    {MIPC_NW_EREGINFO_IND, 1, "EREGINFO_IND", 2, mipc_nw_ereginfo_ind_tlv_checker_info},
    {MIPC_NW_EMODCFG_IND, 1, "EMODCFG_IND", 1, mipc_nw_emodcfg_ind_tlv_checker_info},
    {MIPC_NW_EPCELLINFO_IND, 1, "EPCELLINFO_IND", 1, mipc_nw_epcellinfo_ind_tlv_checker_info},
    {MIPC_NW_PSEUDO_CELL_IND, 1, "PSEUDO_CELL_IND", 3, mipc_nw_pseudo_cell_ind_tlv_checker_info},
    {MIPC_NW_NETWORK_INFO_IND, 1, "NETWORK_INFO_IND", 3, mipc_nw_network_info_ind_tlv_checker_info},
    {MIPC_NW_MCCMNC_IND, 1, "MCCMNC_IND", 1, mipc_nw_mccmnc_ind_tlv_checker_info},
    {MIPC_NW_PHYSICAL_CHANNEL_CONFIGS_IND, 1, "PHYSICAL_CHANNEL_CONFIGS_IND", 4, mipc_nw_physical_channel_configs_ind_tlv_checker_info},
    {MIPC_NW_OTACMSG_IND, 1, "OTACMSG_IND", 1, mipc_nw_otacmsg_ind_tlv_checker_info},
    {MIPC_NW_BARRING_INFO_IND, 1, "BARRING_INFO_IND", 4, mipc_nw_barring_info_ind_tlv_checker_info},
    {MIPC_NW_RADIO_CAPABILITY_IND, 1, "RADIO_CAPABILITY_IND", 1, mipc_nw_radio_capability_ind_tlv_checker_info},
    {MIPC_NW_CURRENT_RAT_IND, 1, "CURRENT_RAT_IND", 3, mipc_nw_current_rat_ind_tlv_checker_info},
    {MIPC_NW_CAMP_STATE_IND, 1, "CAMP_STATE_IND", 3, mipc_nw_camp_state_ind_tlv_checker_info},
    {MIPC_NW_NR_SWITCH_IND, 1, "NR_SWITCH_IND", 1, mipc_nw_nr_switch_ind_tlv_checker_info},
    {MIPC_NW_FEMTOCELL_INFO_IND, 1, "FEMTOCELL_INFO_IND", 14, mipc_nw_femtocell_info_ind_tlv_checker_info},
    {MIPC_NW_ETXPWR_IND, 1, "ETXPWR_IND", 2, mipc_nw_etxpwr_ind_tlv_checker_info},
    {MIPC_NW_ETXPWRSTUS_IND, 1, "ETXPWRSTUS_IND", 2, mipc_nw_etxpwrstus_ind_tlv_checker_info},
    {MIPC_NW_IWLAN_IND, 1, "IWLAN_IND", 1, mipc_nw_iwlan_ind_tlv_checker_info},
    {MIPC_NW_CH_INFO_IND, 1, "CH_INFO_IND", 4, mipc_nw_ch_info_ind_tlv_checker_info},
    {MIPC_NW_NRUW_INFO_IND, 1, "NRUW_INFO_IND", 4, mipc_nw_nruw_info_ind_tlv_checker_info},
    {MIPC_NW_NR_CA_BAND_IND, 1, "NR_CA_BAND_IND", 3, mipc_nw_nr_ca_band_ind_tlv_checker_info},
    {MIPC_NW_NR_SCS_IND, 1, "NR_SCS_IND", 1, mipc_nw_nr_scs_ind_tlv_checker_info},
    {MIPC_NW_NETWORK_SCAN_IND, 1, "NETWORK_SCAN_IND", 2, mipc_nw_network_scan_ind_tlv_checker_info},
    {MIPC_NW_CA_INFO_IND, 1, "CA_INFO_IND", 1, mipc_nw_ca_info_ind_tlv_checker_info},
    {MIPC_NW_NRUC_INFO_IND, 1, "NRUC_INFO_IND", 3, mipc_nw_nruc_info_ind_tlv_checker_info},
    {MIPC_NW_FIRST_PLMN_IND, 1, "FIRST_PLMN_IND", 2, mipc_nw_first_plmn_ind_tlv_checker_info},
    {MIPC_NW_EDRX_IND, 1, "EDRX_IND", 4, mipc_nw_edrx_ind_tlv_checker_info},
    {MIPC_NW_MOBILE_INITIATED_CONNECTION_ONLY_MODE_IND, 1, "MOBILE_INITIATED_CONNECTION_ONLY_MODE_IND", 4, mipc_nw_mobile_initiated_connection_only_mode_ind_tlv_checker_info},
    {MIPC_NW_BASEMENT_DETECTION_IND, 1, "BASEMENT_DETECTION_IND", 1, mipc_nw_basement_detection_ind_tlv_checker_info},
    {MIPC_NW_ENWCFGINFO_IND, 1, "ENWCFGINFO_IND", 3, mipc_nw_enwcfginfo_ind_tlv_checker_info},
    {MIPC_NW_LCM_HOPPING_IND, 1, "LCM_HOPPING_IND", 1, mipc_nw_lcm_hopping_ind_tlv_checker_info},
    {MIPC_NW_NRRC_RRC_RELEASE_UAI_IND, 1, "NRRC_RRC_RELEASE_UAI_IND", 3, mipc_nw_nrrc_rrc_release_uai_ind_tlv_checker_info},
    {MIPC_NW_NRRC_POWERSAVING_UAI_IND, 1, "NRRC_POWERSAVING_UAI_IND", 6, mipc_nw_nrrc_powersaving_uai_ind_tlv_checker_info},
    {MIPC_NW_NRRC_OVERHEATINGASSISTANCE_UAI_IND, 1, "NRRC_OVERHEATINGASSISTANCE_UAI_IND", 1, mipc_nw_nrrc_overheatingassistance_uai_ind_tlv_checker_info},
    {MIPC_NW_NRRC_TIMER_STATUS_IND, 1, "NRRC_TIMER_STATUS_IND", 3, mipc_nw_nrrc_timer_status_ind_tlv_checker_info},
    {MIPC_SIM_STATE_IND, 1, "STATE_IND", 5, mipc_sim_state_ind_tlv_checker_info},
    {MIPC_SIM_STATUS_IND, 1, "STATUS_IND", 3, mipc_sim_status_ind_tlv_checker_info},
    {MIPC_SIM_EUICC_SLOTS_STATUS_IND, 1, "EUICC_SLOTS_STATUS_IND", 9, mipc_sim_euicc_slots_status_ind_tlv_checker_info},
    {MIPC_SIM_ICCID_IND, 1, "ICCID_IND", 1, mipc_sim_iccid_ind_tlv_checker_info},
    {MIPC_SIM_EVENT_IND, 1, "EVENT_IND", 3, mipc_sim_event_ind_tlv_checker_info},
    {MIPC_SIM_PHYSICAL_SLOTS_MAPPING_DONE_IND, 1, "PHYSICAL_SLOTS_MAPPING_DONE_IND", 0, NULL},
    {MIPC_SIM_CSIM_IMSI_CHANGE_IND, 1, "CSIM_IMSI_CHANGE_IND", 1, mipc_sim_csim_imsi_change_ind_tlv_checker_info},
    {MIPC_SIM_SML_STATUS_IND, 1, "SML_STATUS_IND", 6, mipc_sim_sml_status_ind_tlv_checker_info},
    {MIPC_SIM_SML_RSU_IND, 1, "SML_RSU_IND", 3, mipc_sim_sml_rsu_ind_tlv_checker_info},
    {MIPC_SIM_VSIM_RESET_IND, 1, "VSIM_RESET_IND", 0, NULL},
    {MIPC_SIM_VSIM_APDU_IND, 1, "VSIM_APDU_IND", 1, mipc_sim_vsim_apdu_ind_tlv_checker_info},
    {MIPC_SIM_VSIM_EVENT_IND, 1, "VSIM_EVENT_IND", 2, mipc_sim_vsim_event_ind_tlv_checker_info},
    {MIPC_SIM_SIMAPP_IND, 1, "SIMAPP_IND", 4, mipc_sim_simapp_ind_tlv_checker_info},
    {MIPC_SIM_TEST_SIM_IND, 1, "TEST_SIM_IND", 1, mipc_sim_test_sim_ind_tlv_checker_info},
    {MIPC_SIM_CT3G_IND, 1, "CT3G_IND", 1, mipc_sim_ct3g_ind_tlv_checker_info},
    {MIPC_SIM_CARD_TYPE_IND, 1, "CARD_TYPE_IND", 3, mipc_sim_card_type_ind_tlv_checker_info},
    {MIPC_SIM_SIMIND_IND, 1, "SIMIND_IND", 10, mipc_sim_simind_ind_tlv_checker_info},
    {MIPC_SIM_STATUS_CHANGED_IND, 1, "STATUS_CHANGED_IND", 0, NULL},
    {MIPC_SIM_ESLOTESIM_STATE_IND, 1, "ESLOTESIM_STATE_IND", 2, mipc_sim_eslotesim_state_ind_tlv_checker_info},
    {MIPC_SIM_MEP_SLOTS_INFO_IND, 1, "MEP_SLOTS_INFO_IND", 7, mipc_sim_mep_slots_info_ind_tlv_checker_info},
    {MIPC_SMS_CFG_IND, 1, "CFG_IND", 11, mipc_sms_cfg_ind_tlv_checker_info},
    {MIPC_SMS_CFG_IND, 2, "CFG_IND", 6, mipc_sms_cfg_ind_tlv_checker_info_v2},
    {MIPC_SMS_NEW_SMS_IND, 1, "NEW_SMS_IND", 4, mipc_sms_new_sms_ind_tlv_checker_info},
    {MIPC_SMS_NEW_SMS_IND, 2, "NEW_SMS_IND", 4, mipc_sms_new_sms_ind_tlv_checker_info_v2},
    {MIPC_SMS_STORE_STATUS_IND, 1, "STORE_STATUS_IND", 3, mipc_sms_store_status_ind_tlv_checker_info},
    {MIPC_SMS_STORE_STATUS_IND, 2, "STORE_STATUS_IND", 3, mipc_sms_store_status_ind_tlv_checker_info_v2},
    {MIPC_SMS_NEW_STATUS_REPORT_IND, 1, "NEW_STATUS_REPORT_IND", 1, mipc_sms_new_status_report_ind_tlv_checker_info},
    {MIPC_SMS_NEW_STATUS_REPORT_IND, 2, "NEW_STATUS_REPORT_IND", 2, mipc_sms_new_status_report_ind_tlv_checker_info_v2},
    {MIPC_SMS_NEW_CBM_IND, 1, "NEW_CBM_IND", 11, mipc_sms_new_cbm_ind_tlv_checker_info},
    {MIPC_SMS_NEW_CBM_IND, 2, "NEW_CBM_IND", 10, mipc_sms_new_cbm_ind_tlv_checker_info_v2},
    {MIPC_SMS_SCBM_IND, 1, "SCBM_IND", 1, mipc_sms_scbm_ind_tlv_checker_info},
    {MIPC_SMS_EXT_INFO_IND, 1, "EXT_INFO_IND", 3, mipc_sms_ext_info_ind_tlv_checker_info},
    {MIPC_SMS_DUP_NEW_SMS_IND, 1, "DUP_NEW_SMS_IND", 2, mipc_sms_dup_new_sms_ind_tlv_checker_info},
    {MIPC_SMS_DUP_NEW_SMS_IND, 2, "DUP_NEW_SMS_IND", 2, mipc_sms_dup_new_sms_ind_tlv_checker_info_v2},
    {MIPC_SS_USSD_IND, 1, "USSD_IND", 7, mipc_ss_ussd_ind_tlv_checker_info},
    {MIPC_SS_ECMCCSS_IND, 1, "ECMCCSS_IND", 3, mipc_ss_ecmccss_ind_tlv_checker_info},
    {MIPC_SS_CFU_IND, 1, "CFU_IND", 2, mipc_ss_cfu_ind_tlv_checker_info},
    {MIPC_SS_XCAP_RCN_IND, 1, "XCAP_RCN_IND", 2, mipc_ss_xcap_rcn_ind_tlv_checker_info},
    {MIPC_SS_IMS_XUI_IND, 1, "IMS_XUI_IND", 3, mipc_ss_ims_xui_ind_tlv_checker_info},
    {MIPC_STK_PAC_IND, 1, "PAC_IND", 3, mipc_stk_pac_ind_tlv_checker_info},
    {MIPC_STK_SIM_REFRESH_IND, 1, "SIM_REFRESH_IND", 3, mipc_stk_sim_refresh_ind_tlv_checker_info},
    {MIPC_STK_BIP_EVENT_NOTIFY_IND, 1, "BIP_EVENT_NOTIFY_IND", 1, mipc_stk_bip_event_notify_ind_tlv_checker_info},
    {MIPC_CALL_STATUS_IND, 1, "STATUS_IND", 11, mipc_call_status_ind_tlv_checker_info},
    {MIPC_CALL_EVENT_IND, 1, "EVENT_IND", 11, mipc_call_event_ind_tlv_checker_info},
    {MIPC_CALL_MODE_IND, 1, "MODE_IND", 5, mipc_call_mode_ind_tlv_checker_info},
    {MIPC_CALL_SIP_IND, 1, "SIP_IND", 6, mipc_call_sip_ind_tlv_checker_info},
    {MIPC_CALL_CONFERENCE_IND, 1, "CONFERENCE_IND", 8, mipc_call_conference_ind_tlv_checker_info},
    {MIPC_CALL_IMS_EVENT_PACKAGE_IND, 1, "IMS_EVENT_PACKAGE_IND", 3, mipc_call_ims_event_package_ind_tlv_checker_info},
    {MIPC_CALL_ECC_LIST_CHANGE_IND, 1, "ECC_LIST_CHANGE_IND", 0, NULL},
    {MIPC_CALL_SS_IND, 1, "SS_IND", 8, mipc_call_ss_ind_tlv_checker_info},
    {MIPC_CALL_ECBM_CHANGE_IND, 1, "ECBM_CHANGE_IND", 1, mipc_call_ecbm_change_ind_tlv_checker_info},
    {MIPC_CALL_CRSS_IND, 1, "CRSS_IND", 8, mipc_call_crss_ind_tlv_checker_info},
    {MIPC_CALL_ECT_IND, 1, "ECT_IND", 3, mipc_call_ect_ind_tlv_checker_info},
    {MIPC_CALL_CIPHER_IND, 1, "CIPHER_IND", 4, mipc_call_cipher_ind_tlv_checker_info},
    {MIPC_CALL_RTT_AUDIO_IND, 1, "RTT_AUDIO_IND", 2, mipc_call_rtt_audio_ind_tlv_checker_info},
    {MIPC_CALL_RTT_CAPABILITY_IND, 1, "RTT_CAPABILITY_IND", 5, mipc_call_rtt_capability_ind_tlv_checker_info},
    {MIPC_CALL_LOCAL_RTT_MODIFY_RESULT_IND, 1, "LOCAL_RTT_MODIFY_RESULT_IND", 2, mipc_call_local_rtt_modify_result_ind_tlv_checker_info},
    {MIPC_CALL_PEER_RTT_MODIFY_RESULT_IND, 1, "PEER_RTT_MODIFY_RESULT_IND", 2, mipc_call_peer_rtt_modify_result_ind_tlv_checker_info},
    {MIPC_CALL_RTT_TEXT_RECEIVE_IND, 1, "RTT_TEXT_RECEIVE_IND", 3, mipc_call_rtt_text_receive_ind_tlv_checker_info},
    {MIPC_CALL_RCS_DIGITS_LINE_IND, 1, "RCS_DIGITS_LINE_IND", 1, mipc_call_rcs_digits_line_ind_tlv_checker_info},
    {MIPC_CALL_DISPLAY_AND_SIGNALS_INFO_IND, 1, "DISPLAY_AND_SIGNALS_INFO_IND", 4, mipc_call_display_and_signals_info_ind_tlv_checker_info},
    {MIPC_CALL_EXTENDED_DISPLAY_INFO_IND, 1, "EXTENDED_DISPLAY_INFO_IND", 2, mipc_call_extended_display_info_ind_tlv_checker_info},
    {MIPC_CALL_LINE_CONTROL_INFO_IND, 1, "LINE_CONTROL_INFO_IND", 4, mipc_call_line_control_info_ind_tlv_checker_info},
    {MIPC_CALL_REDIRECTING_NUMBER_INFO_IND, 1, "REDIRECTING_NUMBER_INFO_IND", 9, mipc_call_redirecting_number_info_ind_tlv_checker_info},
    {MIPC_CALL_GWSD_EVENT_IND, 1, "GWSD_EVENT_IND", 6, mipc_call_gwsd_event_ind_tlv_checker_info},
    {MIPC_CALL_ECONF_IND, 1, "ECONF_IND", 6, mipc_call_econf_ind_tlv_checker_info},
    {MIPC_CALL_IMS_SIP_HEADER_IND, 1, "IMS_SIP_HEADER_IND", 5, mipc_call_ims_sip_header_ind_tlv_checker_info},
    {MIPC_CALL_ECC_REDIAL_IND, 1, "ECC_REDIAL_IND", 1, mipc_call_ecc_redial_ind_tlv_checker_info},
    {MIPC_CALL_EMERGENCY_BEARER_SUPPORT_IND, 1, "EMERGENCY_BEARER_SUPPORT_IND", 6, mipc_call_emergency_bearer_support_ind_tlv_checker_info},
    {MIPC_CALL_UIS_INFO_IND, 1, "UIS_INFO_IND", 5, mipc_call_uis_info_ind_tlv_checker_info},
    {MIPC_CALL_CALL_ADDITIONAL_INFO_IND, 1, "CALL_ADDITIONAL_INFO_IND", 7, mipc_call_call_additional_info_ind_tlv_checker_info},
    {MIPC_CALL_MT_SIP_INVITE_IND, 1, "MT_SIP_INVITE_IND", 4, mipc_call_mt_sip_invite_ind_tlv_checker_info},
    {MIPC_CALL_RECV_DTMF_IND, 1, "RECV_DTMF_IND", 2, mipc_call_recv_dtmf_ind_tlv_checker_info},
    {MIPC_IMS_CONFIG_IND, 1, "CONFIG_IND", 2, mipc_ims_config_ind_tlv_checker_info},
    {MIPC_IMS_STATE_IND, 1, "STATE_IND", 9, mipc_ims_state_ind_tlv_checker_info},
    {MIPC_IMS_SUPPORT_ECC_IND, 1, "SUPPORT_ECC_IND", 2, mipc_ims_support_ecc_ind_tlv_checker_info},
    {MIPC_IMS_PDN_IND, 1, "PDN_IND", 9, mipc_ims_pdn_ind_tlv_checker_info},
    {MIPC_IMS_NAPTR_IND, 1, "NAPTR_IND", 3, mipc_ims_naptr_ind_tlv_checker_info},
    {MIPC_IMS_REG_IND, 1, "REG_IND", 8, mipc_ims_reg_ind_tlv_checker_info},
    {MIPC_IMS_SIP_REG_INFO_IND, 1, "SIP_REG_INFO_IND", 7, mipc_ims_sip_reg_info_ind_tlv_checker_info},
    {MIPC_IMS_VOPS_IND, 1, "VOPS_IND", 1, mipc_ims_vops_ind_tlv_checker_info},
    {MIPC_IMS_REG_REMAIN_TIME_IND, 1, "REG_REMAIN_TIME_IND", 2, mipc_ims_reg_remain_time_ind_tlv_checker_info},
    {MIPC_IMS_UI_IND, 1, "UI_IND", 1, mipc_ims_ui_ind_tlv_checker_info},
    {MIPC_WFC_CELL_SIGNAL_IND, 1, "CELL_SIGNAL_IND", 2, mipc_wfc_cell_signal_ind_tlv_checker_info},
    {MIPC_WFC_WIFI_PDN_COUNT_IND, 1, "WIFI_PDN_COUNT_IND", 1, mipc_wfc_wifi_pdn_count_ind_tlv_checker_info},
    {MIPC_WFC_PDN_HO_IND, 1, "PDN_HO_IND", 4, mipc_wfc_pdn_ho_ind_tlv_checker_info},
    {MIPC_WFC_ROVE_OUT_IND, 1, "ROVE_OUT_IND", 3, mipc_wfc_rove_out_ind_tlv_checker_info},
    {MIPC_WFC_SSAC_IND, 1, "SSAC_IND", 4, mipc_wfc_ssac_ind_tlv_checker_info},
    {MIPC_WFC_WIFI_PDN_ERR_IND, 1, "WIFI_PDN_ERR_IND", 3, mipc_wfc_wifi_pdn_err_ind_tlv_checker_info},
    {MIPC_WFC_WIFI_PDN_OOS_IND, 1, "WIFI_PDN_OOS_IND", 3, mipc_wfc_wifi_pdn_oos_ind_tlv_checker_info},
    {MIPC_WFC_WFC_IND, 1, "WFC_IND", 5, mipc_wfc_wfc_ind_tlv_checker_info},
    {MIPC_PHB_READY_STATE_IND, 1, "READY_STATE_IND", 1, mipc_phb_ready_state_ind_tlv_checker_info},
    {MIPC_EMBMS_EMSRV_IND, 1, "EMSRV_IND", 2, mipc_embms_emsrv_ind_tlv_checker_info},
    {MIPC_EMBMS_EMSLUI_IND, 1, "EMSLUI_IND", 2, mipc_embms_emslui_ind_tlv_checker_info},
    {MIPC_EMBMS_EMSAILNF_IND, 1, "EMSAILNF_IND", 1, mipc_embms_emsailnf_ind_tlv_checker_info},
    {MIPC_EMBMS_EMSESS_IND, 1, "EMSESS_IND", 4, mipc_embms_emsess_ind_tlv_checker_info},
    {MIPC_EMBMS_EHVOLTE_IND, 1, "EHVOLTE_IND", 1, mipc_embms_ehvolte_ind_tlv_checker_info},
    {MIPC_EMBMS_SERVICE_COVERAGE_IND, 1, "SERVICE_COVERAGE_IND", 1, mipc_embms_service_coverage_ind_tlv_checker_info},
    {MIPC_EMBMS_BROADCAST_SESSION_LIST_IND, 1, "BROADCAST_SESSION_LIST_IND", 1, mipc_embms_broadcast_session_list_ind_tlv_checker_info},
    {MIPC_EMBMS_MBS_FREQ_IND, 1, "MBS_FREQ_IND", 1, mipc_embms_mbs_freq_ind_tlv_checker_info},
    {MIPC_EMBMS_SESSION_STATUS_IND, 1, "SESSION_STATUS_IND", 2, mipc_embms_session_status_ind_tlv_checker_info},
    {MIPC_EMBMS_SAI_INTRA_LIST_IND, 1, "SAI_INTRA_LIST_IND", 1, mipc_embms_sai_intra_list_ind_tlv_checker_info},
    {MIPC_EMBMS_SAI_NEIGHBOR_LIST_IND, 1, "SAI_NEIGHBOR_LIST_IND", 1, mipc_embms_sai_neighbor_list_ind_tlv_checker_info},
    {MIPC_EMBMS_MBS_MULTICAST_AREA_INFO_UPDATE_IND, 1, "MBS_MULTICAST_AREA_INFO_UPDATE_IND", 2, mipc_embms_mbs_multicast_area_info_update_ind_tlv_checker_info},
    {MIPC_EMBMS_MBS_SESSION_UPDATE_IND, 1, "MBS_SESSION_UPDATE_IND", 8, mipc_embms_mbs_session_update_ind_tlv_checker_info},
    {MIPC_ECALL_STATUS_IND, 1, "STATUS_IND", 2, mipc_ecall_status_ind_tlv_checker_info},
    {MIPC_EXIMS_IMSVOPS_IND, 1, "IMSVOPS_IND", 1, mipc_exims_imsvops_ind_tlv_checker_info},
    {MIPC_EXIMS_EMERGENCY_SERVICE_SUPPORT_IND, 1, "EMERGENCY_SERVICE_SUPPORT_IND", 2, mipc_exims_emergency_service_support_ind_tlv_checker_info},
    {MIPC_EXIMS_EMERGENCY_BEARER_SUPPORT_IND, 1, "EMERGENCY_BEARER_SUPPORT_IND", 4, mipc_exims_emergency_bearer_support_ind_tlv_checker_info},
    {MIPC_EXIMS_ECC_LIST_CHANGE_IND, 1, "ECC_LIST_CHANGE_IND", 0, NULL},
    {MIPC_EXIMS_UNLOCK_CALL_BAR_IND, 1, "UNLOCK_CALL_BAR_IND", 1, mipc_exims_unlock_call_bar_ind_tlv_checker_info},
    {MIPC_EXIMS_UNLOCK_SMS_BAR_IND, 1, "UNLOCK_SMS_BAR_IND", 1, mipc_exims_unlock_sms_bar_ind_tlv_checker_info},
    {MIPC_SYS_REBOOT_CMD, 1, "REBOOT_CMD", 3, mipc_sys_reboot_cmd_tlv_checker_info},
    {MIPC_SYS_REBOOT_RSP, 1, "REBOOT_RSP", 0, NULL},
    {MIPC_SYS_SET_CONFIG_DIPC_CMD, 1, "SET_CONFIG_DIPC_CMD", 3, mipc_sys_set_config_dipc_cmd_tlv_checker_info},
    {MIPC_SYS_SET_CONFIG_DIPC_RSP, 1, "SET_CONFIG_DIPC_RSP", 1, mipc_sys_set_config_dipc_rsp_tlv_checker_info},
    {MIPC_SYS_CONFIG_NEEDED_TO_UPDATE_CMD, 1, "CONFIG_NEEDED_TO_UPDATE_CMD", 2, mipc_sys_config_needed_to_update_cmd_tlv_checker_info},
    {MIPC_SYS_CONFIG_NEEDED_TO_UPDATE_RSP, 1, "CONFIG_NEEDED_TO_UPDATE_RSP", 0, NULL},
    {MIPC_SYS_GET_CONFIG_DIPC_CMD, 1, "GET_CONFIG_DIPC_CMD", 2, mipc_sys_get_config_dipc_cmd_tlv_checker_info},
    {MIPC_SYS_GET_CONFIG_DIPC_RSP, 1, "GET_CONFIG_DIPC_RSP", 1, mipc_sys_get_config_dipc_rsp_tlv_checker_info},
    {MIPC_SYS_SET_TIME_CMD, 1, "SET_TIME_CMD", 2, mipc_sys_set_time_cmd_tlv_checker_info},
    {MIPC_SYS_SET_TIME_RSP, 1, "SET_TIME_RSP", 0, NULL},
    {MIPC_INTERNAL_TEST_CMD, 1, "TEST_CMD", 0, NULL},
    {MIPC_INTERNAL_TEST_RSP, 1, "TEST_RSP", 0, NULL},
    {MIPC_INTERNAL_EIPPORT_CMD, 1, "EIPPORT_CMD", 6, mipc_internal_eipport_cmd_tlv_checker_info},
    {MIPC_INTERNAL_EIPPORT_RSP, 1, "EIPPORT_RSP", 3, mipc_internal_eipport_rsp_tlv_checker_info},
    {MIPC_INTERNAL_EIPSPI_CMD, 1, "EIPSPI_CMD", 9, mipc_internal_eipspi_cmd_tlv_checker_info},
    {MIPC_INTERNAL_EIPSPI_RSP, 1, "EIPSPI_RSP", 3, mipc_internal_eipspi_rsp_tlv_checker_info},
    {MIPC_INTERNAL_MULTI_EIPSPI_FREE_CMD, 1, "MULTI_EIPSPI_FREE_CMD", 6, mipc_internal_multi_eipspi_free_cmd_tlv_checker_info},
    {MIPC_INTERNAL_MULTI_EIPSPI_FREE_RSP, 1, "MULTI_EIPSPI_FREE_RSP", 4, mipc_internal_multi_eipspi_free_rsp_tlv_checker_info},
    {MIPC_SMS_NEW_SMS_CMD, 1, "NEW_SMS_CMD", 4, mipc_sms_new_sms_cmd_tlv_checker_info},
    {MIPC_SMS_NEW_SMS_CMD, 2, "NEW_SMS_CMD", 2, mipc_sms_new_sms_cmd_tlv_checker_info_v2},
    {MIPC_SMS_NEW_SMS_RSP, 1, "NEW_SMS_RSP", 6, mipc_sms_new_sms_rsp_tlv_checker_info},
    {MIPC_SMS_NEW_SMS_RSP, 2, "NEW_SMS_RSP", 6, mipc_sms_new_sms_rsp_tlv_checker_info_v2},
    {MIPC_SMS_NEW_STATUS_REPORT_CMD, 1, "NEW_STATUS_REPORT_CMD", 1, mipc_sms_new_status_report_cmd_tlv_checker_info},
    {MIPC_SMS_NEW_STATUS_REPORT_CMD, 2, "NEW_STATUS_REPORT_CMD", 2, mipc_sms_new_status_report_cmd_tlv_checker_info_v2},
    {MIPC_SMS_NEW_STATUS_REPORT_RSP, 1, "NEW_STATUS_REPORT_RSP", 3, mipc_sms_new_status_report_rsp_tlv_checker_info},
    {MIPC_SMS_NEW_STATUS_REPORT_RSP, 2, "NEW_STATUS_REPORT_RSP", 6, mipc_sms_new_status_report_rsp_tlv_checker_info_v2},
    {MIPC_CALL_APPROVE_INCOMING_CMD, 1, "APPROVE_INCOMING_CMD", 6, mipc_call_approve_incoming_cmd_tlv_checker_info},
    {MIPC_CALL_APPROVE_INCOMING_RSP, 1, "APPROVE_INCOMING_RSP", 4, mipc_call_approve_incoming_rsp_tlv_checker_info},
    {MIPC_IMS_PDIS_CMD, 1, "PDIS_CMD", 4, mipc_ims_pdis_cmd_tlv_checker_info},
    {MIPC_IMS_PDIS_RSP, 1, "PDIS_RSP", 3, mipc_ims_pdis_rsp_tlv_checker_info},
    {MIPC_WFC_PING_CMD, 1, "PING_CMD", 1, mipc_wfc_ping_cmd_tlv_checker_info},
    {MIPC_WFC_PING_RSP, 1, "PING_RSP", 3, mipc_wfc_ping_rsp_tlv_checker_info},
    {MIPC_WFC_GET_MAC_CMD, 1, "GET_MAC_CMD", 2, mipc_wfc_get_mac_cmd_tlv_checker_info},
    {MIPC_WFC_GET_MAC_RSP, 1, "GET_MAC_RSP", 4, mipc_wfc_get_mac_rsp_tlv_checker_info},
    {MIPC_WFC_NATT_KEEP_ALIVE_CMD, 1, "NATT_KEEP_ALIVE_CMD", 6, mipc_wfc_natt_keep_alive_cmd_tlv_checker_info},
    {MIPC_WFC_NATT_KEEP_ALIVE_RSP, 1, "NATT_KEEP_ALIVE_RSP", 6, mipc_wfc_natt_keep_alive_rsp_tlv_checker_info},
    {MIPC_WFC_REGISTER_WIFI_SIGNAL_NTF_CMD, 1, "REGISTER_WIFI_SIGNAL_NTF_CMD", 2, mipc_wfc_register_wifi_signal_ntf_cmd_tlv_checker_info},
    {MIPC_WFC_REGISTER_WIFI_SIGNAL_NTF_RSP, 1, "REGISTER_WIFI_SIGNAL_NTF_RSP", 0, NULL},
    {MIPC_DATA_ACT_CALL_NTF, 1, "ACT_CALL_NTF", 2, mipc_data_act_call_ntf_tlv_checker_info},
    {MIPC_INTERNAL_TEST_NTF, 1, "TEST_NTF", 0, NULL},
    {MIPC_INTERNAL_INJECT_TST_NTF, 1, "INJECT_TST_NTF", 3, mipc_internal_inject_tst_ntf_tlv_checker_info},
    {MIPC_WFC_WIFI_SIGNAL_NTF, 1, "WIFI_SIGNAL_NTF", 3, mipc_wfc_wifi_signal_ntf_tlv_checker_info},
    {MIPC_WFC_EPDG_SCREEN_STATE_NTF, 1, "EPDG_SCREEN_STATE_NTF", 1, mipc_wfc_epdg_screen_state_ntf_tlv_checker_info},
    {MIPC_WFC_WIFI_INFO_NTF, 1, "WIFI_INFO_NTF", 22, mipc_wfc_wifi_info_ntf_tlv_checker_info},
};

#endif
