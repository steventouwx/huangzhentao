/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  Copyright (c) [2020], MediaTek Inc. All rights reserved.
*  This software/firmware and related documentation ("MediaTek Software") are
*  protected under relevant copyright laws.
*
*  The information contained herein is confidential and proprietary to
*  MediaTek Inc. and/or its licensors. Except as otherwise provided in the
*  applicable licensing terms with MediaTek Inc. and/or its licensors, any
*  reproduction, modification, use or disclosure of MediaTek Software, and
*  information contained herein, in whole or in part, shall be strictly
*  prohibited.
*****************************************************************************/

#ifndef __MIPC_MSG_TLV_API_H__
#define __MIPC_MSG_TLV_API_H__

#include "mipc_msg_sys_api.h"
#include "mipc_msg_apn_api.h"
#include "mipc_msg_data_api.h"
#include "mipc_msg_internal_api.h"
#include "mipc_msg_nw_api.h"
#include "mipc_msg_sim_api.h"
#include "mipc_msg_sms_api.h"
#include "mipc_msg_ss_api.h"
#include "mipc_msg_stk_api.h"
#include "mipc_msg_call_api.h"
#include "mipc_msg_ims_api.h"
#include "mipc_msg_wfc_api.h"
#include "mipc_msg_phb_api.h"
#include "mipc_msg_embms_api.h"
#include "mipc_msg_ecall_api.h"
#include "mipc_msg_exims_api.h"
#include "mipc_msg_loc_api.h"
#include "mipc_msg_ntn_api.h"
#include "mipc_msg_common_api.h"

#endif /* __MIPC_MSG_TLV_API_H__ */
