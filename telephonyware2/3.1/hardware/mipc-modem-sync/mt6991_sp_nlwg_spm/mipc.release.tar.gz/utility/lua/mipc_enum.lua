BOOLEAN = {
    [0] = "FALSE",
    [1] = "TRUE",
}
SYS_SIM_PS = {
    [1] = "SIM0",
    [2] = "SIM1",
    [4] = "SIM2",
    [8] = "SIM3",
    [16] = "PS0",
    [32] = "PS1",
    [64] = "PS2",
    [128] = "PS3",
    [255] = "ALL",
}
SYS_REBOOT_MODE = {
    [0] = "NORMAL",
    [1] = "DOWNLOAD",
    [2] = "POWEROFF",
    [3] = "PRESHUTDOWN",
    [4] = "DOWNLOAD_NONRST",
    [5] = "SBP_CHANGE",
    [6] = "FAST_DOWNLOAD",
}
SYS_CAP_CELLULAR_CLASS = {
    [1] = "GSM",
    [2] = "CDMA",
}
SYS_VOICE_CLASS = {
    [0] = "UNKNOWN",
    [1] = "NO_VOICE",
    [2] = "SEPARATE_VOICE_DATA",
    [3] = "SIMULTANEOUS_VOICE_DATA",
}
SYS_SIM_CLASS = {
    [0] = "UNKNOWN",
    [1] = "LOGICAL",
    [2] = "REMOVABLE",
}
SYS_CAP_DATA = {
    [0] = "NONE",
    [1] = "GPRS",
    [2] = "EDGE",
    [4] = "UMTS",
    [8] = "HSDPA",
    [16] = "HSUPA",
    [32] = "LTE",
    [64] = "5G_NSA",
    [128] = "5G_SA",
    [65536] = "1XRTT",
    [131072] = "1XEVDO",
    [262144] = "1XEVDO_REVA",
    [524288] = "1XEVDV",
    [1048576] = "3XRTT",
    [2097152] = "1XEVDO_REVB",
    [4194304] = "UMB",
    [1073741824] = "HSPA_PLUS",
    [2147483648] = "CUSTOM",
}
SYS_CAP_SMS = {
    [0] = "NONE",
    [1] = "PDU_RECEIVE",
    [2] = "PDU_SEND",
    [4] = "TEXT_RECEIVE",
    [8] = "TEXT_SEND",
}
SYS_CAP_CTRL = {
    [0] = "NONE",
    [1] = "REG_MANUAL",
    [2] = "HW_RADIO_SWITCH",
    [4] = "CDMA_MOBILE_IP",
    [8] = "CDMA_SIMPLE_IP",
    [16] = "MULTI_CARRIER",
    [32] = "ESIM",
    [64] = "UE_POLICY_ROUTE_SELECTION",
    [128] = "SIM_HOT_SWAP_CAPABLE",
}
SYS_AUTH_ALGO = {
    [0] = "NONE",
    [1] = "SIM",
    [2] = "AKA",
    [3] = "AKAP",
}
SYS_CAP_SERVICE = {
    [0] = "NONE",
    [1] = "LTE_ATTACH",
    [2] = "CONTEXT_MGMT",
    [4] = "MULTI_SIM",
    [8] = "EX_SAR",
    [16] = "NETWORK_BLACKLIST",
    [32] = "5G_NSA",
}
SYS_CAP_GSM_BAND = {
    [2] = "900",
    [8] = "DCS_1800",
    [16] = "PCS_1900",
    [128] = "PCS_850",
}
SYS_CAP_UMTS_BAND = {
    [1] = "I",
    [2] = "II",
    [4] = "III",
    [8] = "IV",
    [16] = "V",
    [32] = "VI",
    [64] = "VII",
    [128] = "VIII",
    [256] = "IX",
    [512] = "X",
}
SYS_CAP_CDMA_BAND = {
    [1] = "0",
    [2] = "1",
    [4] = "2",
    [8] = "3",
    [16] = "4",
    [32] = "5",
    [64] = "6",
    [128] = "7",
    [256] = "8",
    [512] = "9",
    [1024] = "10",
    [2048] = "11",
    [4096] = "12",
    [8192] = "13",
    [16384] = "14",
    [32768] = "15",
    [65536] = "16",
    [131072] = "17",
    [262144] = "18",
    [524288] = "19",
    [1048576] = "20",
}
SYS_CAP_TDS_BAND = {
    [1] = "A",
    [2] = "B",
    [4] = "C",
    [8] = "D",
    [16] = "E",
    [32] = "F",
}
SYS_PRODUCT_TYPE = {
    [0] = "SMARTPHONE",
    [1] = "DATACARD",
}
SYS_FCC_LOCK_MODE = {
}
SYS_FCC_LOCK_STATE = {
}
SYS_CONFIG_CLASS = {
    [0] = "GENERAL_MD_CONFIG",
    [1] = "LEGACY_MD_CONFIG",
    [2] = "HOST_RELAY_DIPC_CONFIG",
    [3] = "N3X_CONFIG",
    [4] = "IWLAN_CONFIG",
}
IMS_CONFIG_CLASS = {
    [0] = "IMS_FEATURE",
    [1] = "IMS_CONFIG",
    [2] = "IMS_PROVISION",
    [3] = "IMS_CAPABILITY",
}
IMS_CONFIG_IND_REASON = {
    [0] = "IMS_READY",
    [1] = "USER_CHANGE",
}
IMS_IND_TYPE = {
    [0] = "NOTIFY",
    [1] = "INIT",
    [2] = "REJECT",
    [127] = "MAX",
}
IMS_STATE_IND_EVENT = {
    [0] = "REG_STATE",
    [1] = "WFC",
    [2] = "REG_URI",
    [3] = "REG_RESP",
}
IMS_STATE = {
    [0] = "UNREGISTERED",
    [1] = "REGISTERED",
    [2] = "UNREGISTERING",
    [3] = "REGISTERING",
    [4] = "REREGISTERING",
}
IMS_SUB_STATE = {
    [0] = "UNSPECIFIED",
    [1] = "UNREGISTERED",
    [2] = "REGISTERED",
    [3] = "UNREGISTERING",
    [4] = "REGISTERING",
    [5] = "REREGISTERING",
    [6] = "OOS",
}
IMS_REG_TYPE = {
    [0] = "NORMAL_SERVICE",
    [1] = "EMERGENCY_SERVICE",
}
IMS_REG_ERR_CODE = {
    [0] = "SIP_OK",
    [1] = "SIP_NO_RESOURCE",
    [2] = "SIP_INVALID_UA_ID",
    [3] = "SIP_INVALID_DIALOG_ID",
    [4] = "SIP_INVALID_UA_STATE",
    [5] = "SIP_INVALID_REQ_ID",
    [6] = "SIP_UNSUPPORTED_METHOD",
    [8] = "SIP_BEARER_ERROR",
    [9] = "SIP_SOCKET_ERROR",
    [10] = "SIP_BEARER_TIMEOUT_ERROR",
    [17] = "SIP_WOULDBLOCK",
    [18] = "SIP_HEADER_NOT_FOUND",
    [19] = "SIP_NO_MEMORY",
    [20] = "SIP_INVALID_PARAM",
    [21] = "SIP_NO_SIP_MSG",
    [22] = "SIP_NO_UA_DISPATCHER",
    [23] = "SIP_NO_URI",
    [24] = "SIP_OP_ALREADY",
    [25] = "SIP_OP_NOT_ALLOW",
    [26] = "SIP_FS_ERROR",
    [27] = "SIP_DNS_ERROR",
    [28] = "SIP_EARLY_NOTIFY",
    [29] = "SIP_DHCP_ERROR",
    [30] = "SIP_INVALID_CONN_ID",
    [31] = "SIP_INVALID_DNS_ID",
    [32] = "SIP_SOCKET_BIND_ERROR",
    [33] = "SIP_TOO_LONG_MESSAGE",
    [99] = "SIP_UNSPECIFIED_ERROR",
    [100] = "SIP_100_TRYING",
    [180] = "SIP_180_RINGING",
    [181] = "SIP_181_CALL_FORWARDED",
    [182] = "SIP_182_QUEUED",
    [183] = "SIP_183_SESSION_PROGRESS",
    [199] = "SIP_199_EARLY_DIALOG_TERMINATED",
    [200] = "SIP_200_OK",
    [202] = "SIP_202_ACCEPTED",
    [300] = "SIP_300_MULTIPLE_CHOICES",
    [301] = "SIP_301_MOVED_PERMANENTLY",
    [302] = "SIP_302_MOVED_TEMPORARILY",
    [305] = "SIP_305_USE_PROXY",
    [380] = "SIP_380_ALTERNATIVE_SERVICE",
    [400] = "SIP_400_BAD_REQUEST",
    [401] = "SIP_401_UNAUTHORIZED",
    [402] = "SIP_402_PAYMENT_REQUIRED",
    [403] = "SIP_403_FORBIDDEN",
    [404] = "SIP_404_NOT_FOUND",
    [405] = "SIP_405_METHOD_NOT_ALLOW",
    [406] = "SIP_406_NOT_ACCEPTABLE",
    [407] = "SIP_407_PROXY_AUTH_REQUIRED",
    [408] = "SIP_408_REQUEST_TIMEOUT",
    [409] = "SIP_409_CONFLICT",
    [410] = "SIP_410_GONE",
    [411] = "SIP_411_LENGTH_REQUIRED",
    [412] = "SIP_412_CONDITIONAL_REQ_FAIL",
    [413] = "SIP_413_REQUEST_ENTITY_TOO_LARGE",
    [414] = "SIP_414_REQUEST_URI_TOO_LARGE",
    [415] = "SIP_415_UNSUPPORTED_MEDIA_TYPE",
    [416] = "SIP_416_UNSUPPORTED_SCHEME",
    [420] = "SIP_420_BAD_EXTENSION",
    [421] = "SIP_421_EXTENSION_REQUIRED",
    [422] = "SIP_422_INTERVAL_TOO_BRIEF",
    [423] = "SIP_423_INTERVAL_TOO_BRIEF",
    [429] = "SIP_429_PROVIDE_REFERRER_ID",
    [433] = "SIP_433_ANONYMITY_DISALLOWED",
    [480] = "SIP_480_TEMP_UNAVAILABLE",
    [481] = "SIP_481_CALL_TRANS_NOT_EXIST",
    [482] = "SIP_482_LOOP_DETECTED",
    [483] = "SIP_483_TOO_MANY_HOPS",
    [484] = "SIP_484_ADDRESS_INCOMPLETE",
    [485] = "SIP_485_AMBIGUOUS",
    [486] = "SIP_486_BUSY_HERE",
    [487] = "SIP_487_REQ_TERMINATED",
    [488] = "SIP_488_NOT_ACCEPTABLE_HERE",
    [489] = "SIP_489_BAD_EVENT",
    [491] = "SIP_491_REQUEST_PENDING",
    [493] = "SIP_493_UNDECIPHERABLE",
    [494] = "SIP_494_SECURITY_AGREEMENT_REQUIRED",
    [499] = "SIP_499_CLIENT_CLOSED_REQUEST",
    [500] = "SIP_500_SERVER_INT_ERROR",
    [501] = "SIP_501_NOT_IMPLEMENTED",
    [502] = "SIP_502_BAD_GATEWAY",
    [503] = "SIP_503_SERVICE_UNAVAILABLE",
    [504] = "SIP_504_SERVER_TIMEOUT",
    [505] = "SIP_505_SIP_VERSION_NOT_SUPPORTED",
    [513] = "SIP_513_MESSAGE_TOO_LARGE",
    [580] = "SIP_580_PRECONDITION_FAILURE",
    [600] = "SIP_600_BUSY_EVERYWHERE",
    [603] = "SIP_603_DECLINE",
    [604] = "SIP_604_DOES_NOT_EXIST_ANYWHERE",
    [605] = "SIP_605_DECLINE_EVERYWHERE",
    [606] = "SIP_606_NOT_ACCEPTABLE",
    [607] = "SIP_607_UNWANTED",
    [608] = "SIP_608_REJECTED",
}
IMS_PDN_ERR_CAUSE = {
    [1] = "ERR_CAUSE_NONE",
    [8] = "OPERATOR_DETERMINED_BARRING",
    [26] = "INSUFFICIENT_RESOURCES",
    [27] = "UNKNOWN_OR_MISSING_APN",
    [28] = "UNKNOWN_PDN_TYPE",
    [29] = "USER_AUTHENTICATION_FAILED",
    [30] = "REQUEST_REJECTED_BY_SERVING_GW_OR_PDN_GW",
    [31] = "REQUEST_REJECTED_UNSPECIFIED",
    [32] = "SERVICE_OPTION_NOT_SUPPORTED",
    [33] = "REQUESTED_SERVICE_OPTION_NOT_SUBSCRIBED",
    [34] = "SERVICE_OPTION_TEMPORARILY_OUT_OF_ORDER",
    [35] = "PTI_ALREADY_IN_USE",
    [36] = "REGULAR_DEACTIVATION",
    [37] = "EPS_QOS_NOT_ACCEPTED",
    [38] = "NETWORK_FAILURE",
    [39] = "REACTIVATION_REQUESTED",
    [41] = "SEMANTIC_ERROR_IN_THE_TFT_OPERATION",
    [42] = "SYNTACTICAL_ERROR_IN_THE_TFT_OPERATION",
    [43] = "INVALID_EPS_BEARER_OR_PDU_SESSION_IDENTITY",
    [44] = "SEMANTIC_ERRORS_IN_PACKET_FILTER",
    [45] = "SYNTACTICAL_ERROR_IN_PACKET_FILTER",
    [46] = "OUT_OF_LAND_SERVICE_AREA",
    [47] = "PTI_MISMATCH",
    [49] = "LAST_PDN_DISCONNECTION_NOT_ALLOWED",
    [50] = "PDN_TYPE_IPV4_ONLY_ALLOWED",
    [51] = "PDN_TYPE_IPV6_ONLY_ALLOWED",
    [52] = "SINGLE_ADDRESS_BEARERS_ONLY_ALLOWED",
    [53] = "ESM_INFORMATION_NOT_RECEIVED",
    [54] = "PDN_CONNECTION_OR_PDU_SESSION_DOES_NOT_EXIST",
    [55] = "MULTIPLE_PDN_CONNECTIONS_FOR_A_GIVEN_APN_NOT_ALLOWED",
    [56] = "COLLISION_WITH_NETWORK_INITIATED_REQUEST",
    [57] = "PDN_TYPE_IPV4V6_ONLY_ALLOWED",
    [58] = "PDN_TYPE_NON_IP_ONLY_ALLOWED",
    [59] = "UNSUPPORTED_QCI_VALUE",
    [60] = "BEARER_HANDLING_NOT_SUPPORTED",
    [65] = "MAXIMUM_NUM_OF_EPS_BEARERS_REACHED",
    [66] = "REQUESTED_APN_NOT_SUPPORTED_IN_CURRENT_RAT_AND_PLMN_COMBINATION",
    [67] = "INSUFFICIENT_RESOURCES_FOR_SPECIFIC_SLICE_AND_DNN",
    [68] = "NOT_SUPPORTED_SSC_MODE",
    [69] = "INSUFFICIENT_RESOURCES_FOR_SPECIFIC_SLICE",
    [70] = "MISSING_OR_UNKNOWN_DNN_IN_A_SLICE",
    [81] = "INVALID_PTI_VALUE",
    [82] = "MAX_DATA_RATE_PER_UE_FOR_USER_PLANE_INTGRITY_PROTECTION_IS_TO_LOW",
    [83] = "SEMANTIC_ERROR_IN_THE_QOS_OPERATION",
    [84] = "SYNTACTICAL_ERROR_IN_THE_QOS_OPERATION",
    [95] = "SEMANTICALLY_INCORRECT_MESSAGE",
    [96] = "INVALID_MANDATORY_INFORMATION",
    [97] = "MESSAGE_TYPE_NON_EXISTENT_OR_NOT_IMPLEMENTED",
    [98] = "MESSAGE_TYPE_NOT_COMPATIBLE_WITH_PROTOCOL_STATE",
    [99] = "INFORMATION_ELEMENT_NON_EXISTENT_OR_NOT_IMPLEMENTED",
    [100] = "CONDITIONAL_IE_ERROR",
    [101] = "MESSAGE_NOT_COMPATIBLE_WITH_PROTOCOL_STATE",
    [111] = "PROTOCO_ERROR_UNSPECIFIED",
    [112] = "APN_RESTRICTION_VALUE_INCOMPATIBLE_WITH_ACTIVE_EPS_BEARER_CONTEXT",
    [113] = "MULTIPLE_ACCESSES_TO_PDN_CONNECTION_NOT_ALLOWED",
}
IMS_ECC_IND_RAT = {
    [0] = "GSM",
    [1] = "WCDMA",
    [2] = "TD_SCDMA",
    [3] = "FDD_LTE",
    [4] = "TDD_LTE",
}
IMS_REPORT_STATUS = {
    [0] = "DISABLE_STATUS",
    [1] = "ENABLE_STATUS",
    [2] = "MAX",
}
IMS_ADDITION_SERVICE = {
    [0] = "CALL_COMPOSER",
    [16] = "INVALID_SERVICE",
}
NW_IMS_VOPS_STATUS = {
    [0] = "NOT_REV_FROM_NW",
    [1] = "REV_FROM_NW",
    [2] = "MAX",
}
SYS_CONFIG_CHANGE_REASON = {
    [0] = "SIM_READY",
    [1] = "USER_CHANGE",
}
SYS_ADPCLK_STATE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
SYS_MCF_OP = {
    [0] = "SET_OTA_AND_OPOTA_FILE_PATH",
    [1] = "SET_OTA_FILE_PATH",
    [2] = "SET_OPOTA_FILE_PATH",
    [3] = "SET_FILE_PATH_IN_MCF_DSBP_ACTIVE_MODE",
    [4] = "GET_APPLIED_FILE_PATH",
    [5] = "DUMP_LID_DATA",
    [6] = "SET_FILE_PATH_AND_AUTO_SELECT_BIN",
    [7] = "UPDATE_OPOTA_FILE",
    [8] = "INI_OPERATION",
    [9] = "LID_VARIABLE_OPERATION",
    [10] = "QUERY_VARIABLE_VALUE",
    [11] = "ASSIGN_COMBINED_PATH",
}
SYS_MCF_CONFIG_TYPE = {
    [0] = "DEFAULT_BIN",
    [1] = "CARRIER_BIN",
    [2] = "GENERAL_CARRIER_BIN",
    [3] = "RAW_BIN",
    [4] = "NETWORK_BIN",
    [5] = "GENERAL_NETWORK_BIN",
    [127] = "MAX",
}
SYS_MCF_PATH_TYPE = {
    [0] = "OTA",
    [1] = "RUNTIME",
    [2] = "MANUAL",
    [127] = "MAX",
}
SYS_SAR_MODE = {
    [0] = "BY_DEVICE",
    [1] = "BY_HOST",
}
SYS_ACCOUNT_ID = {
    [0] = "SIM1_NORMAL",
    [1] = "SIM1_EMERGENCY",
    [2] = "SIM2_NORMAL",
    [3] = "SIM2_EMERGENCY",
    [100] = "FROM_IWLAN",
}
SYS_WAKEUP_REASON = {
    [0] = "WAKEUP_REASON_INVALID",
    [1] = "WAKEUP_REASON_SCHEDULED",
    [2] = "WAKEUP_REASON_SMS",
    [3] = "WAKEUP_REASON_MT_INBAND_CALL",
    [4] = "WAKEUP_REASON_NO_SERVICE",
    [5] = "WAKEUP_REASON_IP_PACKET",
    [12] = "WAKEUP_REASON_PKT_SRVC_STATUS",
    [13] = "WAKEUP_REASON_EXTENDED_IP_CONFIG",
    [14] = "WAKEUP_REASON_NAS",
    [15] = "WAKEUP_REASON_VOICE",
    [16] = "WAKEUP_REASON_IND_UIM",
}
SYS_RAT_MODE = {
    [0] = "GSM",
    [1] = "WCDMA",
    [2] = "CDMA",
    [3] = "LTE",
    [4] = "NR",
}
SYS_TAS_ACTION = {
    [0] = "DISABLE_COMMAND",
    [1] = "TAS_DISABLE",
    [2] = "TAS_ENABLE",
}
MD_INIT_ID = {
    [1] = "SMS_READY",
    [2] = "PHB_READY",
    [8] = "CHANGE_EONS_FILE",
    [16] = "INVALID_SIM",
    [32] = "PHB_NOT_READY",
    [64] = "TCM_READY",
}
SYS_DSBP_MODE = {
    [0] = "DISABLE",
    [1] = "ENABLE_IMS",
    [2] = "ENABLE_ALL",
    [3] = "DYNAMIC_LEVEL",
    [127] = "MAX",
}
SYS_SBP_MODE = {
    [0] = "SET_SBP_ID",
    [1] = "SET_CONFIG_WITH_FEATURE_INT",
    [2] = "SET_DATA_WITH_FEATURE_INT",
    [3] = "GET_CONFIG_WITH_FEATURE_INT",
    [4] = "GET_DATA_WITH_FEATURE_INT",
    [5] = "SET_CONFIG_WITH_FEATURE_STR",
    [6] = "SET_DATA_WITH_FEATURE_STR",
    [7] = "GET_CONFIG_WITH_FEATURE_STR",
    [8] = "GET_DATA_WITH_FEATURE_STR",
}
SYS_SBP_SET_MODE = {
    [0] = "SET_SBP_ID",
    [1] = "SET_CONFIG_WITH_FEATURE_INT",
    [2] = "SET_DATA_WITH_FEATURE_INT",
    [5] = "SET_CONFIG_WITH_FEATURE_STR",
    [6] = "SET_DATA_WITH_FEATURE_STR",
}
SYS_SBP_GET_MODE = {
    [3] = "GET_CONFIG_WITH_FEATURE_INT",
    [4] = "GET_DATA_WITH_FEATURE_INT",
    [7] = "GET_CONFIG_WITH_FEATURE_STR",
    [8] = "GET_DATA_WITH_FEATURE_STR",
}
LOG_MODE = {
    [0] = "DISABLED_MODE",
    [1] = "STREAMING_MODE",
    [2] = "WRAPPING_MODE",
}
SYS_LOG_FLUSH_TRIGGER_RESULT = {
    [0] = "SUCCESS",
    [1] = "PENDING",
    [2] = "NO_DATA",
    [3] = "HAS_MORE_DATA_TO_HANDLE",
    [4] = "ERROR",
    [5] = "SERVICE_NOT_SUPPORT",
    [6] = "SERVICE_NOT_READY",
    [7] = "SERVICE_OPENED",
    [8] = "SERVICE_EXIST",
    [9] = "RESOURCE_NOT_ENOUGH",
    [10] = "INTERNAL_ERROR",
    [11] = "INPUT_DATA_INVAID",
    [12] = "PROCEDURE_IS_ONGOING",
    [13] = "DATA_FLOW_OR_CHANNEL_UNAVAILABLE",
    [14] = "LOG_MODE_INVALID",
    [15] = "TIMEOUT",
}
SYS_MD_LOG_RESULT = {
    [0] = "SUCCESS",
    [1] = "PENDING",
    [2] = "NO_DATA",
    [3] = "HAS_MORE_DATA_TO_HANDLE",
    [4] = "ERROR",
    [5] = "SERVICE_NOT_IMPLEMENT",
    [6] = "SERVICE_NOT_READY",
    [7] = "SERVICE_OPENED",
    [8] = "SERVICE_EXIST",
    [9] = "RESOURCE_NOT_ENOUGH",
    [10] = "INTERNAL_ERROR",
    [11] = "INPUT_DATA_INVAID",
    [12] = "PROCEDURE_IS_ONGOING",
    [13] = "DATA_FLOW_OR_CHANNEL_UNAVAILABLE",
    [14] = "LOG_MODE_INVALID",
    [15] = "TIMEOUT",
    [16] = "SERVICE_NOT_SUPPORT",
    [17] = "BUF_OVERFLOW",
    [18] = "VERSION_MISMATCH",
    [19] = "CMD_NOT_ALLOWED",
}
SYS_HBA_CTRL_MODE = {
    [0] = "PAUSE",
    [1] = "STOP",
    [127] = "INVALID",
}
SYS_SET_RECORDING_TX_COND_IQ_DUMP_REQ_CAPTURE_MODE = {
    [0] = "RA",
    [1] = "SR",
    [2] = "PUSCH",
    [3] = "ACK",
    [4] = "SRS",
}
SYS_SPV_CONTROL_TYPE = {
    [0] = "SSS",
    [1] = "SSPROF",
    [2] = "ELM",
    [3] = "BUSMON",
    [4] = "PDAMON",
    [5] = "SWLA",
}
SYS_PMIC_TYPE = {
    [0] = "DCL_BUCK_CPU",
    [1] = "DCL_BUCK_GPU",
    [2] = "DCL_BUCK_MD",
    [3] = "DCL_BUCK_RF",
    [4] = "DCL_MAIN_PMIC",
    [5] = "DCL_BUCK_VPU",
    [6] = "DCL_SUB_PMIC",
    [7] = "DCL_CLOCK_PMIC",
    [8] = "DCL_SECOND_PMIC",
    [9] = "DCL_SECOND_PMIC_P",
    [10] = "DCL_NR",
}
SYS_IDC_PERIOD_TYPE = {
    [0] = "DOWNLINK",
    [1] = "UPLINK",
    [2] = "BI_DIRECTIONAL",
    [3] = "GUARD_PERIOD",
}
SYS_IDC_CHANNEL_TYPE = {
    [0] = "TDD",
    [1] = "FDD",
}
SYS_TIME_IND_TYPE = {
    [1] = "CIEV",
    [2] = "CTZEU",
}
SYS_FORWARD_AT_REQ_FORWARD_TYPE = {
    [0] = "URC",
    [1] = "RSP",
}
MSPM_SESSION_TYPE = {
    [0] = "SESSION_START",
    [1] = "SESSION_START_NTF",
    [2] = "SESSION_END_NTF",
}
MSPM_BLOCK_MODE = {
    [0] = "MSPM_BLOCK_NONE",
    [1] = "MSPM_BLOCK",
}
MSPM_SIM_INDEX_ENUM = {
    [0] = "MSPM_SIM1",
    [1] = "MSPM_SIM2",
    [2] = "MSPM_SIM3",
    [3] = "MSPM_SIM4",
    [255] = "MSPM_SIM_NONE",
}
MSPM_PROCEDURE_ENUM = {
    [1] = "MSPM_OTTAPP_VVTOP",
    [2] = "MSPM_NDDS_DATA_VALIDATION_SESSION",
    [3] = "MSPM_IMS_RE_REG",
    [4] = "MSPM_IMS_REG_INITIAL",
    [5] = "MSPM_IMS_REG_INITIAL_LOW",
    [6] = "MSPM_IMS_SUBSCRIBE",
    [7] = "MSPM_IMS_SUBSCRIBE_HIGH",
    [8] = "MSPM_IMS_USSD",
    [9] = "MSPM_IMS_CONF_SUBSCRIBE",
    [10] = "MSPM_IMS_MWI_SUBSCRIBE",
    [11] = "MSPM_IMS_CALLPULL_SUBSCRIBE",
    [12] = "MSPM_IMS_CALL_ENDING",
    [13] = "MSPM_IMS_DSDA_CALL_RINGING",
    [14] = "MSPM_IMS_ACTIVE_CALL_SESSION",
    [15] = "MSPM_IMS_MO_CALL",
    [16] = "MSPM_PROTECT_PRESENCE",
}
MSPM_PROCEDURE_CAUSE_ENUM = {
    [0] = "MSPM_PROCEDURE_FAIL",
    [1] = "MSPM_PROCEDURE_SUCCESS",
    [2] = "MSPM_PROCEDURE_USER_TERMINATION",
}
APN_PDP_TYPE = {
    [0] = "DEFAULT",
    [1] = "IPV4",
    [2] = "IPV6",
    [3] = "IPV4V6",
    [4] = "IPV4_AND_IPV6",
    [5] = "ETHERNET",
}
DEACT_REASON_ENUM = {
    [0] = "DONT_CARE",
    [1] = "DEACT_NORMAL",
    [3] = "DEACT_NO_PCSCF",
    [6] = "DEACT_FORCE_TO_LOCAL_RELEASE",
    [7] = "DEACT_AOSP_SHUTDOWN",
    [8] = "DEACT_AOSP_HANDOVER",
    [9] = "DEACT_APN_CHANGED",
    [10] = "DEACT_IMS_HANDOVER",
    [11] = "DEACT_TEMP_DATA_SWITCH",
    [20] = "DEACT_IPCA",
    [127] = "MAX",
}
APN_ENABLED_TYPE = {
    [0] = "DISABLED",
    [1] = "ENABLED",
    [2] = "MAX",
}
PACKET_FILTER_IP_TYPE = {
    [0] = "IPV4",
    [1] = "IPV6",
    [2] = "IP_ALL",
    [127] = "MAX",
}
PACKET_FILTER_PROTOCOL_TYPE = {
    [0] = "TCP",
    [1] = "UDP",
    [2] = "ICMP",
    [3] = "PROTOCOL_ALL",
    [127] = "MAX",
}
IA_MD_PREFER_TYPE = {
    [0] = "DISABLE_MD_PREFER",
    [1] = "ENABLE_MD_PREFER",
    [2] = "MAX",
}
EIF_ADDRESS_TYPE = {
    [0] = "DEFAULT",
    [1] = "IPV4",
    [2] = "IPV6",
    [3] = "IPV4V6",
}
MBS_OP = {
    [0] = "INVALID",
    [1] = "JOIN_MBS_SESSION",
    [2] = "LEAVE_MBS_SESSION",
}
MBS_DECISION = {
    [0] = "INVALID",
    [1] = "SERVICE_AREA_UPDATE",
    [2] = "JOIN_ACCEPTED",
    [3] = "JOIN_REJECTED",
    [4] = "REMOVE_UE_FROM_MBS_SESSION",
    [160] = "VGSM_AREA_CHECK_FAIL",
    [161] = "VGSM_TIMER_CHECK_FAIL",
}
MBS_REJECT_CAUSE = {
    [0] = "NONE",
    [1] = "INSUFFICIENT_RESOURCES",
    [2] = "USER_NOT_AUTHORIZED_TO_USE_SRV",
    [3] = "SESSION_NOT_STARTED_OR_WILL_NOT_START_SOON",
    [4] = "USER_OUTSIDE_MBS_AREA",
    [5] = "SESSION_CONTEXT_NOT_FOUND",
    [6] = "SESSION_IS_RELEASED",
}
MBS_SESSION_ID_TYPE = {
    [0] = "INVALID",
    [1] = "TMGI",
    [2] = "IPV4",
    [3] = "IPV6",
}
SUBWAY_CELL_TYPE = {
    [0] = "INVALID",
    [1] = "PLATFORM",
    [2] = "TUNNEL",
}
APN_AUTH_TYPE = {
    [0] = "NONE",
    [1] = "PAP",
    [2] = "CHAP",
    [3] = "PAP_OR_CHAP",
}
APN_TYPE = {
    [0] = "UNKNOWN",
    [1] = "DEFAULT",
    [2] = "IMS",
    [4] = "MMS",
    [8] = "SUPL",
    [16] = "DUN",
    [32] = "HIPRI",
    [64] = "FOTA",
    [128] = "CBS",
    [256] = "EMERGENCY",
    [512] = "IA",
    [1024] = "DM",
    [2048] = "WAP",
    [4096] = "NET",
    [8192] = "CMMAIL",
    [16384] = "TETHERING",
    [32768] = "RCSE",
    [65536] = "XCAP",
    [131072] = "RCS",
    [262144] = "RCS_PCSCF",
    [524288] = "VSIM",
    [1048576] = "BIP",
    [2097152] = "PTT",
    [2147483648] = "NW_ASSIGNED",
}
APN_COMPRESSION = {
    [0] = "NONE",
    [1] = "ENABLE",
}
APN_CHANGE_REASON = {
    [0] = "DEFAULT",
    [1] = "IMS_HANDOVER",
}
APN_PROFILE_MODE = {
    [0] = "HOST_NOT_SET_APN_PROFILE",
    [1] = "HOST_SET_APN_PROFILE",
}
DATA_FALLBACK_TYPE = {
    [0] = "DISABLE",
    [1] = "IPV4_FIRST",
    [2] = "IPV6_FIRST",
    [127] = "MAX",
}
MIPC_CID_ACT_STATE = {
    [0] = "DEACTIVATED",
    [1] = "ACTIVATED",
}
DATA_REUSE_TYPE = {
    [0] = "DEFAULT",
    [1] = "USER_SETTING_FIRST",
    [2] = "NOT_REUSE",
    [3] = "REUSE_ONLY",
}
DATA_CONFIG_TYPE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
    [2] = "NO_CHANGE",
}
DATA_RETRY_MODE = {
    [0] = "QUERY_TIMER",
    [1] = "RESET_TIMER",
    [2] = "RETRY_AFTER_TIMER",
}
DATA_RETRY_TYPE = {
    [0] = "RETRY_TYPE_NO_SUGGEST",
    [1] = "RETRY_TYPE_NO_RETRY",
    [2] = "RETRY_TYPE_WITH_SUGGEST",
}
DATA_LCE_MODE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
    [2] = "SET",
}
DATA_KEEPALIVE_STATUS_CODE = {
    [0] = "ACTIVE",
    [1] = "INACTIVE",
    [2] = "PENDING",
}
DATA_KEEPALIVE_TYPE = {
    [0] = "NATT_IPV4",
    [1] = "NATT_IPV6",
    [2] = "IPV4_TCP",
    [3] = "IPV4_UDP",
    [4] = "IPV6_TCP",
    [5] = "IPV6_UDP",
}
DATA_LGDCONT_REQ_TYPE = {
    [0] = "NEW_PDP_OR_HANDOVER",
    [1] = "EMERGENCY_PDP",
    [2] = "NEW_PDP",
    [3] = "HANDOVER",
    [4] = "EMERGENCY_HANDOVER",
}
DATA_LGDCONT_RAT_TYPE = {
    [0] = "All_RAT",
    [1] = "RAT_23G",
    [2] = "RAT_4G",
}
DATA_BIND_TYPE = {
    [0] = "NOT_BIND_RNDIS",
    [1] = "BIND_RNDIS",
}
DATA_CALL_IND_RSP = {
    [0] = "ACT_CALL_IND_NOT_NEED",
    [1] = "ACT_CALL_IND_NEED",
    [2] = "DEACT_CALL_IND",
    [127] = "MAX",
}
EXTERNAL_PDN_STATUS = {
    [0] = "DEACTIVATED",
    [1] = "ACTIVATING",
    [2] = "ACTIVATED",
}
DATA_MOD_EVENT_TYPE = {
    [0] = "INFORMATIONAL_EVENT",
    [1] = "ACKNOWLEDGEMENT_REQUIRED",
}
DATA_PAGING_RESTRICTIONS = {
    [0] = "NOT_RESTRICTED",
    [1] = "ALL_RESTRICTED",
    [2] = "RESTRICTED_EXCEPT_VOICE",
    [3] = "RESTRICTED_EXCEPT_SPECIFIED_PDX_CONN",
    [4] = "RESTRICTED_EXCEPT_VOICE_AND_SPECIFIED_PDX_CONN",
}
DATA_PAGING_RESTRICT_RESULT = {
    [0] = "REJECTED",
    [1] = "ACCEPTED",
}
IPC_PACKET_ROUTE_APP_ID_ENUM = {
    [0] = "IPC_PACKET_ROUTE_APP_ID_NONE",
    [1] = "IPC_PACKET_ROUTE_APP_ID_EAP_WIFI",
    [2] = "IPC_PACKET_ROUTE_APP_ID_EAP_IMS",
    [11] = "EAP_PUBLIC_WIFI_1",
    [15] = "EAP_TUNNEL_WIFI_1",
    [16] = "EAP_TUNNEL_WIFI_2",
    [17] = "EAP_TUNNEL_WIFI_3",
    [18] = "EAP_TUNNEL_WIFI_4",
    [19] = "EAP_TUNNEL_WIFI_5",
    [20] = "EAP_TUNNEL_WIFI_6",
    [21] = "EAP_TUNNEL_WIFI_7",
    [22] = "EAP_TUNNEL_WIFI_8",
}
DATA_HANDOVER_STATE = {
    [0] = "START",
    [1] = "END",
}
DATA_IMS_BEARER_STATE = {
    [0] = "START",
    [1] = "STOP",
}
DATA_IMS_BEARER_TYPE = {
    [0] = "SIP",
    [1] = "NON_SIP",
    [2] = "VOICE",
    [3] = "VIDEO",
    [4] = "TEXT",
    [5] = "DATA",
}
DATA_IMS_BEARER_PDP_TYPE = {
    [1] = "IPV4",
    [2] = "IPV6",
}
DATA_IWLAN_TYPE = {
    [0] = "UNSPECIFIED",
    [1] = "WLAN",
    [2] = "DATA1",
    [4] = "DATA2",
    [8] = "DATA3",
    [16] = "DATA4",
}
BEARER_BITMASK = {
    [0] = "UNKNOWN",
    [4096] = "LTE",
    [131072] = "IWLAN",
    [524288] = "NR",
}
DATA_DIRECTION = {
    [0] = "DOWNLINK",
    [1] = "UPLINK",
}
ANBR_REPORT = {
    [0] = "STOP",
    [1] = "START",
}
ANBRQ_CONFIG_REPORT = {
    [0] = "STOP",
    [1] = "START",
}
ANBRQ = {
    [0] = "NOT_SUPPORTED",
    [1] = "SUPPORTED",
}
MIPC_EIWLPL_PRIORITY_TYPE = {
    [0] = "START",
    [1] = "NULL",
    [2] = "CELLULAR",
    [3] = "WIFI",
    [4] = "CELLULAR_GREATER_THAN_WIFI",
    [5] = "WIFI_GREATER_THAN_CELLULAR",
    [6] = "END",
}
INTERNAL_EIF_REQ_CMD = {
    [0] = "IFUP",
    [1] = "IFDOWN",
    [2] = "IPUPDATE",
    [3] = "IFQUERY",
    [4] = "NO_RA_INITIAL",
    [5] = "NO_RA_REFRESH",
    [6] = "IPADD",
    [7] = "IPDEL",
    [8] = "IPCHG",
}
INTERNAL_EIF_IND_CMD = {
    [0] = "IFUP",
    [1] = "IFDOWN",
    [4] = "IPCHG",
    [5] = "IFCHANGE",
    [6] = "MTU",
}
INTERNAL_EIPPORT_ACTION = {
    [0] = "ALLOC",
    [1] = "FREE",
}
INTERNAL_EIPPORT_RESULT = {
    [0] = "FAILURE",
    [1] = "SUCCESS",
}
INTERNAL_EIPSPI_ACTION = {
    [0] = "ALLOC",
    [1] = "FREE",
}
INTERNAL_HO_PROGRESS = {
    [0] = "START",
    [1] = "STOP_SUCCESS",
    [255] = "STOP_FAILED",
    [1] = "END",
    [2] = "IP_READY",
    [127] = "MAX",
}
INTERNAL_IT_CATEGORY = {
    [0] = "MAL_IT",
}
DSDA_ALLOWED_TYPE = {
    [0] = "NOT_ALLOWED",
    [1] = "ALLOWED",
    [127] = "MAX",
}
DSDA_STATE_TYPE = {
    [0] = "ACTIVE",
    [1] = "POSSIBLE",
    [2] = "NOT_POSSIBLE",
    [127] = "MAX",
}
DR_DSDA_TYPE = {
    [0] = "DSDA",
    [1] = "DR_DSDA",
    [127] = "MAX",
}
DR_DSDS_TYPE = {
    [0] = "DSDA",
    [1] = "DR_DSDS",
    [127] = "MAX",
}
PSI_ACTION_ENUM = {
    [0] = "RELEASE",
    [1] = "OCCUPY",
    [2] = "QUERY",
    [3] = "INJECT",
    [4] = "REQUIRE",
    [127] = "MAX",
}
SSC_MODE_ENUM = {
    [0] = "NONE",
    [1] = "SSC_MODE_1",
    [2] = "SSC_MODE_2",
    [3] = "SSC_MODE_3",
    [127] = "MAX",
}
URSP_ROUTE_SUPP_PROFILE_TYPE_ENUM = {
    [1] = "REQ",
    [2147483647] = "MAX",
}
URSP_REEVAL_TYPE_ENUM = {
    [1] = "PERIODIC",
    [2] = "PDU_REL",
    [3] = "PCF_UPDATE",
    [4] = "INTER_SYS",
    [5] = "REG",
    [6] = "WLAN_EST",
    [7] = "WLAN_REL",
    [8] = "ALLOWED_NSSAI",
    [9] = "LADN",
    [2147483647] = "MAX",
}
NSSAI_TYPE_ENUM = {
    [0] = "DEFAULT_CONFIGURED_NSSAI",
    [1] = "DEFAULT_CONFIGURED_AND_REJECT_NSSAI",
    [2] = "DEFAULT_CONFIGURED_AND_REJECT_AND_CONFIGURED_NSSAI",
    [3] = "DEFAULT_CONFIGURED_AND_REJECT_AND_CONFIGURED_AND_ALLOWED_NSSAI",
    [127] = "MAX",
}
NW_RADIO_STATE = {
    [0] = "OFF",
    [1] = "ON",
}
NW_RADIO_STATE_CAUSE = {
    [0] = "UNSPECIFIED",
    [1] = "DUPLEX_MODE_CHANGE",
    [2] = "POWER_OFF",
    [3] = "SIM_SWITCH",
    [128] = "POWER_EPOF",
    [129] = "ENTER_AOC50",
    [130] = "GRACEFUL_POWER_OFF",
}
NW_PROVIDER_STATE = {
    [0] = "UNKNOWN",
    [1] = "AVAILABLE",
    [2] = "CURRENT",
    [3] = "FORBIDDEN",
}
NW_REGISTER_MODE = {
    [0] = "AUTOMATIC",
    [1] = "MANUAL",
    [2] = "DEREGISTER",
    [4] = "MANUAL_EXT",
    [5] = "SEMI_AUTO",
    [7] = "SPECIFY_SEARCH",
}
NW_REGISTER_STATE = {
    [0] = "NOT_REGISTERED",
    [1] = "HOME",
    [2] = "SEARCHING",
    [3] = "DENIED",
    [4] = "UNKNOWN",
    [5] = "ROAMING",
    [6] = "HOME_SMS_ONLY",
    [7] = "ROAMING_SMS_ONLY",
    [8] = "ATTACHED_ECC_ONLY",
    [9] = "HOME_CSFB_NOT_PREF",
    [10] = "ROAMING_CSFB_NOT_PREF",
}
NW_PS = {
    [0] = "DETACH",
    [1] = "ATTACH",
}
NW_IA = {
    [0] = "DETACH",
    [1] = "ATTACH",
}
NW_FAST_DORMANCY = {
    [0] = "DISABLE",
    [1] = "ENABLE",
    [2] = "SET_TIMER",
    [3] = "SCREEN_STATUS",
}
NW_BLACKLIST_TYPE = {
    [0] = "SIM",
    [1] = "NETWORK",
}
NW_CELL_TYPE = {
    [0] = "NONE",
    [1] = "GSM",
    [2] = "CDMA",
    [3] = "LTE",
    [4] = "UMTS",
    [5] = "TD_SCDMA",
    [6] = "NR",
    [7] = "NSA_EXT",
}
NW_CH_LOCK = {
    [0] = "CANCEL",
    [1] = "ENABLE_CH_LK_EM",
    [2] = "ENABLE_CH_LK_CBRS",
    [3] = "CONFIG_CH_LK_CBRS",
}
NW_CH_LOCK_MODE = {
    [0] = "IDLE_MODE_ONLY",
    [1] = "IDLE_MR",
    [2] = "IDLE_HOCCO",
    [3] = "IDLE_AND_CONNECTED",
    [255] = "UNCHANGED",
}
NW_DATA_SPEED = {
    [0] = "NONE_SPECIFIED",
    [1] = "GPRS",
    [2] = "EDGE",
    [4] = "UMTS",
    [8] = "HSDPA",
    [16] = "HSUPA",
    [24] = "HSDPA_UPA",
    [32] = "HSDPAP",
    [48] = "HSDPAP_UPA",
    [64] = "HSUPAP",
    [72] = "HSUPAP_DPA",
    [96] = "HSPAP",
    [136] = "DC_DPA",
    [152] = "DC_DPA_UPA",
    [160] = "DC_HSDPAP",
    [176] = "DC_HSDPAP_UPA",
    [200] = "DC_HSUPAP_DPA",
    [224] = "DC_HSPAP",
    [256] = "1XRTT",
    [512] = "HRPD",
    [1024] = "EHRPD",
    [4096] = "LTE",
    [4112] = "IOTNTN",
    [8192] = "LTE_CA",
    [16384] = "ENDC",
    [32768] = "NR",
    [65535] = "NOT_CHANGE",
}
NW_SIGNAL_TYPE = {
    [0] = "GSM",
    [1] = "UMTS",
    [2] = "LTE",
    [3] = "NR",
    [4] = "NR_NSA",
    [5] = "CDMA",
}
NW_CSCON_MODE = {
    [0] = "IDLE",
    [1] = "CONNECTED",
    [255] = "UNKNOWN",
}
NW_CSCON_STATE = {
    [0] = "UTRAN_URA_PCH",
    [1] = "UTRAN_CELL_PCH",
    [2] = "UTRAN_CELL_FACH",
    [3] = "UTRAN_CELL_DCH",
    [4] = "GERAN_CS_CONNECTED",
    [5] = "GERAN_PS_CONNECTED",
    [6] = "GERAN_CS_PS_CONNECTED",
    [7] = "EUTRAN_CONNECTED",
    [8] = "NR_RAN_CONNECTED",
    [8] = "NR_RAN_INACTIVE",
    [255] = "UNKNOWN",
}
NW_CSCON_ACCESS = {
    [0] = "GERAN",
    [1] = "UTRAN_TDD",
    [2] = "UTRAN_FDD",
    [3] = "EUTRAN_TDD",
    [4] = "EUTRAN_FDD",
    [5] = "NR",
    [255] = "UNKNOWN",
}
NW_CSCON_CORE_NETWORK = {
    [0] = "EPC",
    [1] = "5GCN",
    [255] = "UNKNOWN",
}
NW_PREFER_RAT_TYPE = {
    [1] = "GSM",
    [2] = "UMTS",
    [4] = "LTE",
    [128] = "NR",
}
NW_LTE_CARRIER_ARRREGATION_SWITCH = {
    [0] = "TURNOFF",
    [1] = "TURNON",
}
NW_PS_CS_REG_STATE = {
    [0] = "IN_SERVICE",
    [1] = "OUT_OF_SERVICE",
    [2] = "EMERGENCY_ONLY",
    [3] = "POWER_OFF",
}
NW_PS_CS_ROAMING_TYPE = {
    [0] = "NOT_ROAMING",
    [1] = "UNKNOWN",
    [2] = "DOMESTIC",
    [3] = "INTERNATIONAL",
}
NW_RIL_PS_CS_REG_STATE = {
    [0] = "NOT_REGISTERED_AND_NOT_SEARCHING",
    [1] = "HOME_NETWORK",
    [2] = "NOT_REGISTERED_AND_SEARCHING",
    [3] = "REG_DENIED",
    [4] = "UNKNOWN",
    [5] = "ROAMING",
    [6] = "GOOGLE_UNDEFINED1",
    [7] = "GOOGLE_UNDEFINED2",
    [8] = "GOOGLE_UNDEFINED3",
    [9] = "GOOGLE_UNDEFINED4",
    [10] = "NOT_REGISTERED_AND_NOT_SEARCHING_EMERGENCY_CALL_ENABLED",
    [11] = "GOOGLE_UNDEFINED5",
    [12] = "NOT_REGISTERED_AND_SEARCHING_EMERGENCY_CALL_ENABLED",
    [13] = "REG_DENIED_EMERGENCY_CALL_ENABLED",
    [14] = "UNKNOWN_EMERGENCY_CALL_ENABLED",
    [15] = "GOOGLE_UNDEFINED6",
}
NW_CELLMEASUREMENT_SCAN_TYPE = {
    [0] = "ONLINE_CUS_DEP",
    [1] = "OFFLINE",
    [2] = "ONLINE_NETWORK_DEP",
}
NW_CELLMEASUREMENT_BIT_RAT = {
    [4] = "LTE",
    [128] = "NR",
}
NW_BAND_OPTION = {
    [0] = "CURRENT_SETTING",
    [1] = "SYSTEM_SUPPORT",
}
NW_SIGNAL_THRESHOLD_MODE = {
    [0] = "MAP_VALUE",
    [1] = "RAW",
}
NW_ROAMING_MODE = {
    [0] = "DIS_NONE",
    [1] = "DIS_INTERNATIONAL",
    [2] = "DIS_NATIONAL",
    [4] = "DIS_H_P_PLMN_SEARCH",
}
NW_ANTENNA_PLATFORM = {
    [0] = "VZ_6290",
    [1] = "VZ_6292",
    [2] = "VZ_6294",
}
NW_CELL_CONNECTION_STATE = {
    [0] = "NONE_SERVING",
    [1] = "PRIMARY_SERVING",
    [2] = "SECONDARY_SERVING",
}
NW_RAT_SWITCH_MODE = {
    [0] = "NONE",
    [1] = "NSA_SCG",
    [2] = "NSA_SCG_ALLOW",
    [3] = "NSA_TAU",
    [4] = "SA_ONLY",
    [5] = "SA_TAU",
    [6] = "BOTH",
    [7] = "BOTH_TAU",
    [8] = "ALL",
    [9] = "RRC_STATE",
}
NW_IND_TYPE = {
    [1] = "ECELL",
}
NW_PS_CTRL_MODE = {
    [0] = "CGATT",
    [1] = "EGTYPE",
}
NW_ACT_TYPE = {
    [0] = "GSM",
    [2] = "UMTS",
    [3] = "EGPRS",
    [4] = "HSDPA",
    [5] = "HSUPA",
    [6] = "HSDPA_HSPUPA",
    [7] = "LTE",
    [11] = "NR",
    [12] = "NG_RAN",
    [13] = "ENDC",
    [255] = "INVALID",
}
NW_PS_TEST_MODE = {
    [0] = "NONE",
    [1] = "CTA",
    [2] = "FTA",
    [3] = "IOT",
    [4] = "OPERATOR",
    [5] = "FACTORY",
}
NW_SIGNAL_MEASUREMENT_TYPE = {
    [1] = "RSSI",
    [2] = "RSCP",
    [3] = "RSRP",
    [4] = "RSRQ",
    [5] = "RSSNR",
    [6] = "SSRSRP",
    [7] = "SSRSRQ",
    [8] = "SSSINR",
    [9] = "ECN0",
}
NW_SIGNAL_RAT = {
    [1] = "GSM",
    [2] = "UMTS",
    [3] = "LTE",
    [4] = "C2K",
    [5] = "NR",
}
NW_BIT_RAT = {
    [1] = "GSM_BIT",
    [2] = "UMTS_BIT",
    [4] = "LTE_BIT",
    [8] = "NR_BIT",
    [16] = "C2K_BIT",
    [32] = "IOTNTN_BIT",
}
NW_BIT_ACT = {
    [1] = "GSM_ACTN_BIT",
    [2] = "GSM_COMPACT_ACTN_BIT",
    [4] = "UTRAN_ACTN_BIT",
    [8] = "E_UTRAN_ACTN_BIT",
    [16] = "NG_RAN_ACTN_BIT",
}
NW_IWLAN_STATUS = {
    [0] = "NOT_READY",
    [1] = "READY",
}
NW_CA_MODE = {
    [0] = "TURN_OFF",
    [1] = "TURN_ON",
}
NW_CLEAR_NSSAI_TYPE = {
    [0] = "CLEAR_NSSAI_CONFIG_ALL",
    [1] = "CLEAR_PREFERRED_NON3GPP_NSSAI_CONFIG",
    [2] = "CLEAR_PREFERRED_3GPP_NSSAI_CONFIG",
    [3] = "CLEAR_PREFERRED_ALL_NSSAI_CONFIG",
    [4] = "CLEAR_DEFAULT_NSSAI_CONFIG",
}
RX_MIMO_CTRL_OPERATION = {
    [0] = "CTRL_OPERATION_RESET",
    [1] = "CTRL_OPERATION_FORCED_1RX",
    [2] = "CTRL_OPERATION_FORCED_2RX",
    [3] = "CTRL_OPERATION_FORCED_4RX",
}
RX_MIMO_RELEASE_LEVEL = {
    [0] = "RELEASE_LEVEL_NO_NEED_RELEASE",
    [1] = "RELEASE_LEVEL_ATTEMP_RELEASE",
    [2] = "RELEASE_LEVEL_FORCED_RELEASE",
}
LTE_RRC_STATE = {
    [0] = "NULL",
    [1] = "IDLE",
    [2] = "ATMPT_CONNECTION",
    [3] = "CONNECTED",
    [4] = "ENDING",
}
CELL_LIST_TYPE = {
    [0] = "AVAILABLE",
    [1] = "UNAVAILABLE",
}
CA_LINK_MODE = {
    [0] = "DOWNLINK",
    [1] = "DOWNLIINK_AND_UPLINK",
}
CA_LINK_ENABLE_MODE = {
    [2] = "DOWNLINK",
    [3] = "UPLINK",
}
BAND_COMBO_ENABLE_STATUS = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
TM9_ENABLE_STATUS = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
TM9_SETTING_TYPE = {
    [0] = "FDD",
    [1] = "TDD",
}
OMADM_NODE_TYPE = {
    [0] = "AUTONOMOUS_GAP",
    [1] = "MPSR_DURATION",
    [2] = "SCAN_DURATION",
    [3] = "SLEEP_DURATION",
    [4] = "MPSR_MAX_DURATION",
    [5] = "LONG_MPSR_DURATION",
    [6] = "TPLMN_BARRING_TIMER",
    [7] = "LTE_HPUE",
}
CA_COMB_LIST_TYPE = {
    [0] = "WHITE",
    [1] = "BLACK",
}
NW_SET_CA_RAT = {
    [0] = "ALL",
    [1] = "LTE",
}
NITZ_IND_TYPE = {
    [0] = "CIEV",
    [1] = "CTZEU",
}
NW_TUW_ID = {
    [1] = "TUW1",
    [2] = "TUW2",
    [3] = "TUW3",
}
NW_CH_INFO_RAT = {
    [1] = "GSM",
    [2] = "UMTS",
    [4] = "LTE",
    [128] = "NR",
}
NW_ALLOWED_MCC_LIST_ACTION = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
NW_VG_OPTION_OPERATION = {
    [0] = "VG_OPTION_OPERATION_NONE",
    [1] = "VG_OPTION_OPERATION_LOCAL_RELEASE",
    [2] = "VG_OPTION_OPERATION_LOCAL_RELEASE_NR_SEARCH",
}
NW_SERVING_MEASUREMNT_RAT = {
    [4] = "LTE",
    [128] = "NR",
}
LTE_EVENT_TYPE = {
    [1] = "A1",
    [2] = "A2",
    [3] = "A3",
    [4] = "A4",
    [5] = "A5",
    [6] = "B1_GSM",
    [7] = "B2_GSM",
    [8] = "B1_UMTS",
    [9] = "B2_UMTS",
    [10] = "B1_NR",
    [11] = "B2_NR",
}
SIGNAL_QUALITY_TYPE = {
    [1] = "RSRP",
    [2] = "RSRQ",
    [3] = "SINR",
    [4] = "RSSI",
    [5] = "RSCP",
    [6] = "ECNO",
}
NW_SCAN_ACTION = {
    [1] = "START",
    [2] = "STOP",
    [3] = "HOLD",
    [4] = "HOLD_AND_RESET",
}
NW_SERVICE_SCAN_TYPE = {
    [1] = "NORMAL",
    [2] = "EMERGENCY",
}
NW_EMC_SCAN_TYPE = {
    [0] = "NO_PREFERENCE",
    [1] = "FULL_SERVICE",
    [2] = "LIMITED_SERVICE",
}
NW_SERVICE_DOMAIN = {
    [0] = "UNKNOWN",
    [1] = "CS",
    [2] = "PS",
    [3] = "CS_PS",
}
NW_SCAN_RAT = {
    [1] = "GSM",
    [2] = "UMTS",
    [4] = "LTE",
    [16] = "C2K",
    [128] = "NR",
}
NW_SCAN_TYPE = {
    [0] = "ONE_SHOT",
    [1] = "PERIODIC",
}
NW_INCREMENTAL_RESULTS = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
NW_SCAN_STATUS = {
    [0] = "PARTIAL",
    [1] = "COMPLETE",
}
NW_PLMN_STATUS = {
    [0] = "INVALID",
    [1] = "AVAILABLE",
    [2] = "CURRENT",
    [3] = "FORBIDDEN",
}
NW_REGISTER_STATUS = {
    [0] = "NOT_REGISTERED",
    [1] = "REGISTERED",
}
NW_SRV_CELL_STATUS = {
    [0] = "NONE",
    [1] = "PRIMARY",
    [2] = "SECONDARY",
}
NW_BW_CHECK = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
NW_5GUC_STATE = {
    [0] = "NOT_DISPLAY",
    [1] = "DISPLAY",
}
NW_UC_BAND = {
    [0] = "NOT_ON",
    [1] = "ON",
}
NW_EDRX_ACCESS_TECHNOLOGY_ENUM = {
    [0] = "NOT_USED",
    [1] = "EC_GSM_IOT",
    [2] = "ACT_GSM",
    [3] = "ACT_UTRAN",
    [4] = "ACT_EUTRAN_WB",
    [5] = "ACT_EUTRAN_NB",
    [6] = "ACT_SATELLITE_EUTRAN_NB",
    [7] = "ACT_SATELLITE_EUTRAN_WB",
    [8] = "ACT_NGRAN",
    [9] = "ACT_SATELLITE_NGRAN",
    [255] = "ACT_INVALID",
}
NW_PSM_MODE_ENUM = {
    [0] = "POWER_SAVING_MODE_DISABLE",
    [1] = "POWER_SAVING_MODE_ENABLE",
    [2] = "POWER_SAVING_MODE_DISABLE_AND_DISCARD_PARAM",
}
N3_POWER_STATE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
N3_REG_STATE = {
    [0] = "NOT_REGISTERED",
    [1] = "REGISTERED",
    [2] = "SEARCHING",
    [3] = "REG_DENIED",
    [4] = "UNKNOWN",
    [5] = "EMERGENCY_ONLY",
}
N3_DEVICE_TYPE = {
    [0] = "NONE",
    [1] = "WLAN",
    [2] = "DATA_1",
    [3] = "DATA_2",
    [4] = "DATA_3",
    [5] = "DATA_4",
    [6] = "BLUETOOTH",
    [7] = "WIRE",
    [8] = "UNKNOWN",
}
NW_BASEMENT_STATUS = {
    [0] = "ENTER",
    [1] = "LEAVE",
    [2] = "UNKNOWN",
}
NW_CAG_INFO_FORMAT = {
    [0] = "ALPHANUMERIC",
    [1] = "NUMERIC",
}
NW_CAG_MODE = {
    [0] = "AUTOMATIC",
    [1] = "MANUAL",
}
NW_CELLULAR_ID_TYPE = {
    [0] = "ID_TYPE_INVALID",
    [1] = "ID_TYPE_IMSI",
    [2] = "ID_TYPE_IMEI",
    [3] = "ID_TYPE_UNCIPHERED_SUCI",
}
NW_NAS_MSG_TYPE = {
    [0] = "NAS_MSG_TYPE_INVALID",
    [1] = "ATTACH_REQUEST",
    [2] = "IDENTITY_RESPONSE",
    [3] = "DETACH_REQUEST",
    [4] = "TRACKING_AREA_UPDATE_REQUEST",
    [5] = "LOCATION_UPDATE_REQUEST",
    [6] = "AUTHENTICATION_AND_CIPHERING_RESPONSE",
    [7] = "REGISTRATION_REQUEST",
    [8] = "DEREGISTRATION_REQUEST",
    [9] = "CM_REESTABLISHMENT_REQUEST",
    [10] = "CM_SERVICE_REQUEST",
    [11] = "IMSI_DETACH_INDICATION",
}
NW_CONFIG_RESULT = {
    [0] = "SUCCESS",
    [1] = "BUSY",
    [2] = "FAILURE",
    [3] = "NOT_SUPPORT",
}
NW_CONNECTION_EVENT = {
    [0] = "CS_SIGNALING_GSM",
    [1] = "PS_SIGNALING_GPRS",
    [2] = "CS_SIGNALING_UMTS",
    [3] = "PS_SIGNALING_UMTS",
    [4] = "NAS_SIGNALING_LTE",
    [5] = "AS_SIGNALING_LTE",
    [6] = "VOLTE_SIP",
    [7] = "VOLTE_SIP_SOS",
    [8] = "VOLTE_RTP",
    [9] = "VOLTE_RTP_SOS",
    [10] = "NAS_SIGNALING_5G",
    [11] = "AS_SIGNALING_5G",
    [12] = "VONR_SIP",
    [13] = "VONR_SIP_SOS",
    [14] = "VONR_RTP",
    [15] = "VONR_RTP_SOS",
    [255] = "INVALID_CONNECTION_EVENT",
}
NW_INTEGRITY_ALGO = {
    [14] = "GSM_IA0",
    [15] = "GSM_IA1",
    [16] = "GSM_IA2",
    [17] = "GSM_IA3",
    [18] = "GSM_IA4",
    [19] = "GSM_IA5",
    [29] = "UMTS_IA0",
    [30] = "UMTS_IA1",
    [31] = "UMTS_IA2",
    [41] = "LTE_IA0",
    [42] = "LTE_IA1",
    [43] = "LTE_IA2",
    [44] = "LTE_IA3",
    [55] = "NR_IA0",
    [56] = "NR_IA1",
    [57] = "NR_IA2",
    [58] = "NR_IA3",
    [66] = "SIP_NO_IPSEC_INTEGRITY_ALGO",
    [68] = "SIP_NULL_INTEGRITY",
    [70] = "SIP_AES_GMAC",
    [74] = "SIP_HMAC_SHA1_96",
    [75] = "SIP_HMAC_MD5_96",
    [85] = "RTP",
    [86] = "SRTP_NULL",
    [89] = "SRTP_HMAC_SHA1",
    [255] = "INVALID_INTEGRITY_ALGO",
}
NW_ENCRYPTION_ALGO = {
    [0] = "GSM_A5_0",
    [1] = "GSM_A5_1",
    [2] = "GSM_A5_2",
    [3] = "GSM_A5_3",
    [4] = "GSM_A5_4",
    [14] = "GSM_EA0",
    [15] = "GSM_EA1",
    [16] = "GSM_EA2",
    [17] = "GSM_EA3",
    [18] = "GSM_EA4",
    [19] = "GSM_EA5",
    [29] = "UMTS_EA0",
    [30] = "UMTS_EA1",
    [31] = "UMTS_EA2",
    [41] = "LTE_EA0",
    [42] = "LTE_EA1",
    [43] = "LTE_EA2",
    [44] = "LTE_EA3",
    [55] = "NR_EA0",
    [56] = "NR_EA1",
    [57] = "NR_EA2",
    [58] = "NR_EA3",
    [66] = "SIP_NO_IPSEC_ENCRYPTION_CONFIG",
    [67] = "IMS_NULL",
    [68] = "SIP_NULL_ENCRYPTION",
    [69] = "SIP_AES_GCM",
    [70] = "SIP_AES_GMAC",
    [71] = "SIP_AES_CBC",
    [72] = "SIP_DES_EDE3_CBC",
    [73] = "AES_EDE3_CBC",
    [74] = "HMAC_SHA1_96",
    [75] = "HMAC_MD5_96",
    [85] = "RTP",
    [86] = "SRTP_NULL",
    [87] = "SRTP_AES_COUNTER",
    [88] = "SRTP_AES_F8",
    [89] = "SRTP_HMAC_SHA1",
    [99] = "ENCR_AES_GCM_16",
    [100] = "ENCR_AES_CBC",
    [101] = "AUTH_HMAC_SHA2_256_128",
    [113] = "UNKNOWN_ENCRYPTION_ALGO",
    [114] = "OTHER_ENCRYPTION_ALGO",
    [124] = "OPYX_ENCRYPTION_ALGO",
    [255] = "INVALID_ENCRYPTION_ALGO",
}
RELEASE_PREFERENCE_UAI_REPORT_STATUS = {
    [1] = "NW_CONFIGURED",
    [2] = "NW_NOT_CONFIGURED",
    [3] = "REPORT_SENT",
    [4] = "REPORT_NOT_SENT_TIMER",
    [5] = "REPORT_NOT_SENT_SAME",
    [6] = "REPORT_NOT_SENT_OTHER",
}
UE_PREFERRED_RRC_STATE = {
    [0] = "IDLE",
    [1] = "INACTIVE",
    [2] = "CONNECTED",
    [3] = "OUT_OF_CONNECTED",
}
NRRC_PREFERENCE_REPORT_STATUS = {
    [0] = "INVALID",
    [1] = "NW_CONFIGURED",
    [2] = "NW_NOT_CONFIGURED",
    [3] = "REPORT_SENT",
    [4] = "REPORT_NOT_SENT_TIMER",
    [5] = "REPORT_NOT_SENT_SAME",
    [6] = "REPORT_NOT_SENT_OTHER",
}
OVERHEATING_UAI_REPORT_STATUS = {
    [1] = "NW_CONFIGURED",
    [2] = "NW_NOT_CONFIGURED",
    [3] = "REPORT_SENT",
    [4] = "REPORT_NOT_SENT_TIMER",
    [5] = "REPORT_NOT_SENT_SAME",
    [6] = "REPORT_NOT_SENT_OTHER",
}
NRRC_TIMER_NAME = {
    [0] = "T300",
    [1] = "T301",
    [2] = "T302",
    [3] = "T304",
    [4] = "T311",
    [5] = "T319",
    [6] = "T320",
    [7] = "T321",
    [8] = "T325",
    [9] = "T380",
    [10] = "T390",
    [11] = "T304_SCG",
    [12] = "T346C_MCG",
    [13] = "T346C_SCG",
    [14] = "T346D_MCG",
    [15] = "T346D_SCG",
    [16] = "T346F",
    [17] = "T342",
    [18] = "T345",
    [19] = "T346A_MCG",
    [20] = "T346A_SCG",
    [21] = "T346B_MCG",
    [22] = "T346B_SCG",
    [23] = "T346E_MCG",
    [24] = "T346E_SCG",
}
NRRC_TIMER_STATUS = {
    [0] = "STARTED",
    [1] = "STOPPED",
    [2] = "EXPIRED",
    [3] = "CONFIGURED",
}
NW_HANDOVER_TYPE = {
    [1] = "3G_TO_3G",
    [2] = "3G_TO_4G",
    [3] = "4G_TO_3G",
    [4] = "4G_TO_4G",
    [5] = "4G_TO_5G",
    [6] = "5G_TO_4G",
    [7] = "5G_TO_5G",
}
NW_HANDOVER_RESULT_TYPE = {
    [1] = "SUCCESS",
    [2] = "FAILURE",
}
NW_HANDOVER_RAT_TYPE = {
    [2] = "WCDMA",
    [7] = "LTE",
    [11] = "NR",
}
NW_ENABLE_N1_S1_ACTION = {
    [0] = "UPDATE_CAP_ONLY",
    [1] = "UPDATE_CAP_AND_FORCE_RELEASE",
    [2] = "FORCE_SEARCH",
}
SIM_STATUS = {
    [0] = "NOT_INSERT",
    [1] = "BUSY",
    [2] = "READY",
    [3] = "SIM_PIN",
    [4] = "SIM_PUK",
    [5] = "PH_SIM_PIN",
    [6] = "PH_FSIM_PIN",
    [7] = "PH_FSIM_PUK",
    [8] = "SIM_PIN2",
    [9] = "SIM_PUK2",
    [10] = "PH_NET_PIN",
    [11] = "PH_NET_PUK",
    [12] = "PH_NETSUB_PIN",
    [13] = "PH_NETSUB_PUK",
    [14] = "PH_SP_PIN",
    [15] = "PH_SP_PUK",
    [16] = "PH_CORP_PIN",
    [17] = "PH_CORP_PUK",
    [18] = "CARD_REBOOT",
    [19] = "CARD_RESTRICTED",
    [20] = "EMPT_EUICC",
    [21] = "COMPLETE_READY",
}
SIM_STATE = {
    [0] = "UNKNOWN",
    [1] = "OFFEMPTY",
    [2] = "OFF",
    [3] = "EMPTY",
    [4] = "NOTREADY",
    [5] = "ACTIVE",
    [6] = "ERROR",
    [7] = "ACTIVE_ESIM",
    [8] = "ACTIVE_ESIM_NOPROFILE",
}
SIM_CARD_PRESENT_STATE = {
    [0] = "ABSENT",
    [1] = "PRESENT",
    [2] = "ERROR",
    [3] = "RESTRICTED",
}
SIM_SUB_STATE = {
    [0] = "UNKNOWN",
    [1] = "PLUG_IN",
    [2] = "PLUG_OUT",
    [3] = "RECOVERY_START",
    [4] = "RECOVERY_EN",
}
SIM_PIN_TYPE = {
    [0] = "NONE",
    [1] = "PIN1",
    [2] = "PIN2",
    [3] = "PUK1",
    [4] = "PUK2",
    [5] = "NW",
    [6] = "SUB_NW",
    [7] = "SP",
    [8] = "CORP",
    [9] = "SIM",
    [10] = "NS_SP",
    [11] = "SIM_C",
    [12] = "PUK_N",
    [13] = "PUK_NS",
    [14] = "PUK_SP",
    [15] = "PUK_C",
    [16] = "PUK_SIM",
    [17] = "PUK_NS_SP",
    [18] = "PUK_SIM_C",
}
SIM_PIN_PROTECTION = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
SIM_PIN_MODE = {
    [0] = "NOT_SUPPORT",
    [1] = "ENABLE",
    [2] = "DISABLE",
}
SIM_PIN_FORMAT = {
    [0] = "UNKNOWN",
    [1] = "NUMERIC",
    [2] = "ALPHA_NUMERIC",
}
SIM_PIN_STATE = {
    [0] = "UNLOCKED",
    [1] = "LOCKED",
}
SIM_PIN_OPERATION = {
    [0] = "ENTER",
    [1] = "ENABLE",
    [2] = "DISABLE",
    [3] = "CHANGE",
}
SIM_PASS_THROUGH_MODE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
    [255] = "INVALID",
}
SIM_APP_TYPE = {
    [0] = "UNKNOWN",
    [1] = "MF",
    [2] = "MFSIM",
    [3] = "MFRUIM",
    [4] = "USIM",
    [5] = "CSIM",
    [6] = "ISIM",
}
SIM_APP_TYPE_EX = {
    [0] = "ISIM",
    [1] = "USIM",
    [2] = "CSIM",
    [3] = "SIM",
    [4] = "UIM",
    [255] = "UNKNOWN",
}
SIM_ACCESS_COMMAND = {
    [176] = "READ_BINARY",
    [178] = "READ_RECORD",
    [192] = "GET_RESPONSE",
    [214] = "UPDATE_BINARY",
    [220] = "UPDATE_RECORD",
    [242] = "STATUS",
    [203] = "RETRIEVE_DATA",
    [219] = "SET_DATA",
}
SIM_FILE_ACCESSIBILITY = {
    [0] = "UNKNOWN",
    [1] = "NOTSHAREABLE",
    [2] = "SHAREABLE",
}
SIM_FILE_TYPE = {
    [0] = "UNKNOWN",
    [1] = "WORKING_EF",
    [2] = "INTERNAL_EF",
    [3] = "DF_OR_ADF",
}
SIM_FILE_STRUCTURE = {
    [0] = "UNKNOWN",
    [1] = "TRANSPARENT",
    [2] = "CYCLIC",
    [3] = "LINEAR",
    [4] = "BERTLV",
}
PIN_STATE = {
    [0] = "UNKNOWN",
    [1] = "ENABLED_NOT_VERIFIED",
    [2] = "ENABLED_VERIFIED",
    [3] = "DISABLED",
    [4] = "ENABLED_BLOCKED",
    [5] = "ENABLED_PERM_BLOCKED",
}
SIM_APP_STATE = {
    [0] = "UNKNOWN",
    [1] = "DETECTED",
    [2] = "PIN",
    [3] = "PUK",
    [4] = "SUBSTATE",
    [5] = "READY",
}
SIM_APP_SUB_STATUS = {
    [0] = "UNKNOWN",
    [1] = "IN_PROGRESS",
    [2] = "READY",
    [3] = "NW",
    [4] = "NW_PUK",
    [5] = "SUB_NW",
    [6] = "SUB_NW_PUK",
    [7] = "CORP",
    [8] = "CORP_PUK",
    [9] = "SP",
    [10] = "SP_PUK",
    [11] = "IMSI",
    [12] = "IMSI_PUK",
    [13] = "LINK_NS_SP",
    [14] = "LINK_NS_SP_PUK",
    [15] = "LINK_SIM_C",
    [16] = "LINK_SIM_C_PUK",
}
SIM_CAUSE = {
    [0] = "CARD_REMOVED",
    [1] = "ACCESS_ERROR",
    [2] = "SIM_REFRESH",
    [3] = "SIM_REFRESH_POWER_OFF",
    [4] = "SIM_PUK1",
    [5] = "SIM_ACCESS_PROFILE_ON",
    [6] = "SIM_ACCESS_PROFILE_OFF",
    [7] = "DUAIL_DISCONNECTED",
    [8] = "DUAIL_CONNECTED",
    [9] = "SIM_VSIM_ON",
    [10] = "SIM_VSIM_OFF",
    [11] = "SIM_PLUG_OUT",
    [12] = "SIM_PLUG_IN",
    [13] = "SIM_RECOVERY_START",
    [14] = "SIM_RECOVERY_END",
    [15] = "SIM_IMEI_LOCK_FAIL",
    [16] = "SIM_OP09_LOCK_FAIL",
    [17] = "SIM_CARD_TECHNICAL_PROBLEM",
    [18] = "SIM_POWER_OFF_BY_L4",
    [19] = "SIM_OP20_IMEI_LOCK",
    [20] = "SIM_PLUG_IN_REPLACED",
    [21] = "SIM_OP01_LOCK",
    [22] = "SIM_OP01_UNLOCK",
    [23] = "SIM_FAST_RECOVERY_START",
    [24] = "SIM_FAST_RECOVERY_SUCCESS",
    [25] = "SIM_TRAY_PLUG_OUT",
    [26] = "SIM_PLUG_IN_NO_INIT",
    [27] = "SIM_PRESENCE_DETECTION_FAIL",
    [28] = "SIM_STATE_DISABLE",
    [29] = "SIM_STATE_ENABLE",
}
SIM_ADDITIONAL_CAUSE = {
    [0] = "SIM_REFRESH_TYPE_NAA_INIT_AND_FULL_FCN",
    [1] = "SIM_REFRESH_TYPE_FCN",
    [2] = "SIM_REFRESH_TYPE_NAA_INIT_AND_FCN",
    [3] = "SIM_REFRESH_TYPE_NAA_INIT",
    [4] = "SIM_REFRESH_TYPE_SIM_RESET",
    [5] = "SIM_REFRESH_TYPE_NAA_APP_RESET",
    [6] = "SIM_REFRESH_TYPE_NAA_SESSION_RESET",
    [7] = "SIM_REFRESH_TYPE_STEERING_OF_ROAMING",
    [8] = "SIM_REFRESH_TYPE_STEERING_OF_ROAMING_FOR_IWLAN",
    [9] = "SIM_REFRESH_TYPE_EUICC_PROFILE",
    [255] = "SIM_REFRESH_END",
}
SIM_VSIM_TYPE = {
    [0] = "SIM_TYPE_LOCAL_SIM",
    [1] = "SIM_TYPE_REMOTE_SIM",
}
SIM_VSIM_AUTH_MODE = {
    [0] = "RELEASING_RF",
    [1] = "OCCUPING_RF",
}
SIM_POWER_STATE = {
    [0] = "OFF",
    [1] = "ON",
}
SIM_CRRST_STATE = {
    [0] = "SIM_CRRST_STATE_NULL",
    [1] = "SIM_CRRST_STATE_LOCKED",
    [2] = "SIM_CRRST_STATE_UNLOCKED",
    [3] = "SIM_CRRST_STATE_DISABLED",
}
SIM_CARRIER_RESTRICTION_STATUS = {
    [0] = "SIM_CARRIER_RESTRICTION_STATUS_UNKNOWN",
    [1] = "SIM_CARRIER_RESTRICTION_STATUS_NOT_RESTRICTED",
    [2] = "SIM_CARRIER_RESTRICTION_STATUS_RESTRICTED",
}
SIM_SML_CATEGORY = {
    [0] = "CAT_N",
    [1] = "CAT_NS",
    [2] = "CAT_SP",
    [3] = "CAT_CORP",
    [4] = "CAT_SIM",
    [5] = "CAT_NS_SP",
    [6] = "CAT_SIM_CORP",
    [7] = "CAT_SIZE",
    [8] = "CAT_DUAL_SIM_LOCK_CONTROL",
    [9] = "CAT_MASTER_KEY",
    [255] = "CAT_UNKNOWN",
}
SIM_SML_OPERATION = {
    [0] = "UNLOCK",
    [1] = "LOCK",
    [2] = "ADD",
    [3] = "REMOVE",
    [4] = "DISABLE",
    [5] = "UPDATE_AUTOLOCK_COUNT",
}
SIM_SML_RSU_OPERATION = {
    [1] = "INIT",
    [2] = "UPDATE_LOCK_DATA",
    [3] = "GET_LOCK_STATUS",
    [4] = "UNLOCK_TIMER",
    [5] = "GET_SHARED_KEY",
    [6] = "GET_LOCK_VERSION",
    [7] = "GET_LOCK_DATA",
    [8] = "SET_LOCK_DATA_MORE",
    [9] = "SET_LOCK_DATA_DONE",
    [8] = "GET_ALLOWED_LOCK_DATA",
    [9] = "GET_EXCLUDED_LOCK_DATA",
    [10] = "GET_MD_CONFIG",
    [11] = "GET_API_VERSION",
    [12] = "GET_SIM_SLOTS",
    [13] = "RESET_LOCK_DATA",
    [14] = "VERIFY_TF_STATUS",
    [15] = "GET_IMEI",
    [16] = "GET_SIGNED_TOKEN",
    [17] = "RELOCK",
}
SML_RSU_REQUEST_TYPE = {
    [0] = "STOP",
    [1] = "START",
}
SIM_FCP_CONVERT = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
SIM_EVENT = {
    [0] = "NULL",
    [1] = "APP_INIT",
    [2] = "APP_LIST",
    [3] = "DATA_ICON_READY",
    [4] = "FCP_CACHE_READY",
    [5] = "DATA_CACHE_READY",
}
SIM_MEP_MODE = {
    [0] = "NONE",
    [1] = "MEP_A1",
    [2] = "MEP_A2",
    [3] = "MEP_B",
}
SMS_STATE = {
    [0] = "NOT_INITIALIZED",
    [1] = "INITIALIZED",
}
SMS_FORMAT = {
    [0] = "PDU",
    [1] = "TEXT",
    [2] = "CDMA",
    [3] = "PDU_3GPP",
    [4] = "PDU_3GPP2",
    [253] = "QUERY",
    [254] = "NULL",
    [255] = "INVALID",
}
SMS_CBM_TYPE = {
    [1] = "ETWS_PRIMARY",
    [2] = "ETWS_SECONDARY",
    [4] = "CMAS",
    [2147483648] = "OTHERS",
}
SMS_ETWS_PRIMARY_TYPE = {
    [1] = "ETWS_PRIMARY",
    [2] = "ETWS_PRIMARY_WITH_SECURITY_CHECK",
    [4] = "ETWS_PRIMARY_FOR_TEST",
}
SMS_FLAG = {
    [0] = "ALL",
    [1] = "NEW",
    [2] = "OLD",
    [3] = "SENT",
    [4] = "DRAFT",
    [5] = "INDEX",
    [255] = "INVALID",
}
SMS_STATUS = {
    [0] = "REC_UNREAD",
    [1] = "REC_READ",
    [2] = "STO_UNSENT",
    [3] = "STO_SENT",
    [255] = "INVALID",
}
SMS_CLASS = {
    [0] = "0",
    [1] = "1",
    [2] = "2",
    [3] = "3",
    [254] = "NONE",
    [255] = "INVALID",
}
SMS_STORE_FLAG = {
    [0] = "NONE",
    [1] = "STORE_FULL",
    [2] = "NEW_MESSAGE",
    [4] = "STORE_FULL_SIM",
    [8] = "STORE_FULL_ME",
    [16] = "STORE_FULL_UIM",
    [32] = "NEW_SMS_C2K",
}
SMS_STORAGE = {
    [0] = "SIM",
    [1] = "ME",
    [2] = "TE",
    [3] = "UIM",
    [4] = "MT",
    [253] = "QUERY",
    [254] = "NULL",
    [255] = "INVALID",
}
SMS_ACK = {
    [0] = "NONEED",
    [1] = "NEEDED",
    [253] = "QUERY",
    [254] = "NULL",
    [255] = "INVALID",
}
NEW_SMS_ACK = {
    [0] = "RP_ACK",
    [1] = "RP_ERROR",
    [255] = "INVALID",
}
SMS_SEND_SAVE = {
    [0] = "NO_SAVE",
    [1] = "SAVE_IN_SIM",
    [255] = "INVALID",
}
SMS_MORE_MSG_TO_SEND = {
    [0] = "DISABLE",
    [1] = "ENABLE_ONCE",
    [2] = "ENABLE_ALWAYS",
    [254] = "NULL",
    [255] = "INVALID",
}
SMS_CBM_CFG_TYPE = {
    [1] = "ALLOW",
    [2] = "BAN",
    [253] = "QUERY",
}
SMS_SCBM_STATUS = {
    [0] = "EXIT",
    [1] = "ENTERED",
    [2] = "DISABLED",
    [3] = "REINITED",
}
SMS_C2K_ERR_CLASS = {
    [0] = "NO_ERR",
    [2] = "TEMP",
    [3] = "PERMANENT",
    [255] = "INVALID",
}
SMS_TEXT_MODE_PARAM_ACTION = {
    [1] = "SET",
    [253] = "QUERY",
    [254] = "NULL",
    [255] = "INVALID",
}
SMS_C2K_ERR_CODE = {
    [14] = "FDN_CHECK",
    [107] = "RUIM_ABSENT",
}
SMS_HANDLE_MODE = {
    [1] = "RELAY",
    [2] = "SAVE",
}
SMS_MD_STORAGE = {
    [1] = "SIM",
    [2] = "NV",
    [3] = "SIM_NV",
    [4] = "UIM",
}
SMS_ACK_MODE = {
    [1] = "HOST",
    [2] = "MD",
}
SMS_STANDARD = {
    [1] = "3GPP",
    [2] = "3GPP2",
}
SMS_ACTION = {
    [1] = "SET",
    [2] = "GET",
}
SMS_CGSMS = {
    [0] = "PS_DOMAIN",
    [1] = "CS_DOMAIN",
    [2] = "PS_PREFER",
    [3] = "CS_PREFER",
}
SMS_IMS_CFG = {
    [0] = "NO_IMS",
    [1] = "IMS_ALLOW",
}
EM_ID_TYPE = {
    [0] = "UNKNOWN_SERVICE",
    [1] = "NOT_EMERGENCY_SERVICE",
    [2] = "EMERGENCY_SERVICE",
    [3] = "MAX",
}
PDIS_METHOD_TYPE = {
    [0] = "NONE",
    [1] = "SIM",
    [2] = "MO",
    [3] = "PCO",
    [4] = "DHCPV4",
    [5] = "DHCPV6",
    [6] = "MANUL",
}
SCM_APPLICATION_ENUM = {
    [0] = "MMTEL_VOICE",
    [1] = "MMTEL_VIDEO",
    [2] = "SMS_OVER_IP",
    [3] = "REG_SIG",
    [127] = "MAX",
}
SCM_INDICATION_ENUM = {
    [1] = "START_INDICATION",
    [2] = "END_INDICATION",
    [127] = "MAX",
}
EXIMS_SERVICE_TYPE_ENUM = {
    [1] = "NORMAL_VOICE_CALL",
    [2] = "NORMAL_VIDEO_CALL",
    [3] = "EMERGENCY_CALL",
    [4] = "SMS",
    [5] = "NORMAL_VOICE_CALL_HO",
    [6] = "NORMAL_VIDEO_CALL_HO",
    [7] = "NORMAL_TYPE_SMS_HO",
    [8] = "REG_SIG",
    [9] = "MT_ACCESS",
    [127] = "MAX",
}
EXIMS_SERVICE_STATUS_ENUM = {
    [0] = "START_INDICATION",
    [1] = "STOP_INDICATION",
    [127] = "MAX",
}
EXIMS_UAC_CAUSE_ENUM = {
    [0] = "BARRED",
    [1] = "NO_COVERAGE",
    [2] = "DEREGISTERED",
    [3] = "GEMINI_SUSPEND",
    [127] = "MAX",
}
EXIMS_FLUSH_ACTION_TYPE = {
    [0] = "CLEAR_ALL",
    [1] = "STOP",
}
ACT_CALL_NTF_ENUM = {
    [0] = "USE_FB_DATA_CALL",
    [1] = "UNUSE_FB_DATA_CALL",
    [2] = "DEACT_DATA_CALL",
    [127] = "MAX",
}
IMS_REG_STATE_TYPE = {
    [0] = "NOT_REGISTERED",
    [1] = "REGISTERED",
}
IMS_DEREG_CAUSE_TYPE = {
    [0] = "UNSPECIFIED",
    [1] = "POWER_OFF",
    [2] = "RF_OFF",
}
IMS_RETRY_TYPE = {
    [0] = "NOT_RETRY",
    [1] = "RETRY",
}
IMS_RAT_TYPE = {
    [0] = "LTE",
    [1] = "WIFI",
    [2] = "EHRPD",
    [3] = "GSM",
    [4] = "UMTS",
}
IMS_URI_TYPE = {
    [0] = "URI_MSISDN",
    [1] = "URI_IMSI",
}
IMS_EVODATA_EN_ENUM = {
    [0] = "VODATA_OFF",
    [1] = "VODATA_ON",
}
IMS_EVODATA_MODE_ENUM = {
    [0] = "DEFAULT",
    [1] = "OOS_MODE",
}
IMS_EVODATA_ALLOWRAT_ENUM = {
    [0] = "DEFAULT",
    [1] = "LTE_NR_3G",
}
IMS_VOPS_N3GPP_ENUM = {
    [0] = "IMS_VOPS_NOT_SUPPORT_OVER_NON_3GPP_ACCESS",
    [1] = "IMS_VOPS_SUPPORT_OVER_NON_3GPP_ACCESS",
    [2] = "IMS_VOPS_OVER_NON_3GPP_ACCESS_NOT_UPDATED",
}
WFC_SIGNAL_TYPE = {
    [0] = "LTE_RSRP",
    [1] = "LTE_RS_SNR",
    [2] = "UMTS_RSCP",
    [3] = "UMTS_ECNO",
    [4] = "LTE_RSRQ",
    [5] = "NR_SS_RSRP",
    [255] = "INVALID",
}
EPDG_SCREEN_STATE = {
    [0] = "UNLOCK",
    [1] = "LOCK",
    [2] = "OPEN_KEYGUARD_ON",
    [255] = "INVALID",
}
WIFI_TYPE = {
    [0] = "802_11",
    [1] = "802_11a",
    [2] = "802_11b",
    [3] = "802_11g",
    [4] = "802_11n",
    [5] = "802_11ac",
    [255] = "INVALID",
}
WIFI_EXTEND_STATE = {
    [0] = "DEFAULT_VALUE",
    [1] = "WIFI_TRANSFER_CAPABILITY",
}
WIFI_CONN_STATE = {
    [0] = "DIS_ASSOCIATED",
    [1] = "ASSOCIATED",
}
WIFI_APM_STATE = {
    [0] = "WIFI_TURN_OFF_IN_APM",
    [1] = "WIFI_REMAIN_ON_IN_APM",
}
WFC_PREFER = {
    [0] = "CELL_ONLY",
    [1] = "WIFI_PREFER",
    [2] = "CELL_PREFER",
    [3] = "WIFI_ONLY",
    [255] = "INVALID",
}
WFC_RAT = {
    [1] = "3GPP",
    [2] = "WIFI",
    [255] = "INVALID",
}
WFC_PDN_TYPE = {
    [0] = "IMS",
    [1] = "SMS",
    [2] = "MMS",
    [255] = "INVALID",
}
WFC_PDN_HO_STATUS = {
    [0] = "START",
    [1] = "SUCCESS",
    [255] = "FAIL",
}
WFC_PDN_OOS_STATE = {
    [0] = "OOS_END_PDN_DIS",
    [1] = "OOS_START",
    [2] = "OOS_END_PDN_RESUME",
    [255] = "FAIL",
}
WFC_WIFI_PDN_STATE = {
    [0] = "NOT_REGISTERED",
    [1] = "REGISTERED",
    [2] = "NOT_REGISTERED_WITH_LOCK",
    [255] = "INVALID",
}
SS_USSD = {
    [0] = "NO_ACTION_REQUIRED",
    [1] = "ACTION_REQUIRED",
    [2] = "TERMINATED_BY_NW",
    [3] = "OTHER_LOCAL_CLIENT",
    [4] = "OPERATION_NOT_SUPPORTED",
    [5] = "NW_TIME_OUT",
}
SS_SESSION = {
    [0] = "NEW",
    [1] = "EXISTING",
}
SS_CALL_WAITING = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
SS_SET_CALL_FORWARD_OPERATION_CODE = {
    [0] = "SS_ACTIVATE",
    [1] = "SS_DEACTIVATE",
    [3] = "SS_REGISTRATION",
    [4] = "SS_ERASURE",
}
SS_CALL_FORWARD_REASON = {
    [21] = "CALL_FORWARD_UNCONDITIONAL",
    [67] = "CALL_FORWARD_BUSY",
    [61] = "CALL_FORWARD_NO_REPLY",
    [62] = "CALL_FORWARD_NOT_REACHABLE",
    [2] = "CALL_FORWARD_ALL",
    [4] = "CALL_FORWARD_ALL_CONDITIONAL",
    [68] = "CALL_FORWARD_NOT_REGISTER",
}
SS_ACTIVE_STATUS = {
    [0] = "NOT_ACTIVE",
    [1] = "ACTIVE",
}
SS_TYPE_OF_ADDRESS = {
    [0] = "NORMAL",
    [1] = "INTERNATIONAL",
}
SS_SERVICE_CLASS = {
    [0] = "NONE",
    [1] = "VOICE",
    [2] = "DATA",
    [4] = "FAX",
    [8] = "SMS",
    [16] = "DATA_CIRCUIT_SYNC",
    [32] = "DATA_CIRCUIT_ASYNC",
    [64] = "DEDICATED_PACKET_ACCESS",
    [128] = "DEDICATED_PAD_ACCESS",
    [256] = "MTK_LINE2",
    [512] = "MTK_VIDEO",
    [1023] = "MAX_VALUE",
}
SS_CALL_BARRING_LOCK = {
    [0] = "UNLOCK",
    [1] = "LOCK",
}
SS_CALL_BARRING_FAC = {
    [0] = "AO",
    [1] = "OI",
    [2] = "OX",
    [3] = "AI",
    [4] = "IR",
    [5] = "AB",
    [6] = "AG",
    [7] = "AC",
    [8] = "ACR",
    [9] = "MT",
}
SS_CNAP_STATE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
}
SS_ECFU_ICON_STATUS = {
    [0] = "HIDE_CFU_ICON",
    [1] = "SHOW_CFU_ICON",
}
SPI_STATUS_ENUM = {
    [0] = "SUCCESS",
    [1] = "FAILURE",
    [2] = "ENCAP_NO_RULE",
    [2] = "DECAP_NO_RULE",
    [3] = "DECAP_PACKET_SA_UNMATCH",
    [4] = "SPI_FREE_FAIL_SA_EXISTANT",
    [5] = "ENCAP_SA_SUSPEND",
    [6] = "MAX",
}
IPSEC_PROTO_ENUM = {
    [50] = "ESP",
    [51] = "AH",
    [127] = "MAX",
}
MIPI_DEVICE_TYPE = {
    [0] = "MIPI_RFFE",
}
IPSEC_MODE_ENUM = {
    [0] = "transport",
    [1] = "tunnel",
    [127] = "MAX",
}
STK_NOT_HANDLED = {
    [0] = "BY_FUNCTION_CANNOT_BE_HANDLED_BY_HOST",
    [1] = "By_FUNCTION_MAY_BE_HANDLED_BY_HOST",
}
STK_HANDLED = {
    [2] = "BY_FUNCTION_ONLY_TRANSPARENT_TO_HOST",
    [3] = "BY_FUNCTION_NOTIFICATION_TO_HOST_POSSIBLE",
    [4] = "BY_FUNCTION_NOTIFICATIONS_TO_HOST_ENABLE",
    [5] = "BY_FUNCTION_CAN_BE_OVERRIDDEN_BY_HOST",
    [6] = "BY_HOST_FUNCTION_NOT_ABLE_TO_HANDLE",
    [7] = "BY_HOST_FUNCTION_ABLE_TO_HANDLE",
}
STK_PAC_TYPE = {
    [0] = "PROACTIVE_COMMAND",
    [1] = "NOTIFICATION",
    [2] = "SESSION_END",
}
SIM_REFRESH_RESULT_TYPE = {
    [0] = "SIM_FILE_UPDATE",
    [1] = "SIM_INIT",
    [2] = "SIM_RESET",
    [3] = "APP_INIT",
    [4] = "SIM_INIT_FULL_FILE_CHANGE",
    [5] = "SIM_INIT_FILE_CHANGE",
    [6] = "SESSION_RESET",
}
RAN = {
    [0] = "UNKNOWN",
    [1] = "CELL",
    [2] = "WIFI",
    [3] = "3GPP2",
    [4] = "DATA1",
    [5] = "DATA2",
    [6] = "DATA3",
    [7] = "DATA4",
    [8] = "N3IWF",
}
CALL_STATE = {
    [0] = "IDLE",
    [1] = "ESTABLISHING",
    [2] = "ACTIVE",
    [3] = "HELD",
    [4] = "TERMINATED",
}
CALL_CLCC_STATE = {
    [0] = "ACTIVE",
    [1] = "HELD",
    [2] = "DIALING",
    [3] = "ALERTING",
    [4] = "INCOMING",
    [5] = "WAITING",
}
CALL_DIRECTION = {
    [0] = "MO_CALL",
    [1] = "MT_CALL",
}
SDP_DIRECTION = {
    [0] = "INACTIVE",
    [1] = "SEND_ONLY",
    [2] = "RECV_ONLY",
    [3] = "SEND_RECV",
}
SPEECH_RAT = {
    [1] = "GSM",
    [2] = "UTMS",
    [2] = "UMTS",
    [4] = "IMS",
    [4] = "LTE",
    [8] = "COM_GSM",
    [16] = "C2K",
    [32] = "1xRTT",
    [64] = "HRPD",
    [128] = "NR",
}
CALL_RAT = {
    [0] = "UNKNOWN",
    [1] = "CS",
    [2] = "VoLTE",
    [3] = "WFC",
    [4] = "VoNR",
}
CALL_TYPE = {
    [1] = "MPTY",
    [16] = "EMERGENCY",
    [256] = "VIDEO",
    [4096] = "RTT",
    [65536] = "IN_BAND_TONE",
    [131072] = "IN_BAND_TONE_VIDEO",
    [196608] = "IN_BAND_TONE_VIDEO_VOICE",
    [1048576] = "TCH",
}
CALL_MODE = {
    [0] = "VOICE",
    [1] = "DATA",
    [3] = "VFD_VOICE",
    [4] = "AVD_VOICE",
    [5] = "AVF_VOICE",
    [6] = "VFD_DATA",
    [7] = "AVD_DATA",
    [9] = "UNKNOWN",
    [20] = "IMS_VOICE_CALL",
    [21] = "IMS_VIDEO_CALL",
    [22] = "IMS_VOICE_CONFERENCE",
    [23] = "IMS_VIDEO_CONFERENCE",
    [24] = "IMS_VOICE_CONFERENCE_PARTICIPANT",
    [25] = "IMS_VIDEO_CONFERENCE_PARTICIPANT",
    [40] = "C2K_VOICE_CALL",
    [41] = "C2K_OTASP_CALL_STD",
    [42] = "C2K_OTASP_CALL_NO_STD",
    [43] = "C2K_ECC_CALL",
}
CALL_DIAL_ADDRESS_TYPE = {
    [0] = "NONE",
    [1] = "SIP_URI",
    [2] = "NUMBER",
}
CALL_AUDIO_CODEC = {
    [0] = "NONE",
    [1] = "QCELP13K",
    [2] = "EVRC",
    [3] = "EVRC_B",
    [4] = "EVRC_WB",
    [5] = "EVRC_NW",
    [6] = "AMR_NB",
    [7] = "AMR_WB",
    [8] = "GSM_EFR",
    [9] = "GSM_FR",
    [10] = "GSM_HR",
    [23] = "EVS_NB",
    [24] = "EVS_WB",
    [25] = "EVS_SW",
    [32] = "EVS_FB",
    [33] = "EVS_AWB",
}
SDP_AUDIO_CODEC = {
    [1] = "AMR",
    [2] = "AMR_WB",
    [17] = "EVS",
}
CALL_EVENT = {
    [1] = "MT_REJECTED",
    [2] = "MT_REDIRECT",
    [3] = "SRVCC",
    [4] = "AUDIO_CODEC_CHANGE",
    [5] = "SPEECH_ATTACH",
    [6] = "CRING",
    [7] = "RAT",
    [8] = "NO_CARRIER",
    [9] = "ECONFSRVCC",
}
GWSD_EVENT = {
    [1] = "ECRFCPY",
    [2] = "EICPGU",
    [3] = "EICPGRES",
}
CALL_MSG_TYPE = {
    [0] = "MT_CALL",
    [1] = "DISCONNECT",
    [2] = "ALERT",
    [3] = "CALL_PROCESS",
    [4] = "SYNC",
    [5] = "PROGRESS",
    [6] = "CONNECTED",
    [129] = "ALL_CALLS_DISC",
    [130] = "CALL_ID_ASSIGN",
    [131] = "STATE_CHANGE_HELD",
    [132] = "STATE_CHANGE_ACTIVE",
    [133] = "STATE_CHANGE_DISCONNECTED",
    [134] = "STATE_CHANGE_MO_DISCONNECTING",
    [135] = "STATE_HELD_BY_REMOTE",
    [136] = "STATE_ACTIVE_BY_REMOTE",
}
CALL_DISCONNECTED_CAUSE = {
    [1] = "UNASSIGNED_NUMBER",
    [3] = "NO_ROUTE_TO_DESTINATION",
    [6] = "CHANNEL_UNACCEPTABLE",
    [8] = "OPERATOR_DETERMINED_BARRING",
    [16] = "NORMAL_CALL_CLEARING",
    [17] = "USER_BUSY",
    [18] = "NO_USER_RESPONDING",
    [19] = "NO_ANSWER",
    [21] = "CALL_REJECTED",
    [22] = "NUMBER_CHANGED",
    [24] = "CALL_REJECTED_DUE_FEAT",
    [25] = "PRE_EMPTION",
    [26] = "NONSELECTED_USER_CLEARING",
    [27] = "DESTINATION_OUT_OF_OREDER",
    [28] = "INVALID_NUMBER_FORMAT",
    [29] = "FACILITY_REJECTED",
    [30] = "RESPONSE_TO_STATUS_ENQUIRY",
    [31] = "NORMAL_UNSPECIFIED",
    [34] = "NO_CHANNEL_AVAILABLE",
    [38] = "NW_OUT_OF_ORDER",
    [41] = "TEMPORARY_FAILURE",
    [42] = "SWITCHING_EQUIPMENT_CONGESTION",
    [43] = "ACCESS_INFO_DISCARDER",
    [44] = "REQUESTED_CHANNEL_UNAVAILABLE",
    [47] = "RESOURCE_UNAVAILABLE",
    [49] = "QOS_UNAVAILABLE",
    [50] = "REQUESTED_FACILITY_NOT_SUBSCRIBED",
    [55] = "INCOMING_CALLS_BARRED_IN_CUG",
    [57] = "BEARER_CAPABILITY_NOT_AUTHORIZED",
    [58] = "BEARER_CAPABILITY_NOT_AVAILABLE",
    [63] = "SERVICE_NOT_AVAILABLE",
    [65] = "BEARER_SERVICE_NOT_IMPLEMENTED",
    [68] = "ACM_GREATER_THAN_ACMMAX",
    [69] = "REQUESTED_FACILITY_NOT_IMPLEMENTED",
    [70] = "ONLY_DIGITAL_INFO_BEARER_AVAILABLE",
    [79] = "SERVICE_NOT_IMPLEMENTED",
    [81] = "INVALID_TRANSACTION_IDENTIFIER",
    [87] = "USER_NOT_MEMBER_OF_CUG",
    [88] = "INCOMPATIBLE_DESTINATION",
    [91] = "INVALID_TRANSIT_NW_SELECTION",
    [95] = "SEMANTICALLY_INCORRECT_MSG",
    [96] = "INVALID_MANDATORY_INFO",
    [97] = "MSG_TYPE_NON_EXISTENT",
    [98] = "MSG_TYPE_NOT_COMPATIBLE",
    [99] = "INFO_ELEMENT_NON_EXISTENT",
    [100] = "CONDITIOANL_IE_ERROR",
    [101] = "MSG_NOT_COMPATIBLE",
    [102] = "RECOVERY_ON_TIMER_EXPIRY",
    [111] = "PROTOCOL_ERROR_UNSPECIFIED",
    [127] = "INTERWORKING_UNSPECIFIED",
    [380] = "IMS_EXT_ERROR_REPORT_NON_UE_DETECT_EMERG",
    [899] = "IMS_EXT_ERROR_REPORT_ECT_TIMEOUT",
    [1000] = "IMS_EXT_ERROR_REPORT_DEDICATED_BEARER_TIMEOUT",
    [1001] = "IMS_EXT_ERROR_REPORT_GENERIC_RETRY_CS",
    [1002] = "IMS_EXT_ERROR_REPORT_GENERIC_NO_RETRY",
    [1003] = "IMS_EXT_ERROR_REPORT_GENERIC_RETRY_IMS_CS",
    [1004] = "IMS_EXT_ERROR_REPORT_TIMER_B_EXPIRY",
    [1005] = "IMS_EXT_ERROR_REPORT_GENERIC_RETRY_IMS_VIDEO_TO_VOICE",
    [1006] = "IMS_EXT_ERROR_REPORT_NO_RETRY_BAR_IMS",
    [1007] = "IMS_EXT_ERROR_REPORT_REDIRECTION_FAILURE",
    [2001] = "IMS_EXT_ERROR_REPORT_SILENT_REDIAL_3GPP2",
    [2002] = "IMS_EXT_ERROR_REPORT_DIAL_1XRTT_DIRECTLY",
    [2003] = "MS_EXT_ERROR_REPORT_NEED_GLOBAL_MODE_FOR_EMERG",
    [2004] = "IMS_EXT_ERROR_REPORT_SSAC_BAR",
    [2005] = "IMS_EXT_ERROR_REPORT_RTT_EMC_F",
}
CALL_REJECT_REASON = {
    [0] = "UNDEFINED",
}
CALL_DIAL_TYPE = {
    [1] = "VOICE",
    [2] = "VIDEO",
    [3] = "EMERGENCY",
    [4] = "RTT",
}
CALL_CONFERENCE_DIAL_TYPE = {
    [1] = "VOICE",
    [2] = "VIDEO",
}
CALL_DIAL_DOMAIN = {
    [0] = "AUTO",
    [1] = "CS_ONLY",
    [2] = "3GPP_ONLY",
    [3] = "3GPP2_ONLY",
    [4] = "IMS_AND_3GPP2_ONLY",
    [5] = "3GPP_CS_AND_3GPP2_ONLY",
    [6] = "IMS_ONLY",
}
CALL_CLIR_MODE = {
    [0] = "DEFAULT",
    [1] = "INVOCATION",
    [2] = "SUPPRESSION",
}
CALL_SS_ACTION = {
    [0] = "RELEASE_ALL_HELD_OR_WAITING_CALL",
    [1] = "RELEASE_ALL_ACTIVE_AND_ACCEPT_CALL",
    [2] = "PLACE_ALL_ACTIVE_CALL_ON_HOLD_AND_ACCEPT_CALL",
    [4] = "EXPLICIT_CALL_AND_TRANSFER",
    [5] = "COMPLETION_CALL_BUSY_SUBSCRIBER",
    [131] = "HOLD_CALL",
    [132] = "RESUME_CALL",
}
CALL_CONF_ACTION = {
    [0] = "MERGE",
    [1] = "ADD_PARTICIPANT",
    [2] = "REMOVE_PARTICIPANT",
    [3] = "SPLIT",
    [4] = "CDMA_FLASH",
}
SET_GWSD_MODE_ACTION = {
    [1] = "SET_DSDA_LIKE_MODE",
    [2] = "SET_SINGLE_CARD_GWSD_MODE",
}
CALL_HANGUP_MODE = {
    [0] = "HANGUP",
    [1] = "HANGUP_ALL",
    [2] = "FORCE_HANGUP",
}
CALL_HANGUP_CAUSE = {
    [0] = "USER_HANGUP",
    [1] = "IMS_NO_COVERAGE",
    [2] = "IS_LOW_BATTERY",
    [3] = "IMS_FORWARD",
    [4] = "IMS_SPECIAL_HUNGUP",
    [5] = "IMS_607_UNWANTED",
    [6] = "CS_INCOMING_REJECTED_NO_FORWARD",
}
CALL_ANSWER_MODE = {
    [0] = "DEFAULT",
    [1] = "AUDIO_CALL",
    [2] = "Rx_VIDEO_CALL",
    [3] = "Tx_VIDEO_CALL",
}
CALL_SS_CODE1 = {
    [0] = "UCF_ACTIVE",
    [1] = "CCF_ACTIVE",
    [2] = "FORWARDED_CALL",
    [3] = "WAITING_CALL",
    [4] = "CUG_CALL",
    [5] = "OUTGOING_CALLS_ARE_BARRED",
    [6] = "INCOMING_CALLS_ARE_BARRED",
    [7] = "CLIR_SUPPRESSION_REJECTED",
    [8] = "DEFLECTED_CALL",
    [9] = "CALLED_PARTY_IS_IDLE_FOR_VIDEO_RINGTONE",
    [12] = "CMOS",
}
CALL_SS_CODE2 = {
    [0] = "FORWARDED_CALL",
    [1] = "CUG_CALL",
    [2] = "HOLD_CALL",
    [3] = "RETRIEVED_CALL",
    [4] = "MULTIPARTY_CALL",
    [5] = "HOLD_CALL_HAS_BEEN_RELEASEED",
    [6] = "FORWARD_CHECK_SS_MSG_RECEIVED",
    [7] = "CONNECTED_CALL_WITH_REMOTE_PARTY_IN_ALERTING",
    [8] = "CONNECTED_CALL_WITH_REMOTE_PARTY_IN_EXPLICIT_CALL_TRANSFER",
    [9] = "DEFLECTED_CALL",
    [10] = "ADDITIONAL_INCOMING_CALL_FORWARDED",
    [11] = "CALL_FORWARDED",
    [12] = "CALL_FORWARDED_UNCONDITIONAL",
    [13] = "CALL_FORWARDED_CONDITIONAL",
    [14] = "CALL_BUSY_FORWARDED",
    [15] = "CALL_FORWARDED_ON_NO_REPLY",
    [16] = "CALL_FORWARDED_ON_NOT_REACHABLE",
}
EMERGENCY_CALL_S1_SUPPORT = {
    [0] = "S1_MODE_NOT_SUPPORT",
    [1] = "S1_MODE_SUPPORT",
}
EMERGENCY_CALL_RAT = {
    [0] = "GSM",
    [1] = "WCDMA",
    [2] = "TD_SCDMA",
    [3] = "FDD_LTE",
    [4] = "TDD_LTE",
}
EMERGENCY_CALL_SUPPORT_EMC = {
    [0] = "NOT_SUPPORT",
    [1] = "SUPPORT",
}
EMERGENCY_CALL_EMB_IU_SUPP = {
    [0] = "NOT_SUPPORT_LU_MODE_AND_A_GB_MODE",
    [1] = "ONLY_SUPPORT_LU_MODE",
}
EMERGENCY_CALL_EMS_5G_SUPP = {
    [0] = "EMC_NOT_SUPPORT",
    [1] = "EMC_SUPPORT_NR_5GCN_ONLY",
    [2] = "EMC_SUPPORT_EUTRA_5GCN_ONLY ",
    [3] = "EMC_SUPPORT_NR_5GCN_EUTRA_5GCN",
}
EMERGENCY_CALL_EMF_5G_SUPP = {
    [0] = "EMC_FALLBACK_NOT_SUPPORT",
    [1] = "EMC_FALLBACK_SUPPORT_NR_5GCN_ONLY",
    [2] = "EMC_FALLBACK_SUPPORT_EUTRA_5GCN_ONLY ",
    [3] = "EMC_FALLBACK_SUPPORT_NR_5GCN_EUTRA_5GCN",
}
CALL_UIS_INFO_TYPE = {
    [1] = "BOTTON_CLICKING",
}
CALL_UIS_INFO_RESULT = {
    [0] = "SUCCESS",
    [1] = "FAILURE",
}
CALL_UIS_INFO_CAUSE = {
    [0] = "NONE",
    [1] = "CALL_NOT_EXIST",
    [2] = "DATA_IS_NULL",
    [3] = "LACL_OF_MEMORY",
    [4] = "SIP_ERROR",
}
CALL_PREFER_SET_STATE = {
    [0] = "DATA_PREFER",
    [1] = "CALL_PREFER",
}
CALL_PREFER_SET_MONITOR_MODE = {
    [0] = "NOT_MONITOR",
    [1] = "MONITOR",
}
CALL_RTP_SESSION_VOICE_SESSION_TYPE = {
    [0] = "LTE",
    [1] = "WIFI",
    [2] = "NR",
    [3] = "DATA",
}
CALL_RTP_SESSION_GBR_MBR_PRESENT_BIT = {
    [0] = "MIN",
    [1] = "VOICE",
    [2] = "VIDEO",
    [4] = "TTY",
    [32767] = "MAX",
}
CALL_RTP_SESSION_FUNCTION_CLASS = {
    [0] = "MIN",
    [1] = "RTP",
    [2] = "XMIT",
    [4] = "VOICE",
    [8] = "VIDEO",
    [16] = "DTMF",
    [32] = "CODEC",
    [64] = "HANDOVER",
    [128] = "TTY",
    [2147483647] = "MAX",
}
CALL_RTP_SESSION_TIMER_ID = {
    [1] = "RTP_RTCP_TIMER",
    [2] = "RTP_TIMER",
    [3] = "RTCP_TIMER",
    [4] = "RTP_WARNING_TIMER",
    [5] = "TEXT_RTP_RTCP_TIMER",
    [6] = "TEXT_RTP_TIMER",
    [7] = "TEXT_RTCP_TIMER",
    [8] = "PARAM_ERROR_TIMER",
    [9] = "RTP_SDP_REFRESH_TIMER",
    [10] = "UL_RTP_RTCP_TIMER",
}
CALL_RTP_SESSION_PACKET_DROP = {
    [0] = "NONE",
    [1] = "DLPKT",
    [2] = "ULPKT",
    [3] = "DLUL",
}
CALL_RTP_SESSION_AUDIO_CODEC = {
    [0] = "NONE",
    [1] = "AMR",
    [2] = "AMR_WB",
    [17] = "EVS",
}
CALL_RTP_SESSION_AUDIO_CLOCK_RATE = {
    [0] = "CLOCK_RATE_8000",
    [1] = "CLOCK_RATE_16000",
}
CALL_RTP_SESSION_ECN_METHOD = {
    [0] = "ECN_RTP_NONE",
    [1] = "ECN_RTP",
    [2] = "ECN_RTP_ICE",
    [3] = "ECN_RTP_LEAP",
}
CALL_RTP_SESSION_CHEM_PLR_TYPE = {
    [0] = "PLR_TYPE_NO_PLR",
    [1] = "PLR_TYPE_PLR",
    [2] = "PLR_TYPE_PLR_ALR",
}
RTP_ANBR_UPDATE_REJECT_REASON = {
    [0] = "NONE",
    [1] = "BITRATE_TOO_LOW",
}
CALL_REJECT_CAUSE = {
    [0] = "NORMAL",
    [1] = "ABNORMAL",
    [2] = "NONUMBER",
    [3] = "UNREGISTERED",
    [4] = "DISCONNECT",
    [5] = "BECANCEL",
    [6] = "BEREJECT",
    [7] = "BEREJECT_380",
    [8] = "BEREJECT_380_EMERGENCY_TO_CS",
    [9] = "BEREJECT_380_EMERGENCY_REREG",
    [10] = "BEREJECT_480",
    [11] = "BEREJECT_503",
    [12] = "TX_TIMEOUT",
    [13] = "NO_PRIVACY",
    [14] = "PRECONDFAIL",
    [15] = "SECONDCALL",
    [16] = "NOMEDIACONTENT",
    [17] = "INVALIDMSG",
    [18] = "INVALIDCMD",
    [19] = "INVALIDIDX",
    [20] = "SRVCC",
    [21] = "FACILITY_REJECTED",
    [22] = "DEDICATED_BEARER_TIMEOUT",
    [23] = "UA_MAX",
    [24] = "UNAVAILABLE_OF_CALLS",
    [25] = "IMS_CC_CAUSE_MAX",
    [65535] = "UNKNOWN",
}
CONF_PARTICIPANT_STATUS = {
    [0] = "PENDING",
    [1] = "DIALING_OUT",
    [2] = "DIALING_IN",
    [3] = "ALERTING",
    [4] = "ON_HOLD",
    [5] = "CONNECTED",
    [6] = "DISCONNECTING",
    [7] = "DISCONNECTED",
    [8] = "MUTED_VIA_FOCUS",
    [9] = "CONNECT_FAIL",
}
SIP_DIRECTION = {
    [0] = "SEND",
    [1] = "RECEIVE",
}
SIP_MSG_TYPE = {
    [0] = "REQUEST",
    [1] = "RESPONSE",
}
SIP_METHOD = {
    [1] = "INVITE",
    [2] = "REFER",
    [3] = "UPDATE",
    [4] = "CANCEL",
    [5] = "MESSAGE",
    [6] = "ACK",
    [7] = "BYE",
    [8] = "OPTIONS",
    [9] = "SUBSCRIBE",
    [10] = "NOTIFY",
    [11] = "PUBLISH",
    [12] = "INFO",
    [13] = "PRACK",
}
IMS_EVENT_PACKAGE_TYPE = {
    [1] = "CONFERENCE",
    [2] = "DIALOG",
    [3] = "MWI",
    [100] = "DTMF_GEN",
}
ECC_INFO_TYPE = {
    [0] = "HOST",
    [1] = "SIM",
    [2] = "MCF",
    [3] = "NW",
    [4] = "SPEC",
    [5] = "N3GPP_IKEV2",
    [6] = "N3GPP_DNS",
    [7] = "NW_EXT",
}
DTMF_MODE = {
    [0] = "START",
    [1] = "STOP",
    [2] = "SINGLE_TONE",
    [3] = "BURST_TONE",
}
RECV_DTMF_MODE = {
    [0] = "START",
    [1] = "STOP",
    [2] = "STOOP_ALL",
}
CALL_ECBM_MODE = {
    [0] = "ECBM_OFF",
    [1] = "ECBM_ON",
    [2] = "NO_ECBM",
}
CALL_CLI_VALIDITY = {
    [0] = "CLI_VALID",
    [1] = "CLI_WITHHELD",
    [2] = "CLI_INTERWORK",
    [3] = "CLI_PAYPHONE",
    [4] = "CLI_OTHERS",
}
CALL_CNI_VALIDITY = {
    [0] = "CNI_VALID",
    [1] = "CNI_WITHHELD",
    [2] = "CNI_INTERWORK",
    [3] = "CNI_PAYPHONE",
    [4] = "CNI_OTHERS",
}
CRSS_TYPE = {
    [0] = "CRSS_CALL_WAITING",
    [1] = "CRSS_CALLING_LINE_ID_PRESET",
    [2] = "CRSS_CALLED_LINE_ID_PRESET",
    [3] = "CRSS_CONNECTED_LINE_ID_PRESET",
    [4] = "CDMA_CALL_WAITING",
    [5] = "CDMA_CALLING_LINE_ID_PRESET",
}
NUMBER_PRESENTATION = {
    [0] = "ALLOWED",
    [1] = "RESTRICTED",
    [2] = "UNKNOWN",
}
NUMBER_TYPE = {
    [0] = "UNKNOWN",
    [1] = "INTERNATIONAL",
    [2] = "NATIONAL",
    [129] = "SPEC_UNKNOWN",
    [145] = "SPEC_INTERNATIONAL",
    [161] = "SPEC_NATIONAL",
    [177] = "SPEC_NETWORK_SPECIFIC",
}
CALL_NUMBER_TYPE = {
    [129] = "UNKNOWN",
    [145] = "INTERNATIONAL",
    [161] = "NATIONAL",
    [177] = "NETWORK_SPECIFIC",
}
CALL_ECT_TYPE = {
    [0] = "IMS_DEFAULT",
    [1] = "IMS_BLIND_ECT",
    [2] = "IMS_ASSURED_ECT",
    [3] = "CONSULTATIVE_ECT",
}
CALL_CIPHER_ON_STATUS = {
    [0] = "NO_CIPHER",
    [1] = "CIPHER",
    [255] = "UNKNOWN",
}
CALL_ADDITIONAL_INFO_MODE = {
    [1] = "ORIGINAL_IMS_CALL",
    [2] = "CLIENT_API",
    [3] = "ENRICHED_CALLING",
}
CALL_ADDITIONAL_INFO_TYPE = {
    [1] = "HEADER",
    [2] = "LOCATION",
}
CALL_PEER_RTT_MODIFY_RESULT = {
    [0] = "ACCEPT",
    [1] = "REJECT",
}
CALL_LOCAL_RTT_MODIFY_OP = {
    [0] = "DOWNGRADE",
    [1] = "UPGRADE",
}
CALL_RTT_MODE_OP = {
    [0] = "DISABLE",
    [1] = "AUTOMATIC",
    [2] = "UPON_REQUEST",
}
CALL_RTT_AUDIO_TYPE = {
    [0] = "SILENCE",
    [1] = "SPEECH",
}
CALL_RCS_STATE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
    [2] = "RE_REGISTRATION",
}
CALL_RCS_FEATURE = {
    [0] = "NONE",
    [1] = "SESSION",
    [2] = "FILETRANSFER",
    [4] = "MSG",
    [8] = "LARGEMSG",
    [16] = "GEOPUSH",
    [32] = "GEOPULL",
    [64] = "GEOPULLFT",
    [128] = "IMDN_AGGREGATION",
    [256] = "GEOSMS",
    [512] = "FTHTTP",
    [1024] = "CALLCOMPOSER",
    [2048] = "CHATBOT",
    [4096] = "CHATBOT_SA",
    [8192] = "CHATBOT_VERSION ",
}
CALL_VOICE_DOMAIN = {
    [1] = "CS_ONLY",
    [2] = "CS_PREFERRED",
    [3] = "PS_PREFERRED",
    [4] = "PS_ONLY",
}
CALL_PULL_TYPE = {
    [0] = "VOICE",
    [1] = "VIDEO",
}
CALL_SESSION_STATUS = {
    [0] = "END",
    [1] = "START",
}
CALL_TTY_MODE = {
    [0] = "OFF",
    [1] = "FULL",
    [2] = "HCO",
    [3] = "VCO",
}
CALL_IMS_CALL_MODE = {
    [1] = "ORIGINAL_IMS ",
    [2] = "CLIENT_API",
}
CALL_RTP_SESSION_AUDIO_FRAME_RATE = {
    [0] = "AMR_4_75",
    [1] = "AMR_5_15",
    [2] = "AMR_5_90",
    [3] = "AMR_6_70",
    [4] = "AMR_7_40",
    [5] = "AMR_7_95",
    [6] = "AMR_10_20",
    [7] = "AMR_12_20",
    [8] = "AMR_SID",
    [15] = "AMR_NO_DATA",
    [16] = "AMRWB_6_6",
    [17] = "AMRWB_8_85",
    [18] = "AMRWB_12_65",
    [19] = "AMRWB_14_25",
    [20] = "AMRWB_15_85",
    [21] = "AMRWB_18_25",
    [22] = "AMRWB_19_85",
    [23] = "AMRWB_23_05",
    [24] = "AMRWB_23_85",
    [25] = "AMRWB_SID",
    [30] = "AMRWB_LOST_FRAME",
    [31] = "AMRWB_NO_DATA",
    [32] = "EVS_08k_005_9",
    [33] = "EVS_16k_005_9",
    [128] = "EVS_08k_002_8",
    [129] = "EVS_08k_007_2",
    [130] = "EVS_08k_008_0",
    [131] = "EVS_08k_009_6",
    [132] = "EVS_08k_013_2",
    [133] = "EVS_08k_016_4",
    [134] = "EVS_08k_024_4",
    [140] = "EVS_08k_SID",
    [142] = "EVS_08k_LOST_FRAME",
    [143] = "EVS_08k_NODATA",
    [144] = "EVS_16k_002_8",
    [145] = "EVS_16k_007_2",
    [146] = "EVS_16k_008_0",
    [147] = "EVS_16k_009_6",
    [148] = "EVS_16k_013_2",
    [149] = "EVS_16k_016_4",
    [150] = "EVS_16k_024_4",
    [151] = "EVS_16k_032_0",
    [152] = "EVS_16k_048_0",
    [153] = "EVS_16k_064_0",
    [154] = "EVS_16k_096_0",
    [155] = "EVS_16k_128_0",
    [156] = "EVS_16k_SID",
    [158] = "EVS_16k_LOST_FRAME",
    [159] = "EVS_16k_NODATA",
    [163] = "EVS_32k_009_6",
    [164] = "EVS_32k_013_2",
    [165] = "EVS_32k_016_4",
    [166] = "EVS_32k_024_4",
    [167] = "EVS_32k_032_0",
    [168] = "EVS_32k_048_0",
    [169] = "EVS_32k_064_0",
    [170] = "EVS_32k_096_0",
    [171] = "EVS_32k_128_0",
    [172] = "EVS_32k_SID",
    [174] = "EVS_32k_LOST_FRAME",
    [175] = "EVS_32k_NODATA",
    [181] = "EVS_48k_016_4",
    [182] = "EVS_48k_024_4",
    [183] = "EVS_48k_032_0",
    [184] = "EVS_48k_048_0",
    [185] = "EVS_48k_064_0",
    [186] = "EVS_48k_096_0",
    [187] = "EVS_48k_128_0",
    [188] = "EVS_48k_SID",
    [190] = "EVS_48k_LOST_FRAME",
    [191] = "EVS_48k_NODATA",
    [208] = "EVS_AMRWB_06_60",
    [209] = "EVS_AMRWB_08_85",
    [210] = "EVS_AMRWB_12_65",
    [211] = "EVS_AMRWB_14_25",
    [212] = "EVS_AMRWB_15_85",
    [213] = "EVS_AMRWB_18_25",
    [214] = "EVS_AMRWB_19_85",
    [215] = "EVS_AMRWB_23_05",
    [216] = "EVS_AMRWB_23_85",
    [217] = "EVS_AMRWB_SID",
    [222] = "EVS_AMRWB_LOST_FRAME",
    [223] = "EVS_AMRWB_NODATA",
    [255] = "NONE",
}
CALL_RTP_SESSION_AUDIO_CMR = {
    [0] = "AMR_4_75",
    [1] = "AMR_5_15",
    [2] = "AMR_5_90",
    [3] = "AMR_6_70",
    [4] = "AMR_7_40",
    [5] = "AMR_7_95",
    [6] = "AMR_10_2",
    [7] = "AMR_12_2",
    [16] = "AMRWB_6_60",
    [17] = "AMRWB_8_85",
    [18] = "AMRWB_12_65",
    [19] = "AMRWB_14_25",
    [20] = "AMRWB_15_85",
    [21] = "AMRWB_18_25",
    [22] = "AMRWB_19_85",
    [23] = "AMRWB_23_05",
    [24] = "AMRWB_23_85",
    [32] = "EVS_CF_AMRWB_06_60",
    [33] = "EVS_CF_AMRWB_08_85",
    [34] = "EVS_CF_AMRWB_12_65",
    [35] = "EVS_CF_AMRWB_15_85",
    [36] = "EVS_CF_AMRWB_18_25",
    [37] = "EVS_CF_AMRWB_23_05",
    [38] = "EVS_CF_AMRWB_23_85",
    [128] = "EVS_08k_005_9",
    [129] = "EVS_08k_007_2",
    [130] = "EVS_08k_008_0",
    [131] = "EVS_08k_009_6",
    [132] = "EVS_08k_013_2",
    [133] = "EVS_08k_016_4",
    [134] = "EVS_08k_024_4",
    [144] = "EVS_AMRWB_06_60",
    [145] = "EVS_AMRWB_08_85",
    [146] = "EVS_AMRWB_12_65",
    [147] = "EVS_AMRWB_14_25",
    [148] = "EVS_AMRWB_15_85",
    [149] = "EVS_AMRWB_18_25",
    [150] = "EVS_AMRWB_19_85",
    [151] = "EVS_AMRWB_23_05",
    [152] = "EVS_AMRWB_23_85",
    [160] = "EVS_16k_005_9",
    [161] = "EVS_16k_007_2",
    [162] = "EVS_16k_008_0",
    [163] = "EVS_16k_009_6",
    [164] = "EVS_16k_013_2",
    [165] = "EVS_16k_016_4",
    [166] = "EVS_16k_024_4",
    [167] = "EVS_16k_032_0",
    [168] = "EVS_16k_048_0",
    [169] = "EVS_16k_064_0",
    [170] = "EVS_16k_096_0",
    [171] = "EVS_16k_128_0",
    [179] = "EVS_32k_009_6",
    [180] = "EVS_32k_013_2",
    [181] = "EVS_32k_016_4",
    [182] = "EVS_32k_024_4",
    [183] = "EVS_32k_032_0",
    [184] = "EVS_32k_048_0",
    [185] = "EVS_32k_064_0",
    [186] = "EVS_32k_096_0",
    [187] = "EVS_32k_128_0",
    [197] = "EVS_48k_016_4",
    [198] = "EVS_48k_024_4",
    [199] = "EVS_48k_032_0",
    [200] = "EVS_48k_048_0",
    [201] = "EVS_48k_064_0",
    [202] = "EVS_48k_096_0",
    [203] = "EVS_48k_128_0",
    [208] = "EVS_16k_CA_L_02",
    [209] = "EVS_16k_CA_L_03",
    [210] = "EVS_16k_CA_L_05",
    [211] = "EVS_16k_CA_L_07",
    [212] = "EVS_16k_CA_H_02",
    [213] = "EVS_16k_CA_H_03",
    [214] = "EVS_16k_CA_H_05",
    [215] = "EVS_16k_CA_H_07",
    [224] = "EVS_32k_CA_L_02",
    [225] = "EVS_32k_CA_L_03",
    [226] = "EVS_32k_CA_L_05",
    [227] = "EVS_32k_CA_L_07",
    [228] = "EVS_32k_CA_H_02",
    [229] = "EVS_32k_CA_H_03",
    [230] = "EVS_32k_CA_H_05",
    [231] = "EVS_32k_CA_H_07",
    [255] = "NONE",
}
ECALL_TYPE = {
    [0] = "TEST",
    [1] = "RECOFIG",
    [2] = "MANUAL",
    [3] = "AUTO",
}
ECALL_MSD_FORMAT = {
    [1] = "BINARY",
}
PHB_EF_FILE_TYPE = {
    [0] = "EF_ANR",
    [1] = "EF_EMAIL",
    [2] = "EF_SNE",
    [3] = "EF_AAS",
    [4] = "EF_GAS",
    [5] = "EF_GRP",
}
PHB_ENCODE_METHOD = {
    [0] = "ENCODE_IRA",
    [1] = "ENCODE_UCS2",
    [2] = "ENCODE_UCS2_81",
    [3] = "ENCODE_UCS2_82",
    [4] = "ENCODE_UCS2_GSM7BIT",
    [5] = "ENCODE_UNKNOWN",
}
PHB_STROAGE_TYPE = {
    [0] = "ME",
    [1] = "SM",
    [2] = "LD",
    [3] = "MC",
    [4] = "RC",
    [5] = "DC",
    [6] = "FD",
    [7] = "ON",
}
SYS_LPWR_MODE = {
    [0] = "DISABLE",
    [255] = "USER_1_CONFIG",
    [65280] = "USER_2_CONFIG",
    [16711680] = "USER_3_CONFIG",
    [4278190080] = "USER_4_CONFIG",
}
SYS_THERMAL_ACTUATOR_ID = {
    [1] = "UL_THROTTLING",
    [2] = "TX_POWER",
    [3] = "CC_CTRL",
    [4] = "HEADSWITCH",
    [5] = "RAS",
    [6] = "FR2_OFF",
    [7] = "FLIGHT_MODE",
    [8] = "CHARGER",
}
SYS_FACTORY_MODE = {
    [0] = "FACTORY",
    [1] = "NORMAL",
    [2] = "USB",
    [3] = "FUE",
}
SYS_CHIP_DIAGNOSIS_OPERATION = {
    [0] = "DVFS_TEST",
}
ECALL_ADDRESS_PRIORITY_CLASS = {
    [1] = "CUSTOM_ECALL_URI",
    [2] = "USIM_ECALL_URI",
    [3] = "CUSTOM_ECALL_NUM",
    [4] = "USIM_ECALL_NUM",
}
ECALL_SIM_TYPE = {
    [0] = "NORMAL",
    [1] = "ECALL_ONLY",
    [2] = "ECALL_AND_NORMAL",
}
ECALL_STATUS = {
    [1] = "START",
    [2] = "SENDING_MSD",
    [3] = "LLACK",
    [4] = "ALACK_POSITIVE",
    [5] = "ALACK_CLEARDOWN",
    [9] = "CALL_ID_ASSIGN",
    [10] = "ALERT",
    [11] = "CONNECTED",
    [12] = "DISCONNECTED",
    [13] = "IMS_CONNECTED",
    [14] = "IMS_DISCONNECTED",
    [15] = "ABNORMAL_HANGUP",
    [20] = "IMS_MSD_ACK",
    [21] = "IMS_UPDATE_MSD",
    [22] = "IMS_IN_BAND_TRANSFER",
    [23] = "IMS_MSD_NACK",
    [24] = "IMS_SRVCC",
    [31] = "ECALL_ONLY_DEREG",
    [40] = "PSAP_CALLBACK_START",
    [41] = "PSAP_CALLBACK_IMS_UPDATE_MSD",
    [52] = "ECALL_T2_TIMEOUT",
    [55] = "ECALL_T5_TIMEOUT",
    [56] = "ECALL_T6_TIMEOUT",
    [57] = "ECALL_T7_TIMEOUT",
    [255] = "UNSPECIFIED",
}
ECALL_MODE_TYPE = {
    [0] = "ECALL_NONE",
    [1] = "ECALL_ONLY",
    [2] = "ECALL_AND_NORMAL",
    [3] = "ECALL_TEST_DISABLE",
}
ECALL_T10_STATUS = {
    [0] = "ECALL_T10_NOT_RUN",
    [1] = "ECALL_T10_RUNNING",
}
GPS_STATUS_CONTROL_ENUM = {
    [0] = "GPS_OPEN",
    [1] = "GPS_CLOSE",
    [2] = "MNL_REBOOT",
    [3] = "OPEN_GSP_DONE",
    [4] = "CLOSE_GPS_DONE",
    [5] = "RESET_GPS_DONE",
}
GPS_TIME_SYNC_OPERATION_ENUM = {
    [0] = "TIME_SYNC_REQ",
    [1] = "TIME_SYNC_RSP",
    [2] = "TIME_SYNC_INFO_RSP",
}
LBS_EM_MSG_ENUM = {
    [0] = "CMD_START_LISTEN",
    [1] = "CMD_STOP_LISTEN",
}
LBS_DEBUG_REQ_ENUM = {
    [0] = "ACTION_DEBUG_MSG_REQ",
    [1] = "ACTION_DEBUG_EXTRA_REQ",
}
LBS_DEBUG_IND_ENUM = {
    [0] = "ACTION_DEBUG_REQ_ACK",
    [1] = "ACTION_UPDATE_REBOOT",
    [2] = "ACTION_UPDATE_SESSION_INFO",
    [3] = "ACTION_EXTRA_INFO",
}
LPPE_PROTOCOL_ENUM = {
    [0] = "PROTOCOL_WLAN",
    [1] = "PROTOCOL_BT",
    [2] = "PROTOCOL_SENSOR",
    [3] = "PROTOCOL_NETWORK",
    [4] = "PROTOCOL_IPADDR",
    [5] = "PROTOCOL_LBS",
}
LPPE_MSG_ACTION_ENUM = {
    [0] = "ACTION_REQUEST_CAPABILITIES",
    [1] = "ACTION_PROVIDE_CAPABILITIES",
    [2] = "ACTION_START_MEASUREMENT",
    [3] = "ACTION_STOP_MEASUREMENT",
    [4] = "ACTION_PROVIDE_MEASUREMENT",
    [5] = "ACTION_PROVIDE_MEASUREMENT_FINISHED",
    [6] = "ACTION_REQUEST_INFORMATION",
    [7] = "ACTION_PROVIDE_INFORMATION",
    [8] = "ACTION_REQUEST_CIVIC_ADDRESS",
    [9] = "ACTION_PROVIDE_CIVIC_ADDRESS",
    [10] = "ACTION_PROVIDE_UPDATE_BATTAERY_INFO",
    [11] = "ACTION_PROVIDE_UPDATE_NLP_STATUS",
    [12] = "ACTION_PROVIDE_UPDATE_VOWIFI_REG",
}
LPPE_SUPL_REQ_ACTION_ENUM = {
    [0] = "ACTION_AGPS_NI_RESPONSE",
}
LPPE_SUPL_IND_ACTION_ENUM = {
    [0] = "ACTION_ACQUIRE_WAKE_LOCK",
    [1] = "ACTION_RELEASE_WAKE_LOCK",
    [2] = "ACTION_REQUEST_GPS_ICON",
    [3] = "ACTION_REMOVE_GPS_ICON",
    [4] = "ACTION_AGPS_NI_NOTIFY",
}
LBS_AIDL_REQ_ACTION_ENUM = {
    [0] = "ACTION_GPS_INIT",
    [1] = "ACTION_GPS_CLEANUP",
    [2] = "ACTION_UPDATE_GNSS_CONFIG",
    [3] = "ACTION_SET_NFW_ACCESS",
    [4] = "ACTION_SET_POSITION_MODE",
    [5] = "ACTION_SET_SUPL_SERVER",
    [6] = "ACTION_SET_INSTALL_CERT",
    [7] = "ACTION_SET_REVOKE_CERT",
    [8] = "ACTION_UPDATE_NETWORK_STATE",
    [9] = "ACTION_SYNC_LOCATION",
    [10] = "ACTION_GET_SUPL_CERTI",
    [11] = "ACTION_DELET_CERT_ALL",
    [12] = "ACTION_SYNC_TIME",
    [13] = "ACTION_UPDATE_CUST_CONFIG",
}
LBS_AIDL_IND_ACTION_ENUM = {
    [0] = "ACTION_GET_SUPL_CERTI",
    [1] = "ACTION_MODEM_REBOOT",
}
GPS_ASN_INFO_ACTION_ENUM = {
    [0] = "ACTION_REQUEST_ASN1_ASSIST_DATA",
    [1] = "ACTION_PROVIDE_ASN1_LOCATION_INFORMATION",
    [2] = "ACTION_ASN_ACK",
    [3] = "ACTION_AGPS_VERSION",
    [4] = "ACTION_LSP_GNSS_INFO",
}
GPS_TSX_DATA_ACTION_ENUM = {
    [0] = "TSX_DATA_SYNC_REQ",
    [1] = "TSX_DATA_INFO_RSP",
}
AGPS_STATUS_CMD_ENUM = {
    [0] = "AGPS_REBOOT",
    [1] = "AGPS_OPEN_GPS_REQ",
    [2] = "AGPS_OPEN_GPS_REJECT",
    [3] = "AGPS_CLOSE_GPS_REQ",
    [4] = "AGPS_RESET_GPS_REQ",
}
MNL_AGPS_OPEN_TYPE_ENUM = {
    [0] = "MNL_AGPS_OPEN_TYPE_UNKNOWN",
    [16] = "MNL_AGPS_OPEN_TYPE_C2K",
    [32] = "MNL_AGPS_OPEN_TYPE_SUPL",
    [48] = "MNL_AGPS_OPEN_TYPE_CP_NILR",
    [49] = "MNL_AGPS_OPEN_TYPE_CP_MTLR",
    [50] = "MNL_AGPS_OPEN_TYPE_CP_MOLR",
    [51] = "MNL_AGPS_OPEN_TYPE_CP_QUERY",
    [52] = "MNL_AGPS_OPEN_TYPE_CP_MLR",
}
MNL_AGPS_OPEN_REQUESTOR_ENUM = {
    [0] = "OPEN_REQUESTOR_UNKNOWN",
    [1] = "OPEN_REQUESTOR_CARRIER",
    [2] = "OPEN_REQUESTOR_OEM",
    [3] = "OPEN_REQUESTOR_MODEM_CHIPSET_VENDOR",
    [4] = "OPEN_REQUESTOR_GNSS_CHIPSET_VENDOR",
    [5] = "OPEN_REQUESTOR_OTHER_CHIPSET_VENDOR",
    [6] = "OPEN_REQUESTOR_AUTOMOBILE_CLIENT",
    [7] = "OPEN_REQUESTOR_OTHER_REQUESTOR",
}
MNL_AGPS_NI_NOTIFY_TYPE_ENUM = {
    [0] = "NI_NOTIFY",
    [1] = "NI_NOTIFY2",
}
MNL_AGPS_NI_TYPE_ENUM = {
    [1] = "NI_TYPE_VOICE",
    [2] = "NI_TYPE_UTMS_SUPL",
    [3] = "NI_TYPE_UTMS_CTRL_PLANE",
    [4] = "NI_TYPE_EMERGENCY_SUPL",
}
MNL_AGPS_NI_ENCODING_TYPE_ENUM = {
    [0] = "NI_ENCODING_TYPE_NONE",
    [1] = "NI_ENCODING_TYPE_GSM7",
    [2] = "NI_ENCODING_TYPE_UTF8",
    [3] = "NI_ENCODING_TYPE_UCS2",
}
MNL_AGPS_LOCATION_CONTROL_ENUM = {
    [0] = "AGPS_LOCATION",
    [1] = "AGPS_C2K_CELL_LOCATION",
}
MNL_AGPS_LOCATION_TYPE_ENUM = {
    [0] = "LOC_TYPE_AFLT",
    [1] = "LOC_TYPE_CDMA_CELL",
    [2] = "LOC_TYPE_MOLR_BEGIN_RSP",
    [3] = "LOC_TYPE_SUPL_END",
    [4] = "LOC_TYPE_SUPL_REF_LOC",
    [5] = "LOC_TYPE_CP_REF_LOC",
}
AGPS_MD_TIME_ACTION_ENUM = {
    [0] = "MD_TIME_SYNC_IND",
    [1] = "MD_TIME_SYNC_CNF",
}
AGPS_TSX_DATA_ACTION_ENUM = {
    [0] = "MD_TSX_SYNC_IND",
    [1] = "MD_TSX_SYNC_CNF",
}
AGPS_ASN_DATA_TYPE_ENUM = {
    [0] = "ASN_DATA_TYPE_MAGNSS",
    [1] = "ASN_DATA_TYPE_LSP",
}
AGPS_VERSION_ACTION_ENUM = {
    [0] = "AGPS_VERSION_SYNC",
    [1] = "AGPS_VERSION_QUERY",
}
RESULT = {
    [0] = "SUCCESS",
    [1] = "BUSY",
    [2] = "FAILURE",
    [3] = "SIM_NOT_INSERTED",
    [4] = "BAD_SIM",
    [5] = "PIN_REQUIRED",
    [6] = "PIN_DISABLED",
    [7] = "NOT_REGISTERED",
    [8] = "PROVIDERS_NOT_FOUND",
    [9] = "NO_DEVICE_SUPPORT",
    [10] = "PROVIDER_NOT_VISIBLE",
    [11] = "DATA_CLASS_NOT_AVAILABLE",
    [12] = "PACKET_SERVICE_DETACHED",
    [13] = "MAX_ACTIVATED_CONTEXTS",
    [14] = "NOT_INITIALIZED",
    [15] = "VOICE_CALL_IN_PROGRESS",
    [16] = "CONTEXT_NOT_ACTIVATED",
    [17] = "SERVICE_NOT_ACTIVATED",
    [18] = "INVALID_ACCESS_STRING",
    [19] = "INVALID_USERID_PASSWORD",
    [20] = "RADIO_POWER_OFF",
    [21] = "INVALID_PARAMETERS",
    [22] = "READ_FAILURE",
    [23] = "WRITE_FAILURE",
    [24] = "Reserved_24",
    [25] = "NO_PHONEBOOK",
    [26] = "PARAMETER_TOO_LONG",
    [27] = "STK_BUSY",
    [28] = "OPERATION_NOT_ALLOWED",
    [29] = "MEMORY_FAILURE",
    [30] = "INVALID_MEMORY_INDEX",
    [31] = "MEMORY_FULL",
    [32] = "FILTER_NOT_SUPPORTED",
    [33] = "DSS_INSTANCE_LIMIT",
    [34] = "INVALID_DEVICE_SERVICE_OPERATION",
    [35] = "AUTH_INCORRECT_AUTN",
    [36] = "AUTH_SYNC_FAILURE",
    [37] = "AUTH_AMF_NOT_SET",
    [38] = "CONTEXT_NOT_SUPPORTED",
    [39] = "MISSING_RESOURCE",
    [40] = "NOT_FOUND",
    [41] = "FDN_BLOCKED",
    [43] = "MISSING_ARGUMENT",
    [44] = "PARTIAL_FAILURE",
    [47] = "INVALID_FORMAT",
    [100] = "SMS_UNKNOWN_SMSC_ADDRESS",
    [101] = "SMS_NETWORK_TIMEOUT",
    [102] = "SMS_LANG_NOT_SUPPORTED",
    [103] = "SMS_ENCODING_NOT_SUPPORTED",
    [104] = "SMS_FORMAT_NOT_SUPPORTED",
    [105] = "OPERATION_NOT_SUPPORTED",
    [106] = "ERROR_NOT_FOUND",
    [107] = "ERROR_UNKNOWN",
    [107] = "ERROR_UNKOWN",
    [108] = "INFO_NOT_AVAILABLE",
    [2105] = "ALARM_ID_NOT_SUPPORTED",
    [2106] = "THRESHOLD_OUT_OF_RANGE ",
    [2108] = "SENSOR_ID_NOT_SUPPORTED",
    [2109] = "ACTUATOR_ID_NOT_SUPPORTED",
    [2110] = "ACTUATOR_STATE_NOT_SUPPORTED",
    [262143] = "COMMON_END",
    [524288] = "CAT_EXT_BEGIN",
    [786431] = "CAT_EXT_END",
    [786432] = "CC_EXT_BEGIN",
    [786433] = "CC_CALL_FORCE_RELEASED_BEFORE",
    [786434] = "CC_CALL_IS_ALREADY_HOLD",
    [786435] = "CC_CALL_IS_ALREADY_ACTIVE",
    [786436] = "CC_INTERNAL_ERR",
    [786437] = "CC_NO_MEMORY",
    [786438] = "CC_NO_RESOURECE",
    [786439] = "CC_PORT_UNAVAILABLE",
    [786440] = "CC_CALL_IS_NOT_EXIST",
    [1048575] = "CC_EXT_END",
    [1048576] = "NW_EXT_BEGIN",
    [1310719] = "NW_EXT_END",
    [1310720] = "PDN_EXT_BEGIN",
    [1310720] = "PDN_EXT_NETWORK_ERROR_BEGIN",
    [1310820] = "PDN_EXT_CME_ERROR_BEGIN",
    [1310846] = "PDN_EXT_CME_INSUFFICIENT_RESOURCES_26",
    [1310847] = "PDN_EXT_CME_MISSING_OR_UNKNOWN_DNN_27",
    [1310848] = "PDN_EXT_CME_UNKNOWN_PDU_SESSION_TYPE_28",
    [1310849] = "PDN_EXT_CME_USER_AUTHENTICATION_OR_AUTHORIZATION_FAILED_29",
    [1310850] = "PDN_EXT_CME_ACTIVATION_REJECTED_BY_SERVING_GW_OR_PDN_GW_30",
    [1310851] = "PDN_EXT_CME_REQUEST_REJECTED_UNSPECIFIED_31",
    [1310852] = "PDN_EXT_CME_SERVICE_OPTION_NOT_SUPPORTED_32",
    [1310853] = "PDN_EXT_CME_REQUESTED_SERVICE_OPTION_NOT_SUBSCRIBED_33",
    [1310854] = "PDN_EXT_CME_SERVICE_OPTION_TEMPORARILY_OUT_OF_ORDER_34",
    [1310855] = "PDN_EXT_CME_PTI_ALREADY_IN_USE_35",
    [1310860] = "PDN_EXT_CME_FEATURE_NOT_SUPPORTED_40",
    [1310861] = "PDN_EXT_CME_SEMANTIC_ERROR_IN_THE_TFT_OPERATION_41",
    [1310862] = "PDN_EXT_CME_SYNTACTICAL_ERROR_IN_THE_TFT_OPERATION_42",
    [1310863] = "PDN_EXT_CME_INVALID_PDU_SESSION_IDENTITY_43",
    [1310864] = "PDN_EXT_CME_SEMANTIC_ERRORS_IN_PACKET_FILTERS_44",
    [1310865] = "PDN_EXT_CME_SYNTACTICAL_ERRORS_IN_PACKET_FILTERS_45",
    [1310866] = "PDN_EXT_CME_PDP_CONTEXT_WITHOUT_TFT_ALREADY_ACTIVATED_46",
    [1310869] = "PDN_EXT_CME_PDP_AUTHENTICATION_FAILURE_112",
    [1310891] = "PDN_EXT_CME_LAST_PDN_DISCONNECTION_NOT_ALLOWED_49",
    [1310896] = "PDN_EXT_CME_PROTOCOL_ERROR_UNSPECIFIED_111",
    [1310897] = "PDN_EXT_CME_OPERATOR_DETERMINED_BARRING_8",
    [1310898] = "PDN_EXT_CME_MAXIMUM_NUMBER_OF_EPS_BEARERS_REACHED_65",
    [1310899] = "PDN_EXT_CME_REQUESTED_APN_NOT_SUPPORTED_IN_CURRENT_RAT_AND_PLMN_COMBINATION_66",
    [1310900] = "PDN_EXT_CME_REQUEST_REJECTED_BEARER_CONTROL_MODE_VIOLATION_48",
    [1310901] = "PDN_EXT_CME_UNSUPPORTED_QCI_VALUE_59",
    [1310920] = "PDN_EXT_CME_ERROR_END",
    [1313792] = "PDN_EXT_NETWORK_SM_CAUSE_BEGIN",
    [1313793] = "PDN_EXT_NETWORK_SM_CAUSE_EMPTY",
    [1313800] = "PDN_EXT_NETWORK_SM_CAUSE_OPERATOR_DETERMINED_BARRING",
    [1313817] = "PDN_EXT_NETWORK_SM_CAUSE_LLC_SND_FAILURE",
    [1313818] = "PDN_EXT_NETWORK_SM_CAUSE_INSUFF_RESOURCE",
    [1313819] = "PDN_EXT_NETWORK_SM_CAUSE_UNKNOWN_APN",
    [1313820] = "PDN_EXT_NETWORK_SM_CAUSE_UNKNOWN_PDP_ADDR_OR_TYPE",
    [1313821] = "PDN_EXT_NETWORK_SM_CAUSE_AUTHENTICATION_FAILURE",
    [1313822] = "PDN_EXT_NETWORK_SM_CAUSE_ACTIVATION_REJ_GGSN",
    [1313823] = "PDN_EXT_NETWORK_SM_CAUSE_ACTIVATION_REJ_UNSPECIFIED",
    [1313824] = "PDN_EXT_NETWORK_SM_CAUSE_UNSUPPORTED_SERVICE_OPTION",
    [1313825] = "PDN_EXT_NETWORK_SM_CAUSE_UNSUBSCRIBED_SERVICE_OPTION",
    [1313826] = "PDN_EXT_NETWORK_SM_CAUSE_SERVICE_OPTION_TEMPORARILY_OUT_OF_ORDER",
    [1313827] = "PDN_EXT_NETWORK_SM_CAUSE_PTI_ALREADY_USED",
    [1313828] = "PDN_EXT_NETWORK_SM_CAUSE_REGULAR_DEACTIVATION",
    [1313829] = "PDN_EXT_NETWORK_SM_CAUSE_QOS_NOT_ACCEPTED",
    [1313830] = "PDN_EXT_NETWORK_SM_CAUSE_NETWORK_FAIL",
    [1313831] = "PDN_EXT_NETWORK_SM_CAUSE_REACTIVATION_REQD",
    [1313832] = "PDN_EXT_NETWORK_SM_CAUSE_UNSUPPORTED_NW_CONTEXT_ACTIVATION",
    [1313833] = "PDN_EXT_NETWORK_SM_CAUSE_SEMANTIC_ERROR_IN_TFT_OP",
    [1313834] = "PDN_EXT_NETWORK_SM_CAUSE_SYNTACTICAL_ERROR_IN_TFT_OP",
    [1313835] = "PDN_EXT_NETWORK_SM_CAUSE_UNKNOWN_PDP_CONTEXT",
    [1313836] = "PDN_EXT_NETWORK_SM_CAUSE_SEMANTIC_ERROR_IN_PACKET_FILTER",
    [1313837] = "PDN_EXT_NETWORK_SM_CAUSE_SYNTAX_ERROR_IN_PACKET_FILTER",
    [1313838] = "PDN_EXT_NETWORK_SM_CAUSE_PDP_CONTEXT_WO_TFT_ALREADY_ACT",
    [1313839] = "PDN_EXT_NETWORK_SM_CAUSE_PTI_MISMATCH",
    [1313840] = "PDN_EXT_NETWORK_SM_CAUSE_ACTIVATION_REJ_BCM_VIOLATION",
    [1313841] = "PDN_EXT_NETWORK_SM_CAUSE_LAST_PDN_DISC_NOT_ALLOWED",
    [1313842] = "PDN_EXT_NETWORK_SM_CAUSE_PDP_TYPE_IPV4_ONLY_ALLOWED",
    [1313843] = "PDN_EXT_NETWORK_SM_CAUSE_PDP_TYPE_IPV6_ONLY_ALLOWED",
    [1313844] = "PDN_EXT_NETWORK_SM_CAUSE_SINGLE_ADDR_BEARERS_ONLY_ALLOWED",
    [1313845] = "PDN_EXT_NETWORK_SM_CAUSE_ESM_INFORMATION_NOT_RECEIVED",
    [1313846] = "PDN_EXT_NETWORK_SM_CAUSE_PDN_CONNENCTION_NOT_EXIST",
    [1313847] = "PDN_EXT_NETWORK_SM_CAUSE_MULTIPLE_PDN_APN_NOT_ALLOWED",
    [1313848] = "PDN_EXT_NETWORK_SM_CAUSE_COLLISION_WITH_NW_INITIATED_REQ",
    [1313851] = "PDN_EXT_NETWORK_SM_CAUSE_UNSUPPORTED_QCI_VALUE",
    [1313857] = "PDN_EXT_NETWORK_SM_CAUSE_MAXIMUM_NUM_OF_PDP_CONTEXTS_REACHED",
    [1313858] = "PDN_EXT_NETWORK_SM_CAUSE_REQUESTED_APN_NOT_SUPPORTED_IN_CURRENT_RAT_AND_PLMN_COMBINATION",
    [1313873] = "PDN_EXT_NETWORK_SM_CAUSE_INVALID_TI",
    [1313887] = "PDN_EXT_NETWORK_SM_CAUSE_SM_SEMANTICALLY_INCORRECT_MSG",
    [1313888] = "PDN_EXT_NETWORK_SM_CAUSE_INVALID_MAND_INFO",
    [1313889] = "PDN_EXT_NETWORK_SM_CAUSE_SM_MSG_TYPE_NON_EXISTENT_OR_NOT_IMPLEMENTED",
    [1313890] = "PDN_EXT_NETWORK_SM_CAUSE_SM_MSG_TYPE_NOT_COMPATIBLE_WITH_PROTOCOL_STATE",
    [1313891] = "PDN_EXT_NETWORK_SM_CAUSE_IE_NON_EXISTENCE_OR_NOT_IMPLEMENTED",
    [1313892] = "PDN_EXT_NETWORK_SM_CAUSE_CONDITIONAL_IE_ERROR",
    [1313893] = "PDN_EXT_NETWORK_SM_CAUSE_SM_MSG_NOT_COMPATIBLE_WITH_PROTOCOL_STATE",
    [1313903] = "PDN_EXT_NETWORK_SM_CAUSE_SM_PROTOCOL_ERROR_UNSPECIFIED",
    [1313904] = "PDN_EXT_NETWORK_SM_CAUSE_APN_RESTRICTION_VALUE_INCOMPATIBLE_WITH_ACTIVE_PDP_CTX",
    [1313905] = "PDN_EXT_NETWORK_SM_CAUSE_END",
    [1314048] = "PDN_EXT_NETWORK_ESM_CAUSE_BEGIN",
    [1314049] = "PDN_EXT_NETWORK_ESM_CAUSE_NO_CAUSE",
    [1314056] = "PDN_EXT_NETWORK_ESM_CAUSE_OPERATOR_DETERMINED_BARRING",
    [1314074] = "PDN_EXT_NETWORK_ESM_CAUSE_INSUFFICIENT_RESOURCES",
    [1314075] = "PDN_EXT_NETWORK_ESM_CAUSE_UNKNOWN_OR_MISSING_APN",
    [1314076] = "PDN_EXT_NETWORK_ESM_CAUSE_UNKNOWN_PDN_TYPE",
    [1314077] = "PDN_EXT_NETWORK_ESM_CAUSE_USER_AUTH_FAILED",
    [1314078] = "PDN_EXT_NETWORK_ESM_CAUSE_REQUEST_REJECTED_BY_SGW_OR_PDNGW ",
    [1314079] = "PDN_EXT_NETWORK_ESM_CAUSE_REQUEST_REJECTED_UNSPECIFIED",
    [1314080] = "PDN_EXT_NETWORK_ESM_CAUSE_SERVICE_OPT_NOT_SUPPORTED",
    [1314081] = "PDN_EXT_NETWORK_ESM_CAUSE_REQ_SERVICE_NOT_SUBSCRIBED",
    [1314082] = "PDN_EXT_NETWORK_ESM_CAUSE_SERVICE_TEMP_OUT_OF_ORDER",
    [1314083] = "PDN_EXT_NETWORK_ESM_CAUSE_PTI_ALREADY_USED",
    [1314084] = "PDN_EXT_NETWORK_ESM_CAUSE_REGULAR_DEACTIVATION",
    [1314085] = "PDN_EXT_NETWORK_ESM_CAUSE_EPS_QOS_NOT_ACCEPTED",
    [1314086] = "PDN_EXT_NETWORK_ESM_CAUSE_NETWORK_FAILURE",
    [1314087] = "PDN_EXT_NETWORK_ESM_CAUSE_REACTIVATION_REQUESTED",
    [1314089] = "PDN_EXT_NETWORK_ESM_CAUSE_SEMANTIC_ERROR_IN_TFT",
    [1314090] = "PDN_EXT_NETWORK_ESM_CAUSE_SYNTACTIC_ERROR_IN_TFT",
    [1314091] = "PDN_EXT_NETWORK_ESM_CAUSE_INVALID_EPS_BEARER_IDENTITY",
    [1314092] = "PDN_EXT_NETWORK_ESM_CAUSE_SEMANTIC_ERROR_IN_PACKET_FILTERS",
    [1314093] = "PDN_EXT_NETWORK_ESM_CAUSE_SYNTACTIC_ERROR_IN_PACKET_FILTERS",
    [1314094] = "PDN_EXT_NETWORK_ESM_CAUSE_EPSB_CTXT_WITHOUT_TFT_ACTIVATED",
    [1314095] = "PDN_EXT_NETWORK_ESM_CAUSE_PTI_MISMATCH",
    [1314097] = "PDN_EXT_NETWORK_ESM_CAUSE_LAST_PDN_DISC_NOT_ALLOWED",
    [1314098] = "PDN_EXT_NETWORK_ESM_CAUSE_PDN_TYPE_IPV4_ONLY_ALLOWED",
    [1314099] = "PDN_EXT_NETWORK_ESM_CAUSE_PDN_TYPE_IPV6_ONLY_ALLOWED",
    [1314100] = "PDN_EXT_NETWORK_ESM_CAUSE_SINGLE_ADDRESS_ONLY_ALLOWED",
    [1314101] = "PDN_EXT_NETWORK_ESM_CAUSE_ESM_INFORMATION_NOT_RECEIVED",
    [1314102] = "PDN_EXT_NETWORK_ESM_CAUSE_PDN_CONNENCTION_NOT_EXIST",
    [1314103] = "PDN_EXT_NETWORK_ESM_CAUSE_MULTIPLE_PDN_APN_NOT_ALLOWED",
    [1314104] = "PDN_EXT_NETWORK_ESM_CAUSE_COLLISION_WITH_NW_INIT_REQUESTD",
    [1314107] = "PDN_EXT_NETWORK_ESM_CAUSE_UNSUPPORTED_QCI_VALUE",
    [1314113] = "PDN_EXT_NETWORK_ESM_CAUSE_MAXIMUM_NUM_OF_EPS_BEARERS_REACHED",
    [1314114] = "PDN_EXT_NETWORK_ESM_CAUSE_ESM_REQUESTED_APN_NOT_SUPPORTED_IN_CURRENT_RAT_AND_PLMN_COMBINATION",
    [1314129] = "PDN_EXT_NETWORK_ESM_CAUSE_INVALID_PTI_VALUE",
    [1314143] = "PDN_EXT_NETWORK_ESM_CAUSE_SEMANTIC_INCORRECT_MSG",
    [1314144] = "PDN_EXT_NETWORK_ESM_CAUSE_INVALID_MANDATORY_IE",
    [1314145] = "PDN_EXT_NETWORK_ESM_CAUSE_MSG_TYPE_NON_EXISTENT",
    [1314146] = "PDN_EXT_NETWORK_ESM_CAUSE_MSG_TYPE_NOT_COMPATIBLE_STATE",
    [1314147] = "PDN_EXT_NETWORK_ESM_CAUSE_IE_NON_EXISTENT_NOT_IMPLEMENTED",
    [1314148] = "PDN_EXT_NETWORK_ESM_CAUSE_CONDITIONAL_IE_ERROR",
    [1314149] = "PDN_EXT_NETWORK_ESM_CAUSE_MSG_NOT_COMPATIBLE_STATE",
    [1314159] = "PDN_EXT_NETWORK_ESM_CAUSE_PROTOCOL_ERROR_UNSPECIFIED",
    [1314160] = "PDN_EXT_NETWORK_ESM_CAUSE_APN_RESTRICT_VALUE_INCOMPATIBLE ",
    [1314161] = "PDN_EXT_NETWORK_ESM_CAUSE_END",
    [1314374] = "PDN_EXT_NETWORK_SM_PROPRIETARY_CAUSE_IRAT_TO_5GNR_LOCAL_DEACTIVATED",
    [1314560] = "PDN_EXT_NETWORK_TCM_CAUSE_BEGIN",
    [1314561] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_CID_UNEXPECTED",
    [1314562] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_CID_NOT_DEFINED",
    [1314563] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_FSM_UNEXPECTED",
    [1314564] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_CID_SECONDARY_WITHOUT_TFT",
    [1314565] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_PRIMARY_IS_NOT_ACTIVATED",
    [1314566] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_DEACT_WITH_CID_UNEXPECTED",
    [1314567] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_DEACT_WITH_FSM_UNEXPECTED",
    [1314568] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_DEACT_WITH_ACTIVATED_FROM_UNEXPECTED",
    [1314569] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_MODIFY_WITH_CID_UNEXPECTED",
    [1314570] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_MODIFY_WITH_FSM_UNEXPECTED",
    [1314571] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_MODIFY_WITH_NO_QOS_OR_TFT_SET",
    [1314572] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_CGDATA_WITH_CID_UNEXPECTED",
    [1314573] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_CGDATA_WITH_FSM_UNEXPECTED",
    [1314574] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_CID_UNEXPECTED",
    [1314575] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_NOT_ALLOW_FOR_PPP_TYPE",
    [1314576] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_INVALID_PARAMETER",
    [1314577] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_INVALID_PDP_TYPE",
    [1314578] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_CID_ALREADY_IN_USE",
    [1314579] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_INVALID_APN",
    [1314580] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DSCONT_CID_UNEXPECTED",
    [1314581] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DSCONT_INVALID_PARAMETER",
    [1314582] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DSCONT_CID_PRIMARY_IS_NOT_IN_USE",
    [1314583] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DSCONT_CID_PRIMARY_IS_NOT_ACTIVATED",
    [1314584] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DSCONT_NOT_ALLOW_FOR_PPP_TYPE",
    [1314585] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DSCONT_CID_ALREADY_IN_USE",
    [1314586] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_PRCO_CID_ALREADY_IN_USE",
    [1314587] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_PRCO_CID_UNEXPECTED",
    [1314588] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACT_NOT_SUPPORT_EMERGENCY_BEARER_ACTIVATION",
    [1314589] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACT_ALLOC_NSAPI_FAIL",
    [1314590] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DEACT_IND_BY_TIMER_EXPIRY",
    [1314591] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DEACT_IND_BY_NO_USER_RESPONSE_TILL_RAT_CHANGE_COMPLETE_IND",
    [1314592] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_MOD_PRESERVED_PDP_CONTEXT",
    [1314593] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_MOD_CHECK_TFT_FAIL",
    [1314594] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_MOD_REJ_DUE_TO_DEACT_IND",
    [1314595] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_SET_MULTI_PDN_SUCCESS",
    [1314596] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_SET_MULTI_PDN_CID_UNEXPECTED",
    [1314597] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_SET_MULTI_PDN_PARA_UNEXPECTED",
    [1314598] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_SET_MULTI_PDN_INVALID_PDP_TYPE_AND_LEN",
    [1314599] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_SET_MULTI_PDN_INVALID_APN",
    [1314600] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_ACT_WITH_CID_UNEXPECTED",
    [1314601] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_ACT_WITH_PDP_TYPE_LEN_UNEXPECTED",
    [1314602] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_ACT_WITH_INVALID_CONFIG_PROTOCOL",
    [1314603] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_ACT_WITH_CID_NOT_DEFINED",
    [1314604] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_ACT_WITH_FSM_UNEXPECTED",
    [1314605] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_DEACT_WITH_CID_UNEXPECTED",
    [1314606] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_DEACT_WITH_FSM_UNEXPECTED",
    [1314607] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_DEACT_WITH_ACTIVATED_FROM_UNEXPECTED",
    [1314608] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_CGDATA_WITH_CID_UNEXPECTED",
    [1314609] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_PPP_CHECKED_CGDATA_WITH_FSM_UNEXPECTED",
    [1314610] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_DISPATCH_PDP_ACT_CHECK_TFT_FAIL",
    [1314611] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UPCM_BIND_CNF_BEARER_HAS_BEEN_DEACTIVATED_ALREADY",
    [1314612] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UPCM_UNBIND_CNF_BEARER_HAS_BEEN_DEACTIVATED_ALREADY",
    [1314613] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_APN_NOT_EXIST_IN_ACL",
    [1314614] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_ACTION_NOT_ALLOWED",
    [1314615] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_SIM_FILE_FULL",
    [1314616] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_ADD_ENTRY_FAILED",
    [1314617] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_DEL_ENTRY_FAILED",
    [1314618] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_SET_ENTRY_FAILED",
    [1314619] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_SIM_READ_FAILED",
    [1314620] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ACL_SIM_WRITE_FAILED",
    [1314621] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_CAUSE_START",
    [1314622] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_EMPTY",
    [1314623] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_USER_CANCEL",
    [1314624] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_CID_ALREADY_CONNECT",
    [1314625] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_PDN_NOT_ACTIVATED",
    [1314626] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_BEARER_NOT_ACTIVATED",
    [1314627] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_RMV_LAST_PDN_NOT_ALLOWED",
    [1314628] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_LOCAL_RELEASE",
    [1314629] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_DETACH",
    [1314630] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_IE_ERROR",
    [1314631] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_TIMER_TIMEOUT",
    [1314632] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_TX_FAILURE",
    [1314633] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_RAT_CHANGE",
    [1314634] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_PS_SWITCH",
    [1314635] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_ACTION_NOT_ALLOWED",
    [1314636] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_T3346_CONGESTION",
    [1314637] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_THROTTLING_RUNNING",
    [1314638] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_SERIOUS_ERROR_AT_LOW_LAYER",
    [1314639] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_OTHERS",
    [1314640] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_CAUSE_END",
    [1314641] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_RETRY_NEEDED_AFTER_IRAT_IF_IN_3GPP",
    [1314642] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_LOCAL_REJECTED_DUE_TO_PS_SWITCH",
    [1314643] = "PDN_EXT_NETWORK_TCM_CAUSE_AP_RETRY_NEEDED_AFTER_LTE_TO_C2K_IRAT",
    [1314644] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_DEACT_SUCCESS_DUE_TO_CONTEXT_NEVER_ACTIVATED",
    [1314645] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_MODIFY_FAIL_DUE_TO_CONTEXT_DEACTIVATED",
    [1314646] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_MODIFY_FAIL_DUE_TO_CONTEXT_NOT_ACTIVATED",
    [1314647] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_DEACTIVATED_DUE_TO_NAS_TFT_TRIGGERED_DEACTIVATION",
    [1314648] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_23G_MT_PRIMARY_PDP_IS_ABORTED_DUE_TO_CHANGE_TO_4G",
    [1314649] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_DEACTIVATE_SUCCESS_IMMEDIATELY_BECAUSE_ACTIVATION_IS_NOT_PROCESSED_BY_TCM_YET",
    [1314650] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_EGACT_ACTIVATE_REJ_DUE_TO_ERROR_RAT",
    [1314651] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_EGACT_DEACTIVATE_REJ_DUE_TO_ERROR_RAT",
    [1314652] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_DEACTIVATED_DUE_TO_INACTIVITY_TIMER_TIMEOUT",
    [1314653] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ETCM_CID_NOT_DEFINE_TFT_QOS",
    [1314654] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ETCM_CID_IS_NOT_PRIMARY",
    [1314655] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ETCM_TFT_VALIDATION_ERROR",
    [1314656] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ETCM_PTI_IS_FULL",
    [1314657] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_EGLD_WITH_CID_UNEXPECTED",
    [1314658] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_EGLD_WITH_FSM_UNEXPECTED",
    [1314659] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_EAPNSYNC_WRONG_APN_IDX",
    [1314660] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_EAPNSYNC_APN_TOO_LONG",
    [1314661] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_EAPNSYNC_TOO_MUCH_APN_SETTING",
    [1314662] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_MOD_PRIMARY_QOS_IS_NOT_ALLOWED",
    [1314663] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_MOD_QOS_FOR_NO_MS_PF_IS_NOT_ALLOWED",
    [1314667] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_ACT_FAIL_DUE_TO_IRAT_ONGOING",
    [1314668] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_MODIFY_FAIL_DUE_TO_IRAT_ONGOING",
    [1314669] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_DEACT_FAIL_DUE_TO_IRAT_ONGOING",
    [1314670] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_LOCAL_REJECTED_DUE_TO_FSM_UNEXPECTED",
    [1314671] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_LOCAL_REJECTED_DUE_TO_GUARANTEE_RSPONSE_TIME_TIMEOUT",
    [1314672] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_2_CAUSE_START",
    [1314673] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_CID_INVALID",
    [1314674] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_CID_ALREADY_IN_ACTION",
    [1314675] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_UNEXPECTED_LTE_ATTACH_PDN_IN_23G",
    [1314676] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UGTCM_DEACT_DUE_TO_USER_FORCE_TO_LOCAL_RELEASE",
    [1314677] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACT_NOT_SUPPORT_HANDOVER_OF_EMERGENCY_BEARER",
    [1314678] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UGTCM_DEACT_DUE_TO_AOSP_SHUTDOWN",
    [1314679] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UGTCM_DEACT_DUE_TO_AOSP_HANDOVER",
    [1314680] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_GEMINI_SUSPEND",
    [1314681] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_GEMINI_FAILURE",
    [1314682] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_GEMINI_SUSPEND_DUE_TO_CALL_ONGOING",
    [1314683] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UGTCM_DEACT_DUE_TO_APN_CHANGED",
    [1314684] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_DETACH_REATTACH",
    [1314685] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_VGTCM_DEACT_DUE_TO_AOSP_SHUTDOWN",
    [1314686] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_FAIL_CAUSE_REQ_RES_APN_MISMATCH",
    [1314687] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_UGTCM_DEACT_DUE_TO_IMS_HANDOVER",
    [1314702] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_DEACT_DUE_TO_DRB_RELEASE",
    [1314703] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_2_CAUSE_END",
    [1314704] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_3_CAUSE_START",
    [1314705] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_DCONT_PSI_UNEXPECTED",
    [1314706] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_UNEXPECTED_LTE_ATTACH_PDN_IN_5G",
    [1314707] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHECKED_ACT_WITH_CID_SECONDARY_NOT_SUPPORT_IN_5G",
    [1314708] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_VGTCM_DEACT_DUE_TO_USER_FORCE_TO_LOCAL_RELEASE",
    [1314709] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_EGPCO_CID_UNEXPECTED",
    [1314710] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_EGPCO_PSI_UNEXPECTED",
    [1314711] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_EGDCONT_CID_UNEXPECTED",
    [1314712] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_EGDCONT_PSI_UNEXPECTED",
    [1314713] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_EGDCONT_INVALID_PDP_TYPE",
    [1314714] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_HANDOVER_REESTABLISHMENT_NEEDED",
    [1314715] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_HANDOVER_REESTABLISHMENT_FAIL_DUE_TO_NO_WITHOUT_N26_INFO",
    [1314716] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_VGTCM_DEACT_DUE_TO_INTERRAT",
    [1314717] = "PDN_EXT_NETWORK_TCM_CAUSE_RAT_TCM_LOCAL_REJECTED_DUE_TO_ONGOING_PROCESS",
    [1314735] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_3_CAUSE_END",
    [1314736] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_4_CAUSE_START",
    [1314737] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_PSI_NOT_DEFINED",
    [1314738] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_VGTCM_PROCEDURE_ONGOING_ON_CORRESPONDING_CID",
    [1314739] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CHANGE_PSI_FOR_ACTIVE_CID_NOT_ALLOWED",
    [1314740] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CGAUTH_CID_UNEXPECTED",
    [1314741] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_CGAUTH_PSI_UNEXPECTED",
    [1314742] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_VGTCM_UNEXPECTED_FIC_TYPE",
    [1314743] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_PEER_TO_PEER_MODIFY_WITHOUT_P_CSCF",
    [1314744] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_PEER_TO_PEER_MODIFY_WITH_P_CSCF",
    [1314745] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_MODIFY_DUE_TO_INTERRAT",
    [1314746] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACTIVATE_FAIL_DUE_TO_SAT_DATA_CONNECTION_CTRL_FAIL",
    [1314747] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACTIVATE_FAIL_DUE_TO_SAT_NOT_ALLOW",
    [1314748] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACTIVATE_FAIL_DUE_TO_SAT_SIM_ERROR",
    [1314749] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_L4C_ACTIVATE_FAIL_DUE_TO_DEACTIVATE_ABORT",
    [1314767] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_4_CAUSE_END",
    [1314768] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_5_CAUSE_START",
    [1314768] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_REGION_2_CAUSE_START",
    [1314769] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_4G5_EPS_BEARER_MAPPED_FAILED",
    [1314770] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_ATTACH_FAILURE",
    [1314784] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_ESM_REGION_2_CAUSE_END",
    [1314815] = "PDN_EXT_NETWORK_TCM_CAUSE_TCM_REGION_5_CAUSE_END",
    [1314815] = "PDN_EXT_NETWORK_TCM_CAUSE_END",
    [1315328] = "PDN_EXT_NETWORK_PAM_CAUSE_BEGIN",
    [1315329] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_GRANTED",
    [1315336] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_08",
    [1315354] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_26",
    [1315355] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_27",
    [1315356] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_28",
    [1315357] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_29",
    [1315358] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_30",
    [1315359] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_31",
    [1315360] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_32",
    [1315361] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_33",
    [1315362] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_34",
    [1315363] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_35",
    [1315364] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_36",
    [1315365] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_37",
    [1315366] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_38",
    [1315367] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_39",
    [1315369] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_41",
    [1315370] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_42",
    [1315371] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_43",
    [1315372] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_44",
    [1315373] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_45",
    [1315374] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_46",
    [1315375] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_47",
    [1315377] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_49",
    [1315378] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_50",
    [1315379] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_51",
    [1315380] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_52",
    [1315381] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_53",
    [1315382] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_54",
    [1315383] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_55",
    [1315384] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_56",
    [1315387] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_59",
    [1315393] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_65",
    [1315394] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_66",
    [1315409] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_81",
    [1315423] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_95",
    [1315424] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_96",
    [1315425] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_97",
    [1315426] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_98",
    [1315427] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_99",
    [1315428] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_100",
    [1315429] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_101",
    [1315439] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_111",
    [1315440] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_DUE_TO_CAUSE_112",
    [1315528] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_NOT_IN_ACL",
    [1315529] = "PDN_EXT_NETWORK_PAM_CAUSE_PAM_PDN_ACCESS_REJECT_READ_EF_ACL_ONGOING",
    [1315583] = "PDN_EXT_NETWORK_PAM_CAUSE_END",
    [1315584] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_BEGIN",
    [1315585] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_GRANTED",
    [1315586] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_DISABLE_IN_APN_TABLE",
    [1315587] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_ASK_APN_CHANGE_NOT_READY",
    [1315588] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_CHANGE_APN_CLASS",
    [1315589] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_CHANGE_APN_CLASS_AND_THROTTLE",
    [1315590] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_THROTTLE_FOREVER",
    [1315591] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_THROTTLE",
    [1315592] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_THROTTLE_WITH_BACKOFF_TIMER",
    [1315593] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_THROTTLE_FOREVER_CANDIDATE",
    [1315594] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_THROTTLE_NO_RSP",
    [1315595] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_NOT_IN_ACL",
    [1315596] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_STOP_ATTACH_FOR_CLASS1_AND_CLASS2_NOT_ENABLED",
    [1315597] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_WAIT_TIME_NOT_EXPIRED",
    [1315598] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_EXCEED_MAX_PDN_CONN_TRIES",
    [1315599] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_THROTTLE_BY_MAX_PDN_CONN_TRIES",
    [1315600] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_NO_AVAILABLE_CLASS_CAN_BE_USED",
    [1315601] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_APN_IN_USE",
    [1315602] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_VZ_REQ_LTEDATA_39683_FEB_2016",
    [1315603] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_VZ_REQ_LTEDATA_39684_FEB_2016",
    [1315604] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_ALLOC",
    [1315605] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDN_ACCESS_REJECT_MOD",
    [1315616] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_GRANTED",
    [1315617] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_REJECT_THROTTLE_FOREVER",
    [1315618] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_REJECT_THROTTLE",
    [1315619] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_REJECT_THROTTLE_WITH_BACKOFF_TIMER",
    [1315620] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_REJECT_THROTTLE_NO_RSP",
    [1315621] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_REJECT_MOD",
    [1315622] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_REJECT_EST",
    [1315623] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_PAM_OP12_PDU_ACCESS_THROTTLE_EXEMPTION",
    [1315839] = "PDN_EXT_NETWORK_PAM_OP12_CAUSE_END",
    [1315840] = "PDN_EXT_NETWORK_PAM_ATT_CAUSE_BEGIN",
    [1315841] = "PDN_EXT_NETWORK_PAM_ATT_CAUSE_PAM_ATT_PDN_ACCESS_GRANTED",
    [1315842] = "PDN_EXT_NETWORK_PAM_ATT_CAUSE_PAM_ATT_PDN_ACCESS_REJECT_IMS_PDN_BLOCK_TEMP",
    [1315843] = "PDN_EXT_NETWORK_PAM_ATT_CAUSE_PAM_ATT_PDN_ACCESS_REJECT_IMS_PDN_BLOCK_FOREVER",
    [1316095] = "PDN_EXT_NETWORK_PAM_ATT_CAUSE_END",
    [1316096] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_BEGIN",
    [1316097] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_OK",
    [1316098] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CMD_MODE_NOT_SUPPORT",
    [1316099] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CURRENT_RAT_UNKNOWN",
    [1316100] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_NOT_ACTIVE_FOR_CGCONTRDP",
    [1316101] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_NOT_VALID",
    [1316102] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_IE_PARSE_RESULT_IS_NOT_OK",
    [1316103] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_PCO_ID_IS_NOT_VALID",
    [1316104] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_PCO_ID_IS_NOT_SUPPORTED",
    [1316105] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_PCO_ID_SUPPORTED_IS_NOT_PRESENT",
    [1316106] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_NOT_ACTIVE_FOR_BINDING",
    [1316107] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_NOT_ACTIVE_FOR_UNBINDING",
    [1316108] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CMD_NOT_SUPPORT_IN_CURRENT_DOMAIN",
    [1316109] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_ALREADY_BINDED",
    [1316110] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_ALREADY_UNBINDED",
    [1316111] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CMD_NOT_SUPPORT",
    [1316112] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CGCMOD_NOT_SUPPORT_IN_C2K",
    [1316113] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_EGACT_NOT_SUPPORT_IN_C2K",
    [1316114] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_ACTIVE_BUT_NOT_PRIMARY_PDP",
    [1316115] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_CID_IS_NOT_ACTIVE_FOR_SENDING_DATA",
    [1316116] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_CGEV_IND_FROM_CVAL_WITHOUT_CAUSE",
    [1316117] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_CGEV_IND_NO_CAUSE",
    [1316118] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_EGACT_UNEXPECTED_RAT_IN_C2K",
    [1316119] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_AT_ERROR_C2K_LTE_DEACT_RETRY_NEEDED",
    [1316224] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_CAUSE_START",
    [1316225] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_AT_ERROR_CID_IS_ALREADY_BINDED",
    [1316226] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_AT_ERROR_CID_PDN_TRANSFER_ONGOING",
    [1316227] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_OTHER_DIRECTION_IRAT_STARTED_ABORT_REVIVE",
    [1316228] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_EHRPD_ALL_3_ROUNDS_REVIVE_FAIL",
    [1316229] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_DEACT_ABORT_REVIVE",
    [1316230] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_EHRPD_ONE_PDN_REVIVE_SUCCESS_NO_NEED_REVIVE_OTHER",
    [1316231] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_OTHER_DIRECTION_IRAT_STARTED_ABORT_EHRPD_2ND_REVIVE",
    [1316232] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_L4BPDN_LEISIM_OTHER_DIRECTION_IRAT_STARTED_ABORT_EHRPD_3ND_REVIVE",
    [1316351] = "PDN_EXT_NETWORK_L4BPDN_CAUSE_END",
    [1316352] = "PDN_EXT_NETWORK_D2_CAUSE_BEGIN",
    [1316353] = "PDN_EXT_NETWORK_D2_CAUSE_D2AT_OK",
    [1316354] = "PDN_EXT_NETWORK_D2_CAUSE_D2AT_ERROR_EIF_ERROR",
    [1316355] = "PDN_EXT_NETWORK_D2_CAUSE_D2AT_ERROR_EIF_FORMAT_ERROR",
    [1316356] = "PDN_EXT_NETWORK_D2_CAUSE_D2AT_ERROR_INVALID_INTERFACE_ID",
    [1316357] = "PDN_EXT_NETWORK_D2_CAUSE_D2AT_ERROR_INVALID_STATE",
    [1316358] = "PDN_EXT_NETWORK_D2_CAUSE_D2AT_ERROR_DSCONT_WITHOUT_PRIMARY",
    [1316416] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_OK",
    [1316417] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_ERROR",
    [1316418] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_INVALID_INTERFACE_ID",
    [1316419] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_POOL_FULL",
    [1316420] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_INVALID_STATE",
    [1316421] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_INVALID_PARAMETER",
    [1316423] = "PDN_EXT_NETWORK_D2_CAUSE_D2_NETIF_IMS_IP_CHANGES",
    [1316432] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_NW_CAUSE_START",
    [1316448] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_CAUSE_START",
    [1316449] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_APN_NOT_SET",
    [1316450] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_APN_NOT_FOUND",
    [1316451] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_APN_CID_ALLOC_FAIL",
    [1316452] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_TARGET_DETACH",
    [1316453] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_RF_OFF",
    [1316454] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_APN_ON_WIFI",
    [1316455] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_ICCID_NOT_GET",
    [1316456] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_IMS_ON_WIFI",
    [1316457] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IA_UNBIND_ONGOING",
    [1316464] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_OTHER_CAUSE_START",
    [1316465] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_DATA_NOT_ALLOWED",
    [1316466] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IMPORTANT_USER_USING",
    [1316467] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_IMS_CALLING_ON_OTHER_SIM",
    [1316468] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_DUAL_MDALLOW",
    [1316469] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_MDALLOW_NOT_SUPPORT",
    [1316470] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_PS_MODE_UNKNOWN",
    [1316471] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_CS_CALLING_ON_OTHER_SIM",
    [1316472] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_OP12_DATA_NOT_ALLOWED",
    [1316473] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_DSBP_ONGOING",
    [1316474] = "PDN_EXT_NETWORK_D2_CAUSE_D2AM_SIM_NOT_READY",
    [1316560] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_OK",
    [1316561] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_INVAL_ARG",
    [1316562] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_NOT_CONN",
    [1316563] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_ALREADY_PROG",
    [1316564] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_CONN_ABORT",
    [1316565] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_NO_ADDR",
    [1316566] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_NOT_PERM",
    [1316567] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_IN_USE",
    [1316568] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_CONFLICT",
    [1316569] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_UNRECOV",
    [1316575] = "PDN_EXT_NETWORK_D2_CAUSE_D2CPM_CAUSE_END",
    [1316576] = "PDN_EXT_NETWORK_D2_CAUSE_D2CM_CAUSE_START",
    [1316591] = "PDN_EXT_NETWORK_D2_CAUSE_D2CM_CAUSE_END",
    [1316592] = "PDN_EXT_NETWORK_D2_CAUSE_D2PM_CAUSE_START",
    [1316593] = "PDN_EXT_NETWORK_D2_CAUSE_D2PM_D2RM_REJ",
    [1316594] = "PDN_EXT_NETWORK_D2_CAUSE_D2PM_NW_UNKNOWN",
    [1316607] = "PDN_EXT_NETWORK_D2_CAUSE_END",
    [1316608] = "PDN_EXT_NETWORK_DDM_CAUSE_BEGIN",
    [1316609] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_AT_OK",
    [1316610] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_DEFINE_ATTACH_PDN_FAIL",
    [1316611] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_BLOCK_ACT_DATA_CALL",
    [1316612] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_REUSE_PDP_TYPE_NOT_MATCH",
    [1316613] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_IA_IS_ONGOING",
    [1316614] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_ACT_IS_ONGOING",
    [1316615] = "PDN_EXT_NETWORK_DDM_CAUSE_DDM_DEACT_IS_ONGOING",
    [1316863] = "PDN_EXT_NETWORK_DDM_CAUSE_END",
    [1317376] = "PDN_EXT_NETWORK_5GSM_CAUSE_BEGIN",
    [1317377] = "PDN_EXT_NETWORK_5GSM_CAUSE_NO_CAUSE",
    [1317384] = "PDN_EXT_NETWORK_5GSM_CAUSE_OPERATOR_DETERMINED_BARRING",
    [1317402] = "PDN_EXT_NETWORK_5GSM_CAUSE_INSUFFICIENT_RESOURCES",
    [1317403] = "PDN_EXT_NETWORK_5GSM_CAUSE_MISSING_OR_UNKNOWN_DNN",
    [1317404] = "PDN_EXT_NETWORK_5GSM_CAUSE_UNKNOWN_PDU_SESSION_TYPE",
    [1317405] = "PDN_EXT_NETWORK_5GSM_CAUSE_USER_AUTH_FAILED",
    [1317406] = "PDN_EXT_NETWORK_5GSM_CAUSE_REQUEST_REJECTED_BY_SGW_OR_PDNGW",
    [1317407] = "PDN_EXT_NETWORK_5GSM_CAUSE_REQUEST_REJECTED_UNSPECIFIED",
    [1317408] = "PDN_EXT_NETWORK_5GSM_CAUSE_SERVICE_OPT_NOT_SUPPORTED",
    [1317409] = "PDN_EXT_NETWORK_5GSM_CAUSE_REQ_SERVICE_NOT_SUBSCRIBED",
    [1317410] = "PDN_EXT_NETWORK_5GSM_CAUSE_SERVICE_OPT_TEMP_OUT_OF_ORDER",
    [1317411] = "PDN_EXT_NETWORK_5GSM_CAUSE_PTI_ALREADY_USED",
    [1317412] = "PDN_EXT_NETWORK_5GSM_CAUSE_REGULAR_DEACTIVATION",
    [1317413] = "PDN_EXT_NETWORK_5GSM_CAUSE_EPS_QOS_NOT_ACCEPTED",
    [1317414] = "PDN_EXT_NETWORK_5GSM_CAUSE_NETWORK_FAILURE",
    [1317415] = "PDN_EXT_NETWORK_5GSM_CAUSE_REACTIVATION_REQUESTED",
    [1317417] = "PDN_EXT_NETWORK_5GSM_CAUSE_SEMANTIC_ERROR_IN_TFT",
    [1317418] = "PDN_EXT_NETWORK_5GSM_CAUSE_SYNTACTIC_ERROR_IN_TFT",
    [1317419] = "PDN_EXT_NETWORK_5GSM_CAUSE_INVALID_PDU_SESSION_IDENTITY",
    [1317420] = "PDN_EXT_NETWORK_5GSM_CAUSE_SEMANTIC_ERROR_IN_PACKET_FILTERS",
    [1317421] = "PDN_EXT_NETWORK_5GSM_CAUSE_SYNTACTIC_ERROR_IN_PACKET_FILTERS",
    [1317422] = "PDN_EXT_NETWORK_5GSM_CAUSE_OUT_OF_LADN_SERVICE_AREA",
    [1317423] = "PDN_EXT_NETWORK_5GSM_CAUSE_PTI_MISMATCH",
    [1317425] = "PDN_EXT_NETWORK_5GSM_CAUSE_LAST_PDN_DISC_NOT_ALLOWED",
    [1317426] = "PDN_EXT_NETWORK_5GSM_CAUSE_PDU_SESSION_TYPE_IPV4_ONLY_ALLOWED",
    [1317427] = "PDN_EXT_NETWORK_5GSM_CAUSE_PDU_SESSION_TYPE_IPV6_ONLY_ALLOWED",
    [1317428] = "PDN_EXT_NETWORK_5GSM_CAUSE_SINGLE_ADDRESS_ONLY_ALLOWED",
    [1317430] = "PDN_EXT_NETWORK_5GSM_CAUSE_PDU_SESSION_NOT_EXIST",
    [1317431] = "PDN_EXT_NETWORK_5GSM_CAUSE_MULTIPLE_PDN_APN_NOT_ALLOWED",
    [1317432] = "PDN_EXT_NETWORK_5GSM_CAUSE_COLLISION_WITH_NW_INIT_REQUEST",
    [1317433] = "PDN_EXT_NETWORK_5GSM_CAUSE_PDU_SESSION_TYPE_IPV4V6_ONLY_ALLOWED",
    [1317434] = "PDN_EXT_NETWORK_5GSM_CAUSE_PDU_SESSION_TYPE_UNSTRUCTURED_ONLY_ALLOWED",
    [1317435] = "PDN_EXT_NETWORK_5GSM_CAUSE_UNSUPPORTED_QCI_VALUE",
    [1317437] = "PDN_EXT_NETWORK_5GSM_CAUSE_PDU_SESSION_TYPE_ETHERNET_ONLY_ALLOWED",
    [1317441] = "PDN_EXT_NETWORK_5GSM_CAUSE_MAXIMUM_NUM_OF_EPS_BEARERS_REACHED",
    [1317442] = "PDN_EXT_NETWORK_5GSM_CAUSE_REQUESTED_APN_NOT_SUPPORTED_IN_CURRENT_RAT_AND_PLMN_COMBINATION",
    [1317443] = "PDN_EXT_NETWORK_5GSM_CAUSE_INSUFFICIENT_RESOURCES_FOR_SPECIFIC_SLICE_AND_DNN",
    [1317444] = "PDN_EXT_NETWORK_5GSM_CAUSE_NOT_SUPPORTED_SSC_MODE",
    [1317445] = "PDN_EXT_NETWORK_5GSM_CAUSE_INSUFFICIENT_RESOURCES_FOR_SPECIFIC_SLICE",
    [1317446] = "PDN_EXT_NETWORK_5GSM_CAUSE_MISSING_OR_UNKNOWN_DNN_IN_A_SLICE",
    [1317457] = "PDN_EXT_NETWORK_5GSM_CAUSE_INVALID_PTI_VALUE",
    [1317458] = "PDN_EXT_NETWORK_5GSM_CAUSE_MAX_DATA_RATE_PER_UE_FOR_UPLANE_INTEGRITY_PROTECTION_IS_TOO_LOW",
    [1317459] = "PDN_EXT_NETWORK_5GSM_CAUSE_SEMANTIC_ERROR_IN_QOS_OPERATION",
    [1317460] = "PDN_EXT_NETWORK_5GSM_CAUSE_SYNTACTIC_ERROR_IN_QOS_OPERATION",
    [1317461] = "PDN_EXT_NETWORK_5GSM_CAUSE_INVALID_MAPPED_EPS_BEARER_IDENTITY",
    [1317471] = "PDN_EXT_NETWORK_5GSM_CAUSE_SEMANTICLLY_INCORRECT_MSG",
    [1317472] = "PDN_EXT_NETWORK_5GSM_CAUSE_INVALID_MANDATORY_IE",
    [1317473] = "PDN_EXT_NETWORK_5GSM_CAUSE_MSG_TYPE_NON_EXISTENT_OR_NOT_IMPLEMENT",
    [1317474] = "PDN_EXT_NETWORK_5GSM_CAUSE_MSG_TYPE_NOT_COMPATIBLE_STATE",
    [1317475] = "PDN_EXT_NETWORK_5GSM_CAUSE_IE_NON_EXISTENT_NOT_IMPLEMENTED",
    [1317476] = "PDN_EXT_NETWORK_5GSM_CAUSE_CONDITIONAL_IE_ERROR",
    [1317477] = "PDN_EXT_NETWORK_5GSM_CAUSE_MSG_NOT_COMPATIBLE_STATE",
    [1317487] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROTOCOL_ERROR_UNSPECIFIED",
    [1317531] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_START",
    [1317532] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_RESPONDER_REJ_REQ_DUE_TO_NESTED_SAME_REQ",
    [1317533] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_RESPONDER_REJ_REQ_DUE_TO_INVALID_PSI",
    [1317534] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_RESPONDER_REJ_REQ_DUE_VGSM_INIT_MOD_ONGOING",
    [1317535] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_RESPONDER_PROCESSING_TIME_NOT_ENOUGH",
    [1317536] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_RESPONDER_GUARANTEE_RESPONSE_TIMER_TIME_OUT",
    [1317537] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_RESPONDER_REJ_REQ_DUE_TO_VZ_REQ_5GNRSA_10_2_3",
    [1317546] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_PS_SUSPENDED",
    [1317547] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_ERROR_OCCURED",
    [1317548] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_HURRY_UP_REQ",
    [1317549] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_UAC_BARRING",
    [1317550] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_FATAL_FAIL",
    [1317551] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_ABORT_PROC_DUE_TO_POSSIBLE_LONG_GEMINI_SUSPEND",
    [1317552] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_TRANSMISSION_FAILURE",
    [1317553] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CONN_REJ_REQ_DUE_TO_S_NSSAI_REJECTED",
    [1317556] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_SYSTEM_STATE_CHECK_FAIL",
    [1317557] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_REQ_INFO_ERROR",
    [1317558] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_TX_FAILURE",
    [1317559] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_TIMER_TIMEOUT",
    [1317560] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_LOCAL_RELEASE",
    [1317561] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_CANCLE_BY_RELEASE_FROM_UPPER_LAYER",
    [1317562] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_NW_RELEASE_ABORT_ORIGINAL_PROCEDURE",
    [1317563] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MSG_NOT_FORWARD_ROUTING_FAILURE",
    [1317564] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MSG_NOT_FORWARD_DNN_NOT_SUPPORT_IN_SLICE",
    [1317565] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MSG_NOT_FORWARD_PLMN_MAX_NUM_PDU_SESSION_REACH",
    [1317566] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MT_MOD_ABORT_ORIGINAL_PROCEDURE",
    [1317567] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MT_MOD_ONGOING_MO_MOD_NOT_ALLOW",
    [1317568] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_SYNC_PDUS_STATUS_WITH_NW",
    [1317569] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_UE_DEREGISTER_FROM_NW",
    [1317570] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_5G23_DO_LOCAL_RELEASE",
    [1317571] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_THIS_PDU_WAS_REVIVED_IN_4G",
    [1317572] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_INTERSYSTEM_CHANGE_ABORT",
    [1317573] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_PDU_SESSION_ALREADY_DEACTIVATE",
    [1317574] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_5G4_MAP_FAILED",
    [1317575] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_TRIGGERED_BY_RQOS",
    [1317576] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_THIS_PDUS_CANNOT_TO_4G",
    [1317577] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_SYSTEM_STATE_UNSYNC_WITH_UPPER_LAYER",
    [1317578] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_UPPER_LAYER_REQ_FORCE_TO_LOCAL_REL_PDUS",
    [1317579] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_SYNC_EPSB_STATUS_WITH_NW",
    [1317580] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_PAM_REJECT_REQ",
    [1317581] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_SECOND_EMC_PDUS_NOT_ALLOW",
    [1317582] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_EST_NON_EMC_PDUS_NOT_ALLOW_WHEN_ENTER_EMC_REGISTERED",
    [1317583] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_THIS_MOD_REQ_ON_EMC_PDUS_IS_NOT_ALLOWED",
    [1317584] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_SNSSAI_NOT_IN_NSSAI",
    [1317585] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_DUE_TO_DETACH_WITH_REATTACH_REQUIRED",
    [1317586] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MSG_TYPE_NON_EXISTENT_OR_NOT_IMPLEMENT_INDICATED_BY_5GSM_STATUS",
    [1317587] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_TRIGGERED_BY_SNSSAI_UPDATE",
    [1317588] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_VGMM_ENTER_EMC_TO_LOCAL_RELEASE",
    [1317589] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_PROCESS_NW_MOD_COMMAND_OK",
    [1317590] = "PDN_EXT_NETWORK_5GSM_CAUSE_PROPRIETARY_CAUSE_CORE_MSG_NOT_FORWARD_RESTRICTED_SERVICE_AREA",
    [1317631] = "PDN_EXT_NETWORK_5GSM_CAUSE_END",
    [1317632] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_BEGIN",
    [1317640] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_8",
    [1317658] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_26",
    [1317659] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_27",
    [1317660] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_28",
    [1317661] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_29",
    [1317662] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_30",
    [1317663] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_31",
    [1317664] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_32",
    [1317665] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_33",
    [1317666] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_34",
    [1317667] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_35",
    [1317668] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_36",
    [1317669] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_37",
    [1317670] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_38",
    [1317671] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_39",
    [1317673] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_41",
    [1317674] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_42",
    [1317675] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_43",
    [1317676] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_44",
    [1317677] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_45",
    [1317678] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_46",
    [1317679] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_47",
    [1317681] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_49",
    [1317682] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_50",
    [1317683] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_51",
    [1317686] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_54",
    [1317687] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_55",
    [1317688] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_56",
    [1317689] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_57",
    [1317691] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_59",
    [1317690] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_58",
    [1317693] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_61",
    [1317697] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_65",
    [1317698] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_66",
    [1317699] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_67",
    [1317700] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_68",
    [1317701] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_69",
    [1317702] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_70",
    [1317713] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_81",
    [1317714] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_82",
    [1317715] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_83",
    [1317716] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_84",
    [1317717] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_85",
    [1317727] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_95",
    [1317728] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_96",
    [1317729] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_97",
    [1317730] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_98",
    [1317731] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_99",
    [1317732] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_100",
    [1317733] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_101",
    [1317743] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_CAUSE_111",
    [1317760] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_NOT_FORWARDED_CAUSE_START",
    [1317761] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_DNN_NOT_SUPPORT_IN_SLICE",
    [1317762] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_5G_PDU_SESSION_ACCESS_REJECT_DUE_TO_MAX_PDU_SESSION_REACHED",
    [1317763] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_VGSM_REJECT_DUE_TO_LADN_OUT_OF_SERVICE_AREA",
    [1317764] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_PAM_VGSM_REJECT_DUE_TO_LADN_TABLE_VERSION_NOT_UNSYNC",
    [1317887] = "PDN_EXT_NETWORK_EXT_PAM_CAUSE_END",
    [1376255] = "PDN_EXT_NETWORK_ERROR_END",
    [1376256] = "PDN_EXT_LOCAL_MIPC_ERROR_BEGIN",
    [1376257] = "PDN_EXT_LOCAL_MIPC_ERROR_NO_ENOUGH_INFO",
    [1376511] = "PDN_EXT_LOCAL_MIPC_ERROR_END",
    [1376512] = "PDN_EXT_LOCAL_PARA_ERROR_BEGIN",
    [1376513] = "PDN_EXT_LOCAL_PARA_ERROR_INVALID_PARA",
    [1376514] = "PDN_EXT_LOCAL_PARA_ERROR_NOT_FIND_APN_TO_ACT",
    [1376515] = "PDN_EXT_LOCAL_PARA_ERROR_NO_APN_INFO_TO_ABORT",
    [1376516] = "PDN_EXT_LOCAL_PARA_ERROR_APN_PROFILE_IS_DISABLED",
    [1376517] = "PDN_EXT_LOCAL_PARA_ERROR_NOT_FIND_CALL_INFO",
    [1376518] = "PDN_EXT_LOCAL_PARA_ERROR_REACH_MAX_USER",
    [1376519] = "PDN_EXT_LOCAL_PARA_ERROR_PROFILE_COUNT_ERROR",
    [1376520] = "PDN_EXT_LOCAL_PARA_ERROR_WRONG_APN_TYPE_OR_NO_APN",
    [1376521] = "PDN_EXT_LOCAL_PARA_ERROR_URSP_PLMN_LIST_ERROR",
    [1376767] = "PDN_EXT_LOCAL_PARA_ERROR_END",
    [1376768] = "PDN_EXT_LOCAL_FALLBACK_RES_START",
    [1376769] = "PDN_EXT_LOCAL_FALLBACK_RES_FAIL_ABORT",
    [1376770] = "PDN_EXT_LOCAL_FALLBACK_RES_SUCC_ABORT",
    [1376771] = "PDN_EXT_LOCAL_FALLBACK_RES_FAIL_CONT",
    [1376772] = "PDN_EXT_LOCAL_FALLBACK_RES_SUCC_CONT",
    [1376783] = "PDN_EXT_LOCAL_FALLBACK_RES_END",
    [1572863] = "PDN_EXT_END",
    [1572864] = "RF_EXT_BEGIN",
    [1835007] = "RF_EXT_END",
    [1835008] = "SIM_EXT_BEGIN",
    [1835009] = "SIM_EXT_PUK1_REQUIRED",
    [1835010] = "SIM_EXT_PIN2_REQUIRED",
    [1835011] = "SIM_EXT_PUK2_REQUIRED",
    [1835012] = "SIM_EXT_SIM_FAILURE",
    [1835013] = "SIM_EXT_INCORRECT_PASS_WORD",
    [1835014] = "SIM_EXT_NW_PERSON_PIN_REQUIRED",
    [1835015] = "SIM_EXT_NW_PERSON_PUK_REQUIRED",
    [1835016] = "SIM_EXT_NW_SUB_PERSON_PIN_REQUIRED",
    [1835017] = "SIM_EXT_NW_SUB_PERSON_PUK_REQUIRED",
    [1835018] = "SIM_EXT_SP_PERSON_PIN_REQUIRED",
    [1835019] = "SIM_EXT_SP_PERSON_PUK_REQUIRED",
    [1835020] = "SIM_EXT_CORP_PERSON_PIN_REQUIRED",
    [1835021] = "SIM_EXT_CORP_PERSON_PUK_REQUIRED",
    [1835022] = "SIM_EXT_IMSI_PERSON_PIN_REQUIRED",
    [1835023] = "SIM_EXT_IMSI_PERSON_PUK_REQUIRED",
    [1835024] = "SIM_EXT_LINK_NS_SP_PERSON_PIN_REQUIRED",
    [1835025] = "SIM_EXT_LINK_NS_SP_PERSON_PUK_REQUIRED",
    [1835026] = "SIM_EXT_LINK_SIM_C_PERSON_PIN_REQUIRED",
    [1835027] = "SIM_EXT_LINK_SIM_C_PERSON_PUK_REQUIRED",
    [1835028] = "SIM_EXT_BT_SAP_UNDEFINED",
    [1835029] = "SIM_EXT_BT_SAP_NOT_ACCESSIBLE",
    [1835030] = "SIM_EXT_BT_SAP_CARD_REMOVED",
    [1835031] = "SIM_EXT_BT_SAP_CARD_ALREADY_POWERED_OFF",
    [1835032] = "SIM_EXT_BT_SAP_CARD_ALREADY_POWERED_ON",
    [1835033] = "SIM_EXT_TECHNICAL_PROBLEM",
    [1835034] = "SIM_EXT_VERIFYCATION_FAILED",
    [1835035] = "SIM_EXT_REBOOT_REQUIRED",
    [1835036] = "SIM_EXT_SIM_OFF",
    [2097151] = "SIM_EXT_END",
    [2097152] = "SMS_EXT_BEGIN",
    [2097153] = "SMS_EXT_CBM_CFG_WRONG_MSG_ID_RANGE_FORMAT",
    [2097154] = "SMS_EXT_CBM_CFG_WRONG_MSG_ID_SINGLE_FORMAT",
    [2097155] = "SMS_EXT_CBM_CFG_WRONG_DCS_RANGE_FORMAT",
    [2097156] = "SMS_EXT_CBM_CFG_WRONG_DCS_SINGLE_FORMAT",
    [2097157] = "SMS_EXT_CBM_CFG_TOO_MORE_RANGES_OR_SINGLES",
    [2097158] = "SMS_EXT_CBM_CFG_MSG_ID_LOGIC_ERROR",
    [2097159] = "SMS_EXT_CBM_CFG_DCS_LOGIC_ERROR",
    [2097160] = "SMS_EXT_NEED_SET_PREFER_STORAGE_AGAIN",
    [2097161] = "SMS_EXT_C2K_ERROR",
    [2162688] = "SMS_EXT_AT_ERROR_BEGIN",
    [2162914] = "SMS_EXT_CM_SMS_CONNECTION_BROKEN",
    [2165289] = "SMS_EXT_MTK_FDN_CHECK_FAILURE",
    [2168833] = "SMS_EXT_MTK_REQ_RETRY",
    [2228223] = "SMS_EXT_AT_ERROR_END",
    [2359295] = "SMS_EXT_END",
    [2359296] = "SS_EXT_BEGIN",
    [2621439] = "SS_EXT_END",
    [2621440] = "SWITCH_EXT_BEGIN",
    [2883583] = "SWITCH_EXT_END",
    [2883584] = "SYS_EXT_BEGIN",
    [2883585] = "SYS_EXT_HBA_PROCESS_OK ",
    [2883586] = "SYS_EXT_HBA_NUM_ALREADY_MAX",
    [2883587] = "SYS_EXT_HBA_PROXY_ALREADY_EXIST",
    [2883588] = "SYS_EXT_HBA_INTERNAL_ABNORMAL",
    [2883589] = "SYS_EXT_HBA_PROXY_NOT_EXIST",
    [2883590] = "SYS_EXT_HBA_HW_FILTER_EXHAUST",
    [2883591] = "SYS_EXT_HBA_PASUE_ERR",
    [2883592] = "SYS_EXT_HBA_RESUME_ERR",
    [2883593] = "SYS_EXT_HBA_STOP_ERR",
    [2883594] = "SYS_EXT_HBA_SEDN_TIME_OUT",
    [2883595] = "SYS_EXT_HBA_ACK_TIME_OUT",
    [2883839] = "SYS_EXT_HBA_RESULT_INVALID",
    [2883840] = "SYS_EXT_NVRAM_READ_DISABLE",
    [2883841] = "SYS_EXT_NVRAM_WRITE_DISABLE",
    [2883856] = "SYS_EXT_PCIE_ERR_UNKNOWN",
    [2883857] = "SYS_EXT_PCIE_ALIVE",
    [3145727] = "SYS_EXT_END",
    [3145728] = "IMS_EXT_BEGIN",
    [3407871] = "IMS_EXT_END",
    [3407872] = "PHB_EXT_BEGIN",
    [3407873] = "PHB_EXT_PIN2_REQUIRED",
    [3407874] = "PHB_EXT_PUK2_REQUIRED",
    [3407875] = "PHB_EXT_TEXT_STRING_TOO_LONG",
    [3407876] = "PHB_EXT_DIAL_STRING_TOO_LONG",
    [3473407] = "PHB_EXT_END",
    [4294967294] = "AUTH_REQUIRED",
    [4294967295] = "TIMEOUT",
}
EXIMS_ACTION_TYPE = {
    [0] = "CALL",
    [1] = "SMS",
    [2] = "ECALL",
    [3] = "ESMS",
    [4] = "ECBM",
    [5] = "SCBM",
}
EXIMS_SESSION_STATUS = {
    [0] = "END",
    [1] = "START",
}
EXIMS_HO_STATUS = {
    [0] = "END",
    [1] = "START",
}
EXIMS_CALL_TYPE = {
    [0] = "VOICE",
    [1] = "VIDEO",
    [2] = "EMERGENCY",
}
EXIMS_CALL_STATUS = {
    [0] = "INVITE",
    [1] = "PROGRESS",
    [2] = "ALERTING",
    [3] = "CONNECTED",
    [4] = "DISCONNECTED",
    [5] = "FAILURE",
}
EXIMS_CALL_FAILURE_CAUSE = {
    [0] = "ILLEGAL_OPERATION",
    [1] = "IMS_CORE_FAILURE",
    [2] = "TEMPORARILY_ERROR",
    [3] = "NETWORK_ERROR",
    [255] = "UNSPECIFIED",
}
EXIMS_SMS_DOMAIN = {
    [0] = "NAS",
    [1] = "IMS",
}
EXIMS_SMS_STATUS = {
    [0] = "END",
    [1] = "START",
    [2] = "FAIL",
}
EXIMS_REG_STATE = {
    [0] = "NOT_REGISTERED",
    [1] = "REGISTERED",
    [2] = "REGISTRATION_START",
    [3] = "DEREGISTRATION_START",
    [4] = "OOS",
}
EXIMS_EXT_INFO = {
    [1] = "RTP_VOICE",
    [2] = "RTP_TEXT",
    [4] = "SMS_IMS",
    [8] = "RTP_VIDEO",
}
EXIMS_DEREG_CAUSE = {
    [0] = "UNSPECIFIED",
    [1] = "POWER_OFF",
    [2] = "RF_OFF",
    [7] = "SIM_NOT_READY",
    [50] = "TEMPORARY_FAILURE_DEFAULT",
    [51] = "TEMPORARY_FAILURE_SPECIFIED",
    [60] = "PERMANENT_FAILURE",
}
EXIMS_RETRY_TYPE = {
    [0] = "NO_RETRY",
    [1] = "RETRY",
}
EXIMS_URI_TYPE = {
    [0] = "MSISMDN",
    [1] = "IMSI",
}
EXIMS_CONFIG_TYPE = {
    [0] = "DISABLE",
    [1] = "LTE_ENABLE",
    [3] = "LTE_NR_ENABLE",
}
EXIMS_REG_TYPE = {
    [0] = "NORMAL",
    [1] = "EMERGENCY",
}
EXIMS_EMERGENCY_SUPPORT = {
    [0] = "NOT_SUPPORT",
    [1] = "NR_5GCN_ONLY",
    [2] = "EUTRA_5GCN_ONLY",
    [3] = "NR_5GVN__EUTRA_5GCN",
}
EXIMS_RAT = {
    [0] = "NONE",
    [1] = "GSM",
    [2] = "UMTS",
    [4] = "LTE",
    [8] = "NR",
    [32] = "WIFI",
    [64] = "EHRPD",
}
EXIMS_REGISTER_EVENT = {
    [0] = "NORMAL",
    [1] = "PCO_TRIGGER",
    [2] = "MAX",
}
EXIMS_SIP_CAUSE = {
    [0] = "UNSPECIFIED",
    [300] = "300_MULTIPLE_CHOICES",
    [301] = "301_MOVED_PERMANENTLY",
    [302] = "302_MOVED_TEMPORARILY",
    [305] = "305_USE_PROXY",
    [380] = "380_ALTERNATIVE_SERVICE",
    [400] = "400_BAD_REQUEST",
    [401] = "401_UNAUTHORIZED",
    [402] = "402_PAYMENT_REQUIRED",
    [403] = "403_FORBIDDEN",
    [404] = "404_NOT_FOUND",
    [405] = "405_METHOD_NOT_ALLOWED",
    [406] = "406_NOT_ACCEPTABLE",
    [407] = "407_PROXY_AUTHENTICATION_REQUIRED",
    [408] = "408_REQUEST_TIMEOUT",
    [410] = "410_GONE",
    [413] = "413_REQUEST_ENTITY_TOO_LARGE",
    [414] = "414_REQUEST_URI_TOO_LARGE",
    [415] = "415_UNSUPPORTED_MEDIA_TYPE",
    [416] = "416_UNSUPPORTED_URI_SCHEME",
    [420] = "420_BAD_EXTENSION",
    [421] = "421_EXTENSION_REQUIRED",
    [423] = "423_INTERVAL_TOO_BRIEF",
    [480] = "480_TEMPORARILY_NOT_AVAILABLE",
    [481] = "481_CALL_LEG_TRANSACTION_DOES_NOT_EXIST",
    [482] = "482_LOOP_DETECTED",
    [483] = "483_TOO_MANY_HOPS",
    [484] = "484_ADDRESS_INCOMPLETE",
    [485] = "485_AMBIGUOUS",
    [486] = "486_BUSY_HERE",
    [487] = "487_REQUEST_TERMINATED",
    [488] = "488_NOT_ACCEPTABLE_HERE",
    [491] = "491_REQUEST_PENDING",
    [493] = "493_UNDECIPHERABLE",
    [494] = "494_SECURITY_AGREEMENT_REQUIRED",
    [500] = "500_SERVER_INT_ERROR",
    [501] = "501_NOT_IMPLEMENTED",
    [502] = "502_BAD_GATEWAY",
    [503] = "503_SERVICE_UNAVAILABLE",
    [504] = "504_SERVER_TIME_OUT",
    [505] = "505_SIP_VERSION_NOT_SUPPORTED",
    [513] = "513_MESSAGE_TOO_LARGE",
    [580] = "580_PRECONDITION_FAILURE",
    [600] = "600_BUSY_EVERYWHERE",
    [603] = "603_DECLINE",
    [604] = "604_DOES_NOT_EXIST_ANYWHERE",
    [606] = "606_NOT_ACCEPTABLE",
    [700] = "700_INTERNAL_REQUEST_TIMEOUT",
    [800] = "UNKNOWN",
    [800] = "MAX",
}
EXIMS_ACCESS_TYPE = {
    [0] = "DEFAULT",
    [1] = "VODATA_ON_SIM1",
    [2] = "VODATA_ON_SIM2",
    [3] = "VODATA_ON_SIM3",
    [4] = "VODATA_ON_SIM4",
}
EXIMS_CALL_DOMAIN_CAUSE = {
    [1] = "NOT_REGISTERED",
    [2] = "NO_AVAILABLE_NW",
    [3] = "BARRING_IN_CURRENT_NW",
    [4] = "EXHAUST_ATTEMPT_COUNT",
    [5] = "GLOBAL_RAT_MODE_REQUIRED",
    [255] = "UNSPECIFIED",
}
EXIMS_CALL_BAR = {
    [1] = "SSAC_VOICE",
    [2] = "SSAC_VIDEO",
    [4] = "UAC_VOICE",
    [8] = "UAC_VIDEO",
    [16] = "UAC_EMERGENCY_CALL",
}
EXIMS_SMS_BAR = {
    [1] = "UAC_SMS",
}
EXIMS_REG_BAR = {
    [1] = "UAC_REG",
}
EXIMS_RAN = {
    [0] = "CELLULAR",
    [1] = "WIFI",
}
EXIMS_SRVCC_STATUS_UPDATE_ENUM = {
    [0] = "EXIMS_SRVCC_STATUS_HO_STARTED",
    [1] = "EXIMS_SRVCC_STATUS_HO_SUCCESSFUL",
    [2] = "EXIMS_SRVCC_STATUS_HO_FAILED",
    [3] = "EXIMS_SRVCC_STATUS_HO_CANCELLED",
    [4] = "EXIMS_SRVCC_STATUS_HO_VSRVCC_STARTED",
    [5] = "EXIMS_SRVCC_STATUS_HO_VSRVCC_SUCCESSFUL",
    [6] = "EXIMS_SRVCC_STATUS_HO_MAX",
}
EXIMS_IMS_DEREG_ENUM = {
    [0] = "SET_RAT_MODE_NONE",
    [1] = "SET_RAT_MODE_DETACH",
    [2] = "2G_CHANGE",
}
EXIMS_SERVICE_FAIL_CAUSE_ENUM = {
    [0] = "AC_BARRED",
    [1] = "NW_REJECT_CONN",
    [2] = "T3346_TIMER_START",
    [3] = "T3346_TIMER_STOP",
    [4] = "T3346_TIMER_EXPIRY",
    [5] = "CONN_FAIL",
    [6] = "T3525_START",
    [7] = "T3540_START",
}
EXIMS_SRVCC_CALL_MODE_ENUM = {
    [0] = "EXIMS_SRVCC_CALL_MODE_VOICE",
    [1] = "EXIMS_SRVCC_CALL_MODE_VIDEO",
    [2] = "EXIMS_SRVCC_CALL_MODE_EMERGENCY",
    [3] = "EXIMS_SRVCC_CALL_MODE_VOICE_CONFERENCE",
    [4] = "EXIMS_SRVCC_CALL_MODE_VIDEO_CONFERENCE",
    [5] = "EXIMS_SRVCC_CALL_MODE_VOICE_CONFERENCE_PARTS",
    [6] = "EXIMS_SRVCC_CALL_MODE_VIDEO_CONFERENCE_PARTS",
    [7] = "EXIMS_SRVCC_CALL_MODE_MAX",
}
EXIMS_SRVCC_CALL_DIRECTION_ENUM = {
    [0] = "EXIMS_SRVCC_CALL_DIRECTION_MO",
    [1] = "EXIMS_SRVCC_CALL_DIRECTION_MT",
    [2] = "EXIMS_SRVCC_CALL_DIRECTION_MAX",
}
EXIMS_SRVCC_CALL_STATE_ENUM = {
    [0] = "EXIMS_SRVCC_CALL_STATE_EARLY",
    [1] = "EXIMS_SRVCC_CALL_STATE_EARLY_WITH_MEDIA",
    [2] = "EXIMS_SRVCC_CALL_STATE_ACTIVE",
    [3] = "EXIMS_SRVCC_CALL_STATE_ON_HOLD",
    [4] = "EXIMS_SRVCC_CALL_STATE_PRE_ALERTING",
    [5] = "EXIMS_SRVCC_CALL_STATE_PRE_ALERTING_WITH_MEDIA",
    [6] = "EXIMS_SRVCC_CALL_STATE_ACTIVE_RETRY_CC_CONNECT",
    [7] = "EXIMS_SRVCC_CALL_STATE_MAX",
}
EXIMS_SRVCC_CALL_ECC_CATEGORY_ENUM = {
    [0] = "EXIMS_SRVCC_CALL_ECC_CTGY_UNSPECIFIED",
    [1] = "EXIMS_SRVCC_CALL_ECC_CTGY_POLICE",
    [2] = "EXIMS_SRVCC_CALL_ECC_CTGY_AMBULANCE",
    [4] = "EXIMS_SRVCC_CALL_ECC_CTGY_FIRE",
    [8] = "EXIMS_SRVCC_CALL_ECC_CTGY_MARINE",
    [16] = "EXIMS_SRVCC_CALL_ECC_CTGY_MOUNTAIN",
    [64] = "EXIMS_SRVCC_CALL_ECC_CTGY_MANUALLY",
    [128] = "EXIMS_SRVCC_CALL_ECC_CTGY_AUTO",
    [256] = "EXIMS_SRVCC_CALL_ECC_CTGY_GAS",
    [512] = "EXIMS_SRVCC_CALL_ECC_CTGY_ANIMAL",
    [1024] = "EXIMS_SRVCC_CALL_ECC_CTGY_PHYSICIAN",
    [2048] = "EXIMS_SRVCC_CALL_ECC_CTGY_POISON",
    [4096] = "EXIMS_SRVCC_CALL_ECC_CTGY_TRAFFIC",
    [8192] = "EXIMS_SRVCC_CALL_ECC_CTGY_COUNTRY_SPECIFIC",
    [32768] = "EXIMS_SRVCC_CALL_ECC_CTGY_UNRECOGNIZED",
    [3] = "EXIMS_SRVCC_CALL_ECC_CTGY_KR_SPIES",
    [6] = "EXIMS_SRVCC_CALL_ECC_CTGY_KR_INTELLIGENCE",
    [9] = "EXIMS_SRVCC_CALL_ECC_CTGY_KR_SMUGGLING",
    [18] = "EXIMS_SRVCC_CALL_ECC_CTGY_KR_SCHOOL_VIOLENCE",
    [19] = "EXIMS_SRVCC_CALL_ECC_CTGY_KR_CYBERTERRORISM",
    [65535] = "EXIMS_SRVCC_CALL_ECC_CTGY_MAX",
}
SMS_DIRECTION = {
    [0] = "MO",
    [1] = "MT",
}
SMS_TYPE = {
    [0] = "REGULAR_SMS",
    [1] = "STK_SMS",
    [2] = "EMERGENCY_SMS",
}
NW_DATA_BEARER_CAPABILITY = {
    [0] = "NONE_ACTIVATE",
    [18] = "LTE_CAPABBILITY",
    [19] = "LTE_CA_CAPABILITY",
}
NW_SIGNAL_MODULATION = {
    [0] = "BPSK",
    [1] = "QPSK",
    [2] = "8PSK",
    [3] = "16QAM",
    [4] = "32QAM",
    [5] = "64QAM",
}
NW_RAT_MODE = {
    [0] = "GSM",
    [1] = "UMTS",
    [2] = "GSM_UMTS",
    [3] = "LTE",
    [4] = "GSM_LTE",
    [5] = "UMTS_LTE",
    [6] = "GSM_UMTS_LTE",
    [7] = "C2K",
    [8] = "GSM_C2K",
    [9] = "UMTS_C2K",
    [10] = "GSM_UMTS_C2K",
    [11] = "LTE_C2K",
    [12] = "GSM_LTE_C2K",
    [13] = "UMTS_LTE_C2K",
    [14] = "GSM_UMTS_LTE_C2K",
    [15] = "NR",
    [16] = "GSM_NR",
    [17] = "UMTS_NR",
    [18] = "GSM_UMTS_NR",
    [19] = "LTE_NR",
    [20] = "GSM_LTE_NR",
    [21] = "UMTS_LTE_NR",
    [22] = "GSM_UMTS_LTE_NR",
    [23] = "NR_C2K",
    [24] = "GSM_NR_C2K",
    [25] = "UMTS_NR_C2K",
    [26] = "GSM_UMTS_NR_C2K",
    [27] = "LTE_NR_C2K",
    [28] = "GSM_LTE_NR_C2K",
    [29] = "UMTS_LTE_NR_C2K",
    [30] = "GSM_UMTS_LTE_NR_C2K",
    [31] = "IOTNTN",
}
NW_PREFER_RAT = {
    [0] = "NO_PREFER",
    [1] = "GSM_PREFER",
    [2] = "UMTS_PREFER",
    [4] = "LTE_PREFER",
    [16] = "C2K_PREFER",
    [128] = "NR_PREFER",
}
NW_ACCESS_TECH = {
    [0] = "GSM",
    [2] = "UTRAN",
    [3] = "GSM_EGPRS",
    [4] = "UTRAN_HSDPA",
    [5] = "UTRAN_HSUPA",
    [6] = "UTRAN_HSDPA_HSUPA",
    [7] = "EUTRAN",
    [8] = "EC_GSM_IOT",
    [9] = "EUTRAN_NBS1_MODE",
    [10] = "EUTRAN_5GCN",
    [11] = "NR_5GCN",
    [12] = "NR_EPS",
    [13] = "NG_RAN",
    [14] = "EUTRA_NR_DUAL",
    [255] = "UNKNOWN",
}
NW_RAT_LOCK = {
    [0] = "UNLOCK",
    [1] = "LOCK",
}
NW_MIPI_OP = {
    [0] = "READ",
    [1] = "WRITE",
}
NW_MIPI_RW_TYPE = {
    [0] = "MIPI_RW",
    [1] = "MIPI_EXTRW_1BYTE",
}
NW_MIPI_CAUSE = {
    [1] = "MIPI_PORT_INVALID",
}
NW_BPI_OP = {
    [0] = "READ",
    [1] = "WRITE",
}
NW_ENDC_DEACTIVATE_MODE = {
    [0] = "DISABLE",
    [1] = "ENABLE",
    [2] = "DEACTIVATE_WITHOUT_SEND_SCG_FAILURE",
}
NW_SA_SLIENCE_MODE = {
    [0] = "OFF",
    [1] = "ON",
    [2] = "ENABLE_HANDOVER_ONLY",
    [3] = "REST_ONLY",
}
NW_SA_BLOCKING_MODE = {
    [0] = "NO_BLOCKING",
    [1] = "BLOCKING",
}
NW_TX_RAT_MODE = {
    [0] = "LTE",
    [1] = "NR",
    [2] = "NR_FR1",
    [3] = "NR_FR2",
    [4] = "LTE_NR_FR1",
    [5] = "LTE_NR_FR2",
    [6] = "LTE_NR",
    [7] = "GSM",
    [8] = "WCDMA",
    [9] = "C2K",
}
NW_CG_TYPE = {
    [0] = "MCG",
    [1] = "SCG",
    [2] = "ALL_CG",
    [255] = "INVALID",
}
NW_OVERHEATING_STATUS = {
    [0] = "FAIL",
    [1] = "SUCCESS",
}
NW_UAI_OP = {
    [0] = "LEAVE",
    [1] = "ENTER",
}
NW_SASE_CAUSE = {
    [0] = "NONE",
    [1] = "NOT_SUPPORTED",
    [2] = "T345_PENDING",
    [3] = "UNDER_LV_SESSION",
    [4] = "NO_NEED_TO_SEND",
    [5] = "CONNECTED_NOT_ALLOWED",
}
NW_MIMO_FR_DL = {
    [0] = "MIMO_LAYERS_DL2",
    [1] = "MIMO_LAYERS_DL4",
    [2] = "MIMO_LAYERS_DL8",
}
NW_MIMO_FR_UL = {
    [0] = "MIMO_LAYERS_UL1",
    [1] = "MIMO_LAYERS_UL2",
    [2] = "MIMO_LAYERS_UL4",
}
NW_UAI_POWER_SAVING_TYPE = {
    [0] = "MAX_CC",
    [1] = "MAX_MIMO",
    [2] = "DRX",
    [3] = "MAX_BW",
    [4] = "MIN_SCHED",
}
NW_UAI_REQ_OP = {
    [0] = "UAI_NOT_SUPPORT",
    [1] = "UAI_ALREADY_SENT_ENTER_REQ",
    [2] = "UAI_ALREADY_SENT_LEAVE_REQ",
    [3] = "UAI_ALREADY_PENDING_ENTER_REQ",
    [4] = "UAI_ALREADY_PENDING_LEAVE_REQ",
}
NW_RRC_RELEASE_OP = {
    [0] = "RRC_IDLE",
    [1] = "RRC_INACTIVE",
    [2] = "RRC_OUT_OF_CONNECTED",
    [3] = "RRC_CONNECTED",
}
NW_FAKE_RI_BAND = {
    [0] = "FR1",
    [1] = "FR2",
    [255] = "INVALID",
}
NW_FAKE_RI_CTRL_RANK = {
    [0] = "RANK1",
    [1] = "RANK2",
    [2] = "RANK4",
}
NW_FAKE_RI_RAT = {
    [1] = "LTE",
    [2] = "NR",
}
NW_FTAI_ATTR_ALL_WITH_TYPE = {
    [0] = "FTAI_ATTR_NONE",
    [1] = "FTAI_ATTR_ALL_WITH_INTEGRITY",
    [2] = "FTAI_ATTR_ALL_WITH_NON_INTEGRITY",
}
NW_EPSFB_STATE_ENUM = {
    [0] = "STARTED",
    [1] = "SUCCESSFUL",
    [2] = "FAILURE",
    [3] = "NOT_ALLOWED",
}
NW_EPSFB_TYPE_ENUM = {
    [0] = "HANDOVER",
    [1] = "REDIRECT",
}
NW_TAU_FAIL_CAUSE_ENUM = {
    [0] = "DEFAULT",
}
SYS_COEX_UART_MODE_OP = {
    [0] = "Disable",
    [1] = "Enable",
}
SYS_PCIE_USER = {
    [0] = "DPMAIF",
    [1] = "CLDMA",
    [5] = "NO_USER",
}
SYS_NVRAM_CAUSE = {
    [0] = "OK",
    [1] = "FAIL",
    [2] = "NOT_READY",
    [3] = "INVALID_PTR",
    [4] = "INVALID_ENTITY_ID",
    [5] = "INVALID_REC_INDEX",
    [6] = "INVALID_REC_AMOUNT",
    [7] = "INVALID_LOCK_TYPE",
    [8] = "INVALID_BUF",
    [9] = "INVALID_BUF_SIZE",
    [10] = "INVALID_CMD",
    [11] = "INVALID_CHKSUM_TYPE",
    [12] = "INVALID_RESET_CATEGORY",
    [13] = "WRITE_LOCKED",
    [14] = "ACCESS_DENIED",
    [15] = "ACCESS_CUSTOM_DENIED",
    [16] = "SIG_CHK_FAIL",
    [17] = "MON_POOL_OVERFLOW",
}
SYS_MDDBG_CONTROL_TYPE = {
    [0] = "MDDBG_CONTROL_TYPE_MMV1",
    [1] = "MDDBG_CONTROL_TYPE_DIAG",
    [2] = "MDDBG_CONTROL_TYPE_WP",
    [3] = "MDDBG_CONTROL_TYPE_BP",
}
LCS_STATE = {
    [1095978819] = "LCS_SOC_MANUFACTURING",
    [1095714125] = "LCS_OEM",
    [1095323206] = "LCS_INFIELD",
    [1095912769] = "LCS_FA",
    [4294967295] = "LCS_ERROR",
}
OTP_CAUSE = {
    [0] = "SUCCESS",
    [1] = "ADDR_INVALID",
    [2] = "RANGE_ERROR",
    [3] = "LENGTH_NOT_4BYTES_ALIGN",
    [4] = "READ_ERROR",
}
ENCODING_SCHEME = {
    [0] = "UNKNOWN",
    [1] = "ASCII",
    [2] = "UCS2",
    [3] = "UTF8",
}
PLMN_NAME_SOURCE = {
    [0] = "NOT_FOUND",
    [1] = "SIM",
    [2] = "NETWORK",
    [3] = "TS25",
}
OSLK_CAUSE = {
    [0] = "OSL_CHECK_RF_CAL_DATA_FAIL",
    [1] = "OSL_CAL_OK",
    [3] = "OSL_TXRF_OFF_TO_IN_END",
    [4] = "OSL_TXK_CORE_TO",
    [5] = "OSL_PATTERN_DOWNLOAD_TO",
    [6] = "OSL_ABNORMAL_CDM_SETTING",
    [8] = "OSL_ABNORMAL_MIPI_CW_SETTING",
    [19] = "OSL_CPID_FAIL_RATE_CLAT_DISABLE",
    [25] = "OSL_DO_NOT_REQUIRE_OSLK",
    [26] = "OSL_OSLK_TN0_SNR_FAIL",
    [27] = "OSL_OSLK_TN1_SNR_FAIL",
    [28] = "OSL_OSLK_TN2_SNR_FAIL",
    [29] = "OSL_OSLK_TN3_SNR_FAIL",
}
ADVANCED_CELL_TYPE = {
    [0] = "2G",
    [1] = "3G_FDD",
    [2] = "3G_TDD",
    [3] = "4G_FDD",
    [4] = "4G_TDD",
    [5] = "5G_FDD",
    [6] = "5G_TDD",
    [7] = "5G_U_FDD",
    [8] = "5G_U_TDD",
    [255] = "NONE",
}
ACCESS_STRATUM_STATE = {
    [0] = "NORMAL_SERVICE",
    [1] = "LIMITED_SERVICE",
    [2] = "NO_SERVICE",
    [255] = "UNKNOWN_STATE",
}
PLMN_LOSS_REASON = {
    [0] = "OUT_OF_SERVICE",
    [1] = "INTER_RAT_REDIRECT_FAIL",
    [2] = "GEMINI_LIMIT",
    [255] = "UNKNOWN",
}
CMD_TYPE_ENUM = {
    [1] = "SET_PRIORITY",
    [2] = "DELETE_PRIORITY",
}
STK_PROACTIVE_CMD_TYPE = {
    [0] = "UNKNOWN",
    [1] = "REFRESH",
    [2] = "MORE_TIME",
    [3] = "POLL_INTERVAL",
    [4] = "POLLING_OFF",
    [5] = "SETUP_EVENT_LIST",
    [16] = "SETUP_CALL",
    [17] = "SEND_SS",
    [18] = "SEND_USSD",
    [19] = "SEND_SMS",
    [20] = "DTMF",
    [21] = "LAUNCH_BROWSER",
    [32] = "PLAY_TONE",
    [33] = "DSPL_TXT",
    [34] = "GET_INKEY",
    [35] = "GET_INPUT",
    [36] = "SELECT_ITEM",
    [37] = "SETUP_MENU",
    [38] = "PROVIDE_LOCAL_INFO",
    [39] = "TIMER_MANAGER",
    [40] = "IDLE_MODEL_TXT",
    [48] = "PERFORM_CARD_APDU",
    [49] = "POWER_ON_CARD",
    [50] = "POWER_OFF_CARD",
    [51] = "GET_READER_STATUS",
    [52] = "RUN_AT",
    [53] = "LANGUAGE_NOTIFY",
    [64] = "OPEN_CHAN",
    [65] = "CLOSE_CHAN",
    [66] = "RECEIVE_DATA",
    [67] = "SEND_DATA",
    [68] = "GET_CHAN_STATUS",
    [96] = "RFU",
    [112] = "ACTIVATE",
    [113] = "CONTACTLESS_STATE_CHANGED",
    [129] = "END_PROACTIVE_SESSION",
    [255] = "DETAIL",
}
STK_TR_GENERAL_RESULT = {
    [0] = "COMMAND_PERFORMED_SUCCESSFULLY",
    [1] = "COMMAND_PERFORMED_WITH_PARTIAL_COMPREHENSION",
    [2] = "COMMAND_PERFORMED_WITH_MISSING_INFORMATION",
    [3] = "REFRESH_PERFORMED_WITH_ADDITIONAL_EFS_READ",
    [4] = "COMMAND_PERFORMED_SUCC_BUT_ICON_NOT_BE_DISPLAYED",
    [5] = "COMMAND_PERFORMED_BUT_MODIFIED_BY_CC_BY_NAA",
    [6] = "COMMAND_PERFORMED_SUCCESSFULLY_LIMITED_SERVICE",
    [7] = "COMMAND_PERFORMED_WITH_MODIFICATION",
    [8] = "REFRESH_PERFORMED_BUT_INDICATED_NAA_WAS_NOT_ACTIVE",
    [9] = "COMMAND_PERFORMED_SUCCESSFULLY_TONE_NOT_PLAYED",
    [16] = "PROACTIVE_UICC_SESSION_TERMINATED_BY_THE_USER",
    [17] = "BACKWARD_MOVE",
    [18] = "NO_RESPONSE_FROM_USER",
    [19] = "HELP_INFORMATION_REQUIRED_BY_THE_USER",
    [20] = "USSD_OR_SS_TRANSACTION_TERMINATED_BY_THE_USER",
    [32] = "ME_CURRENTLY_UNABLE_TO_PROCESS_COMMAND",
    [33] = "NETWORK_CURRENTLY_UNABLE_TO_PROCESS_COMMAND",
    [34] = "USER_DID_NOT_ACCEPT_THE_PROACTIVE_COMMAND",
    [35] = "USER_CLEARED_DOWN_CALL_BF_RELEASE",
    [36] = "ACTION_IN_CONTRADICTION_WITH_THE_CURRENT_TIMER_STATE",
    [37] = "INTERACTION_WITH_CC_BY_NAA_TEMPORARY_PROBLEM",
    [38] = "LAUNCH_BROWSER_GENERIC_ERROR",
    [39] = "MMS_TEMPORARY_PROBLEM",
    [48] = "COMMAND_BEYOND_TERMINAL_CAPABILITIES",
    [49] = "COMMAND_TYPE_NOT_UNDERSTOOD_BY_TERMINAL",
    [50] = "COMMAND_DATA_NOT_UNDERSTOOD_BY_TERMINAL",
    [51] = "COMMAND_NUMBER_NOT_KNOWN_BY_TERMINAL",
    [52] = "SS_RETURN_ERROR",
    [53] = "SMS_RP_ERROR",
    [54] = "ERROR_REQUIRED_VALUES_ARE_MISSING",
    [55] = "USSD_RETURN_ERROR",
    [56] = "MULTIPLECARD_COMMANDS_ERROR",
    [57] = "INTERACTION_WITH_CC_BY_USIM_PERM_PROBLEM",
    [58] = "BEARER_INDEPENDENT_PROTOCOL_ERROR",
    [59] = "ACCESS_TECHNOLOGY_UNABLE_TO_PROCESS_COMMAND",
    [60] = "FRAMES_ERROR",
    [61] = "MMS_ERROR",
}
STK_TR_ME_UNABLE_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
    [1] = "SCREEN_IS_BUSY",
    [2] = "ME_CURRENTLY_BUSY_ON_CALL",
    [3] = "ME_CURRENTLY_BUSY_ON_SS_TRANSACTION",
    [4] = "NO_SERVICE",
    [5] = "ACCESS_CONTROL_CLASS_BAR",
    [6] = "RADIO_RESOURCE_NOT_GRANTED",
    [7] = "NOT_IN_SPEECH_CALL",
    [8] = "ME_CURRENTLY_BUSY_ON_USSD_TRANSACTION",
    [9] = "ME_CURRENTLY_BUSY_ON_SEND_DTMF_COMMAND",
    [10] = "NO_NAA_ACTIVE",
}
STK_TR_NW_UNABLE_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
}
STK_TR_LAUCNCH_BROAWSER_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
    [1] = "BEARER_UNAVAILABLE",
    [2] = "BROWSER_UNAVAILABLE",
    [3] = "TERMINAL_UNABLE_TO_READ_THE_PROVISIONING_DATA",
    [4] = "DEFAULT_URL_UNAVAILABLE",
}
STK_TR_MULTIPLE_CARD_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
    [1] = "CARD_READER_REMOVED_OR_NOT_PRESENT",
    [2] = "CARD_REMOVED_OR_NOT_PRESENT",
    [3] = "CARD_READER_BUSY",
    [4] = "CARD_POWERED_OFF",
    [5] = "C_APDU_FORMAT_ERROR",
    [6] = "MUTE_CARD",
    [7] = "TRANSMISSION_ERROR",
    [8] = "PROTOCOL_NOT_SUPPORTED",
    [9] = "SPECIFIED_READER_NOT_VALID",
}
STK_TR_CC_MO_SMS_CTRL_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
    [1] = "ACTION_NOT_ALLOWED",
    [2] = "THE_TYPE_OF_REQUEST_HAS_CHANGED",
}
STK_TR_BEARER_INDEP_PROT_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
    [1] = "NO_CHANNEL_AVAILABLE",
    [2] = "CHANNEL_CLOSED",
    [3] = "CHANNEL_IDENTIFIER_NOT_VALID",
    [4] = "REQUESTED_BUFFER_SIZE_NOT_AVAILABLE",
    [5] = "SECURITY_ERROR",
    [6] = "REQUESTED_UICC_TERMINAL_INTERFACE_TRANSPORT_LEVEL_NOT_AVAILABLE",
    [7] = "REMOTE_DEVICE_IS_NOT_REACHABLE",
    [8] = "SERVICE_ERROR",
    [9] = "SERVICE_IDENTIFIER_UNKNOWN",
    [16] = "PORT_NOT_AVAILABLE",
    [17] = "LAUNCH_PARAMETERS_MISSING_OR_INCORRECT",
    [18] = "APPLICATION_LAUNCH_FAILED",
}
STK_TR_FRAMES_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
    [1] = "FRAME_IDENTIFIER_IS_NOT_VALID",
    [2] = "NUMBER_OF_FRAMES_BEYOND_THE_TERMINAL_CAPABILITIES",
    [3] = "NO_FRAME_DEFINED",
    [4] = "REQUESTED_SIZE_NOT_SUPPORTED",
    [5] = "DEFAULT_ACTIVE_FRAME_IS_NOT_VALID",
}
STK_TR_MMS_ADDI_INFO = {
    [0] = "NO_SPECIFIC_CAUSE_CAN_BE_GIVEN",
}
STK_ENVLP_CMD_TYPE = {
    [0] = "STK_ENVLP_TYPE_MENU_SELECTION",
    [1] = "STK_ENVLP_TYPE_CALL_CONTROL",
    [2] = "STK_ENVLP_TYPE_MO_SMS_CONTROL",
    [3] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_MT_CALL",
    [4] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_CALL_CONNECTED",
    [5] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_CALL_DISCONNECTED",
    [6] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_LOCATION_STATUS",
    [7] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_USER_ACTIVITY",
    [8] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_IDLE_SCREEN_AVAILABLE",
    [9] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_LANGUAGE_SELECTION",
    [10] = "STK_ENVLP_TYPE_EVENT_DOWNLOAD_IMS_REGISTRATION",
    [11] = "STK_ENVLP_TYPE_SMS_PP_DATA_DOWNLOAD",
    [255] = "STK_ENVLP_TYPE_INVALID",
}
STK_CALL_CONTROL_PARA_TYPE = {
    [0] = "CALL_CONTROL_TYPE_ADDRESS",
    [1] = "CALL_CONTROL_TYPE_SS_STRING",
    [2] = "CALL_CONTROL_TYPE_USSD_STRING",
}
STK_CALL_CONTROL_RESULT = {
    [0] = "CALL_CONTROL_RESULT_ALLOWED",
    [1] = "CALL_CONTROL_RESULT_NOT_ALLOWED",
    [2] = "CALL_CONTROL_RESULT_ALLOWED_MODIFIED",
    [254] = "CALL_CONTROL_RESULT_TOOLKIT_BUSY",
    [255] = "CALL_CONTROL_RESULT_SIM_ERROR",
}
STK_BC_REPEAT_INDICATOR = {
    [0] = "BC_REPEAT_INDICATOR_NO_REPEAT_INDICATOR",
    [2] = "BC_REPEAT_INDICATOR_CIRCULAR",
    [3] = "BC_REPEAT_INDICATOR_FALLBACK",
    [4] = "BC_REPEAT_INDICATOR_SCUD_IF",
}
NW_CTRL_BAND = {
    [1] = "FR1",
}
NW_SERVICE_SCAN_CAUSE = {
    [0] = "UNKNOWN",
    [1] = "NO_SERVICE",
}
UE_NW_CAPABILITY = {
    [1] = "N1_MODE",
    [2] = "S1_MODE",
}
NW_CONN_STATUS = {
    [0] = "NO_FAILURE",
    [1] = "FAILURE",
}
NW_CONN_FAIL_REASON = {
    [0] = "NO_FAILURE",
    [1] = "ACCESS_DENIED",
    [2] = "NAS_FAILURE",
    [3] = "RACH_FAILURE",
    [4] = "RLC_FAILURE",
    [5] = "RRC_REJECT",
    [6] = "RRC_TIMEOUT",
    [7] = "NO_SERVICE",
    [8] = "RF_BUSY",
    [65535] = "OTHERS",
}
RRC_REJECT_TYPE = {
    [0] = "REJECT_INVALID",
    [1] = "CONNECTION_REJECT",
    [2] = "REESTABLISHMENT_REJECT",
    [3] = "RESUME_REJECT",
}
RRC_TIMEOUT_TYPE = {
    [0] = "TIMER_INVALID",
    [1] = "TIMER_T300",
    [2] = "TIMER_T301",
    [3] = "TIMER_T319",
    [4] = "TIMER_T319A",
}
NTN_EARFCN_OFFSET_VALUE = {
    [1] = "MINUS_TEN",
    [2] = "MINUS_NINE",
    [3] = "MINUS_EIGHT",
    [4] = "MINUS_SEVEN",
    [5] = "MINUS_SIX",
    [6] = "MINUS_FIVE",
    [7] = "MINUS_FOUR",
    [8] = "MINUS_THREE",
    [9] = "MINUS_TWO",
    [10] = "MINUS_ONE",
    [11] = "MINUS_POINT_FIVE",
    [12] = "ZERO",
    [13] = "ONE",
    [14] = "TWO",
    [15] = "THREE",
    [16] = "FOUR",
    [17] = "FIVE",
    [18] = "SIX",
    [19] = "SEVEN",
    [20] = "EIGHT",
    [21] = "NINE",
}
NTN_FREQUENCY_LOCK_STATE = {
    [0] = "DEACTIVATE",
    [1] = "ACTIVATE",
}
NTN_SIGNAL_REPORT_MODE = {
    [0] = "NW_CONFIG_MODE",
    [1] = "ENHANCE_MODE",
}
NTN_SATELLITE_TYPE = {
    [0] = "GEO",
    [1] = "MEO",
    [2] = "LEO",
}
NTN_PREFER_CELL_SELECT_ORDER = {
    [1] = "SIGNAL_STRENGTH",
    [2] = "PRIORITY",
}
NTN_SEND_DATAGRAM_CAUSE = {
    [0] = "DISCARD_BY_UNKNOWN_REASON",
    [1] = "DISCARD_BY_RLF",
    [2] = "DISCARD_BY_RLC_MAX_RETRY",
    [3] = "DISCARD_BY_LOCAL_RELEASE",
    [5] = "DISCARD_BY_INVALID_RLC_ENTITY",
    [6] = "DISCARD_BY_SRB_RESET",
    [10] = "DISCARD_BY_RRC_EST_FAIL",
    [11] = "DISCARD_BY_CAMP_LOST",
    [12] = "DISCARD_BY_TEMP_NOT_CAMPED",
    [13] = "DISCARD_BY_GNSS_ENQUIRE_FAIL",
    [14] = "DISCARD_BY_NORMAL_RRC_RELEASE",
    [20] = "DISCARD_BY_MM_REQUEST_ABORT",
    [21] = "DISCARD_BY_MM_NO_CONTEXT",
    [22] = "DISCARD_BY_MM_COLLISION",
    [23] = "DISCARD_BY_MM_INVALID_STATE",
    [24] = "DISCARD_BY_MM_CONGESTION",
    [25] = "DISCARD_BY_MM_SERVICE_TIMEOUT",
    [26] = "DISCARD_BY_MM_SERVICE_REJECT",
    [27] = "DISCARD_BY_MM_TAU_FAILURE",
    [28] = "DISCARD_BY_MM_RRC_FAIL",
    [29] = "DISCARD_BY_MM_NO_SERVICE",
    [40] = "DISCARD_BY_SM_INVALID_STATE",
    [41] = "DISCARD_BY_SM_EST_REJ",
    [50] = "DISCARD_BY_LOCAL_DRO",
    [51] = "DISCARD_BY_INVALID_DATA",
    [52] = "DISCARD_BY_ROUTING_FAIL",
    [53] = "DISCARD_BY_RESTRICTION",
    [54] = "DISCARD_BY_BEARER_DEACT",
    [55] = "DISCARD_BY_TFT_NOT_MATCH",
    [60] = "DISCARD_BY_INVALID_CID",
    [70] = "DISCARD_BY_BUFFER_FULL",
}
NW_RAT = {
    [0] = "NONE",
    [4] = "LTE",
    [5] = "NR",
    [6] = "IOTNTN",
}
NTN_ENABLE_SATELLITE_OPTION = {
    [0] = "DISABLE_OTHER_SIM_RADIO",
    [1] = "NONE",
}
PCIE_SET_OPTIONS = {
    [0] = "PROFILE_TIME",
    [1] = "DEBUG_PROFILE_TIME",
    [2] = "MTCMOS_OFF",
    [3] = "LOOPBACK_TEST",
    [4] = "SPEED_CHANGE_ENABLE",
    [5] = "SPEED_CHANGE_MODE_SET",
    [6] = "SPEED_CHANGE_REQ",
    [7] = "SET_REMOTE_TIMER",
}
PCIE_GET_OPTIONS = {
    [0] = "PROFILE_TIME",
    [1] = "RATE",
}
PCIE_SPEED_CHANGE_USER = {
    [0] = "DPMAIF",
    [1] = "CLDMA_0",
    [2] = "CLDMA_1",
    [3] = "CLDMA_4",
}
SCS_ENUM = {
    [15] = "15",
    [30] = "30",
}
SMTC_PERIOD_ENUM = {
    [20] = "20",
    [40] = "40",
    [80] = "80",
    [160] = "160",
}
SFTD_RESULT_TYPE = {
    [0] = "SUCCESS",
    [1] = "NOT_SUPPORTED_CAPABILITY_FAILURE",
    [2] = "INVALID_PARAMETER_FAILURE",
    [3] = "WRONG_RRC_STATE_FAILURE",
    [4] = "CONTROL_MEASUREMENT_FAILURE",
    [5] = "PROCEDURE_CHECK_FAILURE",
    [6] = "NR_CELL_NOT_FOUND_FAILURE",
}
MAX_AT_URC_LEN = 128
MAX_AT_CMD_LEN = 128
MAX_AT_CMD_RSP_LEN = 1024
MAX_AT_GENERAL_LEN = 2048
MAX_REG_UNREG_NUM_IN_ONE_MIPC_REQ = 256
MAX_APN_LEN = 100
MAX_DEL_SPI_NUM = 50
MAX_IP_ADDR_LEN = 16
MAX_APN_BEARER_LEN = 10
MAX_APN_LIST_NUM = 10
MAX_CID_LIST_LEN = 200
MAX_RULE_LIST_LEN = 8
MAX_USERID_LEN = 64
MAX_PASSWORD_LEN = 64
MAX_PROFILE_LIST_COUNT = 20
MAX_MD_PROFILE_LIST_COUNT = 30
MAX_PACKET_FILTER_LIST_COUNT = 10
MAX_EIWLAN_CMD_LEN = 8
MAX_EIWLAN_TYPE_LEN = 16
MAX_EIWLAN_DESCRIPTION_LEN = 32
FIX_CALL_BARRING_PASSWORD_LEN = 5
MAX_OPER_LEN = 16
MAX_USSD_LEN = 160
MAX_USSD_LEN_EX = 10000
MAX_PAC_IND_LEN = 512
MAX_TERMINAL_RESPONSE_LEN = 261
MAX_AID_LEN = 256
MAX_ENVELOP_LEN = 261
MAX_BIP_LEN = 32
MAX_S_NSSAI_NUM = 64
MAX_CLIENT_NAME_LEN = 160
SIM_FIX_ICCID_LEN = 21
SIM_FIX_ICCID_STR_LEN = 21
MAX_IMSI_LEN = 20
MAX_ATR_LEN = 80
MAX_ATR_STR_LEN = 81
MAX_DEVICEID_LEN = 16
MAX_PRI_IMEI_SVN_LEN = 9
MAX_MANUFACTURER_LEN = 32
MAX_FIRMWARE_INFO_LEN = 64
MAX_HARDWAREWARE_INFO_LEN = 30
FIX_ESN_LEN = 8
FIX_IMEISV_LEN = 2
FIX_MEID_LEN = 14
FIX_HARDWARE_ID_LEN = 16
MAX_DUMP_LIDS_LEN = 1024
MAX_MCF_VALUE_LEN = 512
MAX_MCF_CFG_LEN = 1024
MAX_MSPM_PROCEDURE_STR_LEN = 50
MAX_NETWORK_NAME_LEN = 60
MAX_ROAMING_TEXT_LEN = 64
FIX_GSM_AUTH_RAND_LEN = 16
FIX_GSM_AUTH_RSP_KC_LEN = 8
FIX_GSM_AUTH_RSP_SRES_LEN = 4
MAX_EXT_AUTH_CMD_DATA_LEN = 256
MAX_EXT_AUTH_RSP_DATA_LEN = 256
MAX_TERMINAL_CAPABILITY_DATA_LEN = 256
MAX_SIM_APP_LABEL_LEN = 32
MAX_SIM_AID_BYTE_LEN = 20
MAX_SIM_AID_STR_LEN = 40
MAX_SMS_PDU_LEN = 256
MAX_CBM_PDU_LEN = 1246
MAX_SMS_SCA_LEN = 22
FIX_SMS_ETWS_SECUR_INFO_LEN = 50
MAX_SMS_NUM_LEN = 32
MAX_SMS_CBM_MSGID_RANGE_NUM = 30
MAX_SMS_CBM_MSGID_SINGLE_NUM = 60
MAX_SMS_CBM_DCS_RANGE_NUM = 30
MAX_SMS_CBM_DCS_SINGLE_NUM = 60
MAX_SMS_CBM_LANGUAGE_SINGLE_NUM = 60
MAX_SMS_EPSI_LEN = 256
MAX_SMS_SEG_NUM = 15
MAX_SMS_DUP_PDU_LEN = 256
MAX_SMS_NUM = 1024
MAX_SMS_CBM_RANGE_NUM = 30
MAX_SMS_CBM_SINGLE_NUM = 60
MAX_WFC_IFNAME_LEN = 128
MAX_WFC_THRESHOLD_NUM = 16
MAX_WFC_IP_LEN = 16
FIX_WFC_EMC_AID_LEN = 20
MAX_WFC_SSID_LEN = 33
FIX_WFC_MAC_LEN = 6
FIX_WFC_IPV4_LEN = 4
FIX_WFC_IPV6_LEN = 16
MAX_WFC_DNS_NUM = 10
MAX_WFC_WIFI_TYPE_LEN = 32
MAX_SS_DIAL_NUMBER_LEN = 182
MAX_SS_DIAL_NUMBER_FOR_ALIGN_LEN = 183
MAX_SS_DIAL_COUNT = 10
MAX_DIAL_ADDRESS_LEN = 180
MAX_CALL_NUMBER_LEN = 128
MAX_SS_RAW_STRING_LEN = 512
VOLTE_MAX_TLS_ID_LENGTH = 256
VOLTE_MAX_DC_CONFIG_NUM = 6
VOLTE_MAX_DC_DCMAP_NUM = 60
VOLTE_MAX_DCMAP_LABEL_LENGTH = 80
VOLTE_MAX_DCMAP_NUM_PER_CONFIG = 10
VOLTE_MAX_BDC_CONFIG_NUM = 2
VOLTE_MAX_BDC_DCMAP_NUM = 20
VOLTE_IPADDR_LENGTH = 16
VOLTE_MAX_IF_NAME_LENGTH = 16
VOLTE_MAX_FINGERPRINT_LENGTH = 192
VOLTE_MAX_QOS_HINT_LENGTH = 64
VOLTE_MAX_DCMAP_SUBPROTOCOL_LENGTH = 10
MAX_CALL_PAU_LEN = 512
MAX_CALL_ECC_NUMBER_LEN = 10
MAX_CALL_ECC_SUB_SERVICE_LEN = 128
MAX_CALL_CONFERENCE_PARTICIPANT_NUM = 40
MAX_CALL_NAME_LEN = 80
MAX_CALL_EIMSEVTPKG_URI_LEN = 180
MAX_CALL_DISPLAY_NAME_LEN = 64
MAX_CALL_VERSTAT_LEN = 64
MAX_CALL_PRIVACY_LEN = 64
MAX_CALL_SS_SUBADDR_LEN = 64
MAX_CALL_IF_NAME_LEN = 16
MAX_CALL_IP_ADDRESS_LEN = 16
MAX_CALL_MODE_SET_LEN = 16
MAX_CALL_RTP_SESSION_RED_CODEC_LIST = 3
MAX_CALL_CNAME_LEN = 52
MAX_CALL_EVS_CONF_LEN = 2
MAX_SIM_PATH_BYTE_LEN = 12
MAX_SIM_PATH_BYTE_ARRAY_LEN = 10
MAX_SIM_PATH_STR_LEN = 24
MAX_SIM_APDU_BYTE_LEN = 261
MAX_SIM_APDU_STRING_LEN = 522
MAX_SIM_LONG_BIN_DATA_LEN = 65535
MAX_SIM_PIN_CODE_LEN = 16
MAX_SIM_PUK_CODE_LEN = 16
MAX_SIM_CMD_DATA_STR_LEN = 510
MAX_SIM_RSP_DATA_STR_LEN = 510
MAX_SIM_CMD_DATA_BYTE_LEN = 255
MAX_SIM_CMD_EXTENDED_DATA_BYTE_LEN = 65535
MAX_SIM_RSP_DATA_BYTE_LEN = 255
MAX_SIM_NUM = 2
MAX_PHY_SLOT_NUM = 4
MAX_SIM_EID_LEN = 32
MAX_SIM_EID_STR_LEN = 33
FIX_SIM_EID_BYTE_LEN = 16
MAX_SIM_FACILITY_LEN = 3
MAX_SIM_MSISDN_LEN = 81
MAX_MSISDN_NUM = 10
MAX_SIM_SML_HCK_STR_LEN = 128
MAX_CALL_FINISH_REASON_LEN = 128
MAX_DTMF_DIGIT_LEN = 128
MAX_RECV_DTMF_DIGIT_LEN = 2
MAX_CALL_ECC_LIST_RECORD_NUM = 128
MAX_CALL_SIP_HEADER_VALUE_PAIR_LEN = 232
MAX_CALL_SIP_HEADER_VALUE_LEN = 1950
MAX_CALL_ADDITIONAL_INFO_LEN = 1950
MAX_CALL_MT_SIP_INVITE_LEN = 1950
MAX_CALL_RCS_DIGITS_LINE_LEN = 128
MAX_CALL_RTT_TEXT_LEN = 1024
MAX_CALL_PULL_URI_LEN = 128
MAX_CALL_DISPLAY_AND_SIGNALS_INFO_DISPLAY_LEN = 64
MAX_CALL_RTP_SESSION_CODEC_NUM = 8
MAX_CALL_RTP_SESSION_TIMER_NUM = 16
MAX_CALL_RTP_LOSS_RATE_NUM = 4
MAX_CALL_RTP_JITTER_THRESHOLD_NUM = 4
MAX_CALL_EXTENDED_DISPLAY_INFO_LEN = 64
MAX_ECALL_MSD_DATA_LEN = 140
MAX_SIP_REASON_TEXT_LEN = 120
IMS_MAX_URI_LEN = 256
IMS_MAX_ERROR_MESSAGE_LEN = 256
MAX_IMS_EVENT_PACKAGE_DATA_LEN = 64000
MAX_DATA_CHANNEL_XML_DATA_LEN = 64000
MAX_CALL_NUM = 7
MAX_PCO_COUNT = 16
MAX_MBS_SESSION_INFO_NUM = 16
MAX_MBS_SERVICE_AREA_NUM = 16
MAX_SBP_STR_LEN = 256
MAX_PLMN_ID_LEN = 7
MAX_BAND_COMBO_LEN = 16
OMADM_VALUE_LEN = 64
MAX_SYS_THERMAL_ACTUATOR_NAME = 40
MAX_ALPHAID_LEN = 128
MAX_SUB_ADDRESS_LEN = 128
MAX_CHANGE_BARRING_PWD_LEN = 9
MAX_SYS_STR_LEN = 256
MAX_LCE_THRESHOLD_NUMBER = 60
MAX_TIME_LEN = 16
MAX_SET_LOCATION_LEN = 128
MAX_DATA_SNSSAI_LEN = 16
MAX_SPN_LEN = 71
MAX_GID1_NUM = 41
MAX_IMPI_LEN = 149
MAX_SS_ECMCCSS_RAW_LEN = 256
MAX_XCAP_USER_AGENT_STR_LEN = 128
MAX_SS_XUI_INFO_LEN = 512
MAX_SS_COMM_INFO_LEN = 128
MAX_SS_USSD_LANG_LEN = 32
MAX_IMS_STRING_INFO_LEN = 128
MAX_GRP_ID_NUM = 10
MAX_CHANNEL_LOCK_NUM = 32
MAX_SYS_THERMAL_SENSOR_NUM = 8
MAX_SYS_THERMAL_ACTUATOR_NUM = 32
MAX_SYS_THERMAL_TRIP_POINT_NUM_IN_ONE_SENSOR = 16
MAX_SYS_THERMAL_SENSOR_ALARM_SETTING_NUM = 4
MAX_PHYSICAL_CHANNEL_CONFIGS_NUM = 15
MAX_CELL_ID_LEN = 32
MAX_NWSCN_RECORD_NUM = 8
MAX_NWSCN_PLMN_NUM = 20
MAX_NWSCN_RESULT_NUM = 20
MAX_MCCMNC_LEN = 4
MAX_PLMN_CAG_INFO_NUM = 1920
UE_OS_ID_LEN = 16
MAX_UE_OS_ID_NUM = 15
MAX_CELL_INFO_NUM = 33
MAX_UMTS_SERVICE_NUM = 4
MAX_BAND_COMBO_NUM = 600
MAX_TUW_NUM = 3
MAX_SIM_APP_NUM = 20
MAX_SIM_MSISDN_NUM = 7
FIXED_SIM_SML_CATEGORY_CAT_SIZE = 7
MAX_FILTER_LIST_NUM = 16
MAX_PCO_LIST_NUM = 20
MAX_IPV4_NUM = 4
MAX_IPV6_NUM = 4
MAX_DNS_IP_NUM = 10
MAX_PCSCF_IP_NUM = 16
MAX_DMF_RAWDATA_LEN = 2048
MAX_DMF_DATA_NUM = 10
MAX_SYS_DMF_INFO_LEN = 16384
MAX_EDRX_ACT_NUM = 6
MAX_LTE_CC_MEAS_INFO_NUM = 5
MAX_NR_CC_MEAS_INFO_NUM = 8
MAX_RAN_CELL_SIZE = 8
MAX_RAN_RESULT_NUM = 10
MAX_PLMN_NUM = 12
MAX_MCIF_LEN = 3072
MAX_RAW_SIGNAL_NUM = 2
MAX_SERVING_CELL_NUM = 32
MAX_PACKET_FILTER_NUM = 16
MAX_IA_LIST_NUM = 3
MAX_EMSLU_SESSION_NUM = 435
MAX_SAI_LIST_NUM = 16
MAX_UINT8_VALUE = 0xFF
MAX_UINT16_VALUE = 0xFFFF
MAX_UINT32_VALUE = 0xFFFFFFFF
MAX_MSISDN_COUNT = 7
MAX_SIM_CARRIER_NUM = 25
MAX_SID_NID_NUM = 20
MAX_SIM_FILE_NUM = 10
MAX_CALL_WAITING_NUM = 7
MAX_CALL_FORWARD_NUM = 10
MAX_SWITCH_SIM_MAPPING_NUM = 16
MAX_CAG_INFO_LEN = 67
MAX_CID_NUM = 50
MAX_MBS_SERVICE_SESSION_INFO_LENGTH = 128
MAX_MBS_CELL_NUM = 128
MAX_TSN_PMIC_LEN = 8192
MAX_BC_SRC_LEN = 35
MAX_BC_LIST_COUNT = 1000
MAX_I2C_DATA_LEN = 256
MAX_IDC_FRAME_CFG_PERIOD_NUM = 40
MAX_IDC_SCAN_FREQ_NUM = 32
MAX_SIM_PSISMSC_LEN = 256
MAX_SIM_RECORD_LEN = 20
MAX_SIM_SMSP_LEN = 64
MAX_SIM_SERVICE_TABLE_RESP_LEN = 256
MAX_SIM_GID_RESP_LEN = 20
MAX_SIM_IMPI_RESP_LEN = 256
MAX_SIM_IMPU_RESP_LEN = 256
MAX_SIM_DOMAIN_RESP_LEN = 256
MAX_SIM_PCSCF_RESP_LEN = 256
NW_FTAI_LIST_MAX_SIZE = 40
MAX_READ_COEX_UART_LEN = 128
MAX_WRITE_COEX_UART_LEN = 8
MAX_PEWAKE_REASON_LEN = 64
MAX_MAL_IT_TESTING_STRING = 256
MAX_BAND_POWER_SIZE = 10
MAX_NVRAM_DATA_LEN = 64000
MAX_TRACK_INUSE_NUM = 256
MAX_CONGESTION_CFG_SIZE = 12
MAX_SRVCC_CALL_CONTEXT_STRUCT_ARRAY_SIZE = 7
MAX_CALL_NUMBER = 81
MAX_CONF_CALL_NUMBER_STRING_LENGTH = 128
MAX_CONF_CALL_NUMBER_ARRAY_SIZE = 5
MAX_PLMN_NAME_LEN = 512
FIX_DOUBLE_SIZE = 8
FIX_FLOAT_SIZE = 4
FIX_LONG_LONG_SIZE = 8
MAX_GNSS_DATA_LEN = 5120
MAX_GNSS_BIG_DATA_LEN = 32000
MAX_PMTK_LEN = 512
MAX_LOCATION_EM_DATA_SIZE = 1000
MAX_GNSS_DEBUG_SIZE = 1500
MAX_LBS_CONFIG_RAW_DATA_SIZE = 4300
MAX_LPPE_MSG_DATA_LEN = 4300
MAX_LBS_FRAMEWORK_DATA_LEN = 5120
MAX_AGPS_REQUESTOR_ID_LEN = 512
MAX_AGPS_CLIENT_NAME_LEN = 512
MAX_BAND_PRIORITY_BAND_NUM = 32
MAX_BAND_PRIORITY_PLMN_NUM = 25
MAX_STK_TR_DATA_LEN = 242
FIX_STK_DIALLING_NUMBER_LEN = 40
FIX_STK_USSD_DATA_LEN = 183
FIX_STK_IMPU_LIST_LEN = 242
FIX_STK_IMS_STATUS_CODE_LEN = 5
FIX_STK_SMS_TPDU_LEN = 176
FIX_STK_CAPABILITY_PARAMS_LEN = 16
FIX_STK_SUB_ADDRESS_LEN = 40
FIX_STK_ALPHA_ID_LEN = 32
MAX_STK_SMSPP_UICC_ACK_LEN = 128
FIX_STK_DL_LANG_SEL_LEN = 2
COUNTRY_CODE_ALPHA_2_LEN = 3
MAX_SUPPORT_BAND_LIST_NUM = 40
MAX_BAND_LIST_NUM = 19
MAX_EARFCN_LIST_NUM = 40
MAX_DATA_PACKET_LEN = 2048
MAX_DATA_ID_NUM = 16
MAX_OTP_DATA_SIZE = 1024
