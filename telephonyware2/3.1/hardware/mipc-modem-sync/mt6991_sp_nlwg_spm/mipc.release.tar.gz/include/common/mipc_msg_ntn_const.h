/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  Copyright (c) [2020], MediaTek Inc. All rights reserved.
*  This software/firmware and related documentation ("MediaTek Software") are
*  protected under relevant copyright laws.
*
*  The information contained herein is confidential and proprietary to
*  MediaTek Inc. and/or its licensors. Except as otherwise provided in the
*  applicable licensing terms with MediaTek Inc. and/or its licensors, any
*  reproduction, modification, use or disclosure of MediaTek Software, and
*  information contained herein, in whole or in part, shall be strictly
*  prohibited.
*****************************************************************************/

#ifndef __MIPC_MSG_NTN_CONST_H__
#define __MIPC_MSG_NTN_CONST_H__

enum MIPC_NTN_MSG_enum {
    MIPC_NTN_MSG_NONE = 0,
    /*
      This command sets the current supported band information.
      If TLV BAND_LIST is not present, modem will enable all RF support band.
      MIPC Result:
      - MIPC_RESULT_SUCCESS (0)
      - MIPC_RESULT_OPERATION_NOT_SUPPORTTED (105) : BAND_LIST have no valid IOT-NTN supported band.
    */
    MIPC_NTN_SET_SUPPORT_BAND_REQ                           = 5660,
    MIPC_NTN_SET_SUPPORT_BAND_CNF                           = 5661,


};

    /* MIPC_MSG.NTN_SET_SUPPORT_BAND_REQ */
enum mipc_ntn_set_support_band_req_tlv_enum {
    mipc_ntn_set_support_band_req_tlv_NONE = 0,
    /* The NTN supported operating band list. */
    /* type = uint16_t */
    MIPC_NTN_SET_SUPPORT_BAND_REQ_T_BAND_LIST               = 0x100,
};

    /* MIPC_MSG.NTN_SET_SUPPORT_BAND_CNF */
enum mipc_ntn_set_support_band_cnf_tlv_enum {
    mipc_ntn_set_support_band_cnf_tlv_NONE = 0,
    /* no proprietary TLV */
};




#endif /* __MIPC_MSG_NTN_CONST_H__ */
