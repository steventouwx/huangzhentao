/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  Copyright (c) [2023], MediaTek Inc. All rights reserved.
*  This software/firmware and related documentation ("MediaTek Software") are
*  protected under relevant copyright laws.
*
*  The information contained herein is confidential and proprietary to
*  MediaTek Inc. and/or its licensors. Except as otherwise provided in the
*  applicable licensing terms with MediaTek Inc. and/or its licensors, any
*  reproduction, modification, use or disclosure of MediaTek Software, and
*  information contained herein, in whole or in part, shall be strictly
*  prohibited.
*****************************************************************************/

#ifndef _MIPC_MALLOC_H_
#define _MIPC_MALLOC_H_

#include "kal_public_api.h"
#include "kal_public_defs.h"

void *mtk_malloc(kal_uint32 size);
void mtk_free(void *buff_ptr);

#endif /* _MIPC_MALLOC_H_ */
