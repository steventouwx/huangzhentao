/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  Copyright (c) [2020], MediaTek Inc. All rights reserved.
*  This software/firmware and related documentation ("MediaTek Software") are
*  protected under relevant copyright laws.
*
*  The information contained herein is confidential and proprietary to
*  MediaTek Inc. and/or its licensors. Except as otherwise provided in the
*  applicable licensing terms with MediaTek Inc. and/or its licensors, any
*  reproduction, modification, use or disclosure of MediaTek Software, and
*  information contained herein, in whole or in part, shall be strictly
*  prohibited.
*****************************************************************************/

#ifndef __MIPC_MSG_STK_CONST_H__
#define __MIPC_MSG_STK_CONST_H__

enum MIPC_STK_MSG_enum {
    MIPC_STK_MSG_NONE = 0,
    /* This command is used to set PAC information. */
    MIPC_STK_SET_PAC_REQ                                    = 2049,
    MIPC_STK_SET_PAC_CNF                                    = 2050,

    /* This command is used to acquire proactive command management information indicating whether proactive command will be managed by ME or TE. */
    MIPC_STK_GET_PAC_REQ                                    = 2051,
    MIPC_STK_GET_PAC_CNF                                    = 2052,

    /* This command sends terminal response to UICC. When AP receive MIPC_STK_PAC_IND, AP will send MIPC_STK_SEND_TERMINAL_RESPONSE to MD. */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ                     = 2053,
    MIPC_STK_SEND_TERMINAL_RESPONSE_CNF                     = 2054,

    /* This command is used to send envelope to UICC. */
    MIPC_STK_SEND_ENVELOPE_REQ                              = 2055,
    MIPC_STK_SEND_ENVELOPE_CNF                              = 2056,

    /* This command is used to acquire envelope information. */
    MIPC_STK_GET_ENVELOPE_INFO_REQ                          = 2057,
    MIPC_STK_GET_ENVELOPE_INFO_CNF                          = 2058,

    /* This command is used to set the result of host confirmation for BIP open channel command which includes non-null alpha ID. */
    MIPC_STK_HANDLE_CALL_SETUP_FROM_SIM_REQ                 = 2059,
    MIPC_STK_HANDLE_CALL_SETUP_FROM_SIM_CNF                 = 2060,

    /* This command is used to set the result of host confirmation for BIP open channel command. */
    MIPC_STK_SEND_BIPCONF_REQ                               = 2061,
    MIPC_STK_SEND_BIPCONF_CNF                               = 2062,

    /* This command is used to report proactive command from UICC. */
    MIPC_STK_PAC_IND                                        = 18433,

    /* This command is used to report SIM refresh event. */
    MIPC_STK_SIM_REFRESH_IND                                = 18434,

    /* This command is used to report BIP event. */
    MIPC_STK_BIP_EVENT_NOTIFY_IND                           = 18435,


};

    /* MIPC_MSG.STK_SET_PAC_REQ */
enum mipc_stk_set_pac_req_tlv_enum {
    mipc_stk_set_pac_req_tlv_NONE = 0,
    /* It indicates bitmask; each bit uses PAC to indicate if the host intends to handle/receive a notification for a specific proactive command or not (size is 32 bytes) */
    /* type = byte_array */
    MIPC_STK_SET_PAC_REQ_T_PAC_BITMASK_PTR                  = 0x101,
};

    /* MIPC_MSG.STK_SET_PAC_CNF */
enum mipc_stk_set_pac_cnf_tlv_enum {
    mipc_stk_set_pac_cnf_tlv_NONE = 0,
    /* Each byte identifies the current support for a specific proactive command */
    /* type = byte_array */
    MIPC_STK_SET_PAC_CNF_T_PAC_PROFILE                      = 0x100,
};

    /* MIPC_MSG.STK_GET_PAC_REQ */
enum mipc_stk_get_pac_req_tlv_enum {
    mipc_stk_get_pac_req_tlv_NONE = 0,
    /* no proprietary TLV */
};

    /* MIPC_MSG.STK_GET_PAC_CNF */
enum mipc_stk_get_pac_cnf_tlv_enum {
    mipc_stk_get_pac_cnf_tlv_NONE = 0,
    /* Each byte identifies the current support for a specific proactive command */
    /* type = byte_array */
    MIPC_STK_GET_PAC_CNF_T_PAC_PROFILE                      = 0x100,
};

    /* MIPC_MSG.STK_SEND_TERMINAL_RESPONSE_REQ */
enum mipc_stk_send_terminal_response_req_tlv_enum {
    mipc_stk_send_terminal_response_req_tlv_NONE = 0,
    /* Length of terminal response */
    /* type = uint32_t */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_TR_LEN            = 0x101,
    /* Data of terminal response. If use expanded TLV, please input 0xFF. */
    /* type = byte_array */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_TR_PTR            = 0x102,
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_DATA              = 0x102,
    /* Command Number. Refer to 6.5.1 in ETSI 102 223. */
    /* type = uint8_t */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_CMD_NUM           = 0x103,
    /* Command Type. */
    /* type = uint8_t, refer to STK_PROACTIVE_CMD_TYPE */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_CMD_TYPE          = 0x104,
    /* General Result. */
    /* type = uint8_t, refer to STK_TR_GENERAL_RESULT */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_GENERAL_RESULT    = 0x105,
    /*
      ME unable additional information.
      Only valid when GENERAL_RESULT = ME_CURRENTLY_UNABLE_TO_PROCESS_COMMAND (0x20).
    */
    /* type = uint8_t, refer to STK_TR_ME_UNABLE_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_ME_UNABLE_ADDI_INFO = 0x106,
    /*
      Network unable additional information.
      Only valid when GENERAL_RESULT = NETWORK_CURRENTLY_UNABLE_TO_PROCESS_COMMAND (0x21).
    */
    /* type = uint8_t, refer to STK_TR_NW_UNABLE_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_NW_UNABLE_ADDI_INFO = 0x107,
    /*
      Launch browser additional information.
      Only valid when GENERAL_RESULT = LAUNCH_BROWSER_GENERIC_ERROR (0x26).
    */
    /* type = uint8_t, refer to STK_TR_LAUCNCH_BROAWSER_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_LAUCNCH_BROAWSER_ADDI_INFO = 0x108,
    /*
      MultipleCard additional information.
      Only valid when GENERAL_RESULT = MULTIPLECARD_COMMANDS_ERROR (0x38).
    */
    /* type = uint8_t, refer to STK_TR_MULTIPLE_CARD_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_MULTIPLE_CARD_ADDI_INFO = 0x109,
    /*
      Call control MO SMS control additional information.
      Only valid when GENERAL_RESULT = INTERACTION_WITH_CC_BY_USIM_PERM_PROBLEM (0x39).
    */
    /* type = uint8_t, refer to STK_TR_CC_MO_SMS_CTRL_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_CC_MO_SMS_CTRL_ADDI_INFO = 0x10A,
    /*
      Bearer Independent Protocol additional information.
      Only valid when GENERAL_RESULT = BEARER_INDEPENDENT_PROTOCOL_ERROR (0x3A).
    */
    /* type = uint8_t, refer to STK_TR_BEARER_INDEP_PROT_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_BEARER_INDEP_PROT_ADDI_INFO = 0x10B,
    /*
      Frames additional information.
      Only valid when GENERAL_RESULT = FRAMES_ERROR (0x3C).
    */
    /* type = uint8_t, refer to STK_TR_FRAMES_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_FRAMES_ADDI_INFO  = 0x10C,
    /*
      MMS additional information.
      Only valid when GENERAL_RESULT = MMS_ERROR (0x3D).
    */
    /* type = uint8_t, refer to STK_TR_MMS_ADDI_INFO */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_MMS_ADDI_INFO     = 0x10D,
    /*
      SEND SS additional information.
      Only valid when CMD_TYPE=SEND_SS (11) and GENERAL_RESULT = COMMAND_PERFORMED_SUCCESSFULLY (0x00).
    */
    /* type = byte_array */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_SS_ADDI_INFO      = 0x10E,
    /* Conditional data for future usage. Format is {255 - 5(Command details) - 4(Device identities) - 4(Result & Additional info)}. */
    /* type = byte_array */
    MIPC_STK_SEND_TERMINAL_RESPONSE_REQ_T_CON_DATA          = 0x10F,
};

    /* MIPC_MSG.STK_SEND_TERMINAL_RESPONSE_CNF */
enum mipc_stk_send_terminal_response_cnf_tlv_enum {
    mipc_stk_send_terminal_response_cnf_tlv_NONE = 0,
    /* Status word responded from UICC */
    /* type = uint16_t */
    MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_STATUS_WORDS      = 0x100,
    MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_SW                = 0x100,
    /* Length of terminal response */
    /* type = uint32_t */
    MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_TR_LEN            = 0x101,
    /* Data of terminal response, always return default value 0xFF */
    /* type = byte_array */
    MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_TR_PTR            = 0x102,
    MIPC_STK_SEND_TERMINAL_RESPONSE_CNF_T_DATA              = 0x102,
};

    /* MIPC_MSG.STK_SEND_ENVELOPE_REQ */
enum mipc_stk_send_envelope_req_tlv_enum {
    mipc_stk_send_envelope_req_tlv_NONE = 0,
    /* Length of envelope */
    /* type = uint32_t */
    MIPC_STK_SEND_ENVELOPE_REQ_T_ENVELOPE_LEN               = 0x101,
    /* Data of envelope. If use expanded TLV, please input 0xFF. */
    /* type = byte_array */
    MIPC_STK_SEND_ENVELOPE_REQ_T_ENVELOPE_PTR               = 0x102,
    MIPC_STK_SEND_ENVELOPE_REQ_T_DATA                       = 0x102,
    /*
      Command Type.
      If not bring cmd_type or mapping TLV not bring => MIPC_RESULT_MISSING_ARGUMENT (43)
      If cmd_type not support currently => MIPC_RESULT_CONTEXT_NOT_SUPPORTED (38)
    */
    /* type = uint8_t, refer to STK_ENVLP_CMD_TYPE */
    MIPC_STK_SEND_ENVELOPE_REQ_T_ENVLP_CMD_TYPE             = 0x103,
    /*
      Menu Select.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_MENU_SELECTION.
    */
    /* type = struct, refer to stk_menu_select */
    MIPC_STK_SEND_ENVELOPE_REQ_T_MENU_SEL                   = 0x104,
    /*
      Call Control Voice.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_CALL_CONTROL.
    */
    /* type = struct, refer to stk_call_ctrl_voice */
    MIPC_STK_SEND_ENVELOPE_REQ_T_CALL_CTRL_VOICE            = 0x105,
    /*
      Call Control SMS.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_MO_SMS_CONTROL.
    */
    /* type = struct, refer to stk_call_ctrl_sms */
    MIPC_STK_SEND_ENVELOPE_REQ_T_CALL_CTRL_SMS              = 0x106,
    /*
      Event Download MT Call.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_EVENT_DOWNLOAD_MT_CALL.
    */
    /* type = struct, refer to stk_event_dl_mt_call */
    MIPC_STK_SEND_ENVELOPE_REQ_T_EVENT_DL_MT_CALL           = 0x107,
    /*
      Event Download Call Connected.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_EVENT_DOWNLOAD_CALL_CONNECTED.
    */
    /* type = struct, refer to stk_event_dl_call_con */
    MIPC_STK_SEND_ENVELOPE_REQ_T_EVENT_DL_CALL_CON          = 0x108,
    /*
      Event Download Call Disconnected.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_EVENT_DOWNLOAD_CALL_DISCONNECTED.
    */
    /* type = struct, refer to stk_event_dl_call_discon */
    MIPC_STK_SEND_ENVELOPE_REQ_T_EVENT_DL_CALL_DISCON       = 0x109,
    /*
      Refer to 8.45 in ETSI 102 223.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_EVENT_DOWNLOAD_LANGUAGE_SELECTION.
    */
    /* type = byte_array */
    MIPC_STK_SEND_ENVELOPE_REQ_T_EVENT_DL_LANG_SEL          = 0x10A,
    /*
      IMS Registration Status.
      Refer to 8.111 and 8.112 in ETSI 131.111
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_EVENT_DOWNLOAD_IMS_REGISTRATION.
    */
    /* type = struct, refer to stk_ims_registration_status */
    MIPC_STK_SEND_ENVELOPE_REQ_T_EVENT_DL_IMS_REGI          = 0x10B,
    /*
      SMS PP Data Download.
      Only valid on ENVLP_CMD_TYPE = STK_ENVLP_TYPE_SMS_PP_DATA_DOWNLOAD.
    */
    /* type = struct, refer to stk_sms_pp_data_dl */
    MIPC_STK_SEND_ENVELOPE_REQ_T_SMS_PP_DATA_DL             = 0x10C,
};

    /* MIPC_MSG.STK_SEND_ENVELOPE_CNF */
enum mipc_stk_send_envelope_cnf_tlv_enum {
    mipc_stk_send_envelope_cnf_tlv_NONE = 0,
    /* Status word responded from UICC */
    /* type = uint16_t */
    MIPC_STK_SEND_ENVELOPE_CNF_T_STATUS_WORDS               = 0x100,
    MIPC_STK_SEND_ENVELOPE_CNF_T_SW                         = 0x100,
    /* Hex string of the whole envelope response (BER-TLV) given by UICC */
    /* type = string */
    MIPC_STK_SEND_ENVELOPE_CNF_T_ENVELOPE_RESPONSE          = 0x101,
    /* Command Type. */
    /* type = uint8_t, refer to STK_ENVLP_CMD_TYPE */
    MIPC_STK_SEND_ENVELOPE_CNF_T_ENVLP_CMD_TYPE             = 0x102,
    /* Call Control Response. */
    /* type = struct, refer to stk_call_control_rsp */
    MIPC_STK_SEND_ENVELOPE_CNF_T_CALL_CTRL_RSP              = 0x103,
    /* Call control SMS Response. */
    /* type = struct, refer to stk_call_control_sms_rsp */
    MIPC_STK_SEND_ENVELOPE_CNF_T_CALL_CTRL_SMS_RSP          = 0x104,
    /* Refer to 7.1.1.2 in ETSI 131 111. */
    /* type = byte_array */
    MIPC_STK_SEND_ENVELOPE_CNF_T_SMSPP_UICC_ACK             = 0x105,
};

    /* MIPC_MSG.STK_GET_ENVELOPE_INFO_REQ */
enum mipc_stk_get_envelope_info_req_tlv_enum {
    mipc_stk_get_envelope_info_req_tlv_NONE = 0,
    /* no proprietary TLV */
};

    /* MIPC_MSG.STK_GET_ENVELOPE_INFO_CNF */
enum mipc_stk_get_envelope_info_cnf_tlv_enum {
    mipc_stk_get_envelope_info_cnf_tlv_NONE = 0,
    /* Envelope value with bit format */
    /* type = byte_array */
    MIPC_STK_GET_ENVELOPE_INFO_CNF_T_ENVELOPE_BITMASK       = 0x100,
};

    /* MIPC_MSG.STK_HANDLE_CALL_SETUP_FROM_SIM_REQ */
enum mipc_stk_handle_call_setup_from_sim_req_tlv_enum {
    mipc_stk_handle_call_setup_from_sim_req_tlv_NONE = 0,
    /* Integer (e.g., 0, 1, 32, 33, 35, 50, 80, 81) */
    /* type = uint8_t */
    MIPC_STK_HANDLE_CALL_SETUP_FROM_SIM_REQ_T_DATA          = 0x100,
};

    /* MIPC_MSG.STK_HANDLE_CALL_SETUP_FROM_SIM_CNF */
enum mipc_stk_handle_call_setup_from_sim_cnf_tlv_enum {
    mipc_stk_handle_call_setup_from_sim_cnf_tlv_NONE = 0,
    /* no proprietary TLV */
};

    /* MIPC_MSG.STK_SEND_BIPCONF_REQ */
enum mipc_stk_send_bipconf_req_tlv_enum {
    mipc_stk_send_bipconf_req_tlv_NONE = 0,
    /* The number of the BIP configuration request command */
    /* type = uint32_t */
    MIPC_STK_SEND_BIPCONF_REQ_T_CMD_NUM                     = 0x100,
    /* Send BIP configuration result */
    /* type = uint32_t */
    MIPC_STK_SEND_BIPCONF_REQ_T_RESULT                      = 0x101,
};

    /* MIPC_MSG.STK_SEND_BIPCONF_CNF */
enum mipc_stk_send_bipconf_cnf_tlv_enum {
    mipc_stk_send_bipconf_cnf_tlv_NONE = 0,
    /* no proprietary TLV */
};

    /* MIPC_MSG.STK_PAC_IND */
enum mipc_stk_pac_ind_tlv_enum {
    mipc_stk_pac_ind_tlv_NONE = 0,
    /* Proactive command type from UICC */
    /* type = uint8_t, refer to STK_PAC_TYPE */
    MIPC_STK_PAC_IND_T_PAC_TYPE                             = 0x100,
    /* Length of proactive command */
    /* type = uint16_t */
    MIPC_STK_PAC_IND_T_PAC_LEN                              = 0x101,
    /* Data of proactive command payload */
    /* type = byte_array */
    MIPC_STK_PAC_IND_T_PAC                                  = 0x8102,
};

    /* MIPC_MSG.STK_SIM_REFRESH_IND */
enum mipc_stk_sim_refresh_ind_tlv_enum {
    mipc_stk_sim_refresh_ind_tlv_NONE = 0,
    /* The result of SIM refresh */
    /* type = uint8_t, refer to SIM_REFRESH_RESULT_TYPE */
    MIPC_STK_SIM_REFRESH_IND_T_SIM_REFRESH_RESULT           = 0x100,
    /* EF ID of the updated file */
    /* type = uint32_t */
    MIPC_STK_SIM_REFRESH_IND_T_EF_ID                        = 0x101,
    /* AID of application which causes SIM refresh */
    /* type = string */
    MIPC_STK_SIM_REFRESH_IND_T_AID                          = 0x102,
};

    /* MIPC_MSG.STK_BIP_EVENT_NOTIFY_IND */
enum mipc_stk_bip_event_notify_ind_tlv_enum {
    mipc_stk_bip_event_notify_ind_tlv_NONE = 0,
    /* Data of BIP command */
    /* type = string */
    MIPC_STK_BIP_EVENT_NOTIFY_IND_T_CMD_DATA                = 0x100,
};




#endif /* __MIPC_MSG_STK_CONST_H__ */
