#ifndef _MIPC_CONFIG_TABLE_H_
#define _MIPC_CONFIG_TABLE_H_

#ifdef __MTK_INTERNAL_ENG_USER__
typedef struct {
    kal_uint8 property;
    kal_uint16 data_size;
    module_type mod_id;
    kal_char *config_name;
} mipc_sys_config_table_struct;

#define MIPC_CONFIG_PROPERTY_SET 0x01
#define MIPC_CONFIG_PROPERTY_GET 0x02

static mipc_sys_config_table_struct mipc_sys_config_table[] = {
#if defined __MTK_INTERNAL__
    {.property = 3, .data_size = 1, .mod_id = MOD_L4C, .config_name = "RETENTION_CONTEXT"},
#endif
    {.property = 2, .data_size = 0, .mod_id = MOD_MMRF, .config_name = "MD_RF_CHIP_INFO"},
#if defined __NRRC_MEAS_ENH_CUSTOM__
    {.property = 1, .data_size = 1, .mod_id = MOD_NRRC, .config_name = "CUSTOM_MEAS_ENHANCEMENT"},
#endif
};
#endif /* __MTK_INTERNAL_ENG_USER__ */
#endif /* _MIPC_CONFIG_TABLE_H_ */
